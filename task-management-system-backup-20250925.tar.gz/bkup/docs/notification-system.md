# Notification System

The Task Management System includes a comprehensive email notification system that sends notifications for task assignments, status changes, and overdue reminders. The system supports internationalization with Japanese and English languages.

## Features

- **Task Assignment Notifications**: Sent when a task is assigned to a user
- **Status Update Notifications**: Sent when task status changes (todo → in-progress → completed)
- **Overdue Task Reminders**: Sent for tasks that are past their due date
- **Internationalization**: Supports Japanese (default) and English based on user preferences
- **Graceful Error Handling**: Notifications failures don't break the main application flow

## Configuration

### Environment Variables

Set the following environment variables in your `.env` file:

```bash
# Email Configuration (for notifications)
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=your-email@example.com
SMTP_PASSWORD=your-email-password
```

### Email Templates

The system includes pre-built email templates in both Japanese and English:

- **Task Assignment**: Notifies users when they are assigned a new task
- **Status Update**: Notifies stakeholders when task status changes
- **Overdue Reminder**: Reminds users about overdue tasks

## Usage

### Automatic Notifications

Notifications are automatically sent when:

1. **Creating a task with an assignee** - Assignment notification sent to assignee
2. **Updating task assignee** - Reassignment notifications sent to old and new assignees
3. **Changing task status** - Status update notifications sent to task creator and assignee
4. **Running overdue reminder script** - Overdue reminders sent to users with overdue tasks

### Manual Overdue Reminders

Run the overdue reminder script manually or set it up as a cron job:

```bash
# Send reminders for all overdue tasks
npm run send-overdue-reminders

# Send reminders for tasks overdue by 1+ days
npm run send-overdue-reminders -- --days-overdue 1
```

### Cron Job Setup

To automatically send daily overdue reminders, add this to your crontab:

```bash
# Send overdue reminders daily at 9 AM
0 9 * * * cd /path/to/your/app && npm run send-overdue-reminders
```

## API Integration

The notification system is automatically integrated with the task management API:

### Task Creation
```javascript
POST /api/tasks
{
  "title": "New Task",
  "description": "Task description",
  "assigneeId": "user-uuid",
  "dueDate": "2024-12-31T23:59:59Z"
}
// Automatically sends assignment notification if assigneeId is provided
```

### Task Status Update
```javascript
PATCH /api/tasks/:id/status
{
  "status": "completed"
}
// Automatically sends status update notification to stakeholders
```

### Task Reassignment
```javascript
PUT /api/tasks/:id
{
  "assigneeId": "new-user-uuid"
}
// Automatically sends reassignment notifications
```

## Notification Recipients

### Task Assignment
- **Recipient**: New assignee
- **Condition**: Only if assignee is different from task creator

### Status Update
- **Recipients**: Task creator and current assignee
- **Condition**: Excludes the user who made the status change

### Overdue Reminders
- **Recipients**: Users with assigned overdue tasks
- **Condition**: Tasks with due dates in the past and status "todo"

## Language Support

Notifications are sent in the recipient's preferred language:

- **Japanese (ja)**: Default language with Japanese date formatting (YYYY/MM/DD)
- **English (en)**: English language with US date formatting

### Priority and Status Translations

**Priority Levels:**
- Low: 低 (ja) / Low (en)
- Medium: 中 (ja) / Medium (en)
- High: 高 (ja) / High (en)
- Critical: 緊急 (ja) / Critical (en)

**Status Values:**
- Todo: 未着手 (ja) / To Do (en)
- In Progress: 進行中 (ja) / In Progress (en)
- Completed: 完了 (ja) / Completed (en)

## Testing

The notification system includes comprehensive unit tests:

```bash
# Run all notification tests
npm test -- --testPathPattern=notification

# Run specific test files
npm test -- --testPathPattern=notification-service.test.ts
npm test -- --testPathPattern=notification-helper.test.ts
```

## Error Handling

- **SMTP Errors**: Logged but don't break the main application flow
- **Missing Recipients**: Gracefully handled with warning logs
- **Configuration Issues**: Checked before attempting to send notifications
- **Database Errors**: Caught and logged without affecting task operations

## Monitoring

The system provides logging for:

- Successful notification deliveries
- Failed notification attempts
- Configuration issues
- Overdue reminder statistics

Check your application logs for notification-related messages:

```bash
# Example log messages
Task assignment notification sent to user@example.com
Failed to send task assignment notification: SMTP Error
Sent overdue reminders for 5 tasks to 3 users
```

## Troubleshooting

### Notifications Not Sending

1. **Check SMTP Configuration**: Ensure all required environment variables are set
2. **Verify SMTP Credentials**: Test with your email provider's settings
3. **Check Logs**: Look for error messages in application logs
4. **Test Configuration**: Use the test email function in development

### Missing Notifications

1. **User Language Settings**: Verify user preferred language is set correctly
2. **Task Assignment**: Ensure tasks have valid assignee IDs
3. **Notification Logic**: Check if notification conditions are met (e.g., not self-assignment)

### Performance Issues

1. **Batch Processing**: Overdue reminders are processed in batches
2. **Async Operations**: Notifications are sent asynchronously to avoid blocking
3. **Error Isolation**: Failed notifications don't affect other operations