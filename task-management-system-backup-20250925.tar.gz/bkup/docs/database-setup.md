# Database Setup Guide

This guide explains how to set up PostgreSQL for the Task Management System.

## Prerequisites

1. **PostgreSQL 12+** installed on your system
2. **Node.js 18+** with npm
3. **Environment variables** configured

## Installation

### macOS (using Homebrew)
```bash
# Install PostgreSQL
brew install postgresql@14

# Start PostgreSQL service
brew services start postgresql@14

# Create database
createdb task_management
```

### Ubuntu/Debian
```bash
# Install PostgreSQL
sudo apt update
sudo apt install postgresql postgresql-contrib

# Start PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database
sudo -u postgres createdb task_management
```

### Windows
1. Download PostgreSQL from https://www.postgresql.org/download/windows/
2. Run the installer and follow the setup wizard
3. Use pgAdmin or command line to create database

## Configuration

1. **Copy environment file**:
   ```bash
   cp .env.example .env
   ```

2. **Update database credentials** in `.env`:
   ```env
   DB_HOST=localhost
   DB_PORT=5432
   DB_NAME=task_management
   DB_USER=postgres
   DB_PASSWORD=your_password
   ```

3. **Test connection**:
   ```bash
   npm run migrate:status
   ```

## Database Setup

1. **Run migrations**:
   ```bash
   npm run migrate
   ```

2. **Seed sample data** (optional):
   ```bash
   npm run db:seed
   ```

3. **Verify setup**:
   ```bash
   npm run dev:server
   # Visit http://localhost:3001/api/health
   ```

## Available Commands

| Command | Description |
|---------|-------------|
| `npm run migrate` | Run all pending migrations |
| `npm run migrate:status` | Check migration status |
| `npm run migrate:down` | Rollback last migration |
| `npm run migrate:reset` | Clear, migrate, and seed |
| `npm run db:seed` | Add sample data |
| `npm run db:seed:minimal` | Add minimal test data |
| `npm run db:clear` | Clear all data |

## Troubleshooting

### Connection Refused
- Ensure PostgreSQL is running: `pg_ctl status`
- Check port 5432 is available: `lsof -i :5432`
- Verify credentials in `.env` file

### Permission Denied
- Create PostgreSQL user: `createuser -s your_username`
- Grant database permissions: `GRANT ALL ON DATABASE task_management TO your_username;`

### Migration Errors
- Check PostgreSQL logs for details
- Ensure database user has CREATE privileges
- Verify no conflicting data exists

## Database Schema

The system creates the following tables:

1. **users** - User accounts and authentication
2. **projects** - Project organization
3. **tasks** - Task management with status tracking
4. **project_members** - Project-user relationships

See `migrations/README.md` for detailed schema information.

## Development Workflow

```bash
# Initial setup
npm run migrate
npm run db:seed

# Development
npm run dev

# Testing
npm run db:clear
npm run db:seed:minimal
npm test

# Reset everything
npm run migrate:reset
```

## Production Considerations

- Use connection pooling (already configured)
- Set up database backups
- Use environment-specific credentials
- Monitor connection limits
- Consider read replicas for scaling