# Task Management System - Deployment Guide

This guide covers the complete deployment process for the Task Management System in various environments.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Environment Configuration](#environment-configuration)
3. [Local Development](#local-development)
4. [Production Deployment](#production-deployment)
5. [Docker Deployment](#docker-deployment)
6. [Database Setup](#database-setup)
7. [Monitoring and Maintenance](#monitoring-and-maintenance)
8. [Troubleshooting](#troubleshooting)

## Prerequisites

### System Requirements

- **Node.js**: Version 18.0.0 or higher
- **PostgreSQL**: Version 12 or higher
- **npm**: Version 8.0.0 or higher
- **Git**: For version control

### Optional Requirements

- **Docker**: For containerized deployment
- **Docker Compose**: For multi-container setup
- **PM2**: For process management in production
- **Nginx**: For reverse proxy and SSL termination

## Environment Configuration

### Environment Variables

Create a `.env` file in the project root with the following variables:

```bash
# Server Configuration
NODE_ENV=production
PORT=3001
HOST=0.0.0.0

# Database Configuration
DATABASE_URL=postgresql://username:password@localhost:5432/task_management
DB_HOST=localhost
DB_PORT=5432
DB_NAME=task_management
DB_USER=username
DB_PASSWORD=password

# JWT Configuration
JWT_SECRET=your-super-secure-jwt-secret-key-at-least-32-characters-long
JWT_EXPIRES_IN=24h

# Email Configuration (for notifications)
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=your-email@example.com
SMTP_PASSWORD=your-email-password

# Application Configuration
CLIENT_URL=https://yourdomain.com
DEFAULT_LANGUAGE=ja
```

### Environment-Specific Files

You can create environment-specific configuration files:

- `.env.development` - Development settings
- `.env.staging` - Staging environment settings
- `.env.production` - Production settings
- `.env.test` - Test environment settings

## Local Development

### Quick Start

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd task-management-system
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment**
   ```bash
   cp .env.example .env
   # Edit .env with your local settings
   ```

4. **Set up database**
   ```bash
   # Create database
   createdb task_management
   
   # Run migrations
   npm run migrate
   
   # Seed with sample data (optional)
   npm run db:seed
   ```

5. **Start development server**
   ```bash
   npm run dev
   ```

The application will be available at:
- Frontend: http://localhost:3000
- Backend API: http://localhost:3001

## Production Deployment

### Automated Deployment

Use the provided deployment script for automated deployment:

```bash
# Deploy to production
./scripts/deploy.sh production

# Deploy to staging
./scripts/deploy.sh staging
```

### Manual Deployment

1. **Prepare the server**
   ```bash
   # Update system packages
   sudo apt update && sudo apt upgrade -y
   
   # Install Node.js
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   
   # Install PostgreSQL
   sudo apt-get install -y postgresql postgresql-contrib
   ```

2. **Clone and build**
   ```bash
   git clone <repository-url>
   cd task-management-system
   npm ci --only=production
   npm run build
   ```

3. **Configure environment**
   ```bash
   cp .env.example .env
   # Edit .env with production settings
   ```

4. **Set up database**
   ```bash
   # Create database user and database
   sudo -u postgres createuser --createdb --pwprompt taskmanager
   sudo -u postgres createdb -O taskmanager task_management
   
   # Run migrations
   npm run migrate
   ```

5. **Start the application**
   ```bash
   # Using the startup script
   ./scripts/start-production.sh
   
   # Or directly
   NODE_ENV=production node dist/server/index.js
   ```

### Process Management with PM2

1. **Install PM2**
   ```bash
   npm install -g pm2
   ```

2. **Create PM2 configuration**
   ```javascript
   // ecosystem.config.js
   module.exports = {
     apps: [{
       name: 'task-management-system',
       script: 'dist/server/index.js',
       cwd: '/path/to/your/app',
       env: {
         NODE_ENV: 'production',
         PORT: 3001
       },
       instances: 'max',
       exec_mode: 'cluster',
       max_memory_restart: '1G',
       error_file: './logs/err.log',
       out_file: './logs/out.log',
       log_file: './logs/combined.log',
       time: true
     }]
   }
   ```

3. **Start with PM2**
   ```bash
   pm2 start ecosystem.config.js
   pm2 save
   pm2 startup
   ```

### Reverse Proxy with Nginx

1. **Install Nginx**
   ```bash
   sudo apt-get install -y nginx
   ```

2. **Configure Nginx**
   ```nginx
   # /etc/nginx/sites-available/task-management-system
   server {
       listen 80;
       server_name yourdomain.com;
       
       # Redirect HTTP to HTTPS
       return 301 https://$server_name$request_uri;
   }
   
   server {
       listen 443 ssl http2;
       server_name yourdomain.com;
       
       # SSL Configuration
       ssl_certificate /path/to/your/certificate.crt;
       ssl_certificate_key /path/to/your/private.key;
       
       # Security headers
       add_header X-Frame-Options DENY;
       add_header X-Content-Type-Options nosniff;
       add_header X-XSS-Protection "1; mode=block";
       
       # Serve static files
       location / {
           try_files $uri $uri/ @proxy;
       }
       
       # Proxy API requests
       location /api/ {
           proxy_pass http://localhost:3001;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
           proxy_cache_bypass $http_upgrade;
       }
       
       # Fallback to app
       location @proxy {
           proxy_pass http://localhost:3001;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

3. **Enable the site**
   ```bash
   sudo ln -s /etc/nginx/sites-available/task-management-system /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl reload nginx
   ```

## Docker Deployment

### Build Docker Image

```bash
# Build the image
./scripts/docker-build.sh

# Or manually
docker build -t task-management-system .
```

### Docker Compose Deployment

1. **Basic deployment**
   ```bash
   # Start all services
   docker-compose up -d
   
   # View logs
   docker-compose logs -f
   
   # Stop services
   docker-compose down
   ```

2. **With additional services**
   ```bash
   # Include Redis and Nginx
   docker-compose --profile with-redis --profile with-nginx up -d
   ```

3. **Production deployment**
   ```bash
   # Use production compose file
   docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d
   ```

### Single Container Deployment

```bash
# Run with environment file
docker run -d \
  --name task-management-app \
  --env-file .env \
  -p 3001:3001 \
  task-management-system

# Run with individual environment variables
docker run -d \
  --name task-management-app \
  -e NODE_ENV=production \
  -e DATABASE_URL=postgresql://user:pass@host:5432/db \
  -e JWT_SECRET=your-secret \
  -p 3001:3001 \
  task-management-system
```

## Database Setup

### PostgreSQL Installation

#### Ubuntu/Debian
```bash
sudo apt-get update
sudo apt-get install -y postgresql postgresql-contrib
```

#### CentOS/RHEL
```bash
sudo yum install -y postgresql-server postgresql-contrib
sudo postgresql-setup initdb
sudo systemctl enable postgresql
sudo systemctl start postgresql
```

#### macOS
```bash
brew install postgresql
brew services start postgresql
```

### Database Configuration

1. **Create database and user**
   ```sql
   -- Connect as postgres user
   sudo -u postgres psql
   
   -- Create user
   CREATE USER taskmanager WITH PASSWORD 'secure_password';
   
   -- Create database
   CREATE DATABASE task_management OWNER taskmanager;
   
   -- Grant privileges
   GRANT ALL PRIVILEGES ON DATABASE task_management TO taskmanager;
   ```

2. **Configure PostgreSQL**
   ```bash
   # Edit postgresql.conf
   sudo nano /etc/postgresql/13/main/postgresql.conf
   
   # Enable connections
   listen_addresses = 'localhost'
   port = 5432
   
   # Edit pg_hba.conf for authentication
   sudo nano /etc/postgresql/13/main/pg_hba.conf
   
   # Add line for local connections
   local   task_management   taskmanager                     md5
   ```

3. **Run migrations**
   ```bash
   npm run migrate
   ```

### Database Backup and Restore

#### Backup
```bash
# Full database backup
pg_dump -h localhost -U taskmanager -d task_management > backup.sql

# Compressed backup
pg_dump -h localhost -U taskmanager -d task_management | gzip > backup.sql.gz

# Custom format backup (recommended)
pg_dump -h localhost -U taskmanager -d task_management -Fc > backup.dump
```

#### Restore
```bash
# From SQL file
psql -h localhost -U taskmanager -d task_management < backup.sql

# From compressed file
gunzip -c backup.sql.gz | psql -h localhost -U taskmanager -d task_management

# From custom format
pg_restore -h localhost -U taskmanager -d task_management backup.dump
```

## Monitoring and Maintenance

### Health Checks

The application provides several health check endpoints:

- `GET /api/health` - Overall system health
- `GET /api/health/db` - Database connectivity

### Logging

Logs are written to:
- Console output (development)
- Log files in `logs/` directory (production)
- PM2 logs (when using PM2)

### Performance Monitoring

1. **Application Metrics**
   ```bash
   # View PM2 monitoring
   pm2 monit
   
   # View detailed info
   pm2 show task-management-system
   ```

2. **Database Monitoring**
   ```sql
   -- Check active connections
   SELECT count(*) FROM pg_stat_activity;
   
   -- Check database size
   SELECT pg_size_pretty(pg_database_size('task_management'));
   
   -- Check slow queries
   SELECT query, mean_time, calls 
   FROM pg_stat_statements 
   ORDER BY mean_time DESC 
   LIMIT 10;
   ```

### Backup Strategy

1. **Automated Database Backups**
   ```bash
   # Create backup script
   #!/bin/bash
   BACKUP_DIR="/backups/task-management"
   DATE=$(date +%Y%m%d_%H%M%S)
   
   mkdir -p $BACKUP_DIR
   pg_dump -h localhost -U taskmanager -d task_management -Fc > $BACKUP_DIR/backup_$DATE.dump
   
   # Keep only last 7 days
   find $BACKUP_DIR -name "backup_*.dump" -mtime +7 -delete
   ```

2. **Schedule with cron**
   ```bash
   # Add to crontab
   0 2 * * * /path/to/backup-script.sh
   ```

## Troubleshooting

### Common Issues

#### Database Connection Issues
```bash
# Check if PostgreSQL is running
sudo systemctl status postgresql

# Check database connectivity
psql -h localhost -U taskmanager -d task_management -c "SELECT 1;"

# Check logs
sudo tail -f /var/log/postgresql/postgresql-13-main.log
```

#### Application Won't Start
```bash
# Check Node.js version
node --version

# Check if port is in use
sudo netstat -tlnp | grep :3001

# Check application logs
tail -f logs/combined.log

# Check PM2 status
pm2 status
pm2 logs task-management-system
```

#### Build Issues
```bash
# Clear npm cache
npm cache clean --force

# Remove node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# Check TypeScript compilation
npm run type-check
```

### Performance Issues

#### High Memory Usage
```bash
# Check memory usage
free -h
ps aux --sort=-%mem | head

# Restart application
pm2 restart task-management-system
```

#### Slow Database Queries
```sql
-- Enable query logging
ALTER SYSTEM SET log_statement = 'all';
ALTER SYSTEM SET log_min_duration_statement = 1000;
SELECT pg_reload_conf();

-- Check slow queries
SELECT query, mean_time, calls 
FROM pg_stat_statements 
ORDER BY mean_time DESC 
LIMIT 10;
```

### Getting Help

1. **Check application logs**
2. **Review health check endpoints**
3. **Verify environment configuration**
4. **Check database connectivity**
5. **Review system resources**

For additional support, please refer to the project documentation or create an issue in the repository.