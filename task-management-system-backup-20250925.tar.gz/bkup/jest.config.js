module.exports = {
    preset: 'ts-jest',
    testEnvironment: 'jsdom',
    roots: ['<rootDir>/src'],
    testMatch: [
        '**/__tests__/**/*.+(ts|tsx|js)',
        '**/*.(test|spec).+(ts|tsx|js)'
    ],
    transform: {
        '^.+\\.(ts|tsx)$': 'ts-jest'
    },
    collectCoverageFrom: [
        'src/**/*.{ts,tsx}',
        '!src/**/*.d.ts',
        '!src/client/main.tsx',
        '!src/server/index.ts'
    ],
    moduleNameMapper: {
        '^@/(.*)$': '<rootDir>/src/$1',
        '^@/components/(.*)$': '<rootDir>/src/client/components/$1',
        '^@/hooks/(.*)$': '<rootDir>/src/client/hooks/$1',
        '^@/store/(.*)$': '<rootDir>/src/client/store/$1',
        '^@/types/(.*)$': '<rootDir>/src/shared/types/$1',
        '^@/utils/(.*)$': '<rootDir>/src/shared/utils/$1'
    },
    setupFilesAfterEnv: ['<rootDir>/src/test/setup.ts']
}