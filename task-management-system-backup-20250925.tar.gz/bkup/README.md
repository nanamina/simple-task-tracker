# Task Management System

A modern web-based task management system built with React, TypeScript, and Node.js, featuring internationalization support with Japanese as the default language.

## Features

- Task creation and management with detailed information
- Project organization and team collaboration
- Role-based access control
- Internationalization (Japanese/English)
- Real-time notifications
- Progress tracking and reporting

## Tech Stack

### Frontend
- React 18 with TypeScript
- Redux Toolkit for state management
- React Router for navigation
- i18next for internationalization
- Tailwind CSS for styling
- Vite for build tooling

### Backend
- Node.js with Express.js
- TypeScript
- PostgreSQL database
- JWT authentication
- bcrypt for password hashing

## Getting Started

### Prerequisites
- Node.js 18+ 
- PostgreSQL 14+
- npm or yarn

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```

3. Copy environment variables:
   ```bash
   cp .env.example .env
   ```

4. Update the `.env` file with your database credentials and other configuration

5. Set up the database:
   ```bash
   # Run migrations to create tables
   npm run migrate
   
   # Seed with sample data (optional)
   npm run db:seed
   ```

   For detailed database setup instructions, see [docs/database-setup.md](docs/database-setup.md)

### Development

Start the development servers:
```bash
npm run dev
```

This will start:
- Frontend development server on http://localhost:3000
- Backend API server on http://localhost:3001

### Available Scripts

#### Development
- `npm run dev` - Start both frontend and backend in development mode
- `npm run dev:client` - Start only the frontend development server
- `npm run dev:server` - Start only the backend development server

#### Building
- `npm run build` - Build both frontend and backend for production
- `npm run start` - Start production server

#### Database
- `npm run migrate` - Run database migrations
- `npm run migrate:status` - Check migration status
- `npm run db:seed` - Seed database with sample data
- `npm run db:clear` - Clear all database data
- `npm run migrate:reset` - Reset database (clear + migrate + seed)

#### Testing & Quality
- `npm run test` - Run the test suite
- `npm run lint` - Run ESLint
- `npm run type-check` - Run TypeScript type checking

## Project Structure

```
src/
├── client/           # React frontend application
│   ├── components/   # React components
│   ├── hooks/        # Custom React hooks
│   ├── store/        # Redux store and slices
│   └── main.tsx      # Frontend entry point
├── server/           # Node.js backend application
│   ├── controllers/  # Route controllers
│   ├── middleware/   # Express middleware
│   ├── routes/       # API routes
│   ├── services/     # Business logic
│   ├── repositories/ # Data access layer
│   ├── config/       # Configuration files
│   └── index.ts      # Backend entry point
├── shared/           # Shared code between client and server
│   ├── types/        # TypeScript type definitions
│   └── utils/        # Utility functions
└── test/             # Test configuration and utilities
```

## License

MIT