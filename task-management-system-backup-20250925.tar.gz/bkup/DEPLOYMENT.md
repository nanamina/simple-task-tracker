# Task Management System - Quick Deployment Guide

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- PostgreSQL 12+
- npm 8+

### 1. Environment Setup
```bash
# Copy environment template
cp .env.example .env

# Edit with your settings
nano .env
```

### 2. Database Setup
```bash
# Create database
createdb task_management

# Run migrations
npm run migrate

# Optional: Add sample data
npm run db:seed
```

### 3. Deploy
```bash
# Automated deployment
./scripts/deploy.sh production

# Or manual build
npm run build
npm run start:prod
```

### 4. Verify
```bash
# Test deployment
./scripts/verify-deployment.sh

# Check health
curl http://localhost:3001/api/health
```

## 🐳 Docker Deployment

### Quick Docker Setup
```bash
# Build and run with Docker Compose
docker-compose up -d

# Or build custom image
./scripts/docker-build.sh
docker run -p 3001:3001 --env-file .env task-management-system
```

## 📊 Production Checklist

- [ ] Environment variables configured
- [ ] Database created and migrated
- [ ] SSL certificates installed (if HTTPS)
- [ ] Reverse proxy configured (nginx/Apache)
- [ ] Process manager setup (PM2/systemd)
- [ ] Monitoring configured
- [ ] Backups scheduled
- [ ] Health checks passing

## 🔧 Configuration

### Required Environment Variables
```bash
NODE_ENV=production
DATABASE_URL=postgresql://user:pass@host:5432/db
JWT_SECRET=your-secure-secret-key
CLIENT_URL=https://yourdomain.com
```

### Optional Configuration
```bash
SMTP_HOST=smtp.example.com
SMTP_USER=your-email@example.com
SMTP_PASSWORD=your-password
```

## 🏥 Health Monitoring

- Health endpoint: `GET /api/health`
- Database check: `GET /api/health/db`
- Verification script: `./scripts/verify-deployment.sh`

## 📚 Full Documentation

For detailed deployment instructions, see [docs/deployment.md](docs/deployment.md)

## 🆘 Troubleshooting

### Common Issues

**Build fails:**
```bash
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
```

**Database connection:**
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Test connection
psql -h localhost -U username -d task_management
```

**Port already in use:**
```bash
# Find process using port
sudo netstat -tlnp | grep :3001

# Kill process
sudo kill -9 <PID>
```

## 📞 Support

- Check logs: `tail -f logs/combined.log`
- Health status: `curl http://localhost:3001/api/health`
- Process status: `pm2 status` (if using PM2)

---

**Need help?** Check the full deployment documentation or create an issue.