"use strict";
/**
 * Validation schemas and utilities for data models
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateEmail = validateEmail;
exports.validatePassword = validatePassword;
exports.validateName = validateName;
exports.validateRole = validateRole;
exports.validateLanguage = validateLanguage;
exports.validateCreateUser = validateCreateUser;
exports.validateTaskTitle = validateTaskTitle;
exports.validateTaskDescription = validateTaskDescription;
exports.validateTaskPriority = validateTaskPriority;
exports.validateTaskStatus = validateTaskStatus;
exports.validateTaskStatusTransition = validateTaskStatusTransition;
exports.validateDueDate = validateDueDate;
exports.validateCreateTask = validateCreateTask;
exports.validateUpdateTask = validateUpdateTask;
exports.validateProjectName = validateProjectName;
exports.validateProjectDescription = validateProjectDescription;
exports.validateCreateProject = validateCreateProject;
exports.validateUpdateProject = validateUpdateProject;
/**
 * Validates email format
 */
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}
/**
 * Validates password strength
 * Requirements: At least 8 characters, contains letter and number
 */
function validatePassword(password) {
    const errors = [];
    if (password.length < 8) {
        errors.push('Password must be at least 8 characters long');
    }
    if (!/[a-zA-Z]/.test(password)) {
        errors.push('Password must contain at least one letter');
    }
    if (!/\d/.test(password)) {
        errors.push('Password must contain at least one number');
    }
    return {
        isValid: errors.length === 0,
        errors
    };
}
/**
 * Validates user name
 */
function validateName(name) {
    return name.trim().length >= 2 && name.trim().length <= 100;
}
/**
 * Validates user role
 */
function validateRole(role) {
    return ['admin', 'manager', 'member'].includes(role);
}
/**
 * Validates language preference
 */
function validateLanguage(language) {
    return ['ja', 'en'].includes(language);
}
/**
 * Validates complete user creation data
 */
function validateCreateUser(data) {
    const errors = [];
    if (!validateEmail(data.email)) {
        errors.push('Invalid email format');
    }
    if (!validateName(data.name)) {
        errors.push('Name must be between 2 and 100 characters');
    }
    const passwordValidation = validatePassword(data.password);
    if (!passwordValidation.isValid) {
        errors.push(...passwordValidation.errors);
    }
    if (data.role && !validateRole(data.role)) {
        errors.push('Invalid user role');
    }
    if (data.preferredLanguage && !validateLanguage(data.preferredLanguage)) {
        errors.push('Invalid language preference');
    }
    return {
        isValid: errors.length === 0,
        errors
    };
}
/**
 * Validates task title
 */
function validateTaskTitle(title) {
    return title.trim().length >= 1 && title.trim().length <= 255;
}
/**
 * Validates task description
 */
function validateTaskDescription(description) {
    return description.trim().length <= 2000;
}
/**
 * Validates task priority
 */
function validateTaskPriority(priority) {
    return ['low', 'medium', 'high', 'critical'].includes(priority);
}
/**
 * Validates task status
 */
function validateTaskStatus(status) {
    return ['todo', 'in-progress', 'completed'].includes(status);
}
/**
 * Validates task status transition
 */
function validateTaskStatusTransition(fromStatus, toStatus) {
    // Define allowed transitions
    const allowedTransitions = {
        'todo': ['in-progress', 'completed'],
        'in-progress': ['todo', 'completed'],
        'completed': ['todo', 'in-progress']
    };
    if (fromStatus === toStatus) {
        return { isValid: true }; // Same status is always valid
    }
    if (allowedTransitions[fromStatus].includes(toStatus)) {
        return { isValid: true };
    }
    return {
        isValid: false,
        error: `Cannot transition from ${fromStatus} to ${toStatus}`
    };
}
/**
 * Validates due date (must be in the future or today)
 */
function validateDueDate(dueDate) {
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Start of today
    return dueDate >= today;
}
/**
 * Validates complete task creation data
 */
function validateCreateTask(data) {
    const errors = [];
    if (!validateTaskTitle(data.title)) {
        errors.push('Title must be between 1 and 255 characters');
    }
    if (!validateTaskDescription(data.description)) {
        errors.push('Description must be 2000 characters or less');
    }
    if (data.priority && !validateTaskPriority(data.priority)) {
        errors.push('Invalid task priority');
    }
    if (data.dueDate && !validateDueDate(data.dueDate)) {
        errors.push('Due date must be today or in the future');
    }
    return {
        isValid: errors.length === 0,
        errors
    };
}
/**
 * Validates task update data
 */
function validateUpdateTask(data) {
    const errors = [];
    if (data.title !== undefined && !validateTaskTitle(data.title)) {
        errors.push('Title must be between 1 and 255 characters');
    }
    if (data.description !== undefined && !validateTaskDescription(data.description)) {
        errors.push('Description must be 2000 characters or less');
    }
    if (data.priority !== undefined && !validateTaskPriority(data.priority)) {
        errors.push('Invalid task priority');
    }
    if (data.dueDate !== undefined && !validateDueDate(data.dueDate)) {
        errors.push('Due date must be today or in the future');
    }
    return {
        isValid: errors.length === 0,
        errors
    };
}
/**
 * Validates project name
 */
function validateProjectName(name) {
    return name.trim().length >= 1 && name.trim().length <= 255;
}
/**
 * Validates project description
 */
function validateProjectDescription(description) {
    return description.trim().length <= 2000;
}
/**
 * Validates complete project creation data
 */
function validateCreateProject(data) {
    const errors = [];
    if (!validateProjectName(data.name)) {
        errors.push('Name must be between 1 and 255 characters');
    }
    if (!validateProjectDescription(data.description)) {
        errors.push('Description must be 2000 characters or less');
    }
    return {
        isValid: errors.length === 0,
        errors
    };
}
/**
 * Validates project update data
 */
function validateUpdateProject(data) {
    const errors = [];
    if (data.name !== undefined && !validateProjectName(data.name)) {
        errors.push('Name must be between 1 and 255 characters');
    }
    if (data.description !== undefined && !validateProjectDescription(data.description)) {
        errors.push('Description must be 2000 characters or less');
    }
    return {
        isValid: errors.length === 0,
        errors
    };
}
