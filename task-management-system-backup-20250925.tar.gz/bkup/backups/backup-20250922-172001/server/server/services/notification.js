"use strict";
/**
 * Notification service for task assignments and status changes
 * Handles email notifications with internationalization support
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendTaskAssignment = sendTaskAssignment;
exports.sendStatusUpdate = sendStatusUpdate;
exports.sendOverdueReminder = sendOverdueReminder;
exports.testEmailConfiguration = testEmailConfiguration;
const nodemailer = __importStar(require("nodemailer"));
// Email configuration from environment variables
const SMTP_CONFIG = {
    host: process.env.SMTP_HOST || 'localhost',
    port: parseInt(process.env.SMTP_PORT || '587'),
    secure: false, // true for 465, false for other ports
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASSWORD
    }
};
// Email templates with internationalization
const EMAIL_TEMPLATES = {
    taskAssignment: {
        ja: {
            subject: 'タスクが割り当てられました: {taskTitle}',
            body: `
こんにちは {assigneeName}さん、

新しいタスクが割り当てられました。

タスク名: {taskTitle}
説明: {taskDescription}
優先度: {priority}
期限: {dueDate}
作成者: {creatorName}

システムにログインして詳細を確認してください。

よろしくお願いします。
タスク管理システム
            `
        },
        en: {
            subject: 'Task Assigned: {taskTitle}',
            body: `
Hello {assigneeName},

A new task has been assigned to you.

Task: {taskTitle}
Description: {taskDescription}
Priority: {priority}
Due Date: {dueDate}
Created by: {creatorName}

Please log in to the system to view more details.

Best regards,
Task Management System
            `
        }
    },
    statusUpdate: {
        ja: {
            subject: 'タスクステータス更新: {taskTitle}',
            body: `
こんにちは {userName}さん、

タスクのステータスが更新されました。

タスク名: {taskTitle}
新しいステータス: {newStatus}
更新者: {updaterName}
更新日時: {updateTime}

システムにログインして詳細を確認してください。

よろしくお願いします。
タスク管理システム
            `
        },
        en: {
            subject: 'Task Status Updated: {taskTitle}',
            body: `
Hello {userName},

A task status has been updated.

Task: {taskTitle}
New Status: {newStatus}
Updated by: {updaterName}
Update Time: {updateTime}

Please log in to the system to view more details.

Best regards,
Task Management System
            `
        }
    },
    overdueReminder: {
        ja: {
            subject: '期限切れタスクの通知',
            body: `
こんにちは {userName}さん、

以下のタスクが期限を過ぎています：

{overdueTasks}

早急に対応をお願いします。

よろしくお願いします。
タスク管理システム
            `
        },
        en: {
            subject: 'Overdue Tasks Reminder',
            body: `
Hello {userName},

The following tasks are overdue:

{overdueTasks}

Please take action as soon as possible.

Best regards,
Task Management System
            `
        }
    }
};
// Priority translations
const PRIORITY_TRANSLATIONS = {
    ja: {
        low: '低',
        medium: '中',
        high: '高',
        critical: '緊急'
    },
    en: {
        low: 'Low',
        medium: 'Medium',
        high: 'High',
        critical: 'Critical'
    }
};
// Status translations
const STATUS_TRANSLATIONS = {
    ja: {
        todo: '未着手',
        'in-progress': '進行中',
        completed: '完了'
    },
    en: {
        todo: 'To Do',
        'in-progress': 'In Progress',
        completed: 'Completed'
    }
};
/**
 * Create email transporter using SMTP configuration
 * @returns Nodemailer transporter instance
 */
function createTransporter() {
    return nodemailer.createTransport(SMTP_CONFIG);
}
/**
 * Replace template placeholders with actual values
 * @param template - Email template string
 * @param variables - Object containing replacement values
 * @returns Processed template string
 */
function replaceTemplateVariables(template, variables) {
    let result = template;
    Object.entries(variables).forEach(([key, value]) => {
        const placeholder = `{${key}}`;
        result = result.replace(new RegExp(placeholder, 'g'), value || '');
    });
    return result;
}
/**
 * Format date according to user's language preference
 * @param date - Date to format
 * @param language - User's preferred language
 * @returns Formatted date string
 */
function formatDate(date, language) {
    if (!date)
        return language === 'ja' ? '未設定' : 'Not set';
    if (language === 'ja') {
        return date.toLocaleDateString('ja-JP', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        });
    }
    else {
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }
}
/**
 * Send task assignment notification to assignee
 * @param task - Task that was assigned
 * @param assignee - User who was assigned the task
 * @param creator - User who created/assigned the task
 */
async function sendTaskAssignment(task, assignee, creator) {
    try {
        const transporter = createTransporter();
        const language = assignee.preferredLanguage;
        const template = EMAIL_TEMPLATES.taskAssignment[language];
        const variables = {
            assigneeName: assignee.name,
            taskTitle: task.title,
            taskDescription: task.description,
            priority: PRIORITY_TRANSLATIONS[language][task.priority],
            dueDate: formatDate(task.dueDate, language),
            creatorName: creator.name
        };
        const subject = replaceTemplateVariables(template.subject, variables);
        const body = replaceTemplateVariables(template.body, variables);
        const mailOptions = {
            from: process.env.SMTP_USER,
            to: assignee.email,
            subject: subject,
            text: body
        };
        await transporter.sendMail(mailOptions);
        console.log(`Task assignment notification sent to ${assignee.email}`);
    }
    catch (error) {
        console.error('Failed to send task assignment notification:', error);
        throw new Error('Failed to send task assignment notification');
    }
}
/**
 * Send task status update notification to stakeholders
 * @param task - Task that was updated
 * @param stakeholders - Users to notify about the status change
 * @param updater - User who updated the task status
 */
async function sendStatusUpdate(task, stakeholders, updater) {
    try {
        const transporter = createTransporter();
        // Send notification to each stakeholder in their preferred language
        const notifications = stakeholders.map(async (user) => {
            const language = user.preferredLanguage;
            const template = EMAIL_TEMPLATES.statusUpdate[language];
            const variables = {
                userName: user.name,
                taskTitle: task.title,
                newStatus: STATUS_TRANSLATIONS[language][task.status],
                updaterName: updater.name,
                updateTime: formatDate(task.updatedAt, language)
            };
            const subject = replaceTemplateVariables(template.subject, variables);
            const body = replaceTemplateVariables(template.body, variables);
            const mailOptions = {
                from: process.env.SMTP_USER,
                to: user.email,
                subject: subject,
                text: body
            };
            await transporter.sendMail(mailOptions);
            console.log(`Status update notification sent to ${user.email}`);
        });
        await Promise.all(notifications);
    }
    catch (error) {
        console.error('Failed to send status update notifications:', error);
        throw new Error('Failed to send status update notifications');
    }
}
/**
 * Send overdue task reminder to users
 * @param tasks - Array of overdue tasks
 * @param users - Users to notify about overdue tasks
 */
async function sendOverdueReminder(tasks, users) {
    try {
        const transporter = createTransporter();
        // Group tasks by assignee for personalized notifications
        const tasksByUser = new Map();
        tasks.forEach(task => {
            if (task.assigneeId) {
                if (!tasksByUser.has(task.assigneeId)) {
                    tasksByUser.set(task.assigneeId, []);
                }
                tasksByUser.get(task.assigneeId).push(task);
            }
        });
        // Send notifications to each user
        const notifications = users.map(async (user) => {
            const userTasks = tasksByUser.get(user.id) || [];
            if (userTasks.length === 0)
                return;
            const language = user.preferredLanguage;
            const template = EMAIL_TEMPLATES.overdueReminder[language];
            // Format overdue tasks list
            const overdueTasksList = userTasks.map(task => {
                const dueDate = formatDate(task.dueDate, language);
                return `- ${task.title} (${language === 'ja' ? '期限' : 'Due'}: ${dueDate})`;
            }).join('\n');
            const variables = {
                userName: user.name,
                overdueTasks: overdueTasksList
            };
            const subject = replaceTemplateVariables(template.subject, variables);
            const body = replaceTemplateVariables(template.body, variables);
            const mailOptions = {
                from: process.env.SMTP_USER,
                to: user.email,
                subject: subject,
                text: body
            };
            await transporter.sendMail(mailOptions);
            console.log(`Overdue reminder sent to ${user.email}`);
        });
        await Promise.all(notifications);
    }
    catch (error) {
        console.error('Failed to send overdue reminders:', error);
        throw new Error('Failed to send overdue reminders');
    }
}
/**
 * Test email configuration by sending a test email
 * @param testEmail - Email address to send test email to
 */
async function testEmailConfiguration(testEmail) {
    try {
        const transporter = createTransporter();
        const mailOptions = {
            from: process.env.SMTP_USER,
            to: testEmail,
            subject: 'Task Management System - Email Configuration Test',
            text: 'This is a test email to verify the email configuration is working correctly.'
        };
        await transporter.sendMail(mailOptions);
        console.log(`Test email sent successfully to ${testEmail}`);
    }
    catch (error) {
        console.error('Email configuration test failed:', error);
        throw new Error('Email configuration test failed');
    }
}
