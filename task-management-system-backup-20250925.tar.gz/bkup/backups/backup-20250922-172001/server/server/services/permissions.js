"use strict";
/**
 * Permission management service
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PermissionService = void 0;
const authorization_1 = require("../middleware/authorization");
/**
 * Permission service for centralized permission management
 */
class PermissionService {
    /**
     * Check if a user has a specific permission
     * @param userRole - User's role
     * @param permissionKey - Permission key
     * @returns Boolean indicating permission status
     */
    static hasPermission(userRole, permissionKey) {
        return (0, authorization_1.hasPermission)(userRole, permissionKey);
    }
    /**
     * Check if a user can perform an action on a resource
     * @param userRole - User's role
     * @param resource - Resource name
     * @param action - Action name
     * @returns Boolean indicating access status
     */
    static canAccess(userRole, resource, action) {
        return (0, authorization_1.canAccess)(userRole, resource, action);
    }
    /**
     * Get all permissions for a user role
     * @param userRole - User's role
     * @returns Array of permission keys
     */
    static getUserPermissions(userRole) {
        return (0, authorization_1.getUserPermissions)(userRole);
    }
    /**
     * Get permissions for a specific resource
     * @param resource - Resource name
     * @returns Array of permissions
     */
    static getResourcePermissions(resource) {
        return (0, authorization_1.getResourcePermissions)(resource);
    }
    /**
     * Check role hierarchy
     * @param userRole - User's role
     * @param requiredRole - Required minimum role
     * @returns Boolean indicating role level status
     */
    static hasRoleLevel(userRole, requiredRole) {
        return (0, authorization_1.hasRoleLevel)(userRole, requiredRole);
    }
    /**
     * Get user's effective permissions with context
     * @param userRole - User's role
     * @param context - Additional context (e.g., project membership)
     * @returns Object with permission details
     */
    static getUserPermissionContext(userRole, context) {
        const basePermissions = (0, authorization_1.getUserPermissions)(userRole);
        return {
            role: userRole,
            permissions: basePermissions,
            context: context || {},
            canCreateTasks: (0, authorization_1.hasPermission)(userRole, 'tasks:create'),
            canManageProjects: (0, authorization_1.hasPermission)(userRole, 'projects:update'),
            canManageUsers: (0, authorization_1.hasPermission)(userRole, 'users:update'),
            canViewReports: (0, authorization_1.hasPermission)(userRole, 'reports:view'),
            isAdmin: userRole === 'admin',
            isManager: userRole === 'manager' || userRole === 'admin',
            isMember: ['member', 'manager', 'admin'].includes(userRole)
        };
    }
    /**
     * Validate multiple permissions at once
     * @param userRole - User's role
     * @param permissionKeys - Array of permission keys to check
     * @returns Object with permission results
     */
    static validatePermissions(userRole, permissionKeys) {
        const results = {};
        const granted = [];
        const denied = [];
        permissionKeys.forEach(key => {
            const hasAccess = (0, authorization_1.hasPermission)(userRole, key);
            results[key] = hasAccess;
            if (hasAccess) {
                granted.push(key);
            }
            else {
                denied.push(key);
            }
        });
        return {
            results,
            granted,
            denied,
            hasAllPermissions: denied.length === 0,
            hasAnyPermission: granted.length > 0
        };
    }
    /**
     * Get permission requirements for a resource action
     * @param resource - Resource name
     * @param action - Action name
     * @returns Permission details or null if not found
     */
    static getPermissionRequirements(resource, action) {
        const permissionKey = `${resource}:${action}`;
        const permission = authorization_1.PERMISSIONS[permissionKey];
        if (!permission) {
            return null;
        }
        return {
            key: permissionKey,
            resource: permission.resource,
            action: permission.action,
            requiredRoles: permission.roles,
            minimumRole: this.getMinimumRole(permission.roles)
        };
    }
    /**
     * Get the minimum role from a list of roles
     * @param roles - Array of roles
     * @returns Minimum role or null
     */
    static getMinimumRole(roles) {
        const roleHierarchy = {
            'member': 1,
            'manager': 2,
            'admin': 3
        };
        let minLevel = Infinity;
        let minRole = null;
        roles.forEach(role => {
            const level = roleHierarchy[role];
            if (level < minLevel) {
                minLevel = level;
                minRole = role;
            }
        });
        return minRole;
    }
    /**
     * Check if user can perform bulk operations
     * @param userRole - User's role
     * @param operations - Array of operations to check
     * @returns Validation results
     */
    static validateBulkOperations(userRole, operations) {
        const results = operations.map(op => ({
            resource: op.resource,
            action: op.action,
            allowed: (0, authorization_1.canAccess)(userRole, op.resource, op.action),
            permissionKey: `${op.resource}:${op.action}`
        }));
        return {
            operations: results,
            allAllowed: results.every(r => r.allowed),
            allowedCount: results.filter(r => r.allowed).length,
            deniedCount: results.filter(r => !r.allowed).length
        };
    }
}
exports.PermissionService = PermissionService;
