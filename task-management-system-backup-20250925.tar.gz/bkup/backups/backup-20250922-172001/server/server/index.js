"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const path_1 = __importDefault(require("path"));
const database_1 = require("./config/database");
const environment_1 = require("./config/environment");
const production_1 = require("./config/production");
const auth_1 = __importDefault(require("./routes/auth"));
const protected_examples_1 = __importDefault(require("./routes/protected-examples"));
const task_1 = __importDefault(require("./routes/task"));
const project_1 = __importDefault(require("./routes/project"));
const user_1 = __importDefault(require("./routes/user"));
const analytics_1 = require("./routes/analytics");
const database_2 = require("./config/database");
const errorHandler_1 = require("./middleware/errorHandler");
const logger_1 = require("./utils/logger");
// Validate environment configuration
try {
    (0, environment_1.validateEnvironment)();
}
catch (error) {
    console.error('Environment validation failed:', error);
    process.exit(1);
}
const app = (0, express_1.default)();
const environment = (0, environment_1.getEnvironment)();
const serverConfig = (0, environment_1.getServerConfig)();
// Security middleware
app.use((0, helmet_1.default)({
    contentSecurityPolicy: environment === 'production' ? undefined : false,
    crossOriginEmbedderPolicy: environment === 'production'
}));
// Production-specific middleware
if ((0, environment_1.isFeatureEnabled)('securityHeaders')) {
    app.use(production_1.securityHeaders);
}
if ((0, environment_1.isFeatureEnabled)('compression') || (0, environment_1.isFeatureEnabled)('rateLimiting')) {
    app.use(...production_1.productionMiddleware);
}
// CORS configuration
app.use((0, cors_1.default)(serverConfig.cors));
// Body parsing middleware
app.use(express_1.default.json({ limit: '10mb' }));
app.use(express_1.default.urlencoded({ extended: true, limit: '10mb' }));
// Static asset headers
app.use(production_1.staticAssetHeaders);
// Request logging middleware
app.use(logger_1.requestLogger);
// Routes
app.use('/api/auth', auth_1.default);
app.use('/api/protected', protected_examples_1.default);
app.use('/api/tasks', task_1.default);
app.use('/api/projects', project_1.default);
app.use('/api/users', user_1.default);
app.use('/api/analytics', (0, analytics_1.createAnalyticsRoutes)((0, database_2.getPool)()));
// Serve static files in production
if (environment === 'production') {
    const clientPath = path_1.default.join(__dirname, '../client');
    app.use(express_1.default.static(clientPath, {
        maxAge: '1y',
        etag: true,
        lastModified: true
    }));
    // Serve React app for all non-API routes
    app.get('*', (req, res) => {
        if (!req.path.startsWith('/api/')) {
            res.sendFile(path_1.default.join(clientPath, 'index.html'));
        }
    });
}
// Enhanced health check endpoint
app.get('/api/health', async (_req, res) => {
    try {
        // Test database connection
        await (0, database_1.testConnection)();
        const healthData = {
            status: 'ok',
            message: 'Task Management System API is running',
            environment,
            database: 'connected',
            timestamp: new Date().toISOString(),
            uptime: process.uptime(),
            version: process.env.npm_package_version || '1.0.0'
        };
        // Add memory usage in production
        if (environment === 'production') {
            const memUsage = process.memoryUsage();
            healthData.memory = {
                rss: Math.round(memUsage.rss / 1024 / 1024) + ' MB',
                heapTotal: Math.round(memUsage.heapTotal / 1024 / 1024) + ' MB',
                heapUsed: Math.round(memUsage.heapUsed / 1024 / 1024) + ' MB'
            };
        }
        res.json(healthData);
    }
    catch (error) {
        res.status(503).json({
            status: 'error',
            message: 'Database connection failed',
            environment,
            database: 'disconnected',
            timestamp: new Date().toISOString(),
            error: (0, environment_1.isFeatureEnabled)('detailedErrors') && error instanceof Error ? error.message : undefined
        });
    }
});
// Database health check endpoint
app.get('/api/health/db', async (_req, res) => {
    try {
        await (0, database_1.testConnection)();
        res.json({
            status: 'ok',
            message: 'Database connection successful',
            timestamp: new Date().toISOString()
        });
    }
    catch (error) {
        res.status(503).json({
            status: 'error',
            message: 'Database connection failed',
            error: (0, environment_1.isFeatureEnabled)('detailedErrors') && error instanceof Error ? error.message : 'Database unavailable',
            timestamp: new Date().toISOString()
        });
    }
});
// 404 handler for unmatched routes
app.use(errorHandler_1.notFoundHandler);
// Global error handling middleware (must be last)
app.use(errorHandler_1.errorHandler);
// Initialize database connection and start server
async function startServer() {
    try {
        // Test database connection on startup
        logger_1.logger.info('Testing database connection...', 'STARTUP');
        await (0, database_1.testConnection)();
        logger_1.logger.info('Database connection successful', 'STARTUP');
        // Start server
        const server = app.listen(serverConfig.port, serverConfig.host, () => {
            logger_1.logger.info(`Server started successfully`, 'STARTUP', {
                port: serverConfig.port,
                host: serverConfig.host,
                environment,
                database: 'connected',
                features: {
                    rateLimiting: (0, environment_1.isFeatureEnabled)('rateLimiting'),
                    compression: (0, environment_1.isFeatureEnabled)('compression'),
                    securityHeaders: (0, environment_1.isFeatureEnabled)('securityHeaders')
                }
            });
        });
        // Graceful shutdown handling
        const gracefulShutdown = (signal) => {
            logger_1.logger.info(`Received ${signal}, shutting down gracefully...`, 'SHUTDOWN');
            server.close(() => {
                logger_1.logger.info('HTTP server closed', 'SHUTDOWN');
                // Close database connections
                const pool = (0, database_2.getPool)();
                pool.end(() => {
                    logger_1.logger.info('Database connections closed', 'SHUTDOWN');
                    process.exit(0);
                });
            });
            // Force close after 10 seconds
            setTimeout(() => {
                logger_1.logger.error('Could not close connections in time, forcefully shutting down', new Error('Shutdown timeout'), 'SHUTDOWN');
                process.exit(1);
            }, 10000);
        };
        // Listen for termination signals
        process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
        process.on('SIGINT', () => gracefulShutdown('SIGINT'));
    }
    catch (error) {
        logger_1.logger.error('Failed to start server', error, 'STARTUP');
        logger_1.logger.error('Please check your database configuration and ensure PostgreSQL is running');
        process.exit(1);
    }
}
// Start the server
startServer();
