"use strict";
/**
 * Environment Configuration Management
 *
 * Centralized configuration for different deployment environments
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLoggingConfig = exports.getEmailConfig = exports.getJWTConfig = exports.getServerConfig = exports.isFeatureEnabled = exports.getDatabaseConfig = exports.validateEnvironment = exports.getConfig = exports.getEnvironment = void 0;
const dotenv = __importStar(require("dotenv"));
const production_1 = require("./production");
// Load environment variables
dotenv.config();
/**
 * Get current environment
 */
const getEnvironment = () => {
    const env = process.env.NODE_ENV;
    return env || 'development';
};
exports.getEnvironment = getEnvironment;
/**
 * Development configuration
 */
const developmentConfig = {
    server: {
        port: parseInt(process.env.PORT || '3001'),
        host: process.env.HOST || 'localhost',
        cors: {
            origin: process.env.CLIENT_URL || 'http://localhost:3000',
            credentials: true
        }
    },
    database: {
        url: process.env.DATABASE_URL || 'postgresql://username:password@localhost:5432/task_management',
        pool: {
            max: 10,
            idleTimeoutMillis: 30000,
            connectionTimeoutMillis: 2000
        },
        ssl: false
    },
    jwt: {
        secret: process.env.JWT_SECRET || 'development-secret-key',
        expiresIn: process.env.JWT_EXPIRES_IN || '7d'
    },
    email: {
        host: process.env.SMTP_HOST || 'localhost',
        port: parseInt(process.env.SMTP_PORT || '587'),
        secure: false,
        auth: {
            user: process.env.SMTP_USER || '',
            pass: process.env.SMTP_PASSWORD || ''
        }
    },
    logging: {
        level: 'debug',
        format: 'dev'
    },
    features: {
        rateLimiting: false,
        compression: false,
        securityHeaders: false,
        detailedErrors: true
    }
};
/**
 * Production configuration
 */
const productionConfig = {
    server: {
        port: parseInt(process.env.PORT || '3001'),
        host: process.env.HOST || '0.0.0.0',
        cors: {
            origin: process.env.CLIENT_URL?.split(',') || ['https://yourdomain.com'],
            credentials: true
        }
    },
    database: {
        url: process.env.DATABASE_URL || '',
        pool: production_1.productionPoolConfig,
        ssl: true
    },
    jwt: {
        secret: process.env.JWT_SECRET || '',
        expiresIn: process.env.JWT_EXPIRES_IN || '24h'
    },
    email: {
        host: process.env.SMTP_HOST || '',
        port: parseInt(process.env.SMTP_PORT || '587'),
        secure: true,
        auth: {
            user: process.env.SMTP_USER || '',
            pass: process.env.SMTP_PASSWORD || ''
        }
    },
    logging: {
        level: 'info',
        format: 'combined'
    },
    features: {
        rateLimiting: true,
        compression: true,
        securityHeaders: true,
        detailedErrors: false
    }
};
/**
 * Test configuration
 */
const testConfig = {
    server: {
        port: parseInt(process.env.PORT || '3002'),
        host: 'localhost',
        cors: {
            origin: 'http://localhost:3000',
            credentials: true
        }
    },
    database: {
        url: process.env.TEST_DATABASE_URL || 'postgresql://test:test@localhost:5432/test_db',
        pool: {
            max: 5,
            idleTimeoutMillis: 1000,
            connectionTimeoutMillis: 1000
        },
        ssl: false
    },
    jwt: {
        secret: 'test-secret-key',
        expiresIn: '1h'
    },
    email: {
        host: 'localhost',
        port: 587,
        secure: false,
        auth: {
            user: 'test',
            pass: 'test'
        }
    },
    logging: {
        level: 'error',
        format: 'dev'
    },
    features: {
        rateLimiting: false,
        compression: false,
        securityHeaders: false,
        detailedErrors: true
    }
};
/**
 * Staging configuration
 */
const stagingConfig = {
    ...productionConfig,
    server: {
        ...productionConfig.server,
        cors: {
            origin: process.env.CLIENT_URL?.split(',') || ['https://staging.yourdomain.com'],
            credentials: true
        }
    },
    logging: {
        level: 'debug',
        format: 'combined'
    },
    features: {
        ...productionConfig.features,
        detailedErrors: true
    }
};
/**
 * Get configuration for current environment
 */
const getConfig = () => {
    const env = (0, exports.getEnvironment)();
    switch (env) {
        case 'production':
            return productionConfig;
        case 'staging':
            return stagingConfig;
        case 'test':
            return testConfig;
        case 'development':
        default:
            return developmentConfig;
    }
};
exports.getConfig = getConfig;
/**
 * Validate required environment variables
 */
const validateEnvironment = () => {
    const env = (0, exports.getEnvironment)();
    const config = (0, exports.getConfig)();
    const requiredVars = [];
    if (env === 'production') {
        requiredVars.push('DATABASE_URL', 'JWT_SECRET', 'CLIENT_URL');
        // Check if email is configured for notifications
        if (process.env.SMTP_HOST) {
            requiredVars.push('SMTP_USER', 'SMTP_PASSWORD');
        }
    }
    const missingVars = requiredVars.filter(varName => !process.env[varName]);
    if (missingVars.length > 0) {
        throw new Error(`Missing required environment variables: ${missingVars.join(', ')}`);
    }
    // Validate JWT secret strength in production
    if (env === 'production' && config.jwt.secret.length < 32) {
        throw new Error('JWT_SECRET must be at least 32 characters long in production');
    }
    // Validate database URL format
    if (!config.database.url.startsWith('postgresql://')) {
        throw new Error('DATABASE_URL must be a valid PostgreSQL connection string');
    }
};
exports.validateEnvironment = validateEnvironment;
/**
 * Get database pool configuration
 */
const getDatabaseConfig = () => {
    const config = (0, exports.getConfig)();
    return {
        connectionString: config.database.url,
        ssl: config.database.ssl ? { rejectUnauthorized: false } : false,
        ...config.database.pool
    };
};
exports.getDatabaseConfig = getDatabaseConfig;
/**
 * Check if feature is enabled
 */
const isFeatureEnabled = (feature) => {
    const config = (0, exports.getConfig)();
    return config.features[feature];
};
exports.isFeatureEnabled = isFeatureEnabled;
/**
 * Get server configuration
 */
const getServerConfig = () => {
    const config = (0, exports.getConfig)();
    return config.server;
};
exports.getServerConfig = getServerConfig;
/**
 * Get JWT configuration
 */
const getJWTConfig = () => {
    const config = (0, exports.getConfig)();
    return config.jwt;
};
exports.getJWTConfig = getJWTConfig;
/**
 * Get email configuration
 */
const getEmailConfig = () => {
    const config = (0, exports.getConfig)();
    return config.email;
};
exports.getEmailConfig = getEmailConfig;
/**
 * Get logging configuration
 */
const getLoggingConfig = () => {
    const config = (0, exports.getConfig)();
    return config.logging;
};
exports.getLoggingConfig = getLoggingConfig;
