"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.closePool = exports.testConnection = exports.getPool = exports.getDatabaseConfig = void 0;
const pg_1 = require("pg");
const dotenv = __importStar(require("dotenv"));
// Load environment variables
dotenv.config();
/**
 * Get database configuration from environment variables
 * @returns Database configuration object
 */
const getDatabaseConfig = () => {
    return {
        host: process.env.DB_HOST || 'localhost',
        port: parseInt(process.env.DB_PORT || '5432'),
        database: process.env.DB_NAME || 'task_management',
        user: process.env.DB_USER || 'postgres',
        password: process.env.DB_PASSWORD || 'password',
        max: parseInt(process.env.DB_POOL_MAX || '20'),
        idleTimeoutMillis: parseInt(process.env.DB_IDLE_TIMEOUT || '30000'),
        connectionTimeoutMillis: parseInt(process.env.DB_CONNECTION_TIMEOUT || '2000'),
    };
};
exports.getDatabaseConfig = getDatabaseConfig;
/**
 * Database connection pool instance
 */
let pool = null;
/**
 * Get or create database connection pool
 * @returns PostgreSQL connection pool
 */
const getPool = () => {
    if (!pool) {
        const config = (0, exports.getDatabaseConfig)();
        pool = new pg_1.Pool(config);
        // Handle pool errors
        pool.on('error', (err) => {
            console.error('Unexpected error on idle client', err);
            process.exit(-1);
        });
    }
    return pool;
};
exports.getPool = getPool;
/**
 * Test database connection
 * @returns Promise that resolves if connection is successful
 */
const testConnection = async () => {
    const client = (0, exports.getPool)();
    try {
        const result = await client.query('SELECT NOW()');
        console.log('Database connection successful:', result.rows[0]);
    }
    catch (error) {
        console.error('Database connection failed:', error);
        throw error;
    }
};
exports.testConnection = testConnection;
/**
 * Close database connection pool
 */
const closePool = async () => {
    if (pool) {
        await pool.end();
        pool = null;
    }
};
exports.closePool = closePool;
