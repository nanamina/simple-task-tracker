"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrationRunner = exports.MigrationRunner = void 0;
const fs_1 = require("fs");
const path_1 = require("path");
const database_1 = require("./database");
/**
 * Migration runner class for handling database migrations
 */
class MigrationRunner {
    constructor() {
        this.pool = (0, database_1.getPool)();
        this.migrationsPath = (0, path_1.join)(__dirname, '..', '..', '..', 'migrations');
    }
    /**
     * Initialize migration tracking table
     */
    async initializeMigrationTable() {
        const createTableSQL = `
      CREATE TABLE IF NOT EXISTS migrations (
        id SERIAL PRIMARY KEY,
        filename VARCHAR(255) UNIQUE NOT NULL,
        executed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `;
        await this.pool.query(createTableSQL);
    }
    /**
     * Get list of executed migrations
     */
    async getExecutedMigrations() {
        const result = await this.pool.query('SELECT filename FROM migrations ORDER BY id');
        return result.rows.map(row => row.filename);
    }
    /**
     * Load migration files from disk
     */
    loadMigrations() {
        const fs = require('fs');
        const files = fs.readdirSync(this.migrationsPath)
            .filter((file) => file.endsWith('.sql'))
            .sort();
        return files.map((filename) => {
            const filepath = (0, path_1.join)(this.migrationsPath, filename);
            const sql = (0, fs_1.readFileSync)(filepath, 'utf8');
            const id = filename.replace('.sql', '');
            return { id, filename, sql };
        });
    }
    /**
     * Execute a single migration
     */
    async executeMigration(migration) {
        const client = await this.pool.connect();
        try {
            await client.query('BEGIN');
            // Execute the migration SQL
            await client.query(migration.sql);
            // Record the migration as executed
            await client.query('INSERT INTO migrations (filename) VALUES ($1)', [migration.filename]);
            await client.query('COMMIT');
            console.log(`✓ Executed migration: ${migration.filename}`);
        }
        catch (error) {
            await client.query('ROLLBACK');
            console.error(`✗ Failed to execute migration: ${migration.filename}`);
            throw error;
        }
        finally {
            client.release();
        }
    }
    /**
     * Run all pending migrations
     */
    async runMigrations() {
        try {
            console.log('Starting database migrations...');
            // Initialize migration tracking
            await this.initializeMigrationTable();
            // Get executed migrations
            const executedMigrations = await this.getExecutedMigrations();
            // Load all migration files
            const allMigrations = this.loadMigrations();
            // Filter out already executed migrations
            const pendingMigrations = allMigrations.filter(migration => !executedMigrations.includes(migration.filename));
            if (pendingMigrations.length === 0) {
                console.log('No pending migrations found.');
                return;
            }
            console.log(`Found ${pendingMigrations.length} pending migrations`);
            // Execute pending migrations
            for (const migration of pendingMigrations) {
                await this.executeMigration(migration);
            }
            console.log('All migrations completed successfully!');
        }
        catch (error) {
            console.error('Migration failed:', error);
            throw error;
        }
    }
    /**
     * Rollback the last migration (basic implementation)
     */
    async rollbackLastMigration() {
        try {
            const result = await this.pool.query('SELECT filename FROM migrations ORDER BY id DESC LIMIT 1');
            if (result.rows.length === 0) {
                console.log('No migrations to rollback.');
                return;
            }
            const lastMigration = result.rows[0].filename;
            console.log(`Rolling back migration: ${lastMigration}`);
            // Remove from migrations table
            await this.pool.query('DELETE FROM migrations WHERE filename = $1', [lastMigration]);
            console.log(`✓ Rolled back migration: ${lastMigration}`);
            console.log('Note: You may need to manually undo schema changes.');
        }
        catch (error) {
            console.error('Rollback failed:', error);
            throw error;
        }
    }
    /**
     * Get migration status
     */
    async getMigrationStatus() {
        try {
            await this.initializeMigrationTable();
            const executedMigrations = await this.getExecutedMigrations();
            const allMigrations = this.loadMigrations();
            console.log('\nMigration Status:');
            console.log('================');
            for (const migration of allMigrations) {
                const status = executedMigrations.includes(migration.filename) ? '✓' : '✗';
                console.log(`${status} ${migration.filename}`);
            }
            const pendingCount = allMigrations.length - executedMigrations.length;
            console.log(`\nExecuted: ${executedMigrations.length}`);
            console.log(`Pending: ${pendingCount}`);
        }
        catch (error) {
            console.error('Failed to get migration status:', error);
            throw error;
        }
    }
}
exports.MigrationRunner = MigrationRunner;
/**
 * Create and export migration runner instance
 */
exports.migrationRunner = new MigrationRunner();
