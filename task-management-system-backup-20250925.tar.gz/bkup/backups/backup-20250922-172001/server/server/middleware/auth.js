"use strict";
/**
 * Authentication middleware for JWT token validation
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireAuth = exports.requireManagerOrAdmin = exports.requireAdmin = void 0;
exports.authenticateToken = authenticateToken;
exports.optionalAuth = optionalAuth;
exports.requireRole = requireRole;
const auth_1 = require("../services/auth");
/**
 * Authentication middleware that validates JWT tokens
 * Adds user information to request object if token is valid
 */
function authenticateToken(req, res, next) {
    try {
        const authHeader = req.headers.authorization;
        const token = (0, auth_1.extractTokenFromHeader)(authHeader);
        if (!token) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Access token is required',
                    timestamp: new Date().toISOString()
                }
            });
            return;
        }
        const decoded = (0, auth_1.verifyToken)(token);
        if (!decoded) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Invalid or expired token',
                    timestamp: new Date().toISOString()
                }
            });
            return;
        }
        // Add user information to request
        req.user = {
            id: decoded.id,
            email: decoded.email,
            role: decoded.role
        };
        next();
    }
    catch (error) {
        console.error('Authentication error:', error);
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Authentication failed',
                timestamp: new Date().toISOString()
            }
        });
    }
}
/**
 * Optional authentication middleware that adds user info if token exists
 * Does not reject requests without tokens
 */
function optionalAuth(req, _res, next) {
    try {
        const authHeader = req.headers.authorization;
        const token = (0, auth_1.extractTokenFromHeader)(authHeader);
        if (token) {
            const decoded = (0, auth_1.verifyToken)(token);
            if (decoded) {
                req.user = {
                    id: decoded.id,
                    email: decoded.email,
                    role: decoded.role
                };
            }
        }
        next();
    }
    catch (error) {
        // Log error but don't fail the request
        console.error('Optional auth error:', error);
        next();
    }
}
/**
 * Role-based authorization middleware factory
 * @param allowedRoles - Array of roles that can access the route
 * @returns Middleware function that checks user role
 */
function requireRole(allowedRoles) {
    return (req, res, next) => {
        if (!req.user) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: new Date().toISOString()
                }
            });
            return;
        }
        if (!allowedRoles.includes(req.user.role)) {
            res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: `Access denied. Required roles: ${allowedRoles.join(', ')}`,
                    timestamp: new Date().toISOString()
                }
            });
            return;
        }
        next();
    };
}
/**
 * Admin-only access middleware
 */
exports.requireAdmin = requireRole(['admin']);
/**
 * Manager or Admin access middleware
 */
exports.requireManagerOrAdmin = requireRole(['manager', 'admin']);
/**
 * Any authenticated user access middleware
 */
exports.requireAuth = authenticateToken;
