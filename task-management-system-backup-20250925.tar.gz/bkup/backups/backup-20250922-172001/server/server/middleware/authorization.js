"use strict";
/**
 * Authorization middleware and utilities for role-based access control
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PERMISSIONS = void 0;
exports.hasPermission = hasPermission;
exports.canAccess = canAccess;
exports.requirePermission = requirePermission;
exports.requireOwnershipOrPermission = requireOwnershipOrPermission;
exports.requireProjectMembershipOrPermission = requireProjectMembershipOrPermission;
exports.getUserPermissions = getUserPermissions;
exports.getResourcePermissions = getResourcePermissions;
exports.hasRoleLevel = hasRoleLevel;
exports.requireRoleLevel = requireRoleLevel;
/**
 * Predefined permissions for the task management system
 */
exports.PERMISSIONS = {
    // User management permissions
    'users:create': {
        resource: 'users',
        action: 'create',
        roles: ['admin']
    },
    'users:read': {
        resource: 'users',
        action: 'read',
        roles: ['admin', 'manager', 'member']
    },
    'users:update': {
        resource: 'users',
        action: 'update',
        roles: ['admin']
    },
    'users:delete': {
        resource: 'users',
        action: 'delete',
        roles: ['admin']
    },
    'users:list': {
        resource: 'users',
        action: 'list',
        roles: ['admin', 'manager']
    },
    // Project management permissions
    'projects:create': {
        resource: 'projects',
        action: 'create',
        roles: ['admin', 'manager']
    },
    'projects:read': {
        resource: 'projects',
        action: 'read',
        roles: ['admin', 'manager', 'member']
    },
    'projects:update': {
        resource: 'projects',
        action: 'update',
        roles: ['admin', 'manager']
    },
    'projects:delete': {
        resource: 'projects',
        action: 'delete',
        roles: ['admin']
    },
    'projects:manage_members': {
        resource: 'projects',
        action: 'manage_members',
        roles: ['admin', 'manager']
    },
    // Task management permissions
    'tasks:create': {
        resource: 'tasks',
        action: 'create',
        roles: ['admin', 'manager', 'member']
    },
    'tasks:read': {
        resource: 'tasks',
        action: 'read',
        roles: ['admin', 'manager', 'member']
    },
    'tasks:update': {
        resource: 'tasks',
        action: 'update',
        roles: ['admin', 'manager', 'member']
    },
    'tasks:delete': {
        resource: 'tasks',
        action: 'delete',
        roles: ['admin', 'manager']
    },
    'tasks:assign': {
        resource: 'tasks',
        action: 'assign',
        roles: ['admin', 'manager']
    },
    'tasks:update_status': {
        resource: 'tasks',
        action: 'update_status',
        roles: ['admin', 'manager', 'member']
    },
    // Reporting permissions
    'reports:view': {
        resource: 'reports',
        action: 'view',
        roles: ['admin', 'manager']
    },
    'reports:export': {
        resource: 'reports',
        action: 'export',
        roles: ['admin', 'manager']
    }
};
/**
 * Check if a user has a specific permission
 * @param userRole - User's role
 * @param permissionKey - Permission key from PERMISSIONS
 * @returns Boolean indicating if user has permission
 */
function hasPermission(userRole, permissionKey) {
    const permission = exports.PERMISSIONS[permissionKey];
    if (!permission) {
        return false;
    }
    return permission.roles.includes(userRole);
}
/**
 * Check if a user can access a specific resource with a given action
 * @param userRole - User's role
 * @param resource - Resource name
 * @param action - Action name
 * @returns Boolean indicating if user has access
 */
function canAccess(userRole, resource, action) {
    const permissionKey = `${resource}:${action}`;
    return hasPermission(userRole, permissionKey);
}
/**
 * Middleware factory for permission-based access control
 * @param permissionKey - Permission key from PERMISSIONS
 * @returns Middleware function
 */
function requirePermission(permissionKey) {
    return (req, res, next) => {
        if (!req.user) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: new Date().toISOString()
                }
            });
            return;
        }
        if (!hasPermission(req.user.role, permissionKey)) {
            const permission = exports.PERMISSIONS[permissionKey];
            res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: `Access denied. Required permission: ${permissionKey}`,
                    details: {
                        resource: permission?.resource,
                        action: permission?.action,
                        requiredRoles: permission?.roles
                    },
                    timestamp: new Date().toISOString()
                }
            });
            return;
        }
        next();
    };
}
/**
 * Middleware for resource ownership validation
 * Allows users to access their own resources even if they don't have general permission
 * @param getResourceOwnerId - Function to extract owner ID from request
 * @param permissionKey - Fallback permission for non-owners
 * @returns Middleware function
 */
function requireOwnershipOrPermission(getResourceOwnerId, permissionKey) {
    return (req, res, next) => {
        if (!req.user) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: new Date().toISOString()
                }
            });
            return;
        }
        // Check if user owns the resource
        const resourceOwnerId = getResourceOwnerId(req);
        if (resourceOwnerId && resourceOwnerId === req.user.id) {
            next();
            return;
        }
        // Check if user has general permission
        if (hasPermission(req.user.role, permissionKey)) {
            next();
            return;
        }
        // Deny access
        const permission = exports.PERMISSIONS[permissionKey];
        res.status(403).json({
            error: {
                code: 'FORBIDDEN',
                message: 'Access denied. You can only access your own resources or need higher permissions.',
                details: {
                    resource: permission?.resource,
                    action: permission?.action,
                    requiredRoles: permission?.roles
                },
                timestamp: new Date().toISOString()
            }
        });
    };
}
/**
 * Middleware for project membership validation
 * Allows project members to access project resources
 * @param getProjectId - Function to extract project ID from request
 * @param permissionKey - Fallback permission for non-members
 * @returns Middleware function
 */
function requireProjectMembershipOrPermission(getProjectId, permissionKey) {
    return async (req, res, next) => {
        if (!req.user) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: new Date().toISOString()
                }
            });
            return;
        }
        // Check if user has general permission (admin/manager)
        if (hasPermission(req.user.role, permissionKey)) {
            next();
            return;
        }
        // Check project membership (this would require database access)
        const projectId = getProjectId(req);
        if (projectId) {
            // Note: In a real implementation, you would check the database
            // for project membership. For now, we'll assume members can access
            // their project resources if they have basic read permission.
            if (req.user.role === 'member' && hasPermission(req.user.role, 'projects:read')) {
                next();
                return;
            }
        }
        // Deny access
        const permission = exports.PERMISSIONS[permissionKey];
        res.status(403).json({
            error: {
                code: 'FORBIDDEN',
                message: 'Access denied. You must be a project member or have higher permissions.',
                details: {
                    resource: permission?.resource,
                    action: permission?.action,
                    requiredRoles: permission?.roles
                },
                timestamp: new Date().toISOString()
            }
        });
    };
}
/**
 * Get user permissions based on role
 * @param userRole - User's role
 * @returns Array of permission keys the user has
 */
function getUserPermissions(userRole) {
    return Object.keys(exports.PERMISSIONS).filter(permissionKey => hasPermission(userRole, permissionKey));
}
/**
 * Get permissions by resource
 * @param resource - Resource name
 * @returns Array of permissions for the resource
 */
function getResourcePermissions(resource) {
    return Object.values(exports.PERMISSIONS).filter(permission => permission.resource === resource);
}
/**
 * Validate role hierarchy (admin > manager > member)
 * @param userRole - User's role
 * @param requiredRole - Required minimum role
 * @returns Boolean indicating if user role meets requirement
 */
function hasRoleLevel(userRole, requiredRole) {
    const roleHierarchy = {
        'member': 1,
        'manager': 2,
        'admin': 3
    };
    return roleHierarchy[userRole] >= roleHierarchy[requiredRole];
}
/**
 * Middleware for role hierarchy validation
 * @param requiredRole - Minimum required role
 * @returns Middleware function
 */
function requireRoleLevel(requiredRole) {
    return (req, res, next) => {
        if (!req.user) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: new Date().toISOString()
                }
            });
            return;
        }
        if (!hasRoleLevel(req.user.role, requiredRole)) {
            res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: `Access denied. Required role level: ${requiredRole} or higher`,
                    details: {
                        userRole: req.user.role,
                        requiredRole: requiredRole
                    },
                    timestamp: new Date().toISOString()
                }
            });
            return;
        }
        next();
    };
}
