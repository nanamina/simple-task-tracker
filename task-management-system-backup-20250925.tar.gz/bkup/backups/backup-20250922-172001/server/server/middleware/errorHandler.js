"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseError = exports.ConflictError = exports.ForbiddenError = exports.UnauthorizedError = exports.NotFoundError = exports.ValidationAppError = exports.AppError = exports.ErrorCodes = void 0;
exports.errorHandler = errorHandler;
exports.notFoundHandler = notFoundHandler;
exports.asyncHandler = asyncHandler;
exports.handleValidationErrors = handleValidationErrors;
/**
 * Error codes used throughout the application
 */
var ErrorCodes;
(function (ErrorCodes) {
    ErrorCodes["VALIDATION_ERROR"] = "VALIDATION_ERROR";
    ErrorCodes["UNAUTHORIZED"] = "UNAUTHORIZED";
    ErrorCodes["FORBIDDEN"] = "FORBIDDEN";
    ErrorCodes["NOT_FOUND"] = "NOT_FOUND";
    ErrorCodes["CONFLICT"] = "CONFLICT";
    ErrorCodes["INTERNAL_ERROR"] = "INTERNAL_ERROR";
    ErrorCodes["DATABASE_ERROR"] = "DATABASE_ERROR";
    ErrorCodes["RATE_LIMIT_ERROR"] = "RATE_LIMIT_ERROR";
})(ErrorCodes || (exports.ErrorCodes = ErrorCodes = {}));
/**
 * Custom application error class
 */
class AppError extends Error {
    constructor(message, statusCode = 500, code = ErrorCodes.INTERNAL_ERROR, details, isOperational = true) {
        super(message);
        this.statusCode = statusCode;
        this.code = code;
        this.details = details;
        this.isOperational = isOperational;
        // Maintain proper stack trace
        Error.captureStackTrace(this, this.constructor);
    }
}
exports.AppError = AppError;
/**
 * Validation error class for form validation
 */
class ValidationAppError extends AppError {
    constructor(message, details) {
        super(message, 422, ErrorCodes.VALIDATION_ERROR, details);
    }
}
exports.ValidationAppError = ValidationAppError;
/**
 * Not found error class
 */
class NotFoundError extends AppError {
    constructor(resource = 'Resource') {
        super(`${resource} not found`, 404, ErrorCodes.NOT_FOUND);
    }
}
exports.NotFoundError = NotFoundError;
/**
 * Unauthorized error class
 */
class UnauthorizedError extends AppError {
    constructor(message = 'Authentication required') {
        super(message, 401, ErrorCodes.UNAUTHORIZED);
    }
}
exports.UnauthorizedError = UnauthorizedError;
/**
 * Forbidden error class
 */
class ForbiddenError extends AppError {
    constructor(message = 'Access denied') {
        super(message, 403, ErrorCodes.FORBIDDEN);
    }
}
exports.ForbiddenError = ForbiddenError;
/**
 * Conflict error class
 */
class ConflictError extends AppError {
    constructor(message, details) {
        super(message, 409, ErrorCodes.CONFLICT, details);
    }
}
exports.ConflictError = ConflictError;
/**
 * Database error class
 */
class DatabaseError extends AppError {
    constructor(message, details) {
        super(message, 500, ErrorCodes.DATABASE_ERROR, details);
    }
}
exports.DatabaseError = DatabaseError;
/**
 * Generate unique request ID for error tracking
 */
function generateRequestId() {
    return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}
/**
 * Log error with context information
 */
function logError(error, req, requestId) {
    const logData = {
        requestId,
        timestamp: new Date().toISOString(),
        method: req.method,
        url: req.url,
        userAgent: req.get('User-Agent'),
        ip: req.ip,
        userId: req.user?.id,
        error: {
            name: error.name,
            message: error.message,
            stack: error.stack,
            ...(error instanceof AppError && {
                code: error.code,
                statusCode: error.statusCode,
                details: error.details,
                isOperational: error.isOperational,
            }),
        },
    };
    // Log based on error severity
    if (error instanceof AppError && error.isOperational) {
        // Operational errors (expected) - log as warning
        console.warn('Operational Error:', JSON.stringify(logData, null, 2));
    }
    else {
        // Programming errors (unexpected) - log as error
        console.error('Programming Error:', JSON.stringify(logData, null, 2));
    }
    // In production, send to error monitoring service
    if (process.env.NODE_ENV === 'production') {
        // Example: sendToErrorService(logData)
    }
}
/**
 * Handle database errors and convert to appropriate AppError
 */
function handleDatabaseError(error) {
    // PostgreSQL error codes
    switch (error.code) {
        case '23505': // unique_violation
            return new ConflictError('Resource already exists', {
                constraint: error.constraint,
                detail: error.detail,
            });
        case '23503': // foreign_key_violation
            return new ValidationAppError('Referenced resource does not exist', {
                constraint: error.constraint,
                detail: error.detail,
            });
        case '23502': // not_null_violation
            return new ValidationAppError('Required field is missing', {
                column: error.column,
            });
        case '23514': // check_violation
            return new ValidationAppError('Invalid data format', {
                constraint: error.constraint,
            });
        case '42P01': // undefined_table
        case '42703': // undefined_column
            return new DatabaseError('Database schema error', {
                code: error.code,
                message: error.message,
            });
        default:
            return new DatabaseError('Database operation failed', {
                code: error.code,
                message: error.message,
            });
    }
}
/**
 * Convert express-validator errors to our format
 */
function formatValidationErrors(errors) {
    return errors.map(error => ({
        field: error.type === 'field' ? error.path : error.type,
        message: error.msg,
        value: error.type === 'field' ? error.value : undefined,
    }));
}
/**
 * Main error handling middleware
 * Should be the last middleware in the chain
 */
function errorHandler(error, req, res, _next) {
    const requestId = generateRequestId();
    // Log the error
    logError(error, req, requestId);
    let appError;
    // Convert different error types to AppError
    if (error instanceof AppError) {
        appError = error;
    }
    else if (error.name === 'ValidationError' && 'errors' in error) {
        // Mongoose validation errors
        appError = new ValidationAppError('Validation failed', error);
    }
    else if (error.name === 'CastError') {
        // Database casting errors
        appError = new ValidationAppError('Invalid data format');
    }
    else if (error.message?.includes('duplicate key') || error.message?.includes('unique constraint')) {
        // Database unique constraint errors
        appError = new ConflictError('Resource already exists');
    }
    else if (error.name === 'JsonWebTokenError') {
        appError = new UnauthorizedError('Invalid token');
    }
    else if (error.name === 'TokenExpiredError') {
        appError = new UnauthorizedError('Token expired');
    }
    else if (error.name === 'SyntaxError' && 'body' in error) {
        appError = new ValidationAppError('Invalid JSON format');
    }
    else if ('code' in error && typeof error.code === 'string') {
        // Database errors
        appError = handleDatabaseError(error);
    }
    else {
        // Unknown errors
        appError = new AppError(process.env.NODE_ENV === 'production'
            ? 'Internal server error'
            : error.message, 500, ErrorCodes.INTERNAL_ERROR, process.env.NODE_ENV === 'development' ? { stack: error.stack } : undefined, false);
    }
    // Create error response
    const errorResponse = {
        error: {
            code: appError.code,
            message: appError.message,
            timestamp: new Date().toISOString(),
            requestId,
            ...(appError.details && { details: appError.details }),
        },
    };
    // Send error response
    res.status(appError.statusCode).json(errorResponse);
}
/**
 * 404 handler for unmatched routes
 */
function notFoundHandler(req, res, _next) {
    const error = new NotFoundError(`Route ${req.method} ${req.path} not found`);
    const requestId = generateRequestId();
    const errorResponse = {
        error: {
            code: error.code,
            message: error.message,
            timestamp: new Date().toISOString(),
            requestId,
        },
    };
    res.status(404).json(errorResponse);
}
/**
 * Async error wrapper for route handlers
 * Catches async errors and passes them to error middleware
 */
function asyncHandler(fn) {
    return (req, res, next) => {
        Promise.resolve(fn(req, res, next)).catch(next);
    };
}
/**
 * Validation error handler for express-validator
 */
function handleValidationErrors(req, _res, next) {
    const { validationResult } = require('express-validator');
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const formattedErrors = formatValidationErrors(errors.array());
        throw new ValidationAppError('Validation failed', formattedErrors);
    }
    next();
}
