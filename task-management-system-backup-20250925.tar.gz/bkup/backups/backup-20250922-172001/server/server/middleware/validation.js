"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateJapaneseText = exports.sanitizeHtml = exports.validateRoleUpdate = exports.validatePaginationQuery = exports.validateTaskFilters = exports.validateUUIDParam = exports.validateProjectMemberManagement = exports.validateProjectUpdate = exports.validateProjectCreation = exports.validateTaskStatusUpdate = exports.validateTaskUpdate = exports.validateTaskCreation = exports.validateUserProfileUpdate = exports.validateUserLogin = exports.validateUserRegistration = void 0;
const express_validator_1 = require("express-validator");
// Define the valid values for validation
const TASK_STATUSES = ['todo', 'in-progress', 'completed'];
const TASK_PRIORITIES = ['low', 'medium', 'high', 'critical'];
const USER_ROLES = ['admin', 'manager', 'member'];
const LANGUAGES = ['ja', 'en'];
/**
 * Common validation rules for the task management system
 */
// User validation rules
const validateUserRegistration = () => [
    (0, express_validator_1.body)('name')
        .trim()
        .notEmpty()
        .withMessage('Name is required')
        .isLength({ min: 2, max: 100 })
        .withMessage('Name must be between 2 and 100 characters')
        .matches(/^[a-zA-Z\s\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]+$/)
        .withMessage('Name can only contain letters and spaces'),
    (0, express_validator_1.body)('email')
        .trim()
        .notEmpty()
        .withMessage('Email is required')
        .isEmail()
        .withMessage('Please provide a valid email address')
        .normalizeEmail()
        .isLength({ max: 255 })
        .withMessage('Email must be no more than 255 characters'),
    (0, express_validator_1.body)('password')
        .notEmpty()
        .withMessage('Password is required')
        .isLength({ min: 8, max: 128 })
        .withMessage('Password must be between 8 and 128 characters')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).*$/)
        .withMessage('Password must contain at least one lowercase letter, one uppercase letter, and one number'),
    (0, express_validator_1.body)('confirmPassword')
        .notEmpty()
        .withMessage('Password confirmation is required')
        .custom((value, { req }) => {
        if (value !== req.body.password) {
            throw new Error('Passwords do not match');
        }
        return true;
    }),
];
exports.validateUserRegistration = validateUserRegistration;
const validateUserLogin = () => [
    (0, express_validator_1.body)('email')
        .trim()
        .notEmpty()
        .withMessage('Email is required')
        .isEmail()
        .withMessage('Please provide a valid email address')
        .normalizeEmail(),
    (0, express_validator_1.body)('password')
        .notEmpty()
        .withMessage('Password is required'),
];
exports.validateUserLogin = validateUserLogin;
const validateUserProfileUpdate = () => [
    (0, express_validator_1.body)('name')
        .optional()
        .trim()
        .isLength({ min: 2, max: 100 })
        .withMessage('Name must be between 2 and 100 characters')
        .matches(/^[a-zA-Z\s\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]+$/)
        .withMessage('Name can only contain letters and spaces'),
    (0, express_validator_1.body)('email')
        .optional()
        .trim()
        .isEmail()
        .withMessage('Please provide a valid email address')
        .normalizeEmail()
        .isLength({ max: 255 })
        .withMessage('Email must be no more than 255 characters'),
    (0, express_validator_1.body)('preferredLanguage')
        .optional()
        .isIn(LANGUAGES)
        .withMessage(`Preferred language must be one of: ${LANGUAGES.join(', ')}`),
];
exports.validateUserProfileUpdate = validateUserProfileUpdate;
// Task validation rules
const validateTaskCreation = () => [
    (0, express_validator_1.body)('title')
        .trim()
        .notEmpty()
        .withMessage('Task title is required')
        .isLength({ min: 1, max: 255 })
        .withMessage('Task title must be between 1 and 255 characters'),
    (0, express_validator_1.body)('description')
        .optional()
        .trim()
        .isLength({ max: 2000 })
        .withMessage('Task description must be no more than 2000 characters'),
    (0, express_validator_1.body)('status')
        .optional()
        .isIn(TASK_STATUSES)
        .withMessage(`Status must be one of: ${TASK_STATUSES.join(', ')}`),
    (0, express_validator_1.body)('priority')
        .optional()
        .isIn(TASK_PRIORITIES)
        .withMessage(`Priority must be one of: ${TASK_PRIORITIES.join(', ')}`),
    (0, express_validator_1.body)('dueDate')
        .optional()
        .isISO8601()
        .withMessage('Due date must be a valid ISO 8601 date')
        .custom((value) => {
        if (value) {
            const date = new Date(value);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            if (date < today) {
                throw new Error('Due date cannot be in the past');
            }
        }
        return true;
    }),
    (0, express_validator_1.body)('assigneeId')
        .optional()
        .isUUID()
        .withMessage('Assignee ID must be a valid UUID'),
    (0, express_validator_1.body)('projectId')
        .optional()
        .isUUID()
        .withMessage('Project ID must be a valid UUID'),
];
exports.validateTaskCreation = validateTaskCreation;
const validateTaskUpdate = () => [
    (0, express_validator_1.param)('id')
        .isUUID()
        .withMessage('Task ID must be a valid UUID'),
    (0, express_validator_1.body)('title')
        .optional()
        .trim()
        .notEmpty()
        .withMessage('Task title cannot be empty')
        .isLength({ min: 1, max: 255 })
        .withMessage('Task title must be between 1 and 255 characters'),
    (0, express_validator_1.body)('description')
        .optional()
        .trim()
        .isLength({ max: 2000 })
        .withMessage('Task description must be no more than 2000 characters'),
    (0, express_validator_1.body)('status')
        .optional()
        .isIn(TASK_STATUSES)
        .withMessage(`Status must be one of: ${TASK_STATUSES.join(', ')}`),
    (0, express_validator_1.body)('priority')
        .optional()
        .isIn(TASK_PRIORITIES)
        .withMessage(`Priority must be one of: ${TASK_PRIORITIES.join(', ')}`),
    (0, express_validator_1.body)('dueDate')
        .optional()
        .custom((value) => {
        if (value === null || value === '') {
            return true; // Allow clearing due date
        }
        if (!value) {
            return true; // Skip validation if not provided
        }
        // Validate ISO 8601 format
        const date = new Date(value);
        if (isNaN(date.getTime())) {
            throw new Error('Due date must be a valid ISO 8601 date');
        }
        return true;
    }),
    (0, express_validator_1.body)('assigneeId')
        .optional()
        .custom((value) => {
        if (value === null || value === '') {
            return true; // Allow clearing assignee
        }
        if (value && !value.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i)) {
            throw new Error('Assignee ID must be a valid UUID');
        }
        return true;
    }),
    (0, express_validator_1.body)('projectId')
        .optional()
        .custom((value) => {
        if (value === null || value === '') {
            return true; // Allow clearing project
        }
        if (value && !value.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i)) {
            throw new Error('Project ID must be a valid UUID');
        }
        return true;
    }),
];
exports.validateTaskUpdate = validateTaskUpdate;
const validateTaskStatusUpdate = () => [
    (0, express_validator_1.param)('id')
        .isUUID()
        .withMessage('Task ID must be a valid UUID'),
    (0, express_validator_1.body)('status')
        .notEmpty()
        .withMessage('Status is required')
        .isIn(TASK_STATUSES)
        .withMessage(`Status must be one of: ${TASK_STATUSES.join(', ')}`),
];
exports.validateTaskStatusUpdate = validateTaskStatusUpdate;
// Project validation rules
const validateProjectCreation = () => [
    (0, express_validator_1.body)('name')
        .trim()
        .notEmpty()
        .withMessage('Project name is required')
        .isLength({ min: 1, max: 255 })
        .withMessage('Project name must be between 1 and 255 characters'),
    (0, express_validator_1.body)('description')
        .optional()
        .trim()
        .isLength({ max: 2000 })
        .withMessage('Project description must be no more than 2000 characters'),
];
exports.validateProjectCreation = validateProjectCreation;
const validateProjectUpdate = () => [
    (0, express_validator_1.param)('id')
        .isUUID()
        .withMessage('Project ID must be a valid UUID'),
    (0, express_validator_1.body)('name')
        .optional()
        .trim()
        .notEmpty()
        .withMessage('Project name cannot be empty')
        .isLength({ min: 1, max: 255 })
        .withMessage('Project name must be between 1 and 255 characters'),
    (0, express_validator_1.body)('description')
        .optional()
        .trim()
        .isLength({ max: 2000 })
        .withMessage('Project description must be no more than 2000 characters'),
];
exports.validateProjectUpdate = validateProjectUpdate;
const validateProjectMemberManagement = () => [
    (0, express_validator_1.param)('id')
        .isUUID()
        .withMessage('Project ID must be a valid UUID'),
    (0, express_validator_1.body)('userId')
        .notEmpty()
        .withMessage('User ID is required')
        .isUUID()
        .withMessage('User ID must be a valid UUID'),
];
exports.validateProjectMemberManagement = validateProjectMemberManagement;
// Common parameter validations
const validateUUIDParam = (paramName = 'id') => [
    (0, express_validator_1.param)(paramName)
        .isUUID()
        .withMessage(`${paramName} must be a valid UUID`),
];
exports.validateUUIDParam = validateUUIDParam;
// Query parameter validations
const validateTaskFilters = () => [
    (0, express_validator_1.query)('status')
        .optional()
        .isIn(TASK_STATUSES)
        .withMessage(`Status must be one of: ${TASK_STATUSES.join(', ')}`),
    (0, express_validator_1.query)('priority')
        .optional()
        .isIn(TASK_PRIORITIES)
        .withMessage(`Priority must be one of: ${TASK_PRIORITIES.join(', ')}`),
    (0, express_validator_1.query)('assigneeId')
        .optional()
        .isUUID()
        .withMessage('Assignee ID must be a valid UUID'),
    (0, express_validator_1.query)('projectId')
        .optional()
        .isUUID()
        .withMessage('Project ID must be a valid UUID'),
    (0, express_validator_1.query)('search')
        .optional()
        .trim()
        .isLength({ max: 255 })
        .withMessage('Search query must be no more than 255 characters'),
    (0, express_validator_1.query)('limit')
        .optional()
        .isInt({ min: 1, max: 100 })
        .withMessage('Limit must be between 1 and 100'),
    (0, express_validator_1.query)('offset')
        .optional()
        .isInt({ min: 0 })
        .withMessage('Offset must be a non-negative integer'),
];
exports.validateTaskFilters = validateTaskFilters;
const validatePaginationQuery = () => [
    (0, express_validator_1.query)('page')
        .optional()
        .isInt({ min: 1 })
        .withMessage('Page must be a positive integer'),
    (0, express_validator_1.query)('limit')
        .optional()
        .isInt({ min: 1, max: 100 })
        .withMessage('Limit must be between 1 and 100'),
];
exports.validatePaginationQuery = validatePaginationQuery;
// Role validation
const validateRoleUpdate = () => [
    (0, express_validator_1.body)('role')
        .notEmpty()
        .withMessage('Role is required')
        .isIn(USER_ROLES)
        .withMessage(`Role must be one of: ${USER_ROLES.join(', ')}`),
];
exports.validateRoleUpdate = validateRoleUpdate;
/**
 * Sanitization helpers
 */
const sanitizeHtml = (field) => (0, express_validator_1.body)(field).customSanitizer((value) => {
    if (typeof value !== 'string')
        return value;
    // Basic HTML sanitization - remove script tags and dangerous attributes
    return value
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
        .replace(/on\w+="[^"]*"/gi, '')
        .replace(/javascript:/gi, '');
});
exports.sanitizeHtml = sanitizeHtml;
/**
 * Custom validation for Japanese text support
 */
const validateJapaneseText = (field, required = false) => {
    const validator = (0, express_validator_1.body)(field)
        .trim()
        .custom((value) => {
        if (!required && (!value || value === '')) {
            return true;
        }
        if (required && (!value || value === '')) {
            throw new Error(`${field} is required`);
        }
        // Allow Japanese characters, English letters, numbers, and common punctuation
        const japaneseTextRegex = /^[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF\w\s.,!?;:'"()\-_@#$%&*+=<>{}[\]|\\\/~`]*$/;
        if (!japaneseTextRegex.test(value)) {
            throw new Error(`${field} contains invalid characters`);
        }
        return true;
    });
    return validator;
};
exports.validateJapaneseText = validateJapaneseText;
