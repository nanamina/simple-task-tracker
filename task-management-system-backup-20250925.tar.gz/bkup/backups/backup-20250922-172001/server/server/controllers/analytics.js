"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnalyticsController = void 0;
const analytics_1 = require("../services/analytics");
const task_repository_1 = require("../repositories/task-repository");
const project_repository_1 = require("../repositories/project-repository");
const user_repository_1 = require("../repositories/user-repository");
/**
 * Analytics controller for handling reporting and metrics endpoints
 */
class AnalyticsController {
    constructor(db) {
        const taskRepository = new task_repository_1.TaskRepository(db);
        const projectRepository = new project_repository_1.ProjectRepository(db);
        const userRepository = new user_repository_1.UserRepository(db);
        this.analyticsService = new analytics_1.AnalyticsService(taskRepository, projectRepository, userRepository);
    }
    /**
     * Get project metrics and analytics
     * GET /api/analytics/projects/:projectId/metrics
     */
    async getProjectMetrics(req, res) {
        try {
            const { projectId } = req.params;
            if (!projectId) {
                res.status(400).json({
                    error: {
                        code: 'VALIDATION_ERROR',
                        message: 'Project ID is required',
                        timestamp: new Date().toISOString()
                    }
                });
                return;
            }
            const metrics = await this.analyticsService.getProjectMetrics(projectId);
            res.json({
                success: true,
                data: metrics
            });
        }
        catch (error) {
            console.error('Error getting project metrics:', error);
            if (error instanceof Error && error.message.includes('not found')) {
                res.status(404).json({
                    error: {
                        code: 'NOT_FOUND',
                        message: 'Project not found',
                        timestamp: new Date().toISOString()
                    }
                });
                return;
            }
            res.status(500).json({
                error: {
                    code: 'INTERNAL_ERROR',
                    message: 'Failed to get project metrics',
                    timestamp: new Date().toISOString()
                }
            });
        }
    }
    /**
     * Get team workload distribution
     * GET /api/analytics/workload?projectId=optional
     */
    async getTeamWorkload(req, res) {
        try {
            const { projectId } = req.query;
            const workload = await this.analyticsService.getTeamWorkload(projectId);
            res.json({
                success: true,
                data: workload
            });
        }
        catch (error) {
            console.error('Error getting team workload:', error);
            res.status(500).json({
                error: {
                    code: 'INTERNAL_ERROR',
                    message: 'Failed to get team workload',
                    timestamp: new Date().toISOString()
                }
            });
        }
    }
    /**
     * Get task completion trends over time
     * GET /api/analytics/trends?projectId=optional&days=30
     */
    async getCompletionTrends(req, res) {
        try {
            const { projectId, days } = req.query;
            const daysNumber = days ? parseInt(days, 10) : 30;
            if (isNaN(daysNumber) || daysNumber < 1 || daysNumber > 365) {
                res.status(400).json({
                    error: {
                        code: 'VALIDATION_ERROR',
                        message: 'Days must be a number between 1 and 365',
                        timestamp: new Date().toISOString()
                    }
                });
                return;
            }
            const trends = await this.analyticsService.getCompletionTrends(projectId, daysNumber);
            res.json({
                success: true,
                data: trends
            });
        }
        catch (error) {
            console.error('Error getting completion trends:', error);
            res.status(500).json({
                error: {
                    code: 'INTERNAL_ERROR',
                    message: 'Failed to get completion trends',
                    timestamp: new Date().toISOString()
                }
            });
        }
    }
    /**
     * Generate comprehensive project report
     * GET /api/analytics/projects/:projectId/report
     */
    async generateProjectReport(req, res) {
        try {
            const { projectId } = req.params;
            if (!projectId) {
                res.status(400).json({
                    error: {
                        code: 'VALIDATION_ERROR',
                        message: 'Project ID is required',
                        timestamp: new Date().toISOString()
                    }
                });
                return;
            }
            const report = await this.analyticsService.generateProjectReport(projectId);
            res.json({
                success: true,
                data: report
            });
        }
        catch (error) {
            console.error('Error generating project report:', error);
            if (error instanceof Error && error.message.includes('not found')) {
                res.status(404).json({
                    error: {
                        code: 'NOT_FOUND',
                        message: 'Project not found',
                        timestamp: new Date().toISOString()
                    }
                });
                return;
            }
            res.status(500).json({
                error: {
                    code: 'INTERNAL_ERROR',
                    message: 'Failed to generate project report',
                    timestamp: new Date().toISOString()
                }
            });
        }
    }
    /**
     * Export project report as CSV
     * GET /api/analytics/projects/:projectId/export
     */
    async exportProjectReport(req, res) {
        try {
            const { projectId } = req.params;
            const { format = 'csv' } = req.query;
            if (!projectId) {
                res.status(400).json({
                    error: {
                        code: 'VALIDATION_ERROR',
                        message: 'Project ID is required',
                        timestamp: new Date().toISOString()
                    }
                });
                return;
            }
            const report = await this.analyticsService.generateProjectReport(projectId);
            if (format === 'csv') {
                // Generate CSV content
                const csvContent = this.generateCSVReport(report);
                res.setHeader('Content-Type', 'text/csv');
                res.setHeader('Content-Disposition', `attachment; filename="project-${projectId}-report.csv"`);
                res.send(csvContent);
            }
            else if (format === 'json') {
                res.setHeader('Content-Type', 'application/json');
                res.setHeader('Content-Disposition', `attachment; filename="project-${projectId}-report.json"`);
                res.json(report);
            }
            else {
                res.status(400).json({
                    error: {
                        code: 'VALIDATION_ERROR',
                        message: 'Unsupported export format. Use csv or json.',
                        timestamp: new Date().toISOString()
                    }
                });
            }
        }
        catch (error) {
            console.error('Error exporting project report:', error);
            res.status(500).json({
                error: {
                    code: 'INTERNAL_ERROR',
                    message: 'Failed to export project report',
                    timestamp: new Date().toISOString()
                }
            });
        }
    }
    /**
     * Generate CSV content from project report data
     * @param report - Project report data
     * @returns CSV string
     */
    generateCSVReport(report) {
        const lines = [];
        // Header
        lines.push('Project Report');
        lines.push(`Generated: ${report.generatedAt}`);
        lines.push(`Project: ${report.project.name}`);
        lines.push('');
        // Summary
        lines.push('Summary');
        lines.push('Metric,Value');
        lines.push(`Total Tasks,${report.summary.totalTasks}`);
        lines.push(`Completion Rate,${report.summary.completionRate}%`);
        lines.push(`Average Task Duration,${report.summary.averageTaskDuration} days`);
        lines.push(`Overdue Tasks,${report.summary.overdueTasksCount}`);
        lines.push('');
        // Status Distribution
        lines.push('Status Distribution');
        lines.push('Status,Count');
        Object.entries(report.statusDistribution).forEach(([status, count]) => {
            lines.push(`${status},${count}`);
        });
        lines.push('');
        // Team Workload
        lines.push('Team Workload');
        lines.push('User,Total Tasks,Completed,In Progress,Todo,Overdue,Completion Rate');
        report.teamWorkload.forEach((member) => {
            lines.push(`${member.userName},${member.totalTasks},${member.completedTasks},${member.inProgressTasks},${member.todoTasks},${member.overdueTasks},${member.completionRate}%`);
        });
        lines.push('');
        // Completion Trends (last 10 days)
        lines.push('Recent Completion Trends');
        lines.push('Date,Completed Tasks');
        report.completionTrends.slice(-10).forEach((trend) => {
            lines.push(`${trend.date},${trend.completedTasks}`);
        });
        return lines.join('\n');
    }
}
exports.AnalyticsController = AnalyticsController;
