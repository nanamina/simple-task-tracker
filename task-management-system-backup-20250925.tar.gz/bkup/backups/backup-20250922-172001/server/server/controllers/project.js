"use strict";
/**
 * Project management controllers
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addMemberValidation = exports.userIdValidation = exports.projectIdValidation = exports.updateProjectValidation = exports.createProjectValidation = exports.projectQueryValidation = void 0;
exports.listProjects = listProjects;
exports.createProject = createProject;
exports.getProject = getProject;
exports.updateProject = updateProject;
exports.deleteProject = deleteProject;
exports.getProjectTasks = getProjectTasks;
exports.getProjectMembers = getProjectMembers;
exports.addProjectMember = addProjectMember;
exports.removeProjectMember = removeProjectMember;
exports.getProjectMetrics = getProjectMetrics;
const express_validator_1 = require("express-validator");
const project_repository_1 = require("../repositories/project-repository");
const task_repository_1 = require("../repositories/task-repository");
const user_repository_1 = require("../repositories/user-repository");
const database_1 = require("../config/database");
const validation_1 = require("../../shared/types/validation");
require("../middleware/auth"); // Import to ensure type augmentation is loaded
// Initialize repositories
const db = (0, database_1.getPool)();
const projectRepository = new project_repository_1.ProjectRepository(db);
const taskRepository = new task_repository_1.TaskRepository(db);
const userRepository = new user_repository_1.UserRepository(db);
/**
 * List projects with optional filtering
 * GET /api/projects
 */
async function listProjects(req, res) {
    try {
        const errors = (0, express_validator_1.validationResult)(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid query parameters',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            });
        }
        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;
        const memberOnly = req.query.memberOnly === 'true';
        const search = req.query.search;
        const sortBy = req.query.sortBy || 'createdAt';
        const sortOrder = req.query.sortOrder || 'desc';
        // Build filter options
        const filters = {};
        if (search)
            filters.search = search;
        // Build sort options
        const sort = {
            field: sortBy,
            direction: sortOrder
        };
        let projects;
        if (memberOnly) {
            // Get only projects where user is a member
            projects = await projectRepository.getProjectsByMember(req.user.id);
        }
        else {
            // Get all projects (admin/manager) or user's projects (member)
            if (req.user.role === 'admin' || req.user.role === 'manager') {
                projects = await projectRepository.listProjects(filters, sort, limit, offset);
            }
            else {
                projects = await projectRepository.getProjectsByMember(req.user.id);
            }
        }
        res.json({
            projects,
            pagination: {
                limit,
                offset,
                total: projects.length
            }
        });
    }
    catch (error) {
        console.error('Error listing projects:', error);
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to list projects',
                timestamp: new Date().toISOString()
            }
        });
    }
}
/**
 * Create a new project
 * POST /api/projects
 */
async function createProject(req, res) {
    try {
        const errors = (0, express_validator_1.validationResult)(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project data',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            });
        }
        // Additional validation using shared validation functions
        const validation = (0, validation_1.validateCreateProject)(req.body);
        if (!validation.isValid) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project data',
                    details: validation.errors,
                    timestamp: new Date().toISOString()
                }
            });
        }
        const project = await projectRepository.createProject(req.body, req.user.id);
        res.status(201).json({
            message: 'Project created successfully',
            project
        });
    }
    catch (error) {
        console.error('Error creating project:', error);
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to create project',
                timestamp: new Date().toISOString()
            }
        });
    }
}
/**
 * Get a specific project by ID
 * GET /api/projects/:id
 */
async function getProject(req, res) {
    try {
        const errors = (0, express_validator_1.validationResult)(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project ID',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            });
        }
        const projectId = req.params.id;
        const project = await projectRepository.findById(projectId);
        if (!project) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            });
        }
        // Check if user has access to this project
        const isAdmin = req.user.role === 'admin';
        const isManager = req.user.role === 'manager';
        if (!isAdmin && !isManager) {
            const isMember = await projectRepository.isMember(projectId, req.user.id);
            if (!isMember) {
                return res.status(403).json({
                    error: {
                        code: 'FORBIDDEN',
                        message: 'Access denied to this project',
                        timestamp: new Date().toISOString()
                    }
                });
            }
        }
        res.json({ project });
    }
    catch (error) {
        console.error('Error getting project:', error);
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to get project',
                timestamp: new Date().toISOString()
            }
        });
    }
}
/**
 * Update a project
 * PUT /api/projects/:id
 */
async function updateProject(req, res) {
    try {
        const errors = (0, express_validator_1.validationResult)(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project data',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            });
        }
        // Additional validation using shared validation functions
        const validation = (0, validation_1.validateUpdateProject)(req.body);
        if (!validation.isValid) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project data',
                    details: validation.errors,
                    timestamp: new Date().toISOString()
                }
            });
        }
        const projectId = req.params.id;
        // Check if project exists and user has access
        const existingProject = await projectRepository.findById(projectId);
        if (!existingProject) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            });
        }
        // Check permissions - only project creator, managers, or admins can update
        const isCreator = existingProject.createdBy === req.user.id;
        const isAdmin = req.user.role === 'admin';
        const isManager = req.user.role === 'manager';
        if (!isCreator && !isAdmin && !isManager) {
            return res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied to update this project',
                    timestamp: new Date().toISOString()
                }
            });
        }
        const updatedProject = await projectRepository.updateProject(projectId, req.body);
        if (!updatedProject) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            });
        }
        res.json({
            message: 'Project updated successfully',
            project: updatedProject
        });
    }
    catch (error) {
        console.error('Error updating project:', error);
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to update project',
                timestamp: new Date().toISOString()
            }
        });
    }
}
/**
 * Delete a project
 * DELETE /api/projects/:id
 */
async function deleteProject(req, res) {
    try {
        const errors = (0, express_validator_1.validationResult)(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project ID',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            });
        }
        const projectId = req.params.id;
        // Check if project exists and user has access
        const existingProject = await projectRepository.findById(projectId);
        if (!existingProject) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            });
        }
        // Check permissions - only project creator or admins can delete
        const isCreator = existingProject.createdBy === req.user.id;
        const isAdmin = req.user.role === 'admin';
        if (!isCreator && !isAdmin) {
            return res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied to delete this project',
                    timestamp: new Date().toISOString()
                }
            });
        }
        const deleted = await projectRepository.deleteProject(projectId);
        if (!deleted) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            });
        }
        res.json({
            message: 'Project deleted successfully'
        });
    }
    catch (error) {
        console.error('Error deleting project:', error);
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to delete project',
                timestamp: new Date().toISOString()
            }
        });
    }
} /**

 * Get project tasks
 * GET /api/projects/:id/tasks
 */
async function getProjectTasks(req, res) {
    try {
        const errors = (0, express_validator_1.validationResult)(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project ID',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            });
        }
        const projectId = req.params.id;
        // Check if project exists and user has access
        const project = await projectRepository.findById(projectId);
        if (!project) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            });
        }
        const isMember = await projectRepository.isMember(projectId, req.user.id);
        const isAdmin = req.user.role === 'admin';
        const isManager = req.user.role === 'manager';
        if (!isMember && !isAdmin && !isManager) {
            return res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied to this project',
                    timestamp: new Date().toISOString()
                }
            });
        }
        const tasks = await taskRepository.getTasksByProject(projectId);
        res.json({
            project: {
                id: project.id,
                name: project.name
            },
            tasks
        });
    }
    catch (error) {
        console.error('Error getting project tasks:', error);
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to get project tasks',
                timestamp: new Date().toISOString()
            }
        });
    }
}
/**
 * Get project members
 * GET /api/projects/:id/members
 */
async function getProjectMembers(req, res) {
    try {
        const errors = (0, express_validator_1.validationResult)(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project ID',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            });
        }
        const projectId = req.params.id;
        // Check if project exists and user has access
        const project = await projectRepository.findById(projectId);
        if (!project) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            });
        }
        const isMember = await projectRepository.isMember(projectId, req.user.id);
        const isAdmin = req.user.role === 'admin';
        const isManager = req.user.role === 'manager';
        if (!isMember && !isAdmin && !isManager) {
            return res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied to this project',
                    timestamp: new Date().toISOString()
                }
            });
        }
        const members = await projectRepository.getProjectMembers(projectId);
        res.json({
            project: {
                id: project.id,
                name: project.name
            },
            members
        });
    }
    catch (error) {
        console.error('Error getting project members:', error);
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to get project members',
                timestamp: new Date().toISOString()
            }
        });
    }
}
/**
 * Add member to project
 * POST /api/projects/:id/members
 */
async function addProjectMember(req, res) {
    try {
        const errors = (0, express_validator_1.validationResult)(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid request data',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            });
        }
        const projectId = req.params.id;
        const { userId } = req.body;
        // Check if project exists
        const project = await projectRepository.findById(projectId);
        if (!project) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            });
        }
        // Check permissions - only project creator, managers, or admins can add members
        const isCreator = project.createdBy === req.user.id;
        const isAdmin = req.user.role === 'admin';
        const isManager = req.user.role === 'manager';
        if (!isCreator && !isAdmin && !isManager) {
            return res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied to manage project members',
                    timestamp: new Date().toISOString()
                }
            });
        }
        // Check if user exists
        const user = await userRepository.findById(userId);
        if (!user) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'User not found',
                    timestamp: new Date().toISOString()
                }
            });
        }
        // Check if user is already a member
        const isAlreadyMember = await projectRepository.isMember(projectId, userId);
        if (isAlreadyMember) {
            return res.status(409).json({
                error: {
                    code: 'CONFLICT',
                    message: 'User is already a member of this project',
                    timestamp: new Date().toISOString()
                }
            });
        }
        await projectRepository.addMember(projectId, userId);
        res.status(201).json({
            message: 'Member added to project successfully',
            member: {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role
            }
        });
    }
    catch (error) {
        console.error('Error adding project member:', error);
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to add project member',
                timestamp: new Date().toISOString()
            }
        });
    }
}
/**
 * Remove member from project
 * DELETE /api/projects/:id/members/:userId
 */
async function removeProjectMember(req, res) {
    try {
        const errors = (0, express_validator_1.validationResult)(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid request data',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            });
        }
        const projectId = req.params.id;
        const userId = req.params.userId;
        // Check if project exists
        const project = await projectRepository.findById(projectId);
        if (!project) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            });
        }
        // Check permissions - only project creator, managers, or admins can remove members
        // Users can also remove themselves
        const isCreator = project.createdBy === req.user.id;
        const isAdmin = req.user.role === 'admin';
        const isManager = req.user.role === 'manager';
        const isSelf = userId === req.user.id;
        if (!isCreator && !isAdmin && !isManager && !isSelf) {
            return res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied to manage project members',
                    timestamp: new Date().toISOString()
                }
            });
        }
        // Prevent removing the project creator
        if (userId === project.createdBy) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Cannot remove project creator from project',
                    timestamp: new Date().toISOString()
                }
            });
        }
        // Check if user is a member
        const isMember = await projectRepository.isMember(projectId, userId);
        if (!isMember) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'User is not a member of this project',
                    timestamp: new Date().toISOString()
                }
            });
        }
        const removed = await projectRepository.removeMember(projectId, userId);
        if (!removed) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Member not found in project',
                    timestamp: new Date().toISOString()
                }
            });
        }
        res.json({
            message: 'Member removed from project successfully'
        });
    }
    catch (error) {
        console.error('Error removing project member:', error);
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to remove project member',
                timestamp: new Date().toISOString()
            }
        });
    }
}
/**
 * Get project metrics and dashboard data
 * GET /api/projects/:id/metrics
 */
async function getProjectMetrics(req, res) {
    try {
        const errors = (0, express_validator_1.validationResult)(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project ID',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            });
        }
        const projectId = req.params.id;
        // Check if project exists and user has access
        const project = await projectRepository.findById(projectId);
        if (!project) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            });
        }
        const isMember = await projectRepository.isMember(projectId, req.user.id);
        const isAdmin = req.user.role === 'admin';
        const isManager = req.user.role === 'manager';
        if (!isMember && !isAdmin && !isManager) {
            return res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied to this project',
                    timestamp: new Date().toISOString()
                }
            });
        }
        // Get project statistics
        const stats = await projectRepository.getProjectStats(projectId);
        // Get member count
        const members = await projectRepository.getProjectMembers(projectId);
        // Calculate additional metrics
        const metrics = {
            project: {
                id: project.id,
                name: project.name,
                description: project.description,
                createdAt: project.createdAt
            },
            taskStats: stats,
            memberCount: members.length,
            members: members.map(member => ({
                id: member.id,
                name: member.name,
                role: member.role
            })),
            lastUpdated: new Date().toISOString()
        };
        res.json({ metrics });
    }
    catch (error) {
        console.error('Error getting project metrics:', error);
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to get project metrics',
                timestamp: new Date().toISOString()
            }
        });
    }
}
// Validation middleware
exports.projectQueryValidation = [
    (0, express_validator_1.query)('limit')
        .optional()
        .isInt({ min: 1, max: 100 })
        .withMessage('Limit must be between 1 and 100'),
    (0, express_validator_1.query)('offset')
        .optional()
        .isInt({ min: 0 })
        .withMessage('Offset must be a non-negative integer'),
    (0, express_validator_1.query)('memberOnly')
        .optional()
        .isBoolean()
        .withMessage('memberOnly must be a boolean'),
    (0, express_validator_1.query)('search')
        .optional()
        .isLength({ min: 1, max: 255 })
        .withMessage('Search term must be between 1 and 255 characters'),
    (0, express_validator_1.query)('sortBy')
        .optional()
        .isIn(['name', 'createdAt', 'updatedAt', 'relevance'])
        .withMessage('Sort field must be name, createdAt, updatedAt, or relevance'),
    (0, express_validator_1.query)('sortOrder')
        .optional()
        .isIn(['asc', 'desc'])
        .withMessage('Sort order must be asc or desc')
];
exports.createProjectValidation = [
    (0, express_validator_1.body)('name')
        .trim()
        .isLength({ min: 1, max: 255 })
        .withMessage('Name must be between 1 and 255 characters'),
    (0, express_validator_1.body)('description')
        .trim()
        .isLength({ max: 2000 })
        .withMessage('Description must be 2000 characters or less')
];
exports.updateProjectValidation = [
    (0, express_validator_1.body)('name')
        .optional()
        .trim()
        .isLength({ min: 1, max: 255 })
        .withMessage('Name must be between 1 and 255 characters'),
    (0, express_validator_1.body)('description')
        .optional()
        .trim()
        .isLength({ max: 2000 })
        .withMessage('Description must be 2000 characters or less')
];
exports.projectIdValidation = [
    (0, express_validator_1.param)('id')
        .isUUID()
        .withMessage('Project ID must be a valid UUID')
];
exports.userIdValidation = [
    (0, express_validator_1.param)('userId')
        .isUUID()
        .withMessage('User ID must be a valid UUID')
];
exports.addMemberValidation = [
    (0, express_validator_1.body)('userId')
        .isUUID()
        .withMessage('User ID must be a valid UUID')
];
