"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = exports.LogLevel = void 0;
exports.requestLogger = requestLogger;
exports.logError = logError;
exports.logPerformance = logPerformance;
exports.withPerformanceLogging = withPerformanceLogging;
/**
 * Logging levels
 */
var LogLevel;
(function (LogLevel) {
    LogLevel["ERROR"] = "error";
    LogLevel["WARN"] = "warn";
    LogLevel["INFO"] = "info";
    LogLevel["DEBUG"] = "debug";
})(LogLevel || (exports.LogLevel = LogLevel = {}));
/**
 * Logger class for structured logging
 */
class Logger {
    constructor() {
        this.isDevelopment = process.env.NODE_ENV === 'development';
        this.isProduction = process.env.NODE_ENV === 'production';
    }
    /**
     * Log an error
     */
    error(message, error, context, metadata) {
        const logEntry = {
            level: LogLevel.ERROR,
            message,
            timestamp: new Date().toISOString(),
            context,
            metadata,
        };
        if (error) {
            logEntry.error = {
                name: error.name,
                message: error.message,
                stack: this.isDevelopment ? error.stack : undefined,
                ...error.code && { code: error.code },
                ...error.statusCode && { statusCode: error.statusCode },
            };
        }
        this.writeLog(logEntry);
    }
    /**
     * Log a warning
     */
    warn(message, context, metadata) {
        const logEntry = {
            level: LogLevel.WARN,
            message,
            timestamp: new Date().toISOString(),
            context,
            metadata,
        };
        this.writeLog(logEntry);
    }
    /**
     * Log an info message
     */
    info(message, context, metadata) {
        const logEntry = {
            level: LogLevel.INFO,
            message,
            timestamp: new Date().toISOString(),
            context,
            metadata,
        };
        this.writeLog(logEntry);
    }
    /**
     * Log a debug message (only in development)
     */
    debug(message, context, metadata) {
        if (!this.isDevelopment)
            return;
        const logEntry = {
            level: LogLevel.DEBUG,
            message,
            timestamp: new Date().toISOString(),
            context,
            metadata,
        };
        this.writeLog(logEntry);
    }
    /**
     * Log a request
     */
    request(req, responseTime, statusCode) {
        const logEntry = {
            level: LogLevel.INFO,
            message: `${req.method} ${req.path}`,
            timestamp: new Date().toISOString(),
            context: 'HTTP_REQUEST',
            userId: req.user?.id,
            metadata: {
                method: req.method,
                path: req.path,
                query: req.query,
                userAgent: req.get('User-Agent'),
                ip: req.ip,
                responseTime,
                statusCode,
            },
        };
        this.writeLog(logEntry);
    }
    /**
     * Log database operations
     */
    database(operation, table, duration, error) {
        const logEntry = {
            level: error ? LogLevel.ERROR : LogLevel.DEBUG,
            message: `Database ${operation}${table ? ` on ${table}` : ''}`,
            timestamp: new Date().toISOString(),
            context: 'DATABASE',
            metadata: {
                operation,
                table,
                duration,
            },
        };
        if (error) {
            logEntry.error = {
                name: error.name,
                message: error.message,
                stack: this.isDevelopment ? error.stack : undefined,
                ...error.code && { code: error.code },
            };
        }
        this.writeLog(logEntry);
    }
    /**
     * Log authentication events
     */
    auth(event, userId, email, success = true, metadata) {
        const logEntry = {
            level: success ? LogLevel.INFO : LogLevel.WARN,
            message: `Authentication ${event}${success ? ' successful' : ' failed'}`,
            timestamp: new Date().toISOString(),
            context: 'AUTHENTICATION',
            userId,
            metadata: {
                event,
                email,
                success,
                ...metadata,
            },
        };
        this.writeLog(logEntry);
    }
    /**
     * Log security events
     */
    security(event, severity, metadata) {
        const level = severity === 'critical' || severity === 'high' ? LogLevel.ERROR : LogLevel.WARN;
        const logEntry = {
            level,
            message: `Security event: ${event}`,
            timestamp: new Date().toISOString(),
            context: 'SECURITY',
            metadata: {
                event,
                severity,
                ...metadata,
            },
        };
        this.writeLog(logEntry);
    }
    /**
     * Write log entry to appropriate output
     */
    writeLog(logEntry) {
        if (this.isDevelopment) {
            // Pretty print for development
            this.prettyPrint(logEntry);
        }
        else {
            // JSON format for production
            console.log(JSON.stringify(logEntry));
        }
        // In production, you might want to send logs to external service
        if (this.isProduction && logEntry.level === LogLevel.ERROR) {
            // Example: sendToLogService(logEntry)
        }
    }
    /**
     * Pretty print log entry for development
     */
    prettyPrint(logEntry) {
        const colors = {
            [LogLevel.ERROR]: '\x1b[31m', // Red
            [LogLevel.WARN]: '\x1b[33m', // Yellow
            [LogLevel.INFO]: '\x1b[36m', // Cyan
            [LogLevel.DEBUG]: '\x1b[37m', // White
        };
        const reset = '\x1b[0m';
        const color = colors[logEntry.level];
        const timestamp = new Date(logEntry.timestamp).toLocaleTimeString();
        const level = logEntry.level.toUpperCase().padEnd(5);
        const context = logEntry.context ? `[${logEntry.context}]` : '';
        const userId = logEntry.userId ? `(User: ${logEntry.userId})` : '';
        console.log(`${color}${timestamp} ${level}${reset} ${context} ${logEntry.message} ${userId}`);
        if (logEntry.error) {
            console.log(`${color}  Error: ${logEntry.error.message}${reset}`);
            if (logEntry.error.stack) {
                console.log(`${color}  Stack: ${logEntry.error.stack}${reset}`);
            }
        }
        if (logEntry.metadata && Object.keys(logEntry.metadata).length > 0) {
            console.log(`${color}  Metadata:${reset}`, logEntry.metadata);
        }
    }
}
/**
 * Global logger instance
 */
exports.logger = new Logger();
/**
 * Request logging middleware
 */
function requestLogger(req, res, next) {
    const startTime = Date.now();
    // Log request
    exports.logger.request(req);
    // Override res.end to log response
    const originalEnd = res.end;
    res.end = function (chunk, encoding) {
        const responseTime = Date.now() - startTime;
        exports.logger.request(req, responseTime, res.statusCode);
        originalEnd.call(res, chunk, encoding);
    };
    next();
}
/**
 * Error logging helper
 */
function logError(error, context, metadata) {
    exports.logger.error(error.message, error, context, metadata);
}
/**
 * Performance logging helper
 */
function logPerformance(operation, duration, context) {
    const level = duration > 1000 ? LogLevel.WARN : LogLevel.DEBUG;
    if (level === LogLevel.WARN) {
        exports.logger.warn(`Slow operation: ${operation} took ${duration}ms`, context, { duration });
    }
    else {
        exports.logger.debug(`Operation: ${operation} took ${duration}ms`, context, { duration });
    }
}
/**
 * Async operation wrapper with performance logging
 */
async function withPerformanceLogging(operation, operationName, context) {
    const startTime = Date.now();
    try {
        const result = await operation();
        const duration = Date.now() - startTime;
        logPerformance(operationName, duration, context);
        return result;
    }
    catch (error) {
        const duration = Date.now() - startTime;
        exports.logger.error(`Failed operation: ${operationName} (${duration}ms)`, error, context);
        throw error;
    }
}
