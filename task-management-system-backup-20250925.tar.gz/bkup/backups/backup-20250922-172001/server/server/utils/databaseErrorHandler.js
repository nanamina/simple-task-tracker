"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostgreSQLErrorCodes = void 0;
exports.handlePostgreSQLError = handlePostgreSQLError;
exports.withDatabaseErrorHandling = withDatabaseErrorHandling;
exports.isDatabaseConnectionError = isDatabaseConnectionError;
exports.isDatabaseResourceError = isDatabaseResourceError;
exports.isDatabaseSchemaError = isDatabaseSchemaError;
const errorHandler_1 = require("../middleware/errorHandler");
/**
 * Database error handling utilities for PostgreSQL
 */
/**
 * PostgreSQL error codes and their meanings
 */
exports.PostgreSQLErrorCodes = {
    // Class 23 - Integrity Constraint Violation
    UNIQUE_VIOLATION: '23505',
    FOREIGN_KEY_VIOLATION: '23503',
    NOT_NULL_VIOLATION: '23502',
    CHECK_VIOLATION: '23514',
    // Class 42 - Syntax Error or Access Rule Violation
    UNDEFINED_TABLE: '42P01',
    UNDEFINED_COLUMN: '42703',
    UNDEFINED_FUNCTION: '42883',
    // Class 08 - Connection Exception
    CONNECTION_EXCEPTION: '08000',
    CONNECTION_FAILURE: '08006',
    // Class 53 - Insufficient Resources
    INSUFFICIENT_RESOURCES: '53000',
    DISK_FULL: '53100',
    OUT_OF_MEMORY: '53200',
    // Class 57 - Operator Intervention
    ADMIN_SHUTDOWN: '57P01',
    CRASH_SHUTDOWN: '57P02',
    CANNOT_CONNECT_NOW: '57P03',
};
/**
 * Handle PostgreSQL database errors and convert to appropriate AppError
 */
function handlePostgreSQLError(error) {
    const code = error.code;
    const message = error.message || 'Database error occurred';
    const detail = error.detail;
    const constraint = error.constraint;
    const table = error.table;
    const column = error.column;
    switch (code) {
        case exports.PostgreSQLErrorCodes.UNIQUE_VIOLATION:
            return new errorHandler_1.ConflictError(getUniqueViolationMessage(constraint, table, detail), {
                constraint,
                table,
                detail,
                type: 'unique_violation'
            });
        case exports.PostgreSQLErrorCodes.FOREIGN_KEY_VIOLATION:
            return new errorHandler_1.ValidationAppError(getForeignKeyViolationMessage(constraint, table, detail), {
                constraint,
                table,
                detail,
                type: 'foreign_key_violation'
            });
        case exports.PostgreSQLErrorCodes.NOT_NULL_VIOLATION:
            return new errorHandler_1.ValidationAppError(getNotNullViolationMessage(column, table), {
                column,
                table,
                type: 'not_null_violation'
            });
        case exports.PostgreSQLErrorCodes.CHECK_VIOLATION:
            return new errorHandler_1.ValidationAppError(getCheckViolationMessage(constraint, table), {
                constraint,
                table,
                type: 'check_violation'
            });
        case exports.PostgreSQLErrorCodes.UNDEFINED_TABLE:
            return new errorHandler_1.DatabaseError('Database table does not exist', {
                code,
                message,
                type: 'schema_error'
            });
        case exports.PostgreSQLErrorCodes.UNDEFINED_COLUMN:
            return new errorHandler_1.DatabaseError('Database column does not exist', {
                code,
                message,
                type: 'schema_error'
            });
        case exports.PostgreSQLErrorCodes.CONNECTION_EXCEPTION:
        case exports.PostgreSQLErrorCodes.CONNECTION_FAILURE:
            return new errorHandler_1.DatabaseError('Database connection failed', {
                code,
                message,
                type: 'connection_error'
            });
        case exports.PostgreSQLErrorCodes.INSUFFICIENT_RESOURCES:
        case exports.PostgreSQLErrorCodes.DISK_FULL:
        case exports.PostgreSQLErrorCodes.OUT_OF_MEMORY:
            return new errorHandler_1.DatabaseError('Database server is experiencing resource issues', {
                code,
                message,
                type: 'resource_error'
            });
        default:
            return new errorHandler_1.DatabaseError('Database operation failed', {
                code,
                message,
                detail,
                type: 'unknown_database_error'
            });
    }
}
/**
 * Generate user-friendly message for unique constraint violations
 */
function getUniqueViolationMessage(constraint, _table, _detail) {
    // Map common constraints to user-friendly messages
    const constraintMessages = {
        'users_email_key': 'An account with this email address already exists',
        'projects_name_key': 'A project with this name already exists',
        'tasks_title_project_key': 'A task with this title already exists in this project',
    };
    if (constraint && constraintMessages[constraint]) {
        return constraintMessages[constraint];
    }
    // Extract field name from constraint if possible
    if (constraint && constraint.includes('_')) {
        const parts = constraint.split('_');
        if (parts.length >= 2) {
            const field = parts[1];
            return `This ${field} is already in use`;
        }
    }
    // Fallback message
    return 'This resource already exists';
}
/**
 * Generate user-friendly message for foreign key violations
 */
function getForeignKeyViolationMessage(constraint, _table, detail) {
    const constraintMessages = {
        'tasks_assignee_id_fkey': 'The assigned user does not exist',
        'tasks_project_id_fkey': 'The specified project does not exist',
        'tasks_created_by_fkey': 'The user creating this task does not exist',
        'projects_created_by_fkey': 'The user creating this project does not exist',
        'project_members_user_id_fkey': 'The specified user does not exist',
        'project_members_project_id_fkey': 'The specified project does not exist',
    };
    if (constraint && constraintMessages[constraint]) {
        return constraintMessages[constraint];
    }
    // Check if it's a deletion that would violate foreign key
    if (detail && detail.includes('still referenced')) {
        return 'Cannot delete this resource because it is still being used';
    }
    return 'Referenced resource does not exist';
}
/**
 * Generate user-friendly message for not null violations
 */
function getNotNullViolationMessage(column, _table) {
    const fieldMessages = {
        'email': 'Email address is required',
        'name': 'Name is required',
        'title': 'Title is required',
        'password_hash': 'Password is required',
        'status': 'Status is required',
        'priority': 'Priority is required',
        'created_by': 'Creator information is required',
    };
    if (column && fieldMessages[column]) {
        return fieldMessages[column];
    }
    // Format column name for display
    const displayName = column
        ? column.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
        : 'Required field';
    return `${displayName} is required`;
}
/**
 * Generate user-friendly message for check constraint violations
 */
function getCheckViolationMessage(constraint, _table) {
    const constraintMessages = {
        'tasks_status_check': 'Invalid task status',
        'tasks_priority_check': 'Invalid task priority',
        'users_role_check': 'Invalid user role',
        'users_preferred_language_check': 'Invalid preferred language',
    };
    if (constraint && constraintMessages[constraint]) {
        return constraintMessages[constraint];
    }
    return 'Invalid data format';
}
/**
 * Wrap database operations with error handling
 */
async function withDatabaseErrorHandling(operation, context) {
    try {
        return await operation();
    }
    catch (error) {
        // Log the original error for debugging
        console.error(`Database error in ${context || 'unknown operation'}:`, {
            code: error.code,
            message: error.message,
            detail: error.detail,
            constraint: error.constraint,
            table: error.table,
            column: error.column,
        });
        // Convert and throw appropriate error
        throw handlePostgreSQLError(error);
    }
}
/**
 * Check if error is a database connection error
 */
function isDatabaseConnectionError(error) {
    return error.code === exports.PostgreSQLErrorCodes.CONNECTION_EXCEPTION ||
        error.code === exports.PostgreSQLErrorCodes.CONNECTION_FAILURE ||
        error.code === exports.PostgreSQLErrorCodes.CANNOT_CONNECT_NOW;
}
/**
 * Check if error is a resource constraint error
 */
function isDatabaseResourceError(error) {
    return error.code === exports.PostgreSQLErrorCodes.INSUFFICIENT_RESOURCES ||
        error.code === exports.PostgreSQLErrorCodes.DISK_FULL ||
        error.code === exports.PostgreSQLErrorCodes.OUT_OF_MEMORY;
}
/**
 * Check if error is a schema-related error
 */
function isDatabaseSchemaError(error) {
    return error.code === exports.PostgreSQLErrorCodes.UNDEFINED_TABLE ||
        error.code === exports.PostgreSQLErrorCodes.UNDEFINED_COLUMN ||
        error.code === exports.PostgreSQLErrorCodes.UNDEFINED_FUNCTION;
}
