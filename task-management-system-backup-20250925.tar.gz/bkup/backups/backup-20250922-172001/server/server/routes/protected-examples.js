"use strict";
/**
 * Example routes demonstrating role-based access control
 * These routes show how to use the authorization middleware
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const authorization_1 = require("../middleware/authorization");
const permissions_1 = require("../services/permissions");
const router = (0, express_1.Router)();
// Apply authentication to all routes in this router
router.use(auth_1.authenticateToken);
/**
 * GET /api/protected/admin-only
 * Example of admin-only route using permission-based access
 */
router.get('/admin-only', (0, authorization_1.requirePermission)('users:create'), (req, res) => {
    res.json({
        message: 'This is an admin-only endpoint',
        user: req.user,
        timestamp: new Date().toISOString()
    });
});
/**
 * GET /api/protected/manager-or-admin
 * Example of manager+ route using role level
 */
router.get('/manager-or-admin', (0, authorization_1.requireRoleLevel)('manager'), (req, res) => {
    res.json({
        message: 'This endpoint requires manager or admin role',
        user: req.user,
        permissions: permissions_1.PermissionService.getUserPermissions(req.user.role),
        timestamp: new Date().toISOString()
    });
});
/**
 * GET /api/protected/projects/create
 * Example of project creation permission
 */
router.get('/projects/create', (0, authorization_1.requirePermission)('projects:create'), (req, res) => {
    res.json({
        message: 'User can create projects',
        user: req.user,
        timestamp: new Date().toISOString()
    });
});
/**
 * GET /api/protected/tasks/manage
 * Example of task management permission
 */
router.get('/tasks/manage', (0, authorization_1.requirePermission)('tasks:assign'), (req, res) => {
    res.json({
        message: 'User can assign tasks',
        user: req.user,
        timestamp: new Date().toISOString()
    });
});
/**
 * GET /api/protected/profile/:userId
 * Example of ownership-based access (users can access their own profile or admins can access any)
 */
router.get('/profile/:userId', (0, authorization_1.requireOwnershipOrPermission)((req) => req.params.userId, 'users:read'), (req, res) => {
    const { userId } = req.params;
    const isOwnProfile = req.user.id === userId;
    res.json({
        message: isOwnProfile ? 'Accessing own profile' : 'Admin accessing user profile',
        userId,
        user: req.user,
        timestamp: new Date().toISOString()
    });
});
/**
 * GET /api/protected/reports
 * Example of reporting access
 */
router.get('/reports', (0, authorization_1.requirePermission)('reports:view'), (req, res) => {
    res.json({
        message: 'User can view reports',
        user: req.user,
        availableReports: ['task-completion', 'project-progress', 'team-performance'],
        timestamp: new Date().toISOString()
    });
});
/**
 * GET /api/protected/permissions
 * Get current user's permissions
 */
router.get('/permissions', (req, res) => {
    const userRole = req.user.role;
    const permissionContext = permissions_1.PermissionService.getUserPermissionContext(userRole);
    res.json({
        message: 'User permissions retrieved',
        ...permissionContext,
        timestamp: new Date().toISOString()
    });
});
/**
 * POST /api/protected/validate-permissions
 * Validate multiple permissions at once
 */
router.post('/validate-permissions', (req, res) => {
    const { permissions } = req.body;
    if (!Array.isArray(permissions)) {
        res.status(400).json({
            error: {
                code: 'VALIDATION_ERROR',
                message: 'Permissions must be an array',
                timestamp: new Date().toISOString()
            }
        });
        return;
    }
    const userRole = req.user.role;
    const validation = permissions_1.PermissionService.validatePermissions(userRole, permissions);
    res.json({
        message: 'Permission validation completed',
        user: req.user,
        validation,
        timestamp: new Date().toISOString()
    });
});
/**
 * GET /api/protected/bulk-operations
 * Example of bulk operation validation
 */
router.post('/bulk-operations', (req, res) => {
    const { operations } = req.body;
    if (!Array.isArray(operations)) {
        res.status(400).json({
            error: {
                code: 'VALIDATION_ERROR',
                message: 'Operations must be an array of {resource, action} objects',
                timestamp: new Date().toISOString()
            }
        });
        return;
    }
    const userRole = req.user.role;
    const validation = permissions_1.PermissionService.validateBulkOperations(userRole, operations);
    res.json({
        message: 'Bulk operation validation completed',
        user: req.user,
        validation,
        timestamp: new Date().toISOString()
    });
});
exports.default = router;
