"use strict";
/**
 * User management routes
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const user_1 = require("../controllers/user");
const auth_1 = require("../middleware/auth");
const authorization_1 = require("../middleware/authorization");
const router = (0, express_1.Router)();
/**
 * GET /api/users/profile
 * Get current user profile (requires authentication)
 */
router.get('/profile', auth_1.authenticateToken, user_1.getUserProfile);
/**
 * PUT /api/users/profile
 * Update current user profile (requires authentication)
 */
router.put('/profile', auth_1.authenticateToken, user_1.updateProfileValidation, user_1.updateUserProfile);
/**
 * PATCH /api/users/profile/language
 * Update user language preference (requires authentication)
 */
router.patch('/profile/language', auth_1.authenticateToken, user_1.updateLanguagePreference);
/**
 * GET /api/users/team
 * Get list of team members (admin/manager only)
 */
router.get('/team', auth_1.authenticateToken, (0, authorization_1.requirePermission)('users:list'), user_1.getTeamMembers);
/**
 * GET /api/users/:id
 * Get user by ID (admin/manager only, or own profile)
 */
router.get('/:id', auth_1.authenticateToken, (0, authorization_1.requireOwnershipOrPermission)((req) => req.params.id, // User can access their own profile
'users:read' // Or need admin/manager permission
), user_1.getUserById);
exports.default = router;
