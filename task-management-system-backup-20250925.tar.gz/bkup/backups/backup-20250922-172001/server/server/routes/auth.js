"use strict";
/**
 * Authentication routes
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../controllers/auth");
const auth_2 = require("../middleware/auth");
const router = (0, express_1.Router)();
/**
 * POST /api/auth/register
 * Register a new user account
 */
router.post('/register', auth_1.registerValidation, auth_1.register);
/**
 * POST /api/auth/login
 * Login with email and password
 */
router.post('/login', auth_1.loginValidation, auth_1.login);
/**
 * GET /api/auth/profile
 * Get current user profile (requires authentication)
 */
router.get('/profile', auth_2.authenticateToken, auth_1.getProfile);
/**
 * POST /api/auth/refresh
 * Refresh JWT token (requires valid token)
 */
router.post('/refresh', auth_2.authenticateToken, auth_1.refreshToken);
exports.default = router;
