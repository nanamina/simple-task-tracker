"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAnalyticsRoutes = createAnalyticsRoutes;
const express_1 = require("express");
const analytics_1 = require("../controllers/analytics");
const auth_1 = require("../middleware/auth");
const authorization_1 = require("../middleware/authorization");
/**
 * Analytics routes for reporting and metrics endpoints
 */
function createAnalyticsRoutes(db) {
    const router = (0, express_1.Router)();
    const analyticsController = new analytics_1.AnalyticsController(db);
    // All analytics routes require authentication
    router.use(auth_1.authenticateToken);
    /**
     * GET /api/analytics/projects/:projectId/metrics
     * Get project metrics and analytics
     * Requires: manager or admin role
     */
    router.get('/projects/:projectId/metrics', (0, authorization_1.requirePermission)('reports:view'), (req, res) => analyticsController.getProjectMetrics(req, res));
    /**
     * GET /api/analytics/workload
     * Get team workload distribution
     * Query params: projectId (optional)
     * Requires: manager or admin role
     */
    router.get('/workload', (0, authorization_1.requirePermission)('reports:view'), (req, res) => analyticsController.getTeamWorkload(req, res));
    /**
     * GET /api/analytics/trends
     * Get task completion trends over time
     * Query params: projectId (optional), days (default: 30)
     * Requires: manager or admin role
     */
    router.get('/trends', (0, authorization_1.requirePermission)('reports:view'), (req, res) => analyticsController.getCompletionTrends(req, res));
    /**
     * GET /api/analytics/projects/:projectId/report
     * Generate comprehensive project report
     * Requires: manager or admin role
     */
    router.get('/projects/:projectId/report', (0, authorization_1.requirePermission)('reports:view'), (req, res) => analyticsController.generateProjectReport(req, res));
    /**
     * GET /api/analytics/projects/:projectId/export
     * Export project report as CSV or JSON
     * Query params: format (csv|json, default: csv)
     * Requires: manager or admin role
     */
    router.get('/projects/:projectId/export', (0, authorization_1.requirePermission)('reports:export'), (req, res) => analyticsController.exportProjectReport(req, res));
    return router;
}
