"use strict";
/**
 * Task management routes
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const task_1 = require("../controllers/task");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
/**
 * GET /api/tasks
 * List tasks with filtering and sorting
 * Query parameters:
 * - status: Filter by task status (todo, in-progress, completed)
 * - priority: Filter by priority (low, medium, high, critical)
 * - assigneeId: Filter by assignee UUID
 * - projectId: Filter by project UUID
 * - sortBy: Sort field (createdAt, updatedAt, dueDate, priority, title)
 * - sortOrder: Sort direction (asc, desc)
 * - limit: Maximum number of results (1-100, default 50)
 * - offset: Number of results to skip (default 0)
 */
router.get('/', auth_1.authenticateToken, task_1.taskQueryValidation, task_1.listTasks);
/**
 * POST /api/tasks
 * Create a new task
 * Body:
 * - title: Task title (required, 1-255 characters)
 * - description: Task description (required, max 2000 characters)
 * - priority: Task priority (optional, low/medium/high/critical)
 * - dueDate: Due date (optional, ISO 8601 format)
 * - assigneeId: Assignee UUID (optional)
 * - projectId: Project UUID (optional)
 */
router.post('/', auth_1.authenticateToken, task_1.createTaskValidation, task_1.createTask);
/**
 * GET /api/tasks/:id
 * Get a specific task by ID
 */
router.get('/:id', auth_1.authenticateToken, task_1.getTask);
/**
 * PUT /api/tasks/:id
 * Update a task
 * Body: Same as POST but all fields are optional
 */
router.put('/:id', auth_1.authenticateToken, task_1.updateTaskValidation, task_1.updateTask);
/**
 * DELETE /api/tasks/:id
 * Delete a task
 */
router.delete('/:id', auth_1.authenticateToken, task_1.deleteTask);
/**
 * PATCH /api/tasks/:id/status
 * Update task status
 * Body:
 * - status: New status (todo, in-progress, completed)
 */
router.patch('/:id/status', auth_1.authenticateToken, task_1.updateTaskStatusValidation, task_1.updateTaskStatus);
exports.default = router;
