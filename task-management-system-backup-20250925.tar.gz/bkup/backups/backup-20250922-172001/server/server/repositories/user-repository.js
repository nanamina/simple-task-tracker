"use strict";
/**
 * User repository for database operations
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRepository = void 0;
const auth_1 = require("../services/auth");
class UserRepository {
    constructor(db) {
        this.db = db;
    }
    /**
     * Create a new user in the database
     * @param userData - User creation data
     * @returns Promise resolving to created user (without password)
     */
    async createUser(userData) {
        const client = await this.db.connect();
        try {
            // Hash the password before storing
            const passwordHash = await (0, auth_1.hashPassword)(userData.password);
            const query = `
        INSERT INTO users (email, name, password_hash, role, preferred_language)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING id, email, name, role, preferred_language, created_at, updated_at
      `;
            const values = [
                userData.email,
                userData.name,
                passwordHash,
                userData.role || 'member',
                userData.preferredLanguage || 'ja'
            ];
            const result = await client.query(query, values);
            const row = result.rows[0];
            return {
                id: row.id,
                email: row.email,
                name: row.name,
                role: row.role,
                preferredLanguage: row.preferred_language,
                createdAt: row.created_at,
                updatedAt: row.updated_at
            };
        }
        catch (error) {
            if (error instanceof Error && (error.message.includes('duplicate key') || error.message.includes('unique constraint'))) {
                throw new Error('User with this email already exists');
            }
            throw new Error('Failed to create user');
        }
        finally {
            client.release();
        }
    }
    /**
     * Find user by ID
     * @param id - User ID
     * @returns Promise resolving to user or null if not found
     */
    async findById(id) {
        const client = await this.db.connect();
        try {
            const query = `
        SELECT id, email, name, role, preferred_language, created_at, updated_at
        FROM users
        WHERE id = $1
      `;
            const result = await client.query(query, [id]);
            if (result.rows.length === 0) {
                return null;
            }
            const row = result.rows[0];
            return {
                id: row.id,
                email: row.email,
                name: row.name,
                role: row.role,
                preferredLanguage: row.preferred_language,
                createdAt: row.created_at,
                updatedAt: row.updated_at
            };
        }
        catch (error) {
            throw new Error('Failed to find user by ID');
        }
        finally {
            client.release();
        }
    }
    /**
     * Find user by email (including password hash for authentication)
     * @param email - User email
     * @returns Promise resolving to user with password or null if not found
     */
    async findByEmailWithPassword(email) {
        const client = await this.db.connect();
        try {
            const query = `
        SELECT id, email, name, password_hash, role, preferred_language, created_at, updated_at
        FROM users
        WHERE email = $1
      `;
            const result = await client.query(query, [email]);
            if (result.rows.length === 0) {
                return null;
            }
            const row = result.rows[0];
            return {
                id: row.id,
                email: row.email,
                name: row.name,
                passwordHash: row.password_hash,
                role: row.role,
                preferredLanguage: row.preferred_language,
                createdAt: row.created_at,
                updatedAt: row.updated_at
            };
        }
        catch (error) {
            throw new Error('Failed to find user by email');
        }
        finally {
            client.release();
        }
    }
    /**
     * Update user information
     * @param id - User ID
     * @param updates - Fields to update
     * @returns Promise resolving to updated user or null if not found
     */
    async updateUser(id, updates) {
        const client = await this.db.connect();
        try {
            const updateFields = [];
            const values = [];
            let paramCount = 1;
            if (updates.email !== undefined) {
                updateFields.push(`email = $${paramCount}`);
                values.push(updates.email);
                paramCount++;
            }
            if (updates.name !== undefined) {
                updateFields.push(`name = $${paramCount}`);
                values.push(updates.name);
                paramCount++;
            }
            if (updates.role !== undefined) {
                updateFields.push(`role = $${paramCount}`);
                values.push(updates.role);
                paramCount++;
            }
            if (updates.preferredLanguage !== undefined) {
                updateFields.push(`preferred_language = $${paramCount}`);
                values.push(updates.preferredLanguage);
                paramCount++;
            }
            if (updateFields.length === 0) {
                // No fields to update, return current user
                return this.findById(id);
            }
            updateFields.push(`updated_at = CURRENT_TIMESTAMP`);
            values.push(id); // Add ID as last parameter
            const query = `
        UPDATE users
        SET ${updateFields.join(', ')}
        WHERE id = $${paramCount}
        RETURNING id, email, name, role, preferred_language, created_at, updated_at
      `;
            const result = await client.query(query, values);
            if (result.rows.length === 0) {
                return null;
            }
            const row = result.rows[0];
            return {
                id: row.id,
                email: row.email,
                name: row.name,
                role: row.role,
                preferredLanguage: row.preferred_language,
                createdAt: row.created_at,
                updatedAt: row.updated_at
            };
        }
        catch (error) {
            if (error instanceof Error && error.message.includes('duplicate key')) {
                throw new Error('Email already exists');
            }
            throw new Error('Failed to update user');
        }
        finally {
            client.release();
        }
    }
    /**
     * Delete user by ID
     * @param id - User ID
     * @returns Promise resolving to boolean indicating success
     */
    async deleteUser(id) {
        const client = await this.db.connect();
        try {
            const query = 'DELETE FROM users WHERE id = $1';
            const result = await client.query(query, [id]);
            return result.rowCount !== null && result.rowCount > 0;
        }
        catch (error) {
            throw new Error('Failed to delete user');
        }
        finally {
            client.release();
        }
    }
    /**
     * List all users (for admin functionality)
     * @param limit - Maximum number of users to return
     * @param offset - Number of users to skip
     * @returns Promise resolving to array of users
     */
    async listUsers(limit = 50, offset = 0) {
        const client = await this.db.connect();
        try {
            const query = `
        SELECT id, email, name, role, preferred_language, created_at, updated_at
        FROM users
        ORDER BY created_at DESC
        LIMIT $1 OFFSET $2
      `;
            const result = await client.query(query, [limit, offset]);
            return result.rows.map(row => ({
                id: row.id,
                email: row.email,
                name: row.name,
                role: row.role,
                preferredLanguage: row.preferred_language,
                createdAt: row.created_at,
                updatedAt: row.updated_at
            }));
        }
        catch (error) {
            throw new Error('Failed to list users');
        }
        finally {
            client.release();
        }
    }
    /**
     * Check if user exists by email
     * @param email - User email
     * @returns Promise resolving to boolean
     */
    async existsByEmail(email) {
        const client = await this.db.connect();
        try {
            const query = 'SELECT 1 FROM users WHERE email = $1';
            const result = await client.query(query, [email]);
            return result.rows.length > 0;
        }
        catch (error) {
            throw new Error('Failed to check user existence');
        }
        finally {
            client.release();
        }
    }
}
exports.UserRepository = UserRepository;
