import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'path'

export default defineConfig(({ mode }) => ({
    plugins: [react()],
    root: './src/client',
    build: {
        outDir: '../../dist/client',
        emptyOutDir: true,
        // Production optimizations
        minify: mode === 'production' ? 'esbuild' : false,
        sourcemap: mode === 'production' ? false : true,
        rollupOptions: {
            output: {
                // Code splitting for better caching
                manualChunks: {
                    vendor: ['react', 'react-dom'],
                    redux: ['@reduxjs/toolkit', 'react-redux'],
                    router: ['react-router-dom'],
                    i18n: ['i18next', 'react-i18next', 'i18next-browser-languagedetector'],
                    forms: ['react-hook-form']
                },
                // Optimize chunk file names
                chunkFileNames: mode === 'production' ? 'assets/[name].[hash].js' : 'assets/[name].js',
                entryFileNames: mode === 'production' ? 'assets/[name].[hash].js' : 'assets/[name].js',
                assetFileNames: mode === 'production' ? 'assets/[name].[hash].[ext]' : 'assets/[name].[ext]'
            }
        },
        // Optimize bundle size
        chunkSizeWarningLimit: 1000,
        // Enable tree shaking
        target: 'es2020'
    },
    resolve: {
        alias: {
            '@': resolve(__dirname, './src'),
            '@/components': resolve(__dirname, './src/client/components'),
            '@/hooks': resolve(__dirname, './src/client/hooks'),
            '@/store': resolve(__dirname, './src/client/store'),
            '@/types': resolve(__dirname, './src/shared/types'),
            '@/utils': resolve(__dirname, './src/shared/utils')
        }
    },
    server: {
        port: 3000,
        proxy: {
            '/api': {
                target: 'http://localhost:3001',
                changeOrigin: true
            }
        }
    },
    // Production optimizations
    define: {
        __DEV__: mode !== 'production',
        'process.env.NODE_ENV': JSON.stringify(mode)
    },
    // Enable CSS code splitting
    css: {
        devSourcemap: mode !== 'production'
    }
}))