import * as request from 'supertest';
import * as express from 'express';
import { Pool } from 'pg';
import { AnalyticsController } from '../server/controllers/analytics';
import { AnalyticsService } from '../server/services/analytics';

// Mock the analytics service
jest.mock('../server/services/analytics');
jest.mock('../server/repositories/task-repository');
jest.mock('../server/repositories/project-repository');
jest.mock('../server/repositories/user-repository');

const MockAnalyticsService = AnalyticsService as jest.MockedClass<typeof AnalyticsService>;

describe('AnalyticsController', () => {
    let app: express.Application;
    let mockAnalyticsService: jest.Mocked<AnalyticsService>;
    let analyticsController: AnalyticsController;

    const mockProjectMetrics = {
        projectId: 'project-1',
        projectName: 'Test Project',
        totalTasks: 10,
        statusDistribution: {
            todo: 3,
            'in-progress': 4,
            completed: 3
        },
        completionRate: 30,
        averageTaskDuration: 5.5,
        overdueTasksCount: 2,
        overdueTasks: [
            {
                id: 'task-1',
                title: 'Overdue Task 1',
                dueDate: '2024-01-01',
                assigneeId: 'user-1',
                priority: 'high'
            }
        ]
    };

    const mockTeamWorkload = [
        {
            userId: 'user-1',
            userName: 'John Doe',
            totalTasks: 5,
            completedTasks: 2,
            inProgressTasks: 2,
            todoTasks: 1,
            overdueTasks: 1,
            completionRate: 40
        }
    ];

    const mockCompletionTrends = [
        { date: '2024-01-01', completedTasks: 2 },
        { date: '2024-01-02', completedTasks: 3 },
        { date: '2024-01-03', completedTasks: 1 }
    ];

    beforeEach(() => {
        app = express();
        app.use(express.json());

        // Create mock analytics service instance
        mockAnalyticsService = {
            getProjectMetrics: jest.fn(),
            getTeamWorkload: jest.fn(),
            getCompletionTrends: jest.fn(),
            generateProjectReport: jest.fn()
        } as any;

        // Mock the constructor to return our mock service
        MockAnalyticsService.mockImplementation(() => mockAnalyticsService);

        analyticsController = new AnalyticsController({} as Pool);

        // Set up routes
        app.get('/api/analytics/projects/:projectId/metrics',
            (req, res) => analyticsController.getProjectMetrics(req, res));
        app.get('/api/analytics/workload',
            (req, res) => analyticsController.getTeamWorkload(req, res));
        app.get('/api/analytics/trends',
            (req, res) => analyticsController.getCompletionTrends(req, res));
        app.get('/api/analytics/projects/:projectId/report',
            (req, res) => analyticsController.generateProjectReport(req, res));
        app.get('/api/analytics/projects/:projectId/export',
            (req, res) => analyticsController.exportProjectReport(req, res));
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    describe('GET /api/analytics/projects/:projectId/metrics', () => {
        it('should return project metrics successfully', async () => {
            // Arrange
            mockAnalyticsService.getProjectMetrics.mockResolvedValue(mockProjectMetrics);

            // Act
            const response = await request(app)
                .get('/api/analytics/projects/project-1/metrics');

            // Assert
            expect(response.status).toBe(200);
            expect(response.body).toEqual({
                success: true,
                data: mockProjectMetrics
            });
            expect(mockAnalyticsService.getProjectMetrics).toHaveBeenCalledWith('project-1');
        });

        it('should return 400 when project ID is missing', async () => {
            // Act
            const response = await request(app)
                .get('/api/analytics/projects//metrics');

            // Assert
            expect(response.status).toBe(404); // Express returns 404 for malformed routes
        });

        it('should return 404 when project not found', async () => {
            // Arrange
            mockAnalyticsService.getProjectMetrics.mockRejectedValue(new Error('Project not found'));

            // Act
            const response = await request(app)
                .get('/api/analytics/projects/nonexistent/metrics');

            // Assert
            expect(response.status).toBe(404);
            expect(response.body.error.code).toBe('NOT_FOUND');
        });

        it('should return 500 on service error', async () => {
            // Arrange
            mockAnalyticsService.getProjectMetrics.mockRejectedValue(new Error('Database error'));

            // Act
            const response = await request(app)
                .get('/api/analytics/projects/project-1/metrics');

            // Assert
            expect(response.status).toBe(500);
            expect(response.body.error.code).toBe('INTERNAL_ERROR');
        });
    });

    describe('GET /api/analytics/workload', () => {
        it('should return team workload successfully', async () => {
            // Arrange
            mockAnalyticsService.getTeamWorkload.mockResolvedValue(mockTeamWorkload);

            // Act
            const response = await request(app)
                .get('/api/analytics/workload');

            // Assert
            expect(response.status).toBe(200);
            expect(response.body).toEqual({
                success: true,
                data: mockTeamWorkload
            });
            expect(mockAnalyticsService.getTeamWorkload).toHaveBeenCalledWith(undefined);
        });

        it('should pass project ID when provided', async () => {
            // Arrange
            mockAnalyticsService.getTeamWorkload.mockResolvedValue(mockTeamWorkload);

            // Act
            const response = await request(app)
                .get('/api/analytics/workload?projectId=project-1');

            // Assert
            expect(response.status).toBe(200);
            expect(mockAnalyticsService.getTeamWorkload).toHaveBeenCalledWith('project-1');
        });

        it('should return 500 on service error', async () => {
            // Arrange
            mockAnalyticsService.getTeamWorkload.mockRejectedValue(new Error('Service error'));

            // Act
            const response = await request(app)
                .get('/api/analytics/workload');

            // Assert
            expect(response.status).toBe(500);
            expect(response.body.error.code).toBe('INTERNAL_ERROR');
        });
    });

    describe('GET /api/analytics/trends', () => {
        it('should return completion trends successfully', async () => {
            // Arrange
            mockAnalyticsService.getCompletionTrends.mockResolvedValue(mockCompletionTrends);

            // Act
            const response = await request(app)
                .get('/api/analytics/trends');

            // Assert
            expect(response.status).toBe(200);
            expect(response.body).toEqual({
                success: true,
                data: mockCompletionTrends
            });
            expect(mockAnalyticsService.getCompletionTrends).toHaveBeenCalledWith(undefined, 30);
        });

        it('should handle custom days parameter', async () => {
            // Arrange
            mockAnalyticsService.getCompletionTrends.mockResolvedValue(mockCompletionTrends);

            // Act
            const response = await request(app)
                .get('/api/analytics/trends?days=7&projectId=project-1');

            // Assert
            expect(response.status).toBe(200);
            expect(mockAnalyticsService.getCompletionTrends).toHaveBeenCalledWith('project-1', 7);
        });

        it('should return 400 for invalid days parameter', async () => {
            // Act
            const response = await request(app)
                .get('/api/analytics/trends?days=invalid');

            // Assert
            expect(response.status).toBe(400);
            expect(response.body.error.code).toBe('VALIDATION_ERROR');
        });

        it('should return 400 for days out of range', async () => {
            // Act
            const response = await request(app)
                .get('/api/analytics/trends?days=500');

            // Assert
            expect(response.status).toBe(400);
            expect(response.body.error.code).toBe('VALIDATION_ERROR');
        });
    });

    describe('GET /api/analytics/projects/:projectId/report', () => {
        const mockReport = {
            generatedAt: '2024-01-01T00:00:00.000Z',
            project: { id: 'project-1', name: 'Test Project' },
            summary: mockProjectMetrics,
            statusDistribution: mockProjectMetrics.statusDistribution,
            teamWorkload: mockTeamWorkload,
            completionTrends: mockCompletionTrends,
            overdueItems: mockProjectMetrics.overdueTasks
        };

        it('should generate project report successfully', async () => {
            // Arrange
            mockAnalyticsService.generateProjectReport.mockResolvedValue(mockReport);

            // Act
            const response = await request(app)
                .get('/api/analytics/projects/project-1/report');

            // Assert
            expect(response.status).toBe(200);
            expect(response.body).toEqual({
                success: true,
                data: mockReport
            });
            expect(mockAnalyticsService.generateProjectReport).toHaveBeenCalledWith('project-1');
        });

        it('should return 404 when project not found', async () => {
            // Arrange
            mockAnalyticsService.generateProjectReport.mockRejectedValue(new Error('Project not found'));

            // Act
            const response = await request(app)
                .get('/api/analytics/projects/nonexistent/report');

            // Assert
            expect(response.status).toBe(404);
            expect(response.body.error.code).toBe('NOT_FOUND');
        });
    });

    describe('GET /api/analytics/projects/:projectId/export', () => {
        const mockReport = {
            generatedAt: '2024-01-01T00:00:00.000Z',
            project: { id: 'project-1', name: 'Test Project' },
            summary: {
                totalTasks: 10,
                completionRate: 30,
                averageTaskDuration: 5.5,
                overdueTasksCount: 2
            },
            statusDistribution: { todo: 3, 'in-progress': 4, completed: 3 },
            teamWorkload: mockTeamWorkload,
            completionTrends: mockCompletionTrends.slice(-10),
            overdueItems: []
        };

        it('should export report as CSV', async () => {
            // Arrange
            mockAnalyticsService.generateProjectReport.mockResolvedValue(mockReport);

            // Act
            const response = await request(app)
                .get('/api/analytics/projects/project-1/export?format=csv');

            // Assert
            expect(response.status).toBe(200);
            expect(response.headers['content-type']).toBe('text/csv; charset=utf-8');
            expect(response.headers['content-disposition']).toContain('project-project-1-report.csv');
            expect(response.text).toContain('Project Report');
            expect(response.text).toContain('Test Project');
        });

        it('should export report as JSON', async () => {
            // Arrange
            mockAnalyticsService.generateProjectReport.mockResolvedValue(mockReport);

            // Act
            const response = await request(app)
                .get('/api/analytics/projects/project-1/export?format=json');

            // Assert
            expect(response.status).toBe(200);
            expect(response.headers['content-type']).toBe('application/json; charset=utf-8');
            expect(response.headers['content-disposition']).toContain('project-project-1-report.json');
            expect(response.body).toEqual(mockReport);
        });

        it('should default to CSV format', async () => {
            // Arrange
            mockAnalyticsService.generateProjectReport.mockResolvedValue(mockReport);

            // Act
            const response = await request(app)
                .get('/api/analytics/projects/project-1/export');

            // Assert
            expect(response.status).toBe(200);
            expect(response.headers['content-type']).toBe('text/csv; charset=utf-8');
        });

        it('should return 400 for unsupported format', async () => {
            // Act
            const response = await request(app)
                .get('/api/analytics/projects/project-1/export?format=xml');

            // Assert
            expect(response.status).toBe(400);
            expect(response.body.error.code).toBe('VALIDATION_ERROR');
            expect(response.body.error.message).toContain('Unsupported export format');
        });
    });
});