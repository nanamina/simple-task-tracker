/**
 * Integration tests for role-based access control
 */

import * as request from 'supertest'
import * as express from 'express'
import { authenticateToken } from '../server/middleware/auth'
import { requirePermission, requireRoleLevel } from '../server/middleware/authorization'
import { generateToken } from '../server/services/auth'
import { User } from '../shared/types/index'

// Create test app
const createTestApp = () => {
    const app = express()
    app.use(express.json())

    // Test routes with different permission requirements
    app.get('/admin-only',
        authenticateToken,
        requirePermission('users:create'),
        (req, res) => res.json({ message: 'admin access granted', user: req.user })
    )

    app.get('/manager-or-admin',
        authenticateToken,
        requireRoleLevel('manager'),
        (req, res) => res.json({ message: 'manager+ access granted', user: req.user })
    )

    app.get('/member-access',
        authenticateToken,
        requirePermission('tasks:create'),
        (req, res) => res.json({ message: 'member access granted', user: req.user })
    )

    app.get('/project-create',
        authenticateToken,
        requirePermission('projects:create'),
        (req, res) => res.json({ message: 'project creation allowed', user: req.user })
    )

    return app
}

// Mock users
const adminUser: User = {
    id: 'admin-123',
    email: 'admin@example.com',
    name: 'Admin User',
    role: 'admin',
    preferredLanguage: 'ja',
    createdAt: new Date(),
    updatedAt: new Date()
}

const managerUser: User = {
    id: 'manager-123',
    email: 'manager@example.com',
    name: 'Manager User',
    role: 'manager',
    preferredLanguage: 'ja',
    createdAt: new Date(),
    updatedAt: new Date()
}

const memberUser: User = {
    id: 'member-123',
    email: 'member@example.com',
    name: 'Member User',
    role: 'member',
    preferredLanguage: 'ja',
    createdAt: new Date(),
    updatedAt: new Date()
}

describe('Authorization Integration Tests', () => {
    let app: express.Application

    beforeEach(() => {
        app = createTestApp()
    })

    describe('Admin-only routes', () => {
        it('should allow admin access', async () => {
            const token = generateToken(adminUser)

            const response = await request(app)
                .get('/admin-only')
                .set('Authorization', `Bearer ${token}`)
                .expect(200)

            expect(response.body.message).toBe('admin access granted')
            expect(response.body.user.role).toBe('admin')
        })

        it('should deny manager access to admin-only route', async () => {
            const token = generateToken(managerUser)

            const response = await request(app)
                .get('/admin-only')
                .set('Authorization', `Bearer ${token}`)
                .expect(403)

            expect(response.body.error.code).toBe('FORBIDDEN')
            expect(response.body.error.message).toContain('users:create')
        })

        it('should deny member access to admin-only route', async () => {
            const token = generateToken(memberUser)

            const response = await request(app)
                .get('/admin-only')
                .set('Authorization', `Bearer ${token}`)
                .expect(403)

            expect(response.body.error.code).toBe('FORBIDDEN')
        })
    })

    describe('Manager+ routes', () => {
        it('should allow admin access to manager+ route', async () => {
            const token = generateToken(adminUser)

            const response = await request(app)
                .get('/manager-or-admin')
                .set('Authorization', `Bearer ${token}`)
                .expect(200)

            expect(response.body.message).toBe('manager+ access granted')
        })

        it('should allow manager access to manager+ route', async () => {
            const token = generateToken(managerUser)

            const response = await request(app)
                .get('/manager-or-admin')
                .set('Authorization', `Bearer ${token}`)
                .expect(200)

            expect(response.body.message).toBe('manager+ access granted')
        })

        it('should deny member access to manager+ route', async () => {
            const token = generateToken(memberUser)

            const response = await request(app)
                .get('/manager-or-admin')
                .set('Authorization', `Bearer ${token}`)
                .expect(403)

            expect(response.body.error.code).toBe('FORBIDDEN')
            expect(response.body.error.message).toContain('manager or higher')
        })
    })

    describe('Member accessible routes', () => {
        it('should allow admin access to member route', async () => {
            const token = generateToken(adminUser)

            await request(app)
                .get('/member-access')
                .set('Authorization', `Bearer ${token}`)
                .expect(200)
        })

        it('should allow manager access to member route', async () => {
            const token = generateToken(managerUser)

            await request(app)
                .get('/member-access')
                .set('Authorization', `Bearer ${token}`)
                .expect(200)
        })

        it('should allow member access to member route', async () => {
            const token = generateToken(memberUser)

            const response = await request(app)
                .get('/member-access')
                .set('Authorization', `Bearer ${token}`)
                .expect(200)

            expect(response.body.message).toBe('member access granted')
        })
    })

    describe('Project creation routes', () => {
        it('should allow admin to create projects', async () => {
            const token = generateToken(adminUser)

            await request(app)
                .get('/project-create')
                .set('Authorization', `Bearer ${token}`)
                .expect(200)
        })

        it('should allow manager to create projects', async () => {
            const token = generateToken(managerUser)

            await request(app)
                .get('/project-create')
                .set('Authorization', `Bearer ${token}`)
                .expect(200)
        })

        it('should deny member project creation', async () => {
            const token = generateToken(memberUser)

            const response = await request(app)
                .get('/project-create')
                .set('Authorization', `Bearer ${token}`)
                .expect(403)

            expect(response.body.error.code).toBe('FORBIDDEN')
            expect(response.body.error.message).toContain('projects:create')
        })
    })

    describe('Unauthenticated access', () => {
        it('should deny access without token', async () => {
            await request(app)
                .get('/admin-only')
                .expect(401)
        })

        it('should deny access with invalid token', async () => {
            await request(app)
                .get('/admin-only')
                .set('Authorization', 'Bearer invalid-token')
                .expect(401)
        })

        it('should deny access with malformed authorization header', async () => {
            await request(app)
                .get('/admin-only')
                .set('Authorization', 'InvalidFormat token')
                .expect(401)
        })
    })

    describe('Token validation', () => {
        it('should accept valid token format', async () => {
            const token = generateToken(adminUser)

            await request(app)
                .get('/admin-only')
                .set('Authorization', `Bearer ${token}`)
                .expect(200)
        })

        it('should reject token without Bearer prefix', async () => {
            const token = generateToken(adminUser)

            await request(app)
                .get('/admin-only')
                .set('Authorization', token)
                .expect(401)
        })
    })
})