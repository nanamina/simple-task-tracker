import { AnalyticsService } from '../server/services/analytics';
import { TaskRepository } from '../server/repositories/task-repository';
import { ProjectRepository } from '../server/repositories/project-repository';
import { UserRepository } from '../server/repositories/user-repository';
import { Task, Project, User } from '../shared/types';

// Mock repositories
jest.mock('../server/repositories/task-repository');
jest.mock('../server/repositories/project-repository');
jest.mock('../server/repositories/user-repository');

const MockTaskRepository = TaskRepository as jest.MockedClass<typeof TaskRepository>;
const MockProjectRepository = ProjectRepository as jest.MockedClass<typeof ProjectRepository>;
const MockUserRepository = UserRepository as jest.MockedClass<typeof UserRepository>;

describe('AnalyticsService', () => {
    let analyticsService: AnalyticsService;
    let mockTaskRepository: jest.Mocked<TaskRepository>;
    let mockProjectRepository: jest.Mocked<ProjectRepository>;
    let mockUserRepository: jest.Mocked<UserRepository>;

    const mockProject: Project = {
        id: 'project-1',
        name: 'Test Project',
        description: 'Test project description',
        createdBy: 'user-1',
        createdAt: new Date('2024-01-01'),
        updatedAt: new Date('2024-01-01')
    };

    const mockUser: User = {
        id: 'user-1',
        email: 'test@example.com',
        name: 'Test User',
        role: 'member',
        preferredLanguage: 'en',
        createdAt: new Date('2024-01-01'),
        updatedAt: new Date('2024-01-01')
    };

    const mockTasks: Task[] = [
        {
            id: 'task-1',
            title: 'Task 1',
            description: 'Description 1',
            status: 'completed',
            priority: 'high',
            assigneeId: 'user-1',
            projectId: 'project-1',
            createdBy: 'user-1',
            createdAt: new Date('2024-01-01'),
            updatedAt: new Date('2024-01-02'),
            completedAt: new Date('2024-01-03')
        },
        {
            id: 'task-2',
            title: 'Task 2',
            description: 'Description 2',
            status: 'in-progress',
            priority: 'medium',
            assigneeId: 'user-1',
            projectId: 'project-1',
            createdBy: 'user-1',
            createdAt: new Date('2024-01-02'),
            updatedAt: new Date('2024-01-02')
        },
        {
            id: 'task-3',
            title: 'Task 3',
            description: 'Description 3',
            status: 'todo',
            priority: 'low',
            dueDate: new Date('2023-12-31'), // Overdue
            assigneeId: 'user-1',
            projectId: 'project-1',
            createdBy: 'user-1',
            createdAt: new Date('2024-01-01'),
            updatedAt: new Date('2024-01-01')
        }
    ];

    beforeEach(() => {
        mockTaskRepository = {
            getTasksByProject: jest.fn(),
            getAllTasks: jest.fn(),
            createTask: jest.fn(),
            findById: jest.fn(),
            updateTask: jest.fn(),
            updateTaskStatus: jest.fn(),
            deleteTask: jest.fn(),
            listTasks: jest.fn(),
            getTasksByAssignee: jest.fn(),
            getOverdueTasks: jest.fn()
        } as any;

        mockProjectRepository = {
            getById: jest.fn(),
            createProject: jest.fn(),
            updateProject: jest.fn(),
            deleteProject: jest.fn(),
            listProjects: jest.fn(),
            addUserToProject: jest.fn(),
            removeUserFromProject: jest.fn(),
            getProjectMembers: jest.fn()
        } as any;

        mockUserRepository = {
            getById: jest.fn(),
            createUser: jest.fn(),
            findByEmail: jest.fn(),
            updateUser: jest.fn(),
            deleteUser: jest.fn(),
            listUsers: jest.fn()
        } as any;

        analyticsService = new AnalyticsService(
            mockTaskRepository,
            mockProjectRepository,
            mockUserRepository
        );
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    describe('getProjectMetrics', () => {
        it('should calculate project metrics correctly', async () => {
            // Arrange
            mockTaskRepository.getTasksByProject.mockResolvedValue(mockTasks);
            mockProjectRepository.getById.mockResolvedValue(mockProject);

            // Act
            const result = await analyticsService.getProjectMetrics('project-1');

            // Assert
            expect(result).toEqual({
                projectId: 'project-1',
                projectName: 'Test Project',
                totalTasks: 3,
                statusDistribution: {
                    todo: 1,
                    'in-progress': 1,
                    completed: 1
                },
                completionRate: 33.33,
                averageTaskDuration: 2, // Task 1: 2 days from creation to completion
                overdueTasksCount: 1,
                overdueTasks: [{
                    id: 'task-3',
                    title: 'Task 3',
                    dueDate: new Date('2023-12-31'),
                    assigneeId: 'user-1',
                    priority: 'low'
                }]
            });

            expect(mockTaskRepository.getTasksByProject).toHaveBeenCalledWith('project-1');
            expect(mockProjectRepository.getById).toHaveBeenCalledWith('project-1');
        });

        it('should throw error when project not found', async () => {
            // Arrange
            mockTaskRepository.getTasksByProject.mockResolvedValue([]);
            mockProjectRepository.getById.mockResolvedValue(null);

            // Act & Assert
            await expect(analyticsService.getProjectMetrics('nonexistent'))
                .rejects.toThrow('Project not found');
        });

        it('should handle empty task list', async () => {
            // Arrange
            mockTaskRepository.getTasksByProject.mockResolvedValue([]);
            mockProjectRepository.getById.mockResolvedValue(mockProject);

            // Act
            const result = await analyticsService.getProjectMetrics('project-1');

            // Assert
            expect(result.totalTasks).toBe(0);
            expect(result.completionRate).toBe(0);
            expect(result.averageTaskDuration).toBe(0);
            expect(result.overdueTasksCount).toBe(0);
        });
    });

    describe('getTeamWorkload', () => {
        it('should calculate team workload correctly', async () => {
            // Arrange
            mockTaskRepository.getTasksByProject.mockResolvedValue(mockTasks);
            mockUserRepository.getById.mockResolvedValue(mockUser);

            // Act
            const result = await analyticsService.getTeamWorkload('project-1');

            // Assert
            expect(result).toEqual([{
                userId: 'user-1',
                userName: 'Test User',
                totalTasks: 3,
                completedTasks: 1,
                inProgressTasks: 1,
                todoTasks: 1,
                overdueTasks: 1,
                completionRate: 33
            }]);

            expect(mockTaskRepository.getTasksByProject).toHaveBeenCalledWith('project-1');
            expect(mockUserRepository.getById).toHaveBeenCalledWith('user-1');
        });

        it('should get all tasks when no project specified', async () => {
            // Arrange
            mockTaskRepository.getAllTasks.mockResolvedValue(mockTasks);
            mockUserRepository.getById.mockResolvedValue(mockUser);

            // Act
            const result = await analyticsService.getTeamWorkload();

            // Assert
            expect(result).toHaveLength(1);
            expect(mockTaskRepository.getAllTasks).toHaveBeenCalled();
        });

        it('should handle tasks without assignees', async () => {
            // Arrange
            const tasksWithoutAssignee = [
                { ...mockTasks[0], assigneeId: undefined },
                ...mockTasks.slice(1)
            ];
            mockTaskRepository.getTasksByProject.mockResolvedValue(tasksWithoutAssignee);
            mockUserRepository.getById.mockResolvedValue(mockUser);

            // Act
            const result = await analyticsService.getTeamWorkload('project-1');

            // Assert
            expect(result).toHaveLength(1); // Only tasks with assignees are counted
            expect(result[0].totalTasks).toBe(2);
        });
    });

    describe('getCompletionTrends', () => {
        it('should calculate completion trends correctly', async () => {
            // Arrange - use recent dates that would be within the date range
            const today = new Date();
            const yesterday = new Date(today);
            yesterday.setDate(yesterday.getDate() - 1);

            const completedTasks = [
                {
                    ...mockTasks[0],
                    status: 'completed' as const,
                    completedAt: today
                },
                {
                    ...mockTasks[0],
                    id: 'task-4',
                    status: 'completed' as const,
                    completedAt: yesterday
                }
            ];
            mockTaskRepository.getTasksByProject.mockResolvedValue(completedTasks);

            // Act
            const result = await analyticsService.getCompletionTrends('project-1', 3);

            // Assert
            expect(result.length).toBeGreaterThan(0);
            const todayResult = result.find(r => r.date === today.toISOString().split('T')[0]);
            const yesterdayResult = result.find(r => r.date === yesterday.toISOString().split('T')[0]);
            expect(todayResult?.completedTasks).toBe(1);
            expect(yesterdayResult?.completedTasks).toBe(1);
        });

        it('should handle no completed tasks', async () => {
            // Arrange
            mockTaskRepository.getTasksByProject.mockResolvedValue([]);

            // Act
            const result = await analyticsService.getCompletionTrends('project-1', 7);

            // Assert
            expect(result).toHaveLength(8); // 7 days + 1
            expect(result.every(r => r.completedTasks === 0)).toBe(true);
        });
    });

    describe('generateProjectReport', () => {
        it('should generate comprehensive project report', async () => {
            // Arrange
            mockTaskRepository.getTasksByProject.mockResolvedValue(mockTasks);
            mockTaskRepository.getAllTasks.mockResolvedValue(mockTasks);
            mockProjectRepository.getById.mockResolvedValue(mockProject);
            mockUserRepository.getById.mockResolvedValue(mockUser);

            // Act
            const result = await analyticsService.generateProjectReport('project-1');

            // Assert
            expect(result).toHaveProperty('generatedAt');
            expect(result).toHaveProperty('project');
            expect(result).toHaveProperty('summary');
            expect(result).toHaveProperty('statusDistribution');
            expect(result).toHaveProperty('teamWorkload');
            expect(result).toHaveProperty('completionTrends');
            expect(result).toHaveProperty('overdueItems');

            expect(result.project.id).toBe('project-1');
            expect(result.project.name).toBe('Test Project');
            expect(result.summary.totalTasks).toBe(3);
        });

        it('should handle errors gracefully', async () => {
            // Arrange
            mockTaskRepository.getTasksByProject.mockRejectedValue(new Error('Database error'));

            // Act & Assert
            await expect(analyticsService.generateProjectReport('project-1'))
                .rejects.toThrow('Failed to generate project report: Failed to get project metrics: Database error');
        });
    });
});