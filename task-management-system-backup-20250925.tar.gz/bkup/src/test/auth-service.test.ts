/**
 * Unit tests for authentication service functions
 */

import {
    hashPassword,
    comparePassword,
    generateToken,
    verifyToken,
    extractTokenFromHeader
} from '../server/services/auth'
import { User } from '../shared/types/index'
import * as jwt from 'jsonwebtoken'

// Mock user data
const mockUser: User = {
    id: '123e4567-e89b-12d3-a456-426614174000',
    email: 'test@example.com',
    name: 'Test User',
    role: 'member',
    preferredLanguage: 'ja',
    createdAt: new Date(),
    updatedAt: new Date()
}

describe('Authentication Service', () => {
    describe('hashPassword', () => {
        it('should hash password successfully', async () => {
            const password = 'testPassword123'
            const hashedPassword = await hashPassword(password)

            expect(hashedPassword).toBeDefined()
            expect(hashedPassword).not.toBe(password)
            expect(hashedPassword.length).toBeGreaterThan(50) // bcrypt hashes are typically 60 characters
        })

        it('should generate different hashes for same password', async () => {
            const password = 'testPassword123'
            const hash1 = await hashPassword(password)
            const hash2 = await hashPassword(password)

            expect(hash1).not.toBe(hash2) // Salt should make them different
        })

        it('should handle empty password', async () => {
            const password = ''
            const hashedPassword = await hashPassword(password)
            expect(hashedPassword).toBeDefined()
            expect(typeof hashedPassword).toBe('string')
        })
    })

    describe('comparePassword', () => {
        it('should return true for matching password and hash', async () => {
            const password = 'testPassword123'
            const hashedPassword = await hashPassword(password)

            const isMatch = await comparePassword(password, hashedPassword)
            expect(isMatch).toBe(true)
        })

        it('should return false for non-matching password and hash', async () => {
            const password = 'testPassword123'
            const wrongPassword = 'wrongPassword456'
            const hashedPassword = await hashPassword(password)

            const isMatch = await comparePassword(wrongPassword, hashedPassword)
            expect(isMatch).toBe(false)
        })

        it('should return false for invalid hash format', async () => {
            const password = 'testPassword123'
            const invalidHash = 'invalid-hash'

            const isMatch = await comparePassword(password, invalidHash)
            expect(isMatch).toBe(false)
        })
    })

    describe('generateToken', () => {
        it('should generate valid JWT token', () => {
            const token = generateToken(mockUser)

            expect(token).toBeDefined()
            expect(typeof token).toBe('string')
            expect(token.split('.')).toHaveLength(3) // JWT has 3 parts separated by dots
        })

        it('should include user information in token payload', () => {
            const token = generateToken(mockUser)
            const decoded = jwt.decode(token) as any

            expect(decoded.id).toBe(mockUser.id)
            expect(decoded.email).toBe(mockUser.email)
            expect(decoded.role).toBe(mockUser.role)
            expect(decoded.exp).toBeDefined() // Expiration time
        })

        it('should generate different tokens for different users', () => {
            const user2: User = { ...mockUser, id: 'different-id', email: 'different@example.com' }

            const token1 = generateToken(mockUser)
            const token2 = generateToken(user2)

            expect(token1).not.toBe(token2)
        })
    })

    describe('verifyToken', () => {
        it('should verify and decode valid token', () => {
            const token = generateToken(mockUser)
            const decoded = verifyToken(token)

            expect(decoded).toBeDefined()
            expect(decoded?.id).toBe(mockUser.id)
            expect(decoded?.email).toBe(mockUser.email)
            expect(decoded?.role).toBe(mockUser.role)
        })

        it('should return null for invalid token', () => {
            const invalidToken = 'invalid.token.here'
            const decoded = verifyToken(invalidToken)

            expect(decoded).toBeNull()
        })

        it('should return null for expired token', () => {
            // Create token with very short expiration
            const shortLivedToken = jwt.sign(
                { id: mockUser.id, email: mockUser.email, role: mockUser.role },
                process.env.JWT_SECRET || 'test-jwt-secret',
                { expiresIn: '1ms' }
            )

            // Wait a bit to ensure expiration
            setTimeout(() => {
                const decoded = verifyToken(shortLivedToken)
                expect(decoded).toBeNull()
            }, 10)
        })

        it('should return null for malformed token', () => {
            const malformedToken = 'not-a-jwt-token'
            const decoded = verifyToken(malformedToken)

            expect(decoded).toBeNull()
        })
    })

    describe('extractTokenFromHeader', () => {
        it('should extract token from valid Bearer header', () => {
            const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9'
            const authHeader = `Bearer ${token}`

            const extractedToken = extractTokenFromHeader(authHeader)
            expect(extractedToken).toBe(token)
        })

        it('should return null for missing header', () => {
            const extractedToken = extractTokenFromHeader(undefined)
            expect(extractedToken).toBeNull()
        })

        it('should return null for header without Bearer prefix', () => {
            const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9'
            const authHeader = token // Missing "Bearer " prefix

            const extractedToken = extractTokenFromHeader(authHeader)
            expect(extractedToken).toBeNull()
        })

        it('should return null for empty header', () => {
            const extractedToken = extractTokenFromHeader('')
            expect(extractedToken).toBeNull()
        })

        it('should return null for header with wrong prefix', () => {
            const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9'
            const authHeader = `Basic ${token}`

            const extractedToken = extractTokenFromHeader(authHeader)
            expect(extractedToken).toBeNull()
        })

        it('should handle Bearer header with no token', () => {
            const authHeader = 'Bearer '
            const extractedToken = extractTokenFromHeader(authHeader)
            expect(extractedToken).toBe('')
        })
    })
})