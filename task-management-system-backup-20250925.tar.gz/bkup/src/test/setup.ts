// Jest setup file for testing configuration
import '@testing-library/jest-dom'

// Mock environment variables for testing
process.env.NODE_ENV = 'test'
process.env.JWT_SECRET = 'test-jwt-secret-key-for-testing-purposes-only'
process.env.DATABASE_URL = 'postgresql://test:test@localhost:5432/test_db'

// Polyfills for Node.js environment
if (typeof global.TextEncoder === 'undefined') {
    const { TextEncoder, TextDecoder } = require('util');
    global.TextEncoder = TextEncoder;
    global.TextDecoder = TextDecoder;
}

// Mock i18next for testing
jest.mock('i18next-browser-languagedetector', () => ({
    __esModule: true,
    default: {
        type: 'languageDetector',
        init: jest.fn(),
        detect: jest.fn(() => 'ja'),
        cacheUserLanguage: jest.fn(),
    },
}))

// Mock react-i18next
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key,
        i18n: {
            changeLanguage: jest.fn(),
            language: 'ja',
        },
    }),
    initReactI18next: {
        type: '3rdParty',
        init: jest.fn(),
    },
    Trans: ({ children }: { children: React.ReactNode }) => children,
}))

// Global test utilities can be added here