import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { Provider } from 'react-redux';
import { configureStore } from '@reduxjs/toolkit';
import { MemoryRouter } from 'react-router-dom';
import Navigation from '../client/components/Navigation';
import authReducer, { logout } from '../client/store/slices/authSlice';
import { User } from '@/shared/types';

// Mock the useTranslation hook
jest.mock('../client/hooks/useTranslation', () => ({
    useTranslation: () => ({
        t: (key: string) => {
            const translations = {
                'navigation.dashboard': 'ダッシュボード',
                'navigation.tasks': 'タスク',
                'navigation.projects': 'プロジェクト',
                'navigation.profile': 'プロフィール',
                'navigation.logout': 'ログアウト',
                'users.role.admin': '管理者',
                'users.role.manager': 'マネージャー',
                'users.role.member': 'メンバー'
            };
            return translations[key] || key;
        }
    })
}));

// Mock react-router-dom navigate
const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => mockNavigate,
}));

// Mock user data for different roles
const createMockUser = (role: 'admin' | 'manager' | 'member'): User => ({
    id: '1',
    email: 'test@example.com',
    name: 'Test User',
    role,
    preferredLanguage: 'ja',
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
});

// Create a mock store
const createMockStore = (user: User | null = null, isAuthenticated: boolean = false) => {
    return configureStore({
        reducer: {
            auth: authReducer
        },
        preloadedState: {
            auth: {
                user,
                token: isAuthenticated ? 'mock-token' : null,
                isLoading: false,
                error: null,
                isAuthenticated
            }
        }
    });
};

// Test wrapper component
const TestWrapper: React.FC<{
    children: React.ReactNode;
    store?: any;
    initialRoute?: string;
}> = ({
    children,
    store = createMockStore(),
    initialRoute = '/'
}) => (
        <Provider store={store}>
            <MemoryRouter initialEntries={[initialRoute]}>
                {children}
            </MemoryRouter>
        </Provider>
    );

describe('Navigation Component', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        mockNavigate.mockClear();
    });

    it('does not render when user is not authenticated', () => {
        const store = createMockStore(null, false);

        const { container } = render(
            <TestWrapper store={store}>
                <Navigation />
            </TestWrapper>
        );

        expect(container.firstChild).toBeNull();
    });

    it('renders navigation for authenticated member user', () => {
        const user = createMockUser('member');
        const store = createMockStore(user, true);

        render(
            <TestWrapper store={store}>
                <Navigation />
            </TestWrapper>
        );

        // Check if basic navigation items are present
        expect(screen.getByText('ダッシュボード')).toBeInTheDocument();
        expect(screen.getByText('タスク')).toBeInTheDocument();

        // Projects should not be visible for members
        expect(screen.queryByText('プロジェクト')).not.toBeInTheDocument();

        // Check user info
        expect(screen.getByText('Test User')).toBeInTheDocument();
        expect(screen.getByText('メンバー')).toBeInTheDocument();
    });

    it('renders projects navigation for manager user', () => {
        const user = createMockUser('manager');
        const store = createMockStore(user, true);

        render(
            <TestWrapper store={store}>
                <Navigation />
            </TestWrapper>
        );

        // Check if all navigation items are present for manager
        expect(screen.getByText('ダッシュボード')).toBeInTheDocument();
        expect(screen.getByText('タスク')).toBeInTheDocument();
        expect(screen.getByText('プロジェクト')).toBeInTheDocument();

        // Check user role
        expect(screen.getByText('マネージャー')).toBeInTheDocument();
    });

    it('renders projects navigation for admin user', () => {
        const user = createMockUser('admin');
        const store = createMockStore(user, true);

        render(
            <TestWrapper store={store}>
                <Navigation />
            </TestWrapper>
        );

        // Check if all navigation items are present for admin
        expect(screen.getByText('ダッシュボード')).toBeInTheDocument();
        expect(screen.getByText('タスク')).toBeInTheDocument();
        expect(screen.getByText('プロジェクト')).toBeInTheDocument();

        // Check user role
        expect(screen.getByText('管理者')).toBeInTheDocument();
    });

    it('highlights active navigation item', () => {
        const user = createMockUser('admin');
        const store = createMockStore(user, true);

        render(
            <TestWrapper store={store} initialRoute="/tasks">
                <Navigation />
            </TestWrapper>
        );

        const tasksLink = screen.getByText('タスク').closest('a');
        expect(tasksLink).toHaveClass('border-blue-500', 'text-gray-900');
    });

    it('handles logout correctly', () => {
        const user = createMockUser('member');
        const store = createMockStore(user, true);
        const dispatchSpy = jest.spyOn(store, 'dispatch');

        render(
            <TestWrapper store={store}>
                <Navigation />
            </TestWrapper>
        );

        const logoutButton = screen.getByText('ログアウト');
        fireEvent.click(logoutButton);

        expect(dispatchSpy).toHaveBeenCalledWith(logout());
        expect(mockNavigate).toHaveBeenCalledWith('/login');
    });

    it('handles profile navigation', () => {
        const user = createMockUser('member');
        const store = createMockStore(user, true);

        render(
            <TestWrapper store={store}>
                <Navigation />
            </TestWrapper>
        );

        const profileButton = screen.getByLabelText('User profile');
        fireEvent.click(profileButton);

        expect(mockNavigate).toHaveBeenCalledWith('/profile');
    });

    it('toggles mobile menu correctly', () => {
        const user = createMockUser('member');
        const store = createMockStore(user, true);

        render(
            <TestWrapper store={store}>
                <Navigation />
            </TestWrapper>
        );

        // Mobile menu should not be visible initially
        expect(screen.queryByText('Test User')).toBeInTheDocument(); // Desktop version

        // Click mobile menu button
        const mobileMenuButton = screen.getByLabelText('Open main menu');
        fireEvent.click(mobileMenuButton);

        // Mobile menu should now be visible
        expect(screen.getByText('test@example.com')).toBeInTheDocument(); // Mobile version shows email
    });

    it('displays correct logo and brand name', () => {
        const user = createMockUser('member');
        const store = createMockStore(user, true);

        render(
            <TestWrapper store={store}>
                <Navigation />
            </TestWrapper>
        );

        const logo = screen.getByText('TaskManager');
        expect(logo).toBeInTheDocument();
        expect(logo.closest('a')).toHaveAttribute('href', '/dashboard');
    });
});