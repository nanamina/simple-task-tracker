/**
 * Integration tests for task API endpoints
 */

const request = require('supertest')
const express = require('express')
import { Pool } from 'pg'
import { Task, TaskStatus, TaskPriority } from '../shared/types/index'
import { CreateTaskDTO, UpdateTaskDTO } from '../shared/types/validation'

// Mock the database pool
const mockPool = {
    connect: jest.fn(),
    query: jest.fn(),
    end: jest.fn()
}

const mockClient = {
    query: jest.fn(),
    release: jest.fn()
}

// Mock database configuration
jest.mock('../server/config/database', () => ({
    getPool: jest.fn(() => mockPool),
    testConnection: jest.fn()
}))

// Mock authentication middleware
jest.mock('../server/middleware/auth', () => ({
    authenticateToken: (req: any, res: any, next: any) => {
        req.user = { id: 'test-user-id' }
        next()
    }
}))

import taskRoutes from '../server/routes/task'

// Create Express app for testing
const app = express()
app.use(express.json())
app.use('/api/tasks', taskRoutes)

// Mock task data
const mockTask: Task = {
    id: '123e4567-e89b-12d3-a456-426614174000',
    title: 'Test Task',
    description: 'Test task description',
    status: 'todo',
    priority: 'medium',
    dueDate: new Date('2025-12-31'),
    assigneeId: '123e4567-e89b-12d3-a456-426614174001',
    projectId: '123e4567-e89b-12d3-a456-426614174002',
    createdBy: 'test-user-id',
    createdAt: new Date(),
    updatedAt: new Date(),
    completedAt: null
}

const mockTasks: Task[] = [
    mockTask,
    {
        ...mockTask,
        id: '223e4567-e89b-12d3-a456-426614174001',
        title: 'Second Task',
        status: 'in-progress',
        priority: 'high'
    }
]

describe('Task API Endpoints', () => {
    beforeEach(() => {
        jest.clearAllMocks()
        mockPool.connect.mockResolvedValue(mockClient)
    })

    describe('GET /api/tasks', () => {
        it('should list tasks successfully', async () => {
            // Mock database query for listing tasks
            mockClient.query.mockResolvedValue({
                rows: mockTasks.map(task => ({
                    id: task.id,
                    title: task.title,
                    description: task.description,
                    status: task.status,
                    priority: task.priority,
                    due_date: task.dueDate,
                    assignee_id: task.assigneeId,
                    project_id: task.projectId,
                    created_by: task.createdBy,
                    created_at: task.createdAt,
                    updated_at: task.updatedAt,
                    completed_at: task.completedAt
                }))
            })

            const response = await request(app)
                .get('/api/tasks')
                .expect(200)

            expect(response.body.data).toHaveLength(2)
            expect(response.body.data[0].title).toBe('Test Task')
            expect(response.body.meta.count).toBe(2)
            expect(mockClient.query).toHaveBeenCalled()
        })

        it('should filter tasks by status', async () => {
            const filteredTasks = mockTasks.filter(task => task.status === 'todo')
            mockClient.query.mockResolvedValue({
                rows: filteredTasks.map(task => ({
                    id: task.id,
                    title: task.title,
                    description: task.description,
                    status: task.status,
                    priority: task.priority,
                    due_date: task.dueDate,
                    assignee_id: task.assigneeId,
                    project_id: task.projectId,
                    created_by: task.createdBy,
                    created_at: task.createdAt,
                    updated_at: task.updatedAt,
                    completed_at: task.completedAt
                }))
            })

            const response = await request(app)
                .get('/api/tasks?status=todo')
                .expect(200)

            expect(response.body.data).toHaveLength(1)
            expect(response.body.data[0].status).toBe('todo')
        })

        it('should return validation error for invalid status filter', async () => {
            const response = await request(app)
                .get('/api/tasks?status=invalid')
                .expect(400)

            expect(response.body.error.code).toBe('VALIDATION_ERROR')
            expect(response.body.error.message).toBe('Invalid request parameters')
        })

        it('should sort tasks by different fields', async () => {
            mockClient.query.mockResolvedValue({
                rows: mockTasks.map(task => ({
                    id: task.id,
                    title: task.title,
                    description: task.description,
                    status: task.status,
                    priority: task.priority,
                    due_date: task.dueDate,
                    assignee_id: task.assigneeId,
                    project_id: task.projectId,
                    created_by: task.createdBy,
                    created_at: task.createdAt,
                    updated_at: task.updatedAt,
                    completed_at: task.completedAt
                }))
            })

            const response = await request(app)
                .get('/api/tasks?sortBy=priority&sortOrder=asc')
                .expect(200)

            expect(response.body.data).toHaveLength(2)
            expect(mockClient.query).toHaveBeenCalled()
        })
    })

    describe('POST /api/tasks', () => {
        const validTaskData: CreateTaskDTO = {
            title: 'New Task',
            description: 'New task description',
            priority: 'high',
            dueDate: new Date('2025-12-31'),
            assigneeId: '123e4567-e89b-12d3-a456-426614174001',
            projectId: '123e4567-e89b-12d3-a456-426614174002'
        }

        it('should create a task successfully', async () => {
            const createdTask = {
                ...mockTask,
                ...validTaskData,
                id: 'new-task-id'
            }

            mockClient.query.mockResolvedValue({
                rows: [{
                    id: createdTask.id,
                    title: createdTask.title,
                    description: createdTask.description,
                    status: createdTask.status,
                    priority: createdTask.priority,
                    due_date: createdTask.dueDate,
                    assignee_id: createdTask.assigneeId,
                    project_id: createdTask.projectId,
                    created_by: createdTask.createdBy,
                    created_at: createdTask.createdAt,
                    updated_at: createdTask.updatedAt,
                    completed_at: createdTask.completedAt
                }]
            })

            // Send data with ISO string for date
            const requestData = {
                ...validTaskData,
                dueDate: validTaskData.dueDate?.toISOString()
            }

            const response = await request(app)
                .post('/api/tasks')
                .send(requestData)
                .expect(201)

            expect(response.body.data.title).toBe(validTaskData.title)
            expect(response.body.data.description).toBe(validTaskData.description)
            expect(response.body.data.priority).toBe(validTaskData.priority)
            expect(response.body.message).toBe('Task created successfully')
        })

        it('should return validation error for missing title', async () => {
            const invalidTaskData = {
                ...validTaskData,
                title: ''
            }

            const response = await request(app)
                .post('/api/tasks')
                .send(invalidTaskData)
                .expect(400)

            expect(response.body.error.code).toBe('VALIDATION_ERROR')
            expect(response.body.error.message).toBe('Invalid task data')
        })

        it('should return validation error for invalid priority', async () => {
            const invalidTaskData = {
                ...validTaskData,
                priority: 'invalid'
            }

            const response = await request(app)
                .post('/api/tasks')
                .send(invalidTaskData)
                .expect(400)

            expect(response.body.error.code).toBe('VALIDATION_ERROR')
        })

        it('should create task with minimal required fields', async () => {
            const minimalTaskData = {
                title: 'Minimal Task',
                description: 'Minimal description'
            }

            const createdTask = {
                ...mockTask,
                ...minimalTaskData,
                priority: 'medium', // default
                assigneeId: null,
                projectId: null,
                dueDate: null
            }

            mockClient.query.mockResolvedValue({
                rows: [{
                    id: createdTask.id,
                    title: createdTask.title,
                    description: createdTask.description,
                    status: createdTask.status,
                    priority: createdTask.priority,
                    due_date: createdTask.dueDate,
                    assignee_id: createdTask.assigneeId,
                    project_id: createdTask.projectId,
                    created_by: createdTask.createdBy,
                    created_at: createdTask.createdAt,
                    updated_at: createdTask.updatedAt,
                    completed_at: createdTask.completedAt
                }]
            })

            const response = await request(app)
                .post('/api/tasks')
                .send(minimalTaskData)
                .expect(201)

            expect(response.body.data.title).toBe(minimalTaskData.title)
            expect(response.body.data.priority).toBe('medium')
        })
    })

    describe('GET /api/tasks/:id', () => {
        it('should get a task by ID successfully', async () => {
            mockClient.query.mockResolvedValue({
                rows: [{
                    id: mockTask.id,
                    title: mockTask.title,
                    description: mockTask.description,
                    status: mockTask.status,
                    priority: mockTask.priority,
                    due_date: mockTask.dueDate,
                    assignee_id: mockTask.assigneeId,
                    project_id: mockTask.projectId,
                    created_by: mockTask.createdBy,
                    created_at: mockTask.createdAt,
                    updated_at: mockTask.updatedAt,
                    completed_at: mockTask.completedAt
                }]
            })

            const response = await request(app)
                .get(`/api/tasks/${mockTask.id}`)
                .expect(200)

            expect(response.body.data.id).toBe(mockTask.id)
            expect(response.body.data.title).toBe(mockTask.title)
        })

        it('should return 404 for non-existent task', async () => {
            mockClient.query.mockResolvedValue({ rows: [] })

            const response = await request(app)
                .get('/api/tasks/123e4567-e89b-12d3-a456-426614174999')
                .expect(404)

            expect(response.body.error.code).toBe('NOT_FOUND')
            expect(response.body.error.message).toBe('Task not found')
        })

        it('should return validation error for invalid UUID', async () => {
            const response = await request(app)
                .get('/api/tasks/invalid-id')
                .expect(400)

            expect(response.body.error.code).toBe('VALIDATION_ERROR')
            expect(response.body.error.message).toBe('Invalid task ID format')
        })
    })

    describe('PUT /api/tasks/:id', () => {
        const updateData: UpdateTaskDTO = {
            title: 'Updated Task',
            description: 'Updated description',
            priority: 'critical'
        }

        it('should update a task successfully', async () => {
            const updatedTask = {
                ...mockTask,
                ...updateData,
                updatedAt: new Date()
            }

            mockClient.query.mockResolvedValue({
                rows: [{
                    id: updatedTask.id,
                    title: updatedTask.title,
                    description: updatedTask.description,
                    status: updatedTask.status,
                    priority: updatedTask.priority,
                    due_date: updatedTask.dueDate,
                    assignee_id: updatedTask.assigneeId,
                    project_id: updatedTask.projectId,
                    created_by: updatedTask.createdBy,
                    created_at: updatedTask.createdAt,
                    updated_at: updatedTask.updatedAt,
                    completed_at: updatedTask.completedAt
                }]
            })

            const response = await request(app)
                .put(`/api/tasks/${mockTask.id}`)
                .send(updateData)
                .expect(200)

            expect(response.body.data.title).toBe(updateData.title)
            expect(response.body.data.description).toBe(updateData.description)
            expect(response.body.data.priority).toBe(updateData.priority)
            expect(response.body.message).toBe('Task updated successfully')
        })

        it('should return 404 for non-existent task', async () => {
            mockClient.query.mockResolvedValue({ rows: [] })

            const response = await request(app)
                .put('/api/tasks/123e4567-e89b-12d3-a456-426614174999')
                .send(updateData)
                .expect(404)

            expect(response.body.error.code).toBe('NOT_FOUND')
        })

        it('should return validation error for invalid data', async () => {
            const invalidUpdateData = {
                title: '', // Invalid empty title
                priority: 'invalid'
            }

            const response = await request(app)
                .put(`/api/tasks/${mockTask.id}`)
                .send(invalidUpdateData)
                .expect(400)

            expect(response.body.error.code).toBe('VALIDATION_ERROR')
        })
    })

    describe('DELETE /api/tasks/:id', () => {
        it('should delete a task successfully', async () => {
            mockClient.query.mockResolvedValue({ rowCount: 1 })

            const response = await request(app)
                .delete(`/api/tasks/${mockTask.id}`)
                .expect(204)

            expect(response.body).toEqual({})
        })

        it('should return 404 for non-existent task', async () => {
            mockClient.query.mockResolvedValue({ rowCount: 0 })

            const response = await request(app)
                .delete('/api/tasks/123e4567-e89b-12d3-a456-426614174999')
                .expect(404)

            expect(response.body.error.code).toBe('NOT_FOUND')
        })

        it('should return validation error for invalid UUID', async () => {
            const response = await request(app)
                .delete('/api/tasks/invalid-id')
                .expect(400)

            expect(response.body.error.code).toBe('VALIDATION_ERROR')
        })
    })

    describe('PATCH /api/tasks/:id/status', () => {
        it('should update task status successfully', async () => {
            // Mock getting current task
            mockClient.query
                .mockResolvedValueOnce({
                    rows: [{
                        id: mockTask.id,
                        title: mockTask.title,
                        description: mockTask.description,
                        status: 'todo',
                        priority: mockTask.priority,
                        due_date: mockTask.dueDate,
                        assignee_id: mockTask.assigneeId,
                        project_id: mockTask.projectId,
                        created_by: mockTask.createdBy,
                        created_at: mockTask.createdAt,
                        updated_at: mockTask.updatedAt,
                        completed_at: mockTask.completedAt
                    }]
                })
                // Mock updating status
                .mockResolvedValueOnce({
                    rows: [{
                        ...mockTask,
                        status: 'in-progress',
                        updated_at: new Date()
                    }]
                })

            const response = await request(app)
                .patch(`/api/tasks/${mockTask.id}/status`)
                .send({ status: 'in-progress' })
                .expect(200)

            expect(response.body.data.status).toBe('in-progress')
            expect(response.body.message).toBe('Task status updated successfully')
        })

        it('should return validation error for invalid status', async () => {
            const response = await request(app)
                .patch(`/api/tasks/${mockTask.id}/status`)
                .send({ status: 'invalid-status' })
                .expect(400)

            expect(response.body.error.code).toBe('VALIDATION_ERROR')
        })

        it('should return 404 for non-existent task', async () => {
            mockClient.query.mockResolvedValue({ rows: [] })

            const response = await request(app)
                .patch('/api/tasks/123e4567-e89b-12d3-a456-426614174999/status')
                .send({ status: 'completed' })
                .expect(404)

            expect(response.body.error.code).toBe('NOT_FOUND')
        })

        it('should validate status transitions', async () => {
            // Mock getting current task with completed status
            mockClient.query
                .mockResolvedValueOnce({
                    rows: [{
                        id: mockTask.id,
                        title: mockTask.title,
                        description: mockTask.description,
                        status: 'completed',
                        priority: mockTask.priority,
                        due_date: mockTask.dueDate,
                        assignee_id: mockTask.assigneeId,
                        project_id: mockTask.projectId,
                        created_by: mockTask.createdBy,
                        created_at: mockTask.createdAt,
                        updated_at: mockTask.updatedAt,
                        completed_at: mockTask.completedAt
                    }]
                })
                // Mock updating status
                .mockResolvedValueOnce({
                    rows: [{
                        id: mockTask.id,
                        title: mockTask.title,
                        description: mockTask.description,
                        status: 'todo',
                        priority: mockTask.priority,
                        due_date: mockTask.dueDate,
                        assignee_id: mockTask.assigneeId,
                        project_id: mockTask.projectId,
                        created_by: mockTask.createdBy,
                        created_at: mockTask.createdAt,
                        updated_at: new Date(),
                        completed_at: null
                    }]
                })

            const response = await request(app)
                .patch(`/api/tasks/${mockTask.id}/status`)
                .send({ status: 'todo' })
                .expect(200) // This should succeed as our validation allows all transitions

            expect(mockClient.query).toHaveBeenCalledTimes(2) // Get and update calls
        })
    })

    describe('Error Handling', () => {
        it('should handle database connection errors', async () => {
            mockPool.connect.mockRejectedValue(new Error('Database connection failed'))

            const response = await request(app)
                .get('/api/tasks')
                .expect(500)

            expect(response.body.error.code).toBe('INTERNAL_ERROR')
            expect(response.body.error.message).toBe('Failed to retrieve tasks')
        })

        it('should handle database query errors', async () => {
            mockClient.query.mockRejectedValue(new Error('Query failed'))

            const response = await request(app)
                .get('/api/tasks')
                .expect(500)

            expect(response.body.error.code).toBe('INTERNAL_ERROR')
        })
    })
})