import React from 'react';
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
// Mock the useTranslation hook
jest.mock('../client/hooks/useTranslation', () => ({
    useTranslation: () => ({
        t: (key: string) => key
    })
}));
import { ToastContainer, ToastNotification } from '../client/components/NotificationToast';

// Test wrapper component
const TestWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <div>{children}</div>
);

// Mock notification data
const createMockToastNotification = (overrides: Partial<ToastNotification> = {}): ToastNotification => ({
    id: '1',
    type: 'info',
    title: 'Test Toast',
    message: 'This is a test toast notification',
    duration: 0, // No auto-dismiss by default for testing
    ...overrides
});

describe('ToastContainer Component', () => {
    const mockOnDismiss = jest.fn();

    beforeEach(() => {
        jest.clearAllMocks();
        jest.useFakeTimers();
    });

    afterEach(() => {
        jest.useRealTimers();
    });

    it('renders nothing when no notifications', () => {
        const { container } = render(
            <TestWrapper>
                <ToastContainer
                    notifications={[]}
                    onDismiss={mockOnDismiss}
                />
            </TestWrapper>
        );

        expect(container.firstChild).toBeNull();
    });

    it('renders toast notifications correctly', () => {
        const notifications = [
            createMockToastNotification({
                id: '1',
                type: 'success',
                title: 'Success Toast',
                message: 'Operation completed successfully'
            }),
            createMockToastNotification({
                id: '2',
                type: 'error',
                title: 'Error Toast',
                message: 'An error occurred'
            })
        ];

        render(
            <TestWrapper>
                <ToastContainer
                    notifications={notifications}
                    onDismiss={mockOnDismiss}
                />
            </TestWrapper>
        );

        expect(screen.getByText('Success Toast')).toBeInTheDocument();
        expect(screen.getByText('Operation completed successfully')).toBeInTheDocument();
        expect(screen.getByText('Error Toast')).toBeInTheDocument();
        expect(screen.getByText('An error occurred')).toBeInTheDocument();
    });

    it('applies correct styles for different notification types', () => {
        const notifications = [
            createMockToastNotification({
                id: '1',
                type: 'success',
                title: 'Success',
                message: 'Success message'
            }),
            createMockToastNotification({
                id: '2',
                type: 'error',
                title: 'Error',
                message: 'Error message'
            }),
            createMockToastNotification({
                id: '3',
                type: 'warning',
                title: 'Warning',
                message: 'Warning message'
            }),
            createMockToastNotification({
                id: '4',
                type: 'info',
                title: 'Info',
                message: 'Info message'
            })
        ];

        render(
            <TestWrapper>
                <ToastContainer
                    notifications={notifications}
                    onDismiss={mockOnDismiss}
                />
            </TestWrapper>
        );

        // Check for different colored elements
        expect(document.querySelector('.bg-green-50')).toBeInTheDocument(); // Success
        expect(document.querySelector('.bg-red-50')).toBeInTheDocument(); // Error
        expect(document.querySelector('.bg-yellow-50')).toBeInTheDocument(); // Warning
        expect(document.querySelector('.bg-blue-50')).toBeInTheDocument(); // Info
    });

    it('calls onDismiss when close button is clicked', () => {
        const notification = createMockToastNotification({
            id: 'test-1',
            title: 'Test Toast'
        });

        render(
            <TestWrapper>
                <ToastContainer
                    notifications={[notification]}
                    onDismiss={mockOnDismiss}
                />
            </TestWrapper>
        );

        const closeButton = screen.getByRole('button', { name: 'Close' });
        fireEvent.click(closeButton);

        // Should trigger exit animation, then call onDismiss after delay
        act(() => {
            jest.advanceTimersByTime(300);
        });

        expect(mockOnDismiss).toHaveBeenCalledWith('test-1');
    });

    it('auto-dismisses notifications with duration set', () => {
        const notification = createMockToastNotification({
            id: 'auto-dismiss',
            title: 'Auto Dismiss Toast',
            duration: 3000
        });

        render(
            <TestWrapper>
                <ToastContainer
                    notifications={[notification]}
                    onDismiss={mockOnDismiss}
                />
            </TestWrapper>
        );

        // Fast-forward time to trigger auto-dismiss
        act(() => {
            jest.advanceTimersByTime(3000);
        });

        // Should trigger exit animation
        act(() => {
            jest.advanceTimersByTime(300);
        });

        expect(mockOnDismiss).toHaveBeenCalledWith('auto-dismiss');
    });

    it('does not auto-dismiss notifications with duration 0', () => {
        const notification = createMockToastNotification({
            id: 'no-auto-dismiss',
            title: 'Persistent Toast',
            duration: 0
        });

        render(
            <TestWrapper>
                <ToastContainer
                    notifications={[notification]}
                    onDismiss={mockOnDismiss}
                />
            </TestWrapper>
        );

        // Fast-forward time
        act(() => {
            jest.advanceTimersByTime(5000);
        });

        // Should not be dismissed
        expect(mockOnDismiss).not.toHaveBeenCalled();
        expect(screen.getByText('Persistent Toast')).toBeInTheDocument();
    });

    it('handles action button clicks correctly', () => {
        const mockActionClick = jest.fn();
        const notification = createMockToastNotification({
            id: 'action-toast',
            title: 'Action Toast',
            action: {
                label: 'Take Action',
                onClick: mockActionClick
            }
        });

        render(
            <TestWrapper>
                <ToastContainer
                    notifications={[notification]}
                    onDismiss={mockOnDismiss}
                />
            </TestWrapper>
        );

        const actionButton = screen.getByText('Take Action');
        fireEvent.click(actionButton);

        expect(mockActionClick).toHaveBeenCalled();

        // Should also dismiss the toast
        act(() => {
            jest.advanceTimersByTime(300);
        });

        expect(mockOnDismiss).toHaveBeenCalledWith('action-toast');
    });

    it('limits visible notifications based on maxVisible prop', () => {
        const notifications = Array.from({ length: 10 }, (_, i) =>
            createMockToastNotification({
                id: `toast-${i}`,
                title: `Toast ${i}`
            })
        );

        render(
            <TestWrapper>
                <ToastContainer
                    notifications={notifications}
                    onDismiss={mockOnDismiss}
                    maxVisible={3}
                />
            </TestWrapper>
        );

        // Should only render 3 toasts
        expect(screen.getAllByText(/Toast \d/)).toHaveLength(3);
    });

    it('positions toasts correctly based on position prop', () => {
        const notification = createMockToastNotification();

        const { rerender } = render(
            <TestWrapper>
                <ToastContainer
                    notifications={[notification]}
                    onDismiss={mockOnDismiss}
                    position="top-right"
                />
            </TestWrapper>
        );

        let container = document.querySelector('.fixed');
        expect(container).toHaveClass('top-0', 'right-0', 'items-end');

        rerender(
            <TestWrapper>
                <ToastContainer
                    notifications={[notification]}
                    onDismiss={mockOnDismiss}
                    position="bottom-left"
                />
            </TestWrapper>
        );

        container = document.querySelector('.fixed');
        expect(container).toHaveClass('bottom-0', 'left-0', 'items-start');

        rerender(
            <TestWrapper>
                <ToastContainer
                    notifications={[notification]}
                    onDismiss={mockOnDismiss}
                    position="top-center"
                />
            </TestWrapper>
        );

        container = document.querySelector('.fixed');
        expect(container).toHaveClass('top-0', 'left-1/2', 'transform', '-translate-x-1/2', 'items-center');
    });

    it('shows correct icons for different notification types', () => {
        const notifications = [
            createMockToastNotification({
                id: '1',
                type: 'success',
                title: 'Success'
            }),
            createMockToastNotification({
                id: '2',
                type: 'error',
                title: 'Error'
            }),
            createMockToastNotification({
                id: '3',
                type: 'warning',
                title: 'Warning'
            }),
            createMockToastNotification({
                id: '4',
                type: 'info',
                title: 'Info'
            })
        ];

        render(
            <TestWrapper>
                <ToastContainer
                    notifications={notifications}
                    onDismiss={mockOnDismiss}
                />
            </TestWrapper>
        );

        // Check for different colored icons
        expect(document.querySelector('.text-green-500')).toBeInTheDocument(); // Success
        expect(document.querySelector('.text-red-500')).toBeInTheDocument(); // Error
        expect(document.querySelector('.text-yellow-500')).toBeInTheDocument(); // Warning
        expect(document.querySelector('.text-blue-500')).toBeInTheDocument(); // Info
    });

    it('handles entrance animation correctly', async () => {
        const notification = createMockToastNotification({
            title: 'Animated Toast'
        });

        render(
            <TestWrapper>
                <ToastContainer
                    notifications={[notification]}
                    onDismiss={mockOnDismiss}
                />
            </TestWrapper>
        );

        // Initially should have translate-x-full (off-screen)
        const toast = screen.getByText('Animated Toast').closest('div');
        expect(toast).toHaveClass('translate-x-full', 'opacity-0');

        // After animation delay, should be visible
        act(() => {
            jest.advanceTimersByTime(100);
        });

        await waitFor(() => {
            expect(toast).toHaveClass('translate-x-0', 'opacity-100');
        });
    });

    it('clears auto-dismiss timer when component unmounts', () => {
        const notification = createMockToastNotification({
            id: 'timer-test',
            duration: 5000
        });

        const { unmount } = render(
            <TestWrapper>
                <ToastContainer
                    notifications={[notification]}
                    onDismiss={mockOnDismiss}
                />
            </TestWrapper>
        );

        // Unmount before timer expires
        unmount();

        // Fast-forward past the original duration
        act(() => {
            jest.advanceTimersByTime(6000);
        });

        // Should not call onDismiss since component was unmounted
        expect(mockOnDismiss).not.toHaveBeenCalled();
    });
});