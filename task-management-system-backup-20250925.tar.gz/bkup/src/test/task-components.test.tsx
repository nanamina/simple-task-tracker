import React from 'react'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { Provider } from 'react-redux'
import { configureStore } from '@reduxjs/toolkit'
import { TaskCard } from '@/client/components/TaskCard'
import { TaskForm } from '@/client/components/TaskForm'
import { TaskList } from '@/client/components/TaskList'
import { Task } from '@/shared/types'
import taskSlice from '@/client/store/slices/taskSlice'
import authSlice from '@/client/store/slices/authSlice'

// Test data
const mockTask: Task = {
    id: '1',
    title: 'Test Task',
    description: 'Test Description',
    status: 'todo',
    priority: 'medium',
    dueDate: new Date('2024-12-31'),
    assigneeId: 'user1',
    projectId: 'project1',
    createdBy: 'user1',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
}

const mockOverdueTask: Task = {
    ...mockTask,
    id: '2',
    title: 'Overdue Task',
    dueDate: new Date('2023-01-01'), // Past date
}

// Mock the hooks
jest.mock('@/client/hooks/useTranslation', () => ({
    useTranslation: () => ({
        t: (key: string, params?: any) => {
            // Simple mock translation function
            const translations: Record<string, string> = {
                'tasks.title': 'Tasks',
                'tasks.fields.title': 'Title',
                'tasks.fields.description': 'Description',
                'tasks.fields.status': 'Status',
                'tasks.fields.priority': 'Priority',
                'tasks.fields.dueDate': 'Due Date',
                'tasks.fields.assignee': 'Assignee',
                'tasks.fields.project': 'Project',
                'tasks.fields.createdAt': 'Created',
                'tasks.status.todo': 'To Do',
                'tasks.status.inProgress': 'In Progress',
                'tasks.status.completed': 'Completed',
                'tasks.priority.low': 'Low',
                'tasks.priority.medium': 'Medium',
                'tasks.priority.high': 'High',
                'tasks.priority.critical': 'Critical',
                'tasks.filters.overdue': 'Overdue',
                'tasks.filters.all': 'All',
                'tasks.filters.assigned': 'Assigned to Me',
                'tasks.filters.unassigned': 'Unassigned',
                'tasks.messages.confirmDelete': 'Are you sure you want to delete this task?',
                'tasks.messages.noTasks': 'No tasks found',
                'tasks.assign': 'Assign',
                'tasks.create': 'New Task',
                'tasks.edit': 'Edit Task',
                'common.edit': 'Edit',
                'common.delete': 'Delete',
                'common.save': 'Save',
                'common.cancel': 'Cancel',
                'common.create': 'Create',
                'common.update': 'Update',
                'common.loading': 'Loading...',
                'common.search': 'Search',
                'common.sort': 'Sort',
                'validation.required': `${params?.field} is required`,
                'validation.pastDate': 'Past dates are not allowed',
            }
            return translations[key] || key
        },
    }),
}))

jest.mock('@/client/hooks/useFormatting', () => ({
    useFormatting: () => ({
        formatDate: (date: Date) => date.toLocaleDateString('ja-JP'),
    }),
}))

// Mock useTasks hook
let mockUseTasks = {
    tasks: [mockTask],
    filteredTasks: [mockTask],
    loading: false,
    error: null,
    filters: {},
    sortBy: 'createdAt' as const,
    sortOrder: 'desc' as const,
    loadTasks: jest.fn(),
    addTask: jest.fn(),
    editTask: jest.fn(),
    changeTaskStatus: jest.fn(),
    removeTask: jest.fn(),
    updateFilters: jest.fn(),
    updateSorting: jest.fn(),
    clearTaskError: jest.fn(),
}

jest.mock('@/client/hooks/useTasks', () => ({
    useTasks: () => mockUseTasks,
}))

// Create a test store
const createTestStore = (initialState = {}) => {
    return configureStore({
        reducer: {
            tasks: taskSlice,
            auth: authSlice,
        },
        preloadedState: initialState,
    })
}

describe('TaskCard Component', () => {
    const mockProps = {
        task: mockTask,
        onStatusChange: jest.fn(),
        onEdit: jest.fn(),
        onDelete: jest.fn(),
        onAssign: jest.fn(),
    }

    beforeEach(() => {
        jest.clearAllMocks()
    })

    it('renders task information correctly', () => {
        render(<TaskCard {...mockProps} />)

        expect(screen.getByText('Test Task')).toBeInTheDocument()
        expect(screen.getByText('Test Description')).toBeInTheDocument()
        expect(screen.getAllByText('To Do')).toHaveLength(2) // Badge and select option
        expect(screen.getByText('Medium')).toBeInTheDocument()
    })

    it('shows overdue indicator for past due tasks', () => {
        render(<TaskCard {...mockProps} task={mockOverdueTask} />)

        expect(screen.getByText('Overdue')).toBeInTheDocument()
    })

    it('calls onStatusChange when status is changed', () => {
        render(<TaskCard {...mockProps} />)

        const statusSelect = screen.getByDisplayValue('To Do')
        fireEvent.change(statusSelect, { target: { value: 'in-progress' } })

        expect(mockProps.onStatusChange).toHaveBeenCalledWith('1', 'in-progress')
    })

    it('calls onEdit when edit button is clicked', () => {
        render(<TaskCard {...mockProps} />)

        const editButton = screen.getByTitle('Edit')
        fireEvent.click(editButton)

        expect(mockProps.onEdit).toHaveBeenCalledWith(mockTask)
    })

    it('shows confirmation dialog and calls onDelete when delete button is clicked', () => {
        // Mock window.confirm
        const confirmSpy = jest.spyOn(window, 'confirm').mockReturnValue(true)

        render(<TaskCard {...mockProps} />)

        const deleteButton = screen.getByTitle('Delete')
        fireEvent.click(deleteButton)

        expect(confirmSpy).toHaveBeenCalledWith('Are you sure you want to delete this task?')
        expect(mockProps.onDelete).toHaveBeenCalledWith('1')

        confirmSpy.mockRestore()
    })

    it('shows assign button for unassigned tasks', () => {
        const unassignedTask = { ...mockTask, assigneeId: undefined }
        render(<TaskCard {...mockProps} task={unassignedTask} />)

        expect(screen.getByText('Assign')).toBeInTheDocument()
    })
})

describe('TaskForm Component', () => {
    const mockProps = {
        onSubmit: jest.fn(),
        onCancel: jest.fn(),
        loading: false,
    }

    beforeEach(() => {
        jest.clearAllMocks()
    })

    it('renders form fields correctly', () => {
        render(<TaskForm {...mockProps} />)

        expect(screen.getByLabelText(/Title/)).toBeInTheDocument()
        expect(screen.getByLabelText(/Description/)).toBeInTheDocument()
        expect(screen.getByLabelText(/Status/)).toBeInTheDocument()
        expect(screen.getByLabelText(/Priority/)).toBeInTheDocument()
        expect(screen.getByLabelText(/Due Date/)).toBeInTheDocument()
    })

    it('populates form with task data when editing', () => {
        render(<TaskForm {...mockProps} task={mockTask} />)

        expect(screen.getByDisplayValue('Test Task')).toBeInTheDocument()
        expect(screen.getByDisplayValue('Test Description')).toBeInTheDocument()
    })

    it('validates required fields', async () => {
        render(<TaskForm {...mockProps} />)

        const submitButton = screen.getByText('Create')
        fireEvent.click(submitButton)

        await waitFor(() => {
            expect(screen.getByText('Title is required')).toBeInTheDocument()
            expect(screen.getByText('Description is required')).toBeInTheDocument()
        })

        expect(mockProps.onSubmit).not.toHaveBeenCalled()
    })

    it('validates past due dates', async () => {
        render(<TaskForm {...mockProps} />)

        const titleInput = screen.getByLabelText(/Title/)
        const descriptionInput = screen.getByLabelText(/Description/)
        const dueDateInput = screen.getByLabelText(/Due Date/)

        fireEvent.change(titleInput, { target: { value: 'Test Task' } })
        fireEvent.change(descriptionInput, { target: { value: 'Test Description' } })
        fireEvent.change(dueDateInput, { target: { value: '2020-01-01' } })

        const submitButton = screen.getByText('Create')
        fireEvent.click(submitButton)

        await waitFor(() => {
            expect(screen.getByText('Past dates are not allowed')).toBeInTheDocument()
        })

        expect(mockProps.onSubmit).not.toHaveBeenCalled()
    })

    it('submits form with valid data', async () => {
        render(<TaskForm {...mockProps} />)

        const titleInput = screen.getByLabelText(/Title/)
        const descriptionInput = screen.getByLabelText(/Description/)

        fireEvent.change(titleInput, { target: { value: 'New Task' } })
        fireEvent.change(descriptionInput, { target: { value: 'New Description' } })

        const submitButton = screen.getByText('Create')
        fireEvent.click(submitButton)

        await waitFor(() => {
            expect(mockProps.onSubmit).toHaveBeenCalledWith({
                title: 'New Task',
                description: 'New Description',
                status: 'todo',
                priority: 'medium',
                dueDate: undefined,
                assigneeId: undefined,
                projectId: undefined,
            })
        })
    })

    it('calls onCancel when cancel button is clicked', () => {
        render(<TaskForm {...mockProps} />)

        const cancelButton = screen.getByText('Cancel')
        fireEvent.click(cancelButton)

        expect(mockProps.onCancel).toHaveBeenCalled()
    })
})

describe('TaskList Component', () => {
    const initialState = {
        tasks: {
            tasks: [mockTask],
            loading: false,
            error: null,
            filters: {},
            sortBy: 'createdAt' as const,
            sortOrder: 'desc' as const,
        },
        auth: {
            user: null,
            token: null,
            loading: false,
            error: null,
        },
    }

    // Mock fetch for API calls
    beforeEach(() => {
        global.fetch = jest.fn().mockResolvedValue({
            ok: true,
            json: () => Promise.resolve([mockTask]),
        })
        jest.clearAllMocks()
    })

    afterEach(() => {
        jest.restoreAllMocks()
    })

    it('renders task list with tasks', () => {
        const store = createTestStore(initialState)

        render(
            <Provider store={store}>
                <TaskList />
            </Provider>
        )

        expect(screen.getByText('Test Task')).toBeInTheDocument()
    })

    it('shows create task button', () => {
        const store = createTestStore(initialState)

        render(
            <Provider store={store}>
                <TaskList />
            </Provider>
        )

        expect(screen.getByText('New Task')).toBeInTheDocument()
    })

    it('opens task form when create button is clicked', () => {
        const store = createTestStore(initialState)

        render(
            <Provider store={store}>
                <TaskList />
            </Provider>
        )

        const createButton = screen.getByText('New Task')
        fireEvent.click(createButton)

        // Form should be visible
        expect(screen.getByLabelText(/Title/)).toBeInTheDocument()
    })

    it('filters tasks by search term', () => {
        const store = createTestStore(initialState)

        render(
            <Provider store={store}>
                <TaskList />
            </Provider>
        )

        const searchInput = screen.getByPlaceholderText('Search')
        fireEvent.change(searchInput, { target: { value: 'Test' } })

        // Task should still be visible
        expect(screen.getByText('Test Task')).toBeInTheDocument()
    })

    it('shows loading state', () => {
        // Update mock to show loading state
        mockUseTasks.loading = true
        mockUseTasks.filteredTasks = []

        const store = createTestStore(initialState)

        render(
            <Provider store={store}>
                <TaskList />
            </Provider>
        )

        expect(screen.getByText('Loading...')).toBeInTheDocument()

        // Reset mock
        mockUseTasks.loading = false
        mockUseTasks.filteredTasks = [mockTask]
    })

    it('shows error message', () => {
        // Update mock to show error state
        mockUseTasks.error = 'Failed to load tasks'

        const store = createTestStore(initialState)

        render(
            <Provider store={store}>
                <TaskList />
            </Provider>
        )

        expect(screen.getByText('Failed to load tasks')).toBeInTheDocument()

        // Reset mock
        mockUseTasks.error = null
    })
})