import React from 'react'
import { render } from '@testing-library/react'
import { Provider } from 'react-redux'
import { BrowserRouter } from 'react-router-dom'
import { configureStore } from '@reduxjs/toolkit'
import '@testing-library/jest-dom'
import authSlice from '@/client/store/slices/authSlice'

// Mock i18next
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key,
    }),
}))

// Mock react-router-dom
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => jest.fn(),
    useLocation: () => ({ pathname: '/login' }),
}))

const createTestStore = () => {
    return configureStore({
        reducer: {
            auth: authSlice,
        },
    })
}

describe('Auth Components', () => {
    test('can create test store', () => {
        const store = createTestStore()
        expect(store).toBeDefined()
    })

    test('can render with providers', () => {
        const store = createTestStore()
        const TestComponent = () => <div>Test</div>

        const { getByText } = render(
            <Provider store={store}>
                <BrowserRouter>
                    <TestComponent />
                </BrowserRouter>
            </Provider>
        )

        expect(getByText('Test')).toBeInTheDocument()
    })
})