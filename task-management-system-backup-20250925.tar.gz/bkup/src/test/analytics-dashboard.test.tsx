import React from 'react';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { AnalyticsDashboard } from '../client/components/AnalyticsDashboard';

// Mock the translation hook
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key
    })
}));

// Mock fetch
const mockFetch = jest.fn();
global.fetch = mockFetch;

// Mock localStorage
const mockLocalStorage = {
    getItem: jest.fn(),
    setItem: jest.fn(),
    removeItem: jest.fn()
};
Object.defineProperty(window, 'localStorage', {
    value: mockLocalStorage
});

// Mock URL.createObjectURL and related APIs for export functionality
Object.defineProperty(window, 'URL', {
    value: {
        createObjectURL: jest.fn(() => 'mock-url'),
        revokeObjectURL: jest.fn()
    }
});

describe('AnalyticsDashboard', () => {
    const mockProjectMetrics = {
        projectId: 'project-1',
        projectName: 'Test Project',
        totalTasks: 10,
        statusDistribution: {
            todo: 3,
            'in-progress': 4,
            completed: 3
        },
        completionRate: 30,
        averageTaskDuration: 5.5,
        overdueTasksCount: 2,
        overdueTasks: [
            {
                id: 'task-1',
                title: 'Overdue Task 1',
                dueDate: '2024-01-01T00:00:00.000Z',
                assigneeId: 'user-1',
                priority: 'high'
            }
        ]
    };

    const mockTeamWorkload = [
        {
            userId: 'user-1',
            userName: 'John Doe',
            totalTasks: 5,
            completedTasks: 2,
            inProgressTasks: 2,
            todoTasks: 1,
            overdueTasks: 1,
            completionRate: 40
        },
        {
            userId: 'user-2',
            userName: 'Jane Smith',
            totalTasks: 3,
            completedTasks: 3,
            inProgressTasks: 0,
            todoTasks: 0,
            overdueTasks: 0,
            completionRate: 100
        }
    ];

    const mockCompletionTrends = [
        { date: '2024-01-01', completedTasks: 2 },
        { date: '2024-01-02', completedTasks: 3 },
        { date: '2024-01-03', completedTasks: 1 }
    ];

    beforeEach(() => {
        mockLocalStorage.getItem.mockReturnValue('mock-token');
        mockFetch.mockClear();
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    it('should render loading state initially', () => {
        // Arrange
        mockFetch.mockImplementation(() => new Promise(() => { })); // Never resolves

        // Act
        render(<AnalyticsDashboard projectId="project-1" />);

        // Assert
        expect(document.querySelector('.animate-pulse')).toBeInTheDocument();
    });

    it('should render project analytics dashboard successfully', async () => {
        // Arrange
        mockFetch
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockProjectMetrics })
            })
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockTeamWorkload })
            })
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockCompletionTrends })
            });

        // Act
        render(<AnalyticsDashboard projectId="project-1" />);

        // Assert
        await waitFor(() => {
            expect(screen.getByText('Test Project Analytics')).toBeInTheDocument();
        });

        // Check summary cards
        expect(screen.getByText('Total Tasks')).toBeInTheDocument();
        expect(screen.getByText('30%')).toBeInTheDocument(); // Completion rate
        expect(screen.getByText('5.5')).toBeInTheDocument(); // Average duration
        expect(screen.getByText('Overdue Tasks')).toBeInTheDocument();

        // Check overdue tasks table
        expect(screen.getByText('Overdue Tasks')).toBeInTheDocument();
        expect(screen.getByText('Overdue Task 1')).toBeInTheDocument();
    });

    it('should render team analytics when no project specified', async () => {
        // Arrange
        mockFetch
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockTeamWorkload })
            })
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockCompletionTrends })
            });

        // Act
        render(<AnalyticsDashboard />);

        // Assert
        await waitFor(() => {
            expect(screen.getByText('Team Analytics')).toBeInTheDocument();
        });

        // Should not show project-specific metrics
        expect(screen.queryByText('Total Tasks')).not.toBeInTheDocument();
    });

    it('should handle API errors gracefully', async () => {
        // Arrange
        mockFetch.mockRejectedValue(new Error('API Error'));

        // Act
        render(<AnalyticsDashboard projectId="project-1" />);

        // Assert
        await waitFor(() => {
            expect(screen.getByText('Analytics Error')).toBeInTheDocument();
        });
    });

    it('should handle authentication errors', async () => {
        // Arrange
        mockLocalStorage.getItem.mockReturnValue(null);

        // Act
        render(<AnalyticsDashboard projectId="project-1" />);

        // Assert
        await waitFor(() => {
            expect(screen.getByText('Analytics Error')).toBeInTheDocument();
        });
    });

    it('should update data when period changes', async () => {
        // Arrange
        mockFetch
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockProjectMetrics })
            })
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockTeamWorkload })
            })
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockCompletionTrends })
            });

        // Act
        render(<AnalyticsDashboard projectId="project-1" />);

        await waitFor(() => {
            expect(screen.getByText('Test Project Analytics')).toBeInTheDocument();
        });

        // Clear previous calls
        mockFetch.mockClear();

        // Mock new responses for period change
        mockFetch
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockProjectMetrics })
            })
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockTeamWorkload })
            })
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockCompletionTrends })
            });

        // Change period
        const periodSelect = screen.getByDisplayValue('Last 30 days');
        fireEvent.change(periodSelect, { target: { value: '7' } });

        // Assert
        await waitFor(() => {
            expect(mockFetch).toHaveBeenCalledWith(
                expect.stringContaining('days=7'),
                expect.any(Object)
            );
        });
    });

    it('should handle CSV export', async () => {
        // Arrange
        mockFetch
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockProjectMetrics })
            })
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockTeamWorkload })
            })
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockCompletionTrends })
            });

        render(<AnalyticsDashboard projectId="project-1" />);

        await waitFor(() => {
            expect(screen.getByText('Test Project Analytics')).toBeInTheDocument();
        });

        // Mock export response
        mockFetch.mockResolvedValueOnce({
            ok: true,
            blob: () => Promise.resolve(new Blob(['csv content'], { type: 'text/csv' }))
        });

        // Mock DOM methods
        const mockClick = jest.fn();
        const mockAppendChild = jest.fn();
        const mockRemoveChild = jest.fn();
        const mockCreateElement = jest.spyOn(document, 'createElement').mockReturnValue({
            href: '',
            download: '',
            click: mockClick,
            style: {}
        } as any);

        document.body.appendChild = mockAppendChild;
        document.body.removeChild = mockRemoveChild;

        // Act
        const exportButton = screen.getByText('Export CSV');
        fireEvent.click(exportButton);

        // Assert
        await waitFor(() => {
            expect(mockFetch).toHaveBeenCalledWith(
                '/api/analytics/projects/project-1/export?format=csv',
                expect.objectContaining({
                    headers: expect.objectContaining({
                        'Authorization': 'Bearer mock-token'
                    })
                })
            );
        });

        expect(mockCreateElement).toHaveBeenCalledWith('a');
        expect(mockClick).toHaveBeenCalled();
    });

    it('should handle JSON export', async () => {
        // Arrange
        mockFetch
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockProjectMetrics })
            })
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockTeamWorkload })
            })
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockCompletionTrends })
            });

        render(<AnalyticsDashboard projectId="project-1" />);

        await waitFor(() => {
            expect(screen.getByText('Test Project Analytics')).toBeInTheDocument();
        });

        // Mock export response
        mockFetch.mockResolvedValueOnce({
            ok: true,
            blob: () => Promise.resolve(new Blob(['{"data": "json"}'], { type: 'application/json' }))
        });

        // Mock DOM methods
        const mockClick = jest.fn();
        const mockCreateElement = jest.spyOn(document, 'createElement').mockReturnValue({
            href: '',
            download: '',
            click: mockClick,
            style: {}
        } as any);

        // Act
        const exportButton = screen.getByText('Export JSON');
        fireEvent.click(exportButton);

        // Assert
        await waitFor(() => {
            expect(mockFetch).toHaveBeenCalledWith(
                '/api/analytics/projects/project-1/export?format=json',
                expect.any(Object)
            );
        });
    });

    it('should handle export errors', async () => {
        // Arrange
        mockFetch
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockProjectMetrics })
            })
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockTeamWorkload })
            })
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockCompletionTrends })
            });

        render(<AnalyticsDashboard projectId="project-1" />);

        await waitFor(() => {
            expect(screen.getByText('Test Project Analytics')).toBeInTheDocument();
        });

        // Mock export error
        mockFetch.mockRejectedValueOnce(new Error('Export failed'));

        // Act
        const exportButton = screen.getByText('Export CSV');
        fireEvent.click(exportButton);

        // Assert
        await waitFor(() => {
            expect(screen.getByText('Analytics Error')).toBeInTheDocument();
        });
    });

    it('should not show export buttons when no project specified', async () => {
        // Arrange
        mockFetch
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockTeamWorkload })
            })
            .mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({ data: mockCompletionTrends })
            });

        // Act
        render(<AnalyticsDashboard />);

        // Assert
        await waitFor(() => {
            expect(screen.getByText('Team Analytics')).toBeInTheDocument();
        });

        expect(screen.queryByText('Export CSV')).not.toBeInTheDocument();
        expect(screen.queryByText('Export JSON')).not.toBeInTheDocument();
    });
});