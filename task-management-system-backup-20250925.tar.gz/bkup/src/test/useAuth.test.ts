import { useAuth } from '@/client/hooks/useAuth'

describe('useAuth hook', () => {
    test('hook exists and can be imported', () => {
        expect(useAuth).toBeDefined()
        expect(typeof useAuth).toBe('function')
    })
})