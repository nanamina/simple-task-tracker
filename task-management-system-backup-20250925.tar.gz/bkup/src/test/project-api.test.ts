/**
 * Integration tests for project API endpoints
 */

const request = require('supertest')
const express = require('express')
import { Pool } from 'pg'
import { Project } from '../shared/types/index'
import { CreateProjectDTO, UpdateProjectDTO } from '../shared/types/validation'

// Mock the database pool
const mockPool = {
    connect: jest.fn(),
    query: jest.fn(),
    end: jest.fn()
}

const mockClient = {
    query: jest.fn(),
    release: jest.fn()
}

// Mock database configuration
jest.mock('../server/config/database', () => ({
    getPool: jest.fn(() => mockPool),
    testConnection: jest.fn()
}))

// Mock authentication middleware
jest.mock('../server/middleware/auth', () => ({
    authenticateToken: (req: any, res: any, next: any) => {
        req.user = {
            id: 'test-user-id',
            role: 'admin',
            email: 'test@example.com',
            name: 'Test User'
        }
        next()
    }
}))

import projectRoutes from '../server/routes/project'

// Create Express app for testing
const app = express()
app.use(express.json())
app.use('/api/projects', projectRoutes)

// Mock project data
const mockProject: Project = {
    id: '123e4567-e89b-12d3-a456-426614174000',
    name: 'Test Project',
    description: 'Test project description',
    createdBy: 'test-user-id',
    createdAt: new Date(),
    updatedAt: new Date(),
    members: ['test-user-id']
}

describe('Project API Endpoints', () => {
    beforeEach(() => {
        jest.clearAllMocks()
        mockPool.connect.mockResolvedValue(mockClient)
    })

    describe('POST /api/projects', () => {
        const validProjectData: CreateProjectDTO = {
            name: 'New Project',
            description: 'New project description'
        }

        it('should create a project successfully', async () => {
            // Mock transaction queries
            mockClient.query
                .mockResolvedValueOnce(undefined) // BEGIN
                .mockResolvedValueOnce({ // INSERT project
                    rows: [{
                        id: 'new-project-id',
                        name: validProjectData.name,
                        description: validProjectData.description,
                        created_by: 'test-user-id',
                        created_at: new Date(),
                        updated_at: new Date()
                    }]
                })
                .mockResolvedValueOnce(undefined) // INSERT member
                .mockResolvedValueOnce(undefined) // COMMIT

            const response = await request(app)
                .post('/api/projects')
                .send(validProjectData)
                .expect(201)

            expect(response.body.project.name).toBe(validProjectData.name)
            expect(response.body.project.description).toBe(validProjectData.description)
            expect(response.body.message).toBe('Project created successfully')
        })

        it('should return validation error for missing name', async () => {
            const invalidProjectData = {
                name: '', // Empty name
                description: 'Valid description'
            }

            const response = await request(app)
                .post('/api/projects')
                .send(invalidProjectData)
                .expect(400)

            expect(response.body.error.code).toBe('VALIDATION_ERROR')
        })
    })

    describe('GET /api/projects', () => {
        it('should list projects successfully', async () => {
            mockClient.query.mockResolvedValue({
                rows: [{
                    id: mockProject.id,
                    name: mockProject.name,
                    description: mockProject.description,
                    created_by: mockProject.createdBy,
                    created_at: mockProject.createdAt,
                    updated_at: mockProject.updatedAt,
                    members: mockProject.members
                }]
            })

            const response = await request(app)
                .get('/api/projects')
                .expect(200)

            expect(response.body.projects).toHaveLength(1)
            expect(response.body.projects[0].name).toBe('Test Project')
            expect(mockClient.query).toHaveBeenCalled()
        })
    })

    describe('GET /api/projects/:id', () => {
        it('should get a project by ID successfully', async () => {
            // Mock project query and members query
            mockClient.query
                .mockResolvedValueOnce({
                    rows: [{
                        id: mockProject.id,
                        name: mockProject.name,
                        description: mockProject.description,
                        created_by: mockProject.createdBy,
                        created_at: mockProject.createdAt,
                        updated_at: mockProject.updatedAt
                    }]
                })
                .mockResolvedValueOnce({
                    rows: [{ user_id: 'test-user-id' }]
                })

            const response = await request(app)
                .get(`/api/projects/${mockProject.id}`)
                .expect(200)

            expect(response.body.project.id).toBe(mockProject.id)
            expect(response.body.project.name).toBe(mockProject.name)
        })

        it('should return 404 for non-existent project', async () => {
            mockClient.query.mockResolvedValue({ rows: [] })

            const response = await request(app)
                .get('/api/projects/123e4567-e89b-12d3-a456-426614174999')
                .expect(404)

            expect(response.body.error.code).toBe('NOT_FOUND')
        })
    })

    describe('Error Handling', () => {
        it('should handle database connection errors', async () => {
            mockPool.connect.mockRejectedValue(new Error('Database connection failed'))

            const response = await request(app)
                .get('/api/projects')
                .expect(500)

            expect(response.body.error.code).toBe('INTERNAL_ERROR')
        })
    })
})