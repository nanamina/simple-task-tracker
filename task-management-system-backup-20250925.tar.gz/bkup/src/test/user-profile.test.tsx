import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { Provider } from 'react-redux';
import { configureStore } from '@reduxjs/toolkit';
import { BrowserRouter } from 'react-router-dom';
import UserProfile from '../client/components/UserProfile';
import authReducer from '../client/store/slices/authSlice';
import { User } from '@/shared/types';

// Mock the useTranslation hook
jest.mock('../client/hooks/useTranslation', () => ({
    useTranslation: () => ({
        t: (key: string) => {
            const translations = {
                'common.loading': '読み込み中...',
                'common.save': '保存',
                'common.cancel': 'キャンセル',
                'common.saving': '保存中...',
                'profile.title': 'プロフィール',
                'profile.edit': 'プロフィールを編集',
                'profile.fields.name': '名前',
                'profile.fields.email': 'メールアドレス',
                'profile.fields.role': '役割',
                'profile.fields.preferredLanguage': '優先言語',
                'profile.fields.joinedAt': '参加日',
                'profile.roles.admin': '管理者',
                'profile.roles.manager': 'マネージャー',
                'profile.roles.member': 'メンバー',
                'profile.languages.ja': '日本語',
                'profile.languages.en': 'English',
                'profile.messages.profileUpdated': 'プロフィールが更新されました'
            };
            return translations[key] || key;
        }
    })
}));

// Mock fetch globally
global.fetch = jest.fn();

// Mock user data
const mockUser: User = {
    id: '1',
    email: 'test@example.com',
    name: 'Test User',
    role: 'member',
    preferredLanguage: 'ja',
    createdAt: new Date('2023-01-01'),
    updatedAt: new Date('2023-01-01')
};

// Create a mock store
const createMockStore = (user: User | null = mockUser, token: string | null = 'mock-token') => {
    return configureStore({
        reducer: {
            auth: authReducer
        },
        preloadedState: {
            auth: {
                user,
                token,
                isLoading: false,
                error: null,
                isAuthenticated: !!user
            }
        }
    });
};

// Test wrapper component
const TestWrapper: React.FC<{ children: React.ReactNode; store?: any }> = ({
    children,
    store = createMockStore()
}) => (
    <Provider store={store}>
        <BrowserRouter>
            {children}
        </BrowserRouter>
    </Provider>
);

describe('UserProfile Component', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        (fetch as jest.Mock).mockClear();
    });

    it('renders user profile information correctly', () => {
        render(
            <TestWrapper>
                <UserProfile />
            </TestWrapper>
        );

        // Check if user information is displayed
        expect(screen.getByDisplayValue('Test User')).toBeInTheDocument();
        expect(screen.getByDisplayValue('test@example.com')).toBeInTheDocument();
        expect(screen.getByText('メンバー')).toBeInTheDocument(); // Japanese role translation
    });

    it('shows loading state when user is not available', () => {
        const store = createMockStore(null, null);

        render(
            <TestWrapper store={store}>
                <UserProfile />
            </TestWrapper>
        );

        expect(screen.getByText('読み込み中...')).toBeInTheDocument();
    });

    it('enters edit mode when edit button is clicked', () => {
        render(
            <TestWrapper>
                <UserProfile />
            </TestWrapper>
        );

        const editButton = screen.getByText('プロフィールを編集');
        fireEvent.click(editButton);

        // Check if form inputs are now editable
        expect(screen.getByDisplayValue('Test User')).not.toBeDisabled();
        expect(screen.getByDisplayValue('test@example.com')).not.toBeDisabled();

        // Check if save and cancel buttons are visible
        expect(screen.getByText('保存')).toBeInTheDocument();
        expect(screen.getByText('キャンセル')).toBeInTheDocument();
    });

    it('cancels edit mode and resets form when cancel is clicked', () => {
        render(
            <TestWrapper>
                <UserProfile />
            </TestWrapper>
        );

        // Enter edit mode
        const editButton = screen.getByText('プロフィールを編集');
        fireEvent.click(editButton);

        // Change form values
        const nameInput = screen.getByDisplayValue('Test User');
        fireEvent.change(nameInput, { target: { value: 'Changed Name' } });

        // Cancel editing
        const cancelButton = screen.getByText('キャンセル');
        fireEvent.click(cancelButton);

        // Check if form is reset and edit mode is exited
        expect(screen.getByDisplayValue('Test User')).toBeInTheDocument();
        expect(screen.getByText('プロフィールを編集')).toBeInTheDocument();
    });

    it('submits form with updated data when save is clicked', async () => {
        (fetch as jest.Mock).mockResolvedValueOnce({
            ok: true,
            json: async () => ({ ...mockUser, name: 'Updated Name' })
        });

        // Mock alert to avoid actual alert in tests
        window.alert = jest.fn();

        render(
            <TestWrapper>
                <UserProfile />
            </TestWrapper>
        );

        // Enter edit mode
        const editButton = screen.getByText('プロフィールを編集');
        fireEvent.click(editButton);

        // Update name
        const nameInput = screen.getByDisplayValue('Test User');
        fireEvent.change(nameInput, { target: { value: 'Updated Name' } });

        // Submit form
        const saveButton = screen.getByText('保存');
        fireEvent.click(saveButton);

        // Wait for API call
        await waitFor(() => {
            expect(fetch).toHaveBeenCalledWith('/api/users/profile', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer mock-token'
                },
                body: JSON.stringify({
                    name: 'Updated Name',
                    email: 'test@example.com',
                    preferredLanguage: 'ja'
                })
            });
        });

        // Check if success message is shown
        expect(window.alert).toHaveBeenCalledWith('プロフィールが更新されました');
    });

    it('displays error message when API call fails', async () => {
        (fetch as jest.Mock).mockResolvedValueOnce({
            ok: false,
            json: async () => ({ error: { message: 'Update failed' } })
        });

        render(
            <TestWrapper>
                <UserProfile />
            </TestWrapper>
        );

        // Enter edit mode and submit
        const editButton = screen.getByText('プロフィールを編集');
        fireEvent.click(editButton);

        const saveButton = screen.getByText('保存');
        fireEvent.click(saveButton);

        // Wait for error to appear
        await waitFor(() => {
            expect(screen.getByText('Update failed')).toBeInTheDocument();
        });
    });

    it('handles language preference changes', () => {
        render(
            <TestWrapper>
                <UserProfile />
            </TestWrapper>
        );

        // Enter edit mode
        const editButton = screen.getByText('プロフィールを編集');
        fireEvent.click(editButton);

        // Change language preference
        const languageSelect = screen.getByDisplayValue('日本語');
        fireEvent.change(languageSelect, { target: { value: 'en' } });

        expect(languageSelect).toHaveValue('en');
    });

    it('calls onClose when close button is clicked', () => {
        const mockOnClose = jest.fn();

        render(
            <TestWrapper>
                <UserProfile onClose={mockOnClose} />
            </TestWrapper>
        );

        const closeButton = screen.getByLabelText('Close profile');
        fireEvent.click(closeButton);

        expect(mockOnClose).toHaveBeenCalled();
    });

    it('displays join date correctly', () => {
        render(
            <TestWrapper>
                <UserProfile />
            </TestWrapper>
        );

        // Check if join date is formatted correctly
        const joinDate = new Date('2023-01-01').toLocaleDateString();
        expect(screen.getByText(joinDate)).toBeInTheDocument();
    });

    it('shows loading state during form submission', async () => {
        (fetch as jest.Mock).mockImplementation(() =>
            new Promise(resolve => setTimeout(() => resolve({
                ok: true,
                json: async () => mockUser
            }), 100))
        );

        render(
            <TestWrapper>
                <UserProfile />
            </TestWrapper>
        );

        // Enter edit mode and submit
        const editButton = screen.getByText('プロフィールを編集');
        fireEvent.click(editButton);

        const saveButton = screen.getByText('保存');
        fireEvent.click(saveButton);

        // Check loading state
        expect(screen.getByText('保存中...')).toBeInTheDocument();
        expect(saveButton).toBeDisabled();

        // Wait for completion
        await waitFor(() => {
            expect(screen.queryByText('保存中...')).not.toBeInTheDocument();
        });
    });
});