import React from 'react'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { Provider } from 'react-redux'
import { BrowserRouter } from 'react-router-dom'
import { configureStore } from '@reduxjs/toolkit'

// Mock react-i18next
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string, options?: any) => {
            const translations: Record<string, string> = {
                'common.error': 'エラーが発生しました',
                'projects.notFound': 'プロジェクトが見つかりません',
                'projects.edit': 'プロジェクトを編集',
                'tasks.create': 'タスクを作成',
                'projects.createdAt': '作成日',
                'projects.totalTasks': '総タスク数',
                'projects.completedTasks': '完了タスク',
                'projects.inProgressTasks': '進行中タスク',
                'projects.overdueTasks': '期限切れタスク',
                'projects.progress': '進捗',
                'projects.complete': '完了',
                'projects.tasksByStatus': 'ステータス別タスク',
                'projects.tasksByPriority': '優先度別タスク',
                'projects.recentTasks': '最近のタスク',
                'projects.noTasks': 'タスクがありません',
                'tasks.status.todo': '未着手',
                'tasks.status.in-progress': '進行中',
                'tasks.status.completed': '完了',
                'tasks.priority.critical': '緊急',
                'tasks.priority.high': '高',
                'tasks.priority.medium': '中',
                'tasks.priority.low': '低',
                'projects.name': 'プロジェクト名',
                'projects.description': '説明',
                'validation.required': options?.field ? `${options.field}は必須です` : '必須項目です',
                'validation.minLength': options?.field && options?.min ? `${options.field}は${options.min}文字以上で入力してください` : '文字数が不足しています',
                'validation.maxLength': options?.field && options?.max ? `${options.field}は${options.max}文字以下で入力してください` : '文字数が超過しています',
                'common.create': '作成',
                'common.update': '更新',
                'common.cancel': 'キャンセル',
                'common.saving': '保存中...',
                'common.characters': '文字',
                'projects.namePlaceholder': 'プロジェクト名を入力',
                'projects.descriptionPlaceholder': 'プロジェクトの説明を入力',
                'projects.createDescription': '新しいプロジェクトの詳細を入力してください',
                'projects.editDescription': 'プロジェクトの詳細を編集してください',
                'projects.title': 'プロジェクト',
                'projects.subtitle': 'チームのプロジェクトを管理',
                'projects.create': 'プロジェクトを作成',
                'projects.searchPlaceholder': 'プロジェクトを検索',
                'projects.sortByName': '名前順',
                'projects.sortByCreated': '作成日順',
                'projects.sortByUpdated': '更新日順',
                'projects.members': 'メンバー',
                'projects.updated': '更新日',
                'projects.viewDetails': '詳細を表示',
                'common.edit': '編集',
                'common.delete': '削除',
                'projects.noProjects': 'プロジェクトがありません',
                'projects.noSearchResults': '検索結果がありません',
                'projects.tryDifferentSearch': '別のキーワードで検索してください',
                'projects.getStarted': '新しいプロジェクトを作成して始めましょう',
                'projects.createFirst': '最初のプロジェクトを作成',
                'projects.addMember': 'メンバーを追加',
                'projects.addNewMember': '新しいメンバーを追加',
                'users.role.admin': '管理者',
                'users.role.manager': 'マネージャー',
                'users.role.member': 'メンバー',
                'common.remove': '削除',
                'projects.allUsersAreMembers': 'すべてのユーザーが既にメンバーです',
            }
            return translations[key] || key
        },
    }),
    I18nextProvider: ({ children }: { children: React.ReactNode }) => children,
}))
import authSlice from '@/client/store/slices/authSlice'
import taskSlice from '@/client/store/slices/taskSlice'
import projectSlice from '@/client/store/slices/projectSlice'
import ProjectDashboard from '@/client/components/ProjectDashboard'
import ProjectForm from '@/client/components/ProjectForm'
import ProjectList from '@/client/components/ProjectList'
import ProjectMemberManagement from '@/client/components/ProjectMemberManagement'
import { Project, User, Task } from '@/shared/types'

// Mock fetch globally
global.fetch = jest.fn()

// Mock react-router-dom hooks
const mockNavigate = jest.fn()
const mockParams = { projectId: 'test-project-id' }

jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => mockNavigate,
    useParams: () => mockParams,
    Link: ({ children, to }: { children: React.ReactNode; to: string }) => (
        <a href={to}>{children}</a>
    ),
}))

// Test data
const mockUser: User = {
    id: 'user-1',
    email: 'test@example.com',
    name: 'Test User',
    role: 'manager',
    preferredLanguage: 'ja',
    createdAt: new Date(),
    updatedAt: new Date(),
}

const mockProject: Project = {
    id: 'project-1',
    name: 'Test Project',
    description: 'Test project description',
    createdBy: 'user-1',
    createdAt: new Date(),
    updatedAt: new Date(),
    members: ['user-1', 'user-2'],
}

const mockTasks: Task[] = [
    {
        id: 'task-1',
        title: 'Test Task 1',
        description: 'Test task description',
        status: 'todo',
        priority: 'high',
        projectId: 'project-1',
        createdBy: 'user-1',
        createdAt: new Date(),
        updatedAt: new Date(),
    },
    {
        id: 'task-2',
        title: 'Test Task 2',
        description: 'Another test task',
        status: 'completed',
        priority: 'medium',
        projectId: 'project-1',
        createdBy: 'user-1',
        createdAt: new Date(),
        updatedAt: new Date(),
        completedAt: new Date(),
    },
]

const mockUsers: User[] = [
    mockUser,
    {
        id: 'user-2',
        email: 'user2@example.com',
        name: 'User Two',
        role: 'member',
        preferredLanguage: 'en',
        createdAt: new Date(),
        updatedAt: new Date(),
    },
]

// Helper function to create test store
const createTestStore = (initialState = {}) => {
    const defaultState = {
        auth: {
            user: mockUser,
            token: 'test-token',
            isAuthenticated: true,
            loading: false,
            error: null,
        },
        projects: {
            projects: [mockProject],
            currentProject: mockProject,
            projectTasks: mockTasks,
            projectMetrics: {
                totalTasks: 2,
                completedTasks: 1,
                inProgressTasks: 0,
                todoTasks: 1,
                completionRate: 50,
                overdueTasksCount: 0,
            },
            availableUsers: mockUsers,
            loading: false,
            error: null,
        },
        tasks: {
            tasks: mockTasks,
            loading: false,
            error: null,
            filters: {},
            sortBy: 'createdAt',
            sortOrder: 'desc',
        },
    }

    // Deep merge the initial state
    const mergedState = JSON.parse(JSON.stringify(defaultState))
    if (initialState) {
        Object.keys(initialState).forEach(key => {
            if (initialState[key] && typeof initialState[key] === 'object') {
                mergedState[key] = { ...mergedState[key], ...initialState[key] }
            } else {
                mergedState[key] = initialState[key]
            }
        })
    }

    return configureStore({
        reducer: {
            auth: authSlice,
            tasks: taskSlice,
            projects: projectSlice,
        },
        preloadedState: mergedState,
    })
}

// Helper function to render component with providers
const renderWithProviders = (component: React.ReactElement, store = createTestStore()) => {
    return render(
        <Provider store={store}>
            <BrowserRouter>
                {component}
            </BrowserRouter>
        </Provider>
    )
}

describe('ProjectDashboard', () => {
    beforeEach(() => {
        jest.clearAllMocks()
            ; (fetch as jest.Mock).mockResolvedValue({
                ok: true,
                json: async () => mockProject,
            })
    })

    test('renders project dashboard with project information', () => {
        renderWithProviders(<ProjectDashboard />)

        expect(screen.getByText('Test Project')).toBeInTheDocument()
        expect(screen.getByText('Test project description')).toBeInTheDocument()
    })

    test('displays project metrics correctly', () => {
        renderWithProviders(<ProjectDashboard />)

        expect(screen.getByText('2')).toBeInTheDocument() // Total tasks
        expect(screen.getByText('1')).toBeInTheDocument() // Completed tasks
    })

    test('shows loading state', () => {
        const store = createTestStore({
            projects: {
                projects: [],
                currentProject: null,
                projectTasks: [],
                projectMetrics: null,
                availableUsers: [],
                loading: true,
                error: null,
            },
        })

        renderWithProviders(<ProjectDashboard />, store)

        expect(screen.getByRole('status')).toBeInTheDocument()
    })

    test('displays error message when error occurs', () => {
        const store = createTestStore({
            projects: {
                projects: [],
                currentProject: null,
                projectTasks: [],
                projectMetrics: null,
                availableUsers: [],
                loading: false,
                error: 'Failed to load project',
            },
        })

        renderWithProviders(<ProjectDashboard />, store)

        expect(screen.getByText('Failed to load project')).toBeInTheDocument()
    })
})

describe('ProjectForm', () => {
    beforeEach(() => {
        jest.clearAllMocks()
            ; (fetch as jest.Mock).mockResolvedValue({
                ok: true,
                json: async () => mockProject,
            })
    })

    test('renders create project form', () => {
        renderWithProviders(<ProjectForm />)

        expect(screen.getByLabelText(/プロジェクト名/)).toBeInTheDocument()
        expect(screen.getByLabelText(/説明/)).toBeInTheDocument()
        expect(screen.getByRole('button', { name: /作成/ })).toBeInTheDocument()
    })

    test('renders edit project form with existing data', () => {
        renderWithProviders(<ProjectForm project={mockProject} />)

        expect(screen.getByDisplayValue('Test Project')).toBeInTheDocument()
        expect(screen.getByDisplayValue('Test project description')).toBeInTheDocument()
        expect(screen.getByRole('button', { name: /更新/ })).toBeInTheDocument()
    })

    test('validates required fields', async () => {
        renderWithProviders(<ProjectForm />)

        const submitButton = screen.getByRole('button', { name: /作成/ })
        fireEvent.click(submitButton)

        await waitFor(() => {
            expect(screen.getByText(/必須項目です/)).toBeInTheDocument()
        })
    })

    test('submits form with valid data', async () => {
        ; (fetch as jest.Mock).mockResolvedValue({
            ok: true,
            json: async () => ({ ...mockProject, id: 'new-project-id' }),
        })

        renderWithProviders(<ProjectForm />)

        const nameInput = screen.getByLabelText(/プロジェクト名/)
        const descriptionInput = screen.getByLabelText(/説明/)
        const submitButton = screen.getByRole('button', { name: /作成/ })

        fireEvent.change(nameInput, { target: { value: 'New Project' } })
        fireEvent.change(descriptionInput, { target: { value: 'New project description' } })
        fireEvent.click(submitButton)

        await waitFor(() => {
            expect(fetch).toHaveBeenCalledWith('/api/projects', expect.objectContaining({
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: 'New Project',
                    description: 'New project description',
                }),
            }))
        })
    })
})

describe('ProjectList', () => {
    beforeEach(() => {
        jest.clearAllMocks()
            ; (fetch as jest.Mock).mockResolvedValue({
                ok: true,
                json: async () => [mockProject],
            })
    })

    test('renders project list', () => {
        renderWithProviders(<ProjectList />)

        expect(screen.getByText('Test Project')).toBeInTheDocument()
        expect(screen.getByText('Test project description')).toBeInTheDocument()
    })

    test('filters projects by search term', () => {
        const store = createTestStore({
            projects: {
                projects: [
                    mockProject,
                    {
                        ...mockProject,
                        id: 'project-2',
                        name: 'Another Project',
                        description: 'Different description',
                    },
                ],
                currentProject: null,
                projectTasks: [],
                projectMetrics: null,
                availableUsers: [],
                loading: false,
                error: null,
            },
        })

        renderWithProviders(<ProjectList />, store)

        const searchInput = screen.getByPlaceholderText(/プロジェクトを検索/)
        fireEvent.change(searchInput, { target: { value: 'Test' } })

        expect(screen.getByText('Test Project')).toBeInTheDocument()
        expect(screen.queryByText('Another Project')).not.toBeInTheDocument()
    })

    test('shows create button for managers and admins', () => {
        renderWithProviders(<ProjectList />)

        expect(screen.getByRole('button', { name: /プロジェクトを作成/ })).toBeInTheDocument()
    })

    test('hides create button for regular members', () => {
        const store = createTestStore({
            auth: {
                user: { ...mockUser, role: 'member' },
                token: 'test-token',
                isAuthenticated: true,
                loading: false,
                error: null,
            },
        })

        renderWithProviders(<ProjectList />, store)

        expect(screen.queryByRole('button', { name: /プロジェクトを作成/ })).not.toBeInTheDocument()
    })
})

describe('ProjectMemberManagement', () => {
    beforeEach(() => {
        jest.clearAllMocks()
            ; (fetch as jest.Mock).mockResolvedValue({
                ok: true,
                json: async () => mockUsers,
            })
    })

    test('renders project members', () => {
        renderWithProviders(<ProjectMemberManagement project={mockProject} />)

        expect(screen.getByText('Test User')).toBeInTheDocument()
        expect(screen.getByText('test@example.com')).toBeInTheDocument()
    })

    test('shows add member button for managers', () => {
        renderWithProviders(<ProjectMemberManagement project={mockProject} />)

        expect(screen.getByRole('button', { name: /メンバーを追加/ })).toBeInTheDocument()
    })

    test('allows adding new members', async () => {
        ; (fetch as jest.Mock)
            .mockResolvedValueOnce({
                ok: true,
                json: async () => mockUsers,
            })
            .mockResolvedValueOnce({
                ok: true,
                json: async () => ({ ...mockProject, members: [...mockProject.members, 'user-3'] }),
            })

        renderWithProviders(<ProjectMemberManagement project={mockProject} />)

        const addButton = screen.getByRole('button', { name: /メンバーを追加/ })
        fireEvent.click(addButton)

        await waitFor(() => {
            expect(screen.getByText(/新しいメンバーを追加/)).toBeInTheDocument()
        })
    })

    test('confirms before removing members', async () => {
        window.confirm = jest.fn(() => true)

        renderWithProviders(<ProjectMemberManagement project={mockProject} />)

        const removeButtons = screen.getAllByText(/削除/)
        if (removeButtons.length > 0) {
            fireEvent.click(removeButtons[0])

            expect(window.confirm).toHaveBeenCalled()
        }
    })
})