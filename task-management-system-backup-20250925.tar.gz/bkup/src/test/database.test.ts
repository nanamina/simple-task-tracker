import { testConnection, getPool, closePool } from '../server/config/database'
import { migrationRunner } from '../server/config/migrate'
import { databaseSeeder } from '../server/config/seeds'

// Skip database tests if no database is available
const skipIfNoDatabase = process.env.CI || !process.env.DB_NAME

describe('Database Configuration', () => {
    beforeAll(() => {
        if (skipIfNoDatabase) {
            console.log('Skipping database tests - no database configured')
        }
    })

    afterAll(async () => {
        if (!skipIfNoDatabase) {
            await closePool()
        }
    })

    test('should connect to database', async () => {
        if (skipIfNoDatabase) {
            console.log('Skipping: No database configured')
            return
        }

        await expect(testConnection()).resolves.not.toThrow()
    })

    test('should get database pool', () => {
        const pool = getPool()
        expect(pool).toBeDefined()
        expect(typeof pool.query).toBe('function')
    })

    test('should execute simple query', async () => {
        if (skipIfNoDatabase) {
            console.log('Skipping: No database configured')
            return
        }

        const pool = getPool()
        const result = await pool.query('SELECT 1 as test')
        expect(result.rows).toHaveLength(1)
        expect(result.rows[0].test).toBe(1)
    })
})

describe('Migration Runner', () => {
    afterAll(async () => {
        if (!skipIfNoDatabase) {
            await closePool()
        }
    })

    test('should get migration status', async () => {
        if (skipIfNoDatabase) {
            console.log('Skipping: No database configured')
            return
        }

        // This test just ensures the migration runner can check status without errors
        await expect(migrationRunner.getMigrationStatus()).resolves.not.toThrow()
    })
})

describe('Database Seeder', () => {
    afterAll(async () => {
        if (!skipIfNoDatabase) {
            await closePool()
        }
    })

    test('should be able to clear data', async () => {
        if (skipIfNoDatabase) {
            console.log('Skipping: No database configured')
            return
        }

        // This test ensures the seeder can clear data without errors
        await expect(databaseSeeder.clearAllData()).resolves.not.toThrow()
    })

    test('should be able to seed minimal data', async () => {
        if (skipIfNoDatabase) {
            console.log('Skipping: No database configured')
            return
        }

        // Clear first, then seed minimal data
        await databaseSeeder.clearAllData()
        await expect(databaseSeeder.seedMinimal()).resolves.not.toThrow()
    })
})

// Unit tests that don't require database connection
describe('Database Configuration (Unit Tests)', () => {
    test('should have correct database configuration structure', () => {
        const { getDatabaseConfig } = require('../server/config/database')
        const config = getDatabaseConfig()

        expect(config).toHaveProperty('host')
        expect(config).toHaveProperty('port')
        expect(config).toHaveProperty('database')
        expect(config).toHaveProperty('user')
        expect(config).toHaveProperty('password')
        expect(typeof config.port).toBe('number')
    })

    test('migration runner should be instantiable', () => {
        expect(migrationRunner).toBeDefined()
        expect(typeof migrationRunner.runMigrations).toBe('function')
        expect(typeof migrationRunner.getMigrationStatus).toBe('function')
    })

    test('database seeder should be instantiable', () => {
        expect(databaseSeeder).toBeDefined()
        expect(typeof databaseSeeder.seedAll).toBe('function')
        expect(typeof databaseSeeder.clearAllData).toBe('function')
    })
})