/**
 * Unit tests for notification service
 */

import * as nodemailer from 'nodemailer'
import { sendTaskAssignment, sendStatusUpdate, sendOverdueReminder, testEmailConfiguration } from '../server/services/notification'
import { User, Task } from '../shared/types/index'

// Mock transporter
const mockSendMail = jest.fn()
const mockTransporter = {
    sendMail: mockSendMail
}

// Mock nodemailer
jest.mock('nodemailer', () => ({
    createTransporter: jest.fn(() => mockTransporter)
}))

// Test data
const mockUser: User = {
    id: '123e4567-e89b-12d3-a456-426614174000',
    email: 'test@example.com',
    name: 'Test User',
    role: 'member',
    preferredLanguage: 'ja',
    createdAt: new Date('2024-01-01T00:00:00Z'),
    updatedAt: new Date('2024-01-01T00:00:00Z')
}

const mockEnglishUser: User = {
    ...mockUser,
    id: '123e4567-e89b-12d3-a456-426614174001',
    email: 'english@example.com',
    name: 'English User',
    preferredLanguage: 'en'
}

const mockCreator: User = {
    ...mockUser,
    id: '123e4567-e89b-12d3-a456-426614174002',
    email: 'creator@example.com',
    name: 'Creator User'
}

const mockTask: Task = {
    id: '123e4567-e89b-12d3-a456-426614174003',
    title: 'Test Task',
    description: 'This is a test task',
    status: 'todo',
    priority: 'high',
    dueDate: new Date('2024-12-31T23:59:59Z'),
    assigneeId: mockUser.id,
    projectId: '123e4567-e89b-12d3-a456-426614174004',
    createdBy: mockCreator.id,
    createdAt: new Date('2024-01-01T00:00:00Z'),
    updatedAt: new Date('2024-01-01T00:00:00Z')
}

const mockOverdueTask: Task = {
    ...mockTask,
    id: '123e4567-e89b-12d3-a456-426614174005',
    title: 'Overdue Task',
    dueDate: new Date('2023-12-31T23:59:59Z') // Past date
}

describe('Notification Service', () => {
    beforeEach(() => {
        jest.clearAllMocks()
        mockSendMail.mockResolvedValue({ messageId: 'test-message-id' })

        // Mock environment variables
        process.env.SMTP_HOST = 'smtp.test.com'
        process.env.SMTP_PORT = '587'
        process.env.SMTP_USER = 'test@smtp.com'
        process.env.SMTP_PASSWORD = 'test-password'
    })

    afterEach(() => {
        // Clean up environment variables
        delete process.env.SMTP_HOST
        delete process.env.SMTP_PORT
        delete process.env.SMTP_USER
        delete process.env.SMTP_PASSWORD
    })

    describe('sendTaskAssignment', () => {
        it('should send task assignment notification in Japanese', async () => {
            await sendTaskAssignment(mockTask, mockUser, mockCreator)

            expect(nodemailer.createTransporter).toHaveBeenCalled()

            expect(mockSendMail).toHaveBeenCalledWith({
                from: process.env.SMTP_USER,
                to: 'test@example.com',
                subject: 'タスクが割り当てられました: Test Task',
                text: expect.stringContaining('こんにちは Test Userさん')
            })
        })

        it('should send task assignment notification in English', async () => {
            await sendTaskAssignment(mockTask, mockEnglishUser, mockCreator)

            expect(mockSendMail).toHaveBeenCalledWith({
                from: 'test@smtp.com',
                to: 'english@example.com',
                subject: 'Task Assigned: Test Task',
                text: expect.stringContaining('Hello English User')
            })
        })

        it('should include task details in notification', async () => {
            await sendTaskAssignment(mockTask, mockUser, mockCreator)

            const emailCall = mockSendMail.mock.calls[0][0]
            expect(emailCall.text).toContain('Test Task')
            expect(emailCall.text).toContain('This is a test task')
            expect(emailCall.text).toContain('高') // High priority in Japanese
            expect(emailCall.text).toContain('Creator User')
        })

        it('should handle tasks without due date', async () => {
            const taskWithoutDueDate = { ...mockTask, dueDate: undefined }

            await sendTaskAssignment(taskWithoutDueDate, mockUser, mockCreator)

            const emailCall = mockSendMail.mock.calls[0][0]
            expect(emailCall.text).toContain('未設定') // "Not set" in Japanese
        })

        it('should throw error when email sending fails', async () => {
            mockSendMail.mockRejectedValue(new Error('SMTP Error'))

            await expect(sendTaskAssignment(mockTask, mockUser, mockCreator))
                .rejects.toThrow('Failed to send task assignment notification')
        })
    })

    describe('sendStatusUpdate', () => {
        it('should send status update notification to multiple stakeholders', async () => {
            const stakeholders = [mockUser, mockEnglishUser]
            const updatedTask = { ...mockTask, status: 'completed' as const }

            await sendStatusUpdate(updatedTask, stakeholders, mockCreator)

            expect(mockSendMail).toHaveBeenCalledTimes(2)

            // Check Japanese notification
            expect(mockSendMail).toHaveBeenCalledWith({
                from: 'test@smtp.com',
                to: 'test@example.com',
                subject: 'タスクステータス更新: Test Task',
                text: expect.stringContaining('完了') // "Completed" in Japanese
            })

            // Check English notification
            expect(mockSendMail).toHaveBeenCalledWith({
                from: 'test@smtp.com',
                to: 'english@example.com',
                subject: 'Task Status Updated: Test Task',
                text: expect.stringContaining('Completed')
            })
        })

        it('should include updater information in notification', async () => {
            const stakeholders = [mockUser]

            await sendStatusUpdate(mockTask, stakeholders, mockCreator)

            const emailCall = mockSendMail.mock.calls[0][0]
            expect(emailCall.text).toContain('Creator User')
        })

        it('should handle empty stakeholders array', async () => {
            await sendStatusUpdate(mockTask, [], mockCreator)

            expect(mockSendMail).not.toHaveBeenCalled()
        })

        it('should throw error when email sending fails', async () => {
            mockSendMail.mockRejectedValue(new Error('SMTP Error'))
            const stakeholders = [mockUser]

            await expect(sendStatusUpdate(mockTask, stakeholders, mockCreator))
                .rejects.toThrow('Failed to send status update notifications')
        })
    })

    describe('sendOverdueReminder', () => {
        it('should send overdue reminder to users with overdue tasks', async () => {
            const overdueTasks = [mockOverdueTask]
            const users = [mockUser]

            await sendOverdueReminder(overdueTasks, users)

            expect(mockSendMail).toHaveBeenCalledWith({
                from: 'test@smtp.com',
                to: 'test@example.com',
                subject: '期限切れタスクの通知',
                text: expect.stringContaining('Overdue Task')
            })
        })

        it('should group tasks by assignee', async () => {
            const task1 = { ...mockOverdueTask, assigneeId: mockUser.id, title: 'Task 1' }
            const task2 = { ...mockOverdueTask, assigneeId: mockUser.id, title: 'Task 2' }
            const overdueTasks = [task1, task2]
            const users = [mockUser]

            await sendOverdueReminder(overdueTasks, users)

            const emailCall = mockSendMail.mock.calls[0][0]
            expect(emailCall.text).toContain('Task 1')
            expect(emailCall.text).toContain('Task 2')
        })

        it('should not send notification to users without overdue tasks', async () => {
            const overdueTasks = [{ ...mockOverdueTask, assigneeId: 'other-user-id' }]
            const users = [mockUser]

            await sendOverdueReminder(overdueTasks, users)

            expect(mockSendMail).not.toHaveBeenCalled()
        })

        it('should handle tasks without assignee', async () => {
            const taskWithoutAssignee = { ...mockOverdueTask, assigneeId: undefined }
            const overdueTasks = [taskWithoutAssignee]
            const users = [mockUser]

            await sendOverdueReminder(overdueTasks, users)

            expect(mockSendMail).not.toHaveBeenCalled()
        })

        it('should send notifications in user preferred language', async () => {
            const overdueTasks = [
                { ...mockOverdueTask, assigneeId: mockUser.id },
                { ...mockOverdueTask, assigneeId: mockEnglishUser.id, title: 'English Task' }
            ]
            const users = [mockUser, mockEnglishUser]

            await sendOverdueReminder(overdueTasks, users)

            expect(mockSendMail).toHaveBeenCalledTimes(2)

            // Check Japanese notification
            const japaneseCall = mockSendMail.mock.calls.find(call =>
                call[0].to === 'test@example.com'
            )
            expect(japaneseCall[0].subject).toBe('期限切れタスクの通知')

            // Check English notification
            const englishCall = mockSendMail.mock.calls.find(call =>
                call[0].to === 'english@example.com'
            )
            expect(englishCall[0].subject).toBe('Overdue Tasks Reminder')
        })

        it('should throw error when email sending fails', async () => {
            mockSendMail.mockRejectedValue(new Error('SMTP Error'))
            const overdueTasks = [mockOverdueTask]
            const users = [mockUser]

            await expect(sendOverdueReminder(overdueTasks, users))
                .rejects.toThrow('Failed to send overdue reminders')
        })
    })

    describe('testEmailConfiguration', () => {
        it('should send test email successfully', async () => {
            const testEmail = 'test@example.com'

            await testEmailConfiguration(testEmail)

            expect(mockSendMail).toHaveBeenCalledWith({
                from: 'test@smtp.com',
                to: testEmail,
                subject: 'Task Management System - Email Configuration Test',
                text: 'This is a test email to verify the email configuration is working correctly.'
            })
        })

        it('should throw error when test email fails', async () => {
            mockSendMail.mockRejectedValue(new Error('SMTP Error'))

            await expect(testEmailConfiguration('test@example.com'))
                .rejects.toThrow('Email configuration test failed')
        })
    })

    describe('Date formatting', () => {
        it('should format dates according to Japanese locale', async () => {
            const taskWithDate = {
                ...mockTask,
                dueDate: new Date('2024-12-31T00:00:00Z')
            }

            await sendTaskAssignment(taskWithDate, mockUser, mockCreator)

            const emailCall = mockSendMail.mock.calls[0][0]
            expect(emailCall.text).toContain('2024/12/31')
        })

        it('should format dates according to English locale', async () => {
            const taskWithDate = {
                ...mockTask,
                dueDate: new Date('2024-12-31T00:00:00Z')
            }

            await sendTaskAssignment(taskWithDate, mockEnglishUser, mockCreator)

            const emailCall = mockSendMail.mock.calls[0][0]
            expect(emailCall.text).toContain('December 31, 2024')
        })
    })

    describe('Priority and Status translations', () => {
        it('should translate priority levels correctly', async () => {
            const criticalTask = { ...mockTask, priority: 'critical' as const }

            await sendTaskAssignment(criticalTask, mockUser, mockCreator)

            const emailCall = mockSendMail.mock.calls[0][0]
            expect(emailCall.text).toContain('緊急') // "Critical" in Japanese
        })

        it('should translate status correctly', async () => {
            const inProgressTask = { ...mockTask, status: 'in-progress' as const }
            const stakeholders = [mockUser]

            await sendStatusUpdate(inProgressTask, stakeholders, mockCreator)

            const emailCall = mockSendMail.mock.calls[0][0]
            expect(emailCall.text).toContain('進行中') // "In Progress" in Japanese
        })
    })
})