/**
 * Performance tests for critical backend endpoints
 */

import request from 'supertest'
import express from 'express'
import { Pool } from 'pg'

// Import routes
import taskRoutes from '@/server/routes/task'
import projectRoutes from '@/server/routes/project'
import userRoutes from '@/server/routes/user'

// Import middleware
import { errorHandler } from '@/server/middleware/errorHandler'

// Mock database with performance simulation
const mockClient = {
    query: jest.fn(),
    release: jest.fn(),
}

const mockPool = {
    connect: jest.fn(() => Promise.resolve(mockClient)),
    query: jest.fn(),
    end: jest.fn(),
} as unknown as Pool

jest.mock('@/server/config/database', () => ({
    getPool: jest.fn(() => mockPool),
    testConnection: jest.fn(() => Promise.resolve()),
}))

// Mock authentication middleware
jest.mock('@/server/middleware/auth', () => ({
    authenticateToken: (req: any, res: any, next: any) => {
        req.user = { id: 'test-user-id', email: 'test@example.com', role: 'manager' }
        next()
    },
}))

// Create Express app for testing
const createTestApp = () => {
    const app = express()
    app.use(express.json())

    app.use('/api/tasks', taskRoutes)
    app.use('/api/projects', projectRoutes)
    app.use('/api/users', userRoutes)

    app.use(errorHandler)

    return app
}

// Helper function to generate mock data
const generateMockTasks = (count: number) => {
    return Array.from({ length: count }, (_, i) => ({
        id: `task-${i}`,
        title: `Task ${i}`,
        description: `Description for task ${i}`,
        status: ['todo', 'in-progress', 'completed'][i % 3],
        priority: ['low', 'medium', 'high', 'critical'][i % 4],
        assigneeId: `user-${i % 10}`,
        projectId: `project-${i % 5}`,
        createdBy: 'test-user-id',
        createdAt: new Date(),
        updatedAt: new Date(),
    }))
}

const generateMockProjects = (count: number) => {
    return Array.from({ length: count }, (_, i) => ({
        id: `project-${i}`,
        name: `Project ${i}`,
        description: `Description for project ${i}`,
        createdBy: 'test-user-id',
        createdAt: new Date(),
        updatedAt: new Date(),
        members: [`user-${i % 10}`],
    }))
}

describe('Performance Tests', () => {
    let app: express.Application

    beforeAll(() => {
        app = createTestApp()
    })

    beforeEach(() => {
        jest.clearAllMocks()
        mockClient.query.mockClear()
    })

    describe('Task Endpoints Performance', () => {
        test('GET /api/tasks should handle large datasets efficiently', async () => {
            const largeMockData = generateMockTasks(1000)

            // Simulate database query time for large dataset
            mockClient.query.mockImplementation(() =>
                new Promise(resolve =>
                    setTimeout(() => resolve({
                        rows: largeMockData,
                        rowCount: 1000,
                    }), 50) // 50ms database query time
                )
            )

            const startTime = Date.now()
            const response = await request(app)
                .get('/api/tasks')
                .set('Authorization', 'Bearer mock-token')

            const endTime = Date.now()
            const responseTime = endTime - startTime

            expect(response.status).toBe(200)
            expect(response.body.data).toHaveLength(1000)
            expect(responseTime).toBeLessThan(500) // Should respond within 500ms
        })

        test('GET /api/tasks with filters should be optimized', async () => {
            const filteredMockData = generateMockTasks(100).filter(task => task.status === 'todo')

            mockClient.query.mockImplementation(() =>
                new Promise(resolve =>
                    setTimeout(() => resolve({
                        rows: filteredMockData,
                        rowCount: filteredMockData.length,
                    }), 30) // Optimized query time
                )
            )

            const startTime = Date.now()
            const response = await request(app)
                .get('/api/tasks?status=todo&priority=high')
                .set('Authorization', 'Bearer mock-token')

            const endTime = Date.now()
            const responseTime = endTime - startTime

            expect(response.status).toBe(200)
            expect(responseTime).toBeLessThan(200) // Filtered queries should be faster
        })

        test('POST /api/tasks should handle concurrent requests', async () => {
            mockClient.query.mockResolvedValue({
                rows: [{
                    id: 'new-task-id',
                    title: 'New Task',
                    description: 'New task description',
                    status: 'todo',
                    priority: 'medium',
                    createdBy: 'test-user-id',
                    createdAt: new Date(),
                    updatedAt: new Date(),
                }],
            })

            // Create 20 concurrent requests
            const requests = Array.from({ length: 20 }, (_, i) =>
                request(app)
                    .post('/api/tasks')
                    .set('Authorization', 'Bearer mock-token')
                    .send({
                        title: `Concurrent Task ${i}`,
                        description: `Description ${i}`,
                        priority: 'medium',
                    })
            )

            const startTime = Date.now()
            const responses = await Promise.all(requests)
            const endTime = Date.now()
            const totalTime = endTime - startTime

            // All requests should succeed
            responses.forEach(response => {
                expect(response.status).toBe(201)
                expect(response.body.success).toBe(true)
            })

            // Should handle all requests within reasonable time
            expect(totalTime).toBeLessThan(2000) // 2 seconds for 20 concurrent requests

            // Average response time should be reasonable
            const avgResponseTime = totalTime / 20
            expect(avgResponseTime).toBeLessThan(100) // 100ms average per request
        })

        test('PUT /api/tasks/:id should be efficient for updates', async () => {
            const mockTask = generateMockTasks(1)[0]

            mockClient.query
                .mockResolvedValueOnce({ rows: [mockTask] }) // Find task
                .mockResolvedValueOnce({ rows: [{ ...mockTask, title: 'Updated Task' }] }) // Update task

            const startTime = Date.now()
            const response = await request(app)
                .put('/api/tasks/task-123')
                .set('Authorization', 'Bearer mock-token')
                .send({
                    title: 'Updated Task',
                    description: 'Updated description',
                })

            const endTime = Date.now()
            const responseTime = endTime - startTime

            expect(response.status).toBe(200)
            expect(responseTime).toBeLessThan(100) // Updates should be very fast
        })
    })

    describe('Project Endpoints Performance', () => {
        test('GET /api/projects should handle pagination efficiently', async () => {
            const mockProjects = generateMockProjects(500)

            mockClient.query.mockImplementation(() =>
                new Promise(resolve =>
                    setTimeout(() => resolve({
                        rows: mockProjects.slice(0, 50), // First page
                        rowCount: 500,
                    }), 40)
                )
            )

            const startTime = Date.now()
            const response = await request(app)
                .get('/api/projects?page=1&limit=50')
                .set('Authorization', 'Bearer mock-token')

            const endTime = Date.now()
            const responseTime = endTime - startTime

            expect(response.status).toBe(200)
            expect(response.body.data).toHaveLength(50)
            expect(responseTime).toBeLessThan(200)
        })

        test('GET /api/projects/:id/tasks should optimize project task queries', async () => {
            const projectTasks = generateMockTasks(200)

            mockClient.query.mockImplementation(() =>
                new Promise(resolve =>
                    setTimeout(() => resolve({
                        rows: projectTasks,
                        rowCount: 200,
                    }), 60) // Slightly longer for join query
                )
            )

            const startTime = Date.now()
            const response = await request(app)
                .get('/api/projects/project-123/tasks')
                .set('Authorization', 'Bearer mock-token')

            const endTime = Date.now()
            const responseTime = endTime - startTime

            expect(response.status).toBe(200)
            expect(responseTime).toBeLessThan(300) // Join queries can be slightly slower
        })
    })

    describe('Memory Usage Tests', () => {
        test('should handle large response payloads without memory issues', async () => {
            const largeMockData = generateMockTasks(5000)

            mockClient.query.mockResolvedValue({
                rows: largeMockData,
                rowCount: 5000,
            })

            const initialMemory = process.memoryUsage()

            const response = await request(app)
                .get('/api/tasks')
                .set('Authorization', 'Bearer mock-token')

            const finalMemory = process.memoryUsage()
            const memoryIncrease = finalMemory.heapUsed - initialMemory.heapUsed

            expect(response.status).toBe(200)
            expect(response.body.data).toHaveLength(5000)

            // Memory increase should be reasonable (less than 50MB for 5000 records)
            expect(memoryIncrease).toBeLessThan(50 * 1024 * 1024)
        })

        test('should properly clean up resources after requests', async () => {
            const mockData = generateMockTasks(100)
            mockClient.query.mockResolvedValue({
                rows: mockData,
                rowCount: 100,
            })

            // Make multiple requests
            for (let i = 0; i < 10; i++) {
                await request(app)
                    .get('/api/tasks')
                    .set('Authorization', 'Bearer mock-token')
            }

            // Verify database connections are properly released
            expect(mockClient.release).toHaveBeenCalledTimes(10)
        })
    })

    describe('Database Connection Pool Performance', () => {
        test('should efficiently manage database connections', async () => {
            mockClient.query.mockResolvedValue({
                rows: generateMockTasks(10),
                rowCount: 10,
            })

            // Simulate multiple concurrent requests
            const requests = Array.from({ length: 50 }, () =>
                request(app)
                    .get('/api/tasks')
                    .set('Authorization', 'Bearer mock-token')
            )

            const startTime = Date.now()
            const responses = await Promise.all(requests)
            const endTime = Date.now()
            const totalTime = endTime - startTime

            // All requests should succeed
            responses.forEach(response => {
                expect(response.status).toBe(200)
            })

            // Should handle concurrent connections efficiently
            expect(totalTime).toBeLessThan(3000) // 3 seconds for 50 concurrent requests

            // Verify connections are acquired and released properly
            expect(mockPool.connect).toHaveBeenCalledTimes(50)
            expect(mockClient.release).toHaveBeenCalledTimes(50)
        })
    })

    describe('Response Time Benchmarks', () => {
        const performanceThresholds = {
            simpleGet: 100,      // Simple GET requests should be under 100ms
            complexQuery: 300,   // Complex queries should be under 300ms
            create: 150,         // Create operations should be under 150ms
            update: 100,         // Update operations should be under 100ms
            delete: 100,         // Delete operations should be under 100ms
        }

        test('simple GET requests meet performance thresholds', async () => {
            mockClient.query.mockResolvedValue({
                rows: generateMockTasks(10),
                rowCount: 10,
            })

            const startTime = Date.now()
            const response = await request(app)
                .get('/api/tasks?limit=10')
                .set('Authorization', 'Bearer mock-token')

            const responseTime = Date.now() - startTime

            expect(response.status).toBe(200)
            expect(responseTime).toBeLessThan(performanceThresholds.simpleGet)
        })

        test('complex queries meet performance thresholds', async () => {
            mockClient.query.mockImplementation(() =>
                new Promise(resolve =>
                    setTimeout(() => resolve({
                        rows: generateMockTasks(100),
                        rowCount: 100,
                    }), 100) // Simulate complex query time
                )
            )

            const startTime = Date.now()
            const response = await request(app)
                .get('/api/tasks?status=todo&priority=high&assigneeId=user-123&sortBy=dueDate')
                .set('Authorization', 'Bearer mock-token')

            const responseTime = Date.now() - startTime

            expect(response.status).toBe(200)
            expect(responseTime).toBeLessThan(performanceThresholds.complexQuery)
        })

        test('create operations meet performance thresholds', async () => {
            mockClient.query.mockResolvedValue({
                rows: [{
                    id: 'new-task-id',
                    title: 'Performance Test Task',
                    description: 'Testing create performance',
                    status: 'todo',
                    priority: 'medium',
                    createdBy: 'test-user-id',
                    createdAt: new Date(),
                    updatedAt: new Date(),
                }],
            })

            const startTime = Date.now()
            const response = await request(app)
                .post('/api/tasks')
                .set('Authorization', 'Bearer mock-token')
                .send({
                    title: 'Performance Test Task',
                    description: 'Testing create performance',
                    priority: 'medium',
                })

            const responseTime = Date.now() - startTime

            expect(response.status).toBe(201)
            expect(responseTime).toBeLessThan(performanceThresholds.create)
        })
    })

    describe('Load Testing Simulation', () => {
        test('should handle sustained load', async () => {
            mockClient.query.mockResolvedValue({
                rows: generateMockTasks(50),
                rowCount: 50,
            })

            const requestsPerSecond = 10
            const testDurationSeconds = 5
            const totalRequests = requestsPerSecond * testDurationSeconds

            const requests: Promise<any>[] = []
            const startTime = Date.now()

            // Simulate sustained load
            for (let i = 0; i < totalRequests; i++) {
                const delay = (i / requestsPerSecond) * 1000

                const delayedRequest = new Promise(resolve => {
                    setTimeout(async () => {
                        const response = await request(app)
                            .get('/api/tasks')
                            .set('Authorization', 'Bearer mock-token')
                        resolve(response)
                    }, delay)
                })

                requests.push(delayedRequest)
            }

            const responses = await Promise.all(requests)
            const endTime = Date.now()
            const actualDuration = endTime - startTime

            // All requests should succeed
            responses.forEach((response: any) => {
                expect(response.status).toBe(200)
            })

            // Should complete within expected timeframe (with some tolerance)
            expect(actualDuration).toBeLessThan((testDurationSeconds + 2) * 1000)

            // Calculate actual throughput
            const actualThroughput = totalRequests / (actualDuration / 1000)
            expect(actualThroughput).toBeGreaterThan(requestsPerSecond * 0.8) // 80% of target throughput
        })
    })

    describe('Error Handling Performance', () => {
        test('should handle errors efficiently without performance degradation', async () => {
            // Simulate database errors
            mockClient.query.mockRejectedValue(new Error('Database connection failed'))

            const requests = Array.from({ length: 10 }, () =>
                request(app)
                    .get('/api/tasks')
                    .set('Authorization', 'Bearer mock-token')
            )

            const startTime = Date.now()
            const responses = await Promise.all(requests)
            const endTime = Date.now()
            const totalTime = endTime - startTime

            // All requests should return error responses quickly
            responses.forEach(response => {
                expect(response.status).toBe(500)
                expect(response.body.success).toBe(false)
            })

            // Error handling should be fast
            expect(totalTime).toBeLessThan(1000) // 1 second for 10 error responses
        })
    })
})