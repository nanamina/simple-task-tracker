/**
 * Unit tests for authentication service
 */

import {
    hashPassword,
    comparePassword,
    generateToken,
    verifyToken,
    extractTokenFromHeader
} from '../server/services/auth'
import { User } from '../shared/types/index'

describe('Authentication Service', () => {
    const mockUser: User = {
        id: '123e4567-e89b-12d3-a456-426614174000',
        email: 'test@example.com',
        name: 'Test User',
        role: 'member',
        preferredLanguage: 'ja',
        createdAt: new Date('2024-01-01'),
        updatedAt: new Date('2024-01-01')
    }

    describe('hashPassword', () => {
        it('should hash a password successfully', async () => {
            const password = 'testpassword123'
            const hashedPassword = await hashPassword(password)

            expect(hashedPassword).toBeDefined()
            expect(hashedPassword).not.toBe(password)
            expect(hashedPassword.length).toBeGreaterThan(50) // bcrypt hashes are typically 60 chars
        })

        it('should generate different hashes for the same password', async () => {
            const password = 'testpassword123'
            const hash1 = await hashPassword(password)
            const hash2 = await hashPassword(password)

            expect(hash1).not.toBe(hash2) // Due to salt, hashes should be different
        })

        it('should handle empty password', async () => {
            await expect(hashPassword('')).resolves.toBeDefined()
        })
    })

    describe('comparePassword', () => {
        it('should return true for matching password and hash', async () => {
            const password = 'testpassword123'
            const hashedPassword = await hashPassword(password)

            const isMatch = await comparePassword(password, hashedPassword)
            expect(isMatch).toBe(true)
        })

        it('should return false for non-matching password and hash', async () => {
            const password = 'testpassword123'
            const wrongPassword = 'wrongpassword456'
            const hashedPassword = await hashPassword(password)

            const isMatch = await comparePassword(wrongPassword, hashedPassword)
            expect(isMatch).toBe(false)
        })

        it('should return false for empty password against hash', async () => {
            const password = 'testpassword123'
            const hashedPassword = await hashPassword(password)

            const isMatch = await comparePassword('', hashedPassword)
            expect(isMatch).toBe(false)
        })

        it('should handle invalid hash gracefully', async () => {
            const password = 'testpassword123'
            const invalidHash = 'invalid-hash'

            const result = await comparePassword(password, invalidHash)
            expect(result).toBe(false) // bcrypt returns false for invalid hashes
        })
    })

    describe('generateToken', () => {
        it('should generate a valid JWT token', () => {
            const token = generateToken(mockUser)

            expect(token).toBeDefined()
            expect(typeof token).toBe('string')
            expect(token.split('.')).toHaveLength(3) // JWT has 3 parts separated by dots
        })

        it('should generate different tokens for different users', () => {
            const user2: User = { ...mockUser, id: '456e7890-e89b-12d3-a456-426614174001', email: 'user2@example.com' }

            const token1 = generateToken(mockUser)
            const token2 = generateToken(user2)

            expect(token1).not.toBe(token2)
        })
    })

    describe('verifyToken', () => {
        it('should verify and decode a valid token', () => {
            const token = generateToken(mockUser)
            const decoded = verifyToken(token)

            expect(decoded).toBeDefined()
            expect(decoded?.id).toBe(mockUser.id)
            expect(decoded?.email).toBe(mockUser.email)
            expect(decoded?.role).toBe(mockUser.role)
        })

        it('should return null for invalid token', () => {
            const invalidToken = 'invalid.token.here'
            const decoded = verifyToken(invalidToken)

            expect(decoded).toBeNull()
        })

        it('should return null for expired token', () => {
            // This test would require mocking time or using a token with very short expiry
            // For now, we'll test with a malformed token
            const malformedToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.invalid.signature'
            const decoded = verifyToken(malformedToken)

            expect(decoded).toBeNull()
        })

        it('should return null for empty token', () => {
            const decoded = verifyToken('')
            expect(decoded).toBeNull()
        })
    })

    describe('extractTokenFromHeader', () => {
        it('should extract token from valid Bearer header', () => {
            const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test.token'
            const authHeader = `Bearer ${token}`

            const extractedToken = extractTokenFromHeader(authHeader)
            expect(extractedToken).toBe(token)
        })

        it('should return null for header without Bearer prefix', () => {
            const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test.token'
            const authHeader = token

            const extractedToken = extractTokenFromHeader(authHeader)
            expect(extractedToken).toBeNull()
        })

        it('should return null for undefined header', () => {
            const extractedToken = extractTokenFromHeader(undefined)
            expect(extractedToken).toBeNull()
        })

        it('should return null for empty header', () => {
            const extractedToken = extractTokenFromHeader('')
            expect(extractedToken).toBeNull()
        })

        it('should return null for malformed Bearer header', () => {
            const extractedToken = extractTokenFromHeader('Bearer') // Missing space after Bearer
            expect(extractedToken).toBeNull()
        })

        it('should handle Bearer header with extra spaces', () => {
            const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test.token'
            const authHeader = `Bearer  ${token}` // Extra space

            const extractedToken = extractTokenFromHeader(authHeader)
            expect(extractedToken).toBe(` ${token}`) // Will include the extra space
        })
    })
})