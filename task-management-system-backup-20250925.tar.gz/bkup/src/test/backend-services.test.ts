/**
 * Comprehensive unit tests for backend services
 */

import { Pool } from 'pg'

// Import services
import * as authService from '@/server/services/auth'
import * as notificationService from '@/server/services/notification'
import * as permissionsService from '@/server/services/permissions'

// Import repositories
import * as taskRepository from '@/server/repositories/task-repository'
import * as projectRepository from '@/server/repositories/project-repository'
import * as userRepository from '@/server/repositories/user-repository'

// Import utilities
import * as logger from '@/server/utils/logger'
import * as databaseErrorHandler from '@/server/utils/databaseErrorHandler'

// Import types
import { User, Task, Project, CreateTaskDTO, CreateProjectDTO, CreateUserDTO } from '@/shared/types'

// Mock dependencies
jest.mock('bcrypt')
jest.mock('jsonwebtoken')
jest.mock('nodemailer')

// Mock database
const mockClient = {
    query: jest.fn(),
    release: jest.fn(),
}

const mockPool = {
    connect: jest.fn(() => Promise.resolve(mockClient)),
    query: jest.fn(),
    end: jest.fn(),
} as unknown as Pool

jest.mock('@/server/config/database', () => ({
    getPool: jest.fn(() => mockPool),
    testConnection: jest.fn(() => Promise.resolve()),
}))

// Test data
const mockUser: User = {
    id: 'user-123',
    email: 'test@example.com',
    name: 'Test User',
    role: 'manager',
    preferredLanguage: 'ja',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
}

const mockTask: Task = {
    id: 'task-123',
    title: 'Test Task',
    description: 'Test task description',
    status: 'todo',
    priority: 'medium',
    dueDate: new Date('2024-12-31'),
    assigneeId: 'user-123',
    projectId: 'project-123',
    createdBy: 'user-123',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
}

const mockProject: Project = {
    id: 'project-123',
    name: 'Test Project',
    description: 'Test project description',
    createdBy: 'user-123',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
    members: ['user-123'],
}

describe('Backend Services Unit Tests', () => {
    beforeEach(() => {
        jest.clearAllMocks()
        mockClient.query.mockClear()
        mockPool.query.mockClear()
    })

    describe('Authentication Service', () => {
        const bcrypt = require('bcrypt')
        const jwt = require('jsonwebtoken')

        beforeEach(() => {
            bcrypt.hash.mockResolvedValue('hashed-password')
            bcrypt.compare.mockResolvedValue(true)
            jwt.sign.mockReturnValue('mock-jwt-token')
            jwt.verify.mockReturnValue({ userId: 'user-123', email: 'test@example.com' })
        })

        describe('hashPassword', () => {
            test('should hash password with correct salt rounds', async () => {
                const password = 'testPassword123'
                const result = await authService.hashPassword(password)

                expect(bcrypt.hash).toHaveBeenCalledWith(password, 12)
                expect(result).toBe('hashed-password')
            })

            test('should handle bcrypt errors', async () => {
                bcrypt.hash.mockRejectedValueOnce(new Error('Hashing failed'))

                await expect(authService.hashPassword('password')).rejects.toThrow('Hashing failed')
            })
        })

        describe('comparePassword', () => {
            test('should compare password with hash correctly', async () => {
                const password = 'testPassword123'
                const hash = 'hashed-password'

                const result = await authService.comparePassword(password, hash)

                expect(bcrypt.compare).toHaveBeenCalledWith(password, hash)
                expect(result).toBe(true)
            })

            test('should return false for incorrect password', async () => {
                bcrypt.compare.mockResolvedValueOnce(false)

                const result = await authService.comparePassword('wrong-password', 'hash')

                expect(result).toBe(false)
            })
        })

        describe('generateToken', () => {
            test('should generate JWT token with correct payload', () => {
                const payload = { userId: 'user-123', email: 'test@example.com' }
                const result = authService.generateToken(payload)

                expect(jwt.sign).toHaveBeenCalledWith(
                    payload,
                    process.env.JWT_SECRET,
                    { expiresIn: '24h' }
                )
                expect(result).toBe('mock-jwt-token')
            })
        })

        describe('verifyToken', () => {
            test('should verify JWT token correctly', () => {
                const token = 'valid-token'
                const result = authService.verifyToken(token)

                expect(jwt.verify).toHaveBeenCalledWith(token, process.env.JWT_SECRET)
                expect(result).toEqual({ userId: 'user-123', email: 'test@example.com' })
            })

            test('should handle invalid token', () => {
                jwt.verify.mockImplementationOnce(() => {
                    throw new Error('Invalid token')
                })

                expect(() => authService.verifyToken('invalid-token')).toThrow('Invalid token')
            })
        })
    })

    describe('Notification Service', () => {
        const nodemailer = require('nodemailer')
        const mockTransporter = {
            sendMail: jest.fn(),
        }

        beforeEach(() => {
            nodemailer.createTransporter.mockReturnValue(mockTransporter)
            mockTransporter.sendMail.mockResolvedValue({ messageId: 'test-message-id' })
        })

        describe('sendTaskAssignmentNotification', () => {
            test('should send email notification for task assignment', async () => {
                await notificationService.sendTaskAssignmentNotification(mockTask, mockUser)

                expect(mockTransporter.sendMail).toHaveBeenCalledWith({
                    from: process.env.SMTP_FROM,
                    to: mockUser.email,
                    subject: expect.stringContaining('Task Assigned'),
                    html: expect.stringContaining(mockTask.title),
                })
            })

            test('should use user preferred language for email content', async () => {
                const japaneseUser = { ...mockUser, preferredLanguage: 'ja' as const }

                await notificationService.sendTaskAssignmentNotification(mockTask, japaneseUser)

                expect(mockTransporter.sendMail).toHaveBeenCalledWith({
                    from: process.env.SMTP_FROM,
                    to: japaneseUser.email,
                    subject: expect.stringContaining('タスクが割り当てられました'),
                    html: expect.stringContaining(mockTask.title),
                })
            })

            test('should handle email sending errors gracefully', async () => {
                mockTransporter.sendMail.mockRejectedValueOnce(new Error('SMTP error'))

                // Should not throw, but log the error
                await expect(
                    notificationService.sendTaskAssignmentNotification(mockTask, mockUser)
                ).resolves.not.toThrow()
            })
        })

        describe('sendTaskStatusUpdateNotification', () => {
            test('should send notification when task status changes', async () => {
                const stakeholders = [mockUser]

                await notificationService.sendTaskStatusUpdateNotification(
                    mockTask,
                    'completed',
                    stakeholders
                )

                expect(mockTransporter.sendMail).toHaveBeenCalledWith({
                    from: process.env.SMTP_FROM,
                    to: mockUser.email,
                    subject: expect.stringContaining('Task Status Updated'),
                    html: expect.stringContaining('completed'),
                })
            })
        })

        describe('sendOverdueTaskReminder', () => {
            test('should send reminder for overdue tasks', async () => {
                const overdueTasks = [{ ...mockTask, dueDate: new Date('2023-01-01') }]

                await notificationService.sendOverdueTaskReminder(overdueTasks, mockUser)

                expect(mockTransporter.sendMail).toHaveBeenCalledWith({
                    from: process.env.SMTP_FROM,
                    to: mockUser.email,
                    subject: expect.stringContaining('Overdue Tasks'),
                    html: expect.stringContaining('overdue'),
                })
            })
        })
    })

    describe('Permissions Service', () => {
        describe('canUserAccessTask', () => {
            test('should allow admin to access any task', () => {
                const adminUser = { ...mockUser, role: 'admin' as const }
                const result = permissionsService.canUserAccessTask(adminUser, mockTask)

                expect(result).toBe(true)
            })

            test('should allow task creator to access task', () => {
                const result = permissionsService.canUserAccessTask(mockUser, mockTask)

                expect(result).toBe(true)
            })

            test('should allow assigned user to access task', () => {
                const assignedUser = { ...mockUser, id: 'user-456' }
                const taskWithAssignee = { ...mockTask, assigneeId: 'user-456' }

                const result = permissionsService.canUserAccessTask(assignedUser, taskWithAssignee)

                expect(result).toBe(true)
            })

            test('should deny access to unrelated user', () => {
                const unrelatedUser = { ...mockUser, id: 'user-456', role: 'member' as const }
                const unrelatedTask = { ...mockTask, createdBy: 'user-789', assigneeId: 'user-999' }

                const result = permissionsService.canUserAccessTask(unrelatedUser, unrelatedTask)

                expect(result).toBe(false)
            })
        })

        describe('canUserModifyTask', () => {
            test('should allow admin to modify any task', () => {
                const adminUser = { ...mockUser, role: 'admin' as const }
                const result = permissionsService.canUserModifyTask(adminUser, mockTask)

                expect(result).toBe(true)
            })

            test('should allow manager to modify tasks in their projects', () => {
                const managerUser = { ...mockUser, role: 'manager' as const }
                const result = permissionsService.canUserModifyTask(managerUser, mockTask)

                expect(result).toBe(true)
            })

            test('should allow task creator to modify their task', () => {
                const result = permissionsService.canUserModifyTask(mockUser, mockTask)

                expect(result).toBe(true)
            })

            test('should deny modification to regular member for others tasks', () => {
                const memberUser = { ...mockUser, id: 'user-456', role: 'member' as const }
                const othersTask = { ...mockTask, createdBy: 'user-789' }

                const result = permissionsService.canUserModifyTask(memberUser, othersTask)

                expect(result).toBe(false)
            })
        })

        describe('canUserAccessProject', () => {
            test('should allow project member to access project', () => {
                const result = permissionsService.canUserAccessProject(mockUser, mockProject)

                expect(result).toBe(true)
            })

            test('should deny access to non-member', () => {
                const nonMemberUser = { ...mockUser, id: 'user-456' }
                const projectWithoutUser = { ...mockProject, members: ['user-789'] }

                const result = permissionsService.canUserAccessProject(nonMemberUser, projectWithoutUser)

                expect(result).toBe(false)
            })
        })

        describe('canUserCreateProject', () => {
            test('should allow admin to create projects', () => {
                const adminUser = { ...mockUser, role: 'admin' as const }
                const result = permissionsService.canUserCreateProject(adminUser)

                expect(result).toBe(true)
            })

            test('should allow manager to create projects', () => {
                const managerUser = { ...mockUser, role: 'manager' as const }
                const result = permissionsService.canUserCreateProject(managerUser)

                expect(result).toBe(true)
            })

            test('should deny project creation to regular members', () => {
                const memberUser = { ...mockUser, role: 'member' as const }
                const result = permissionsService.canUserCreateProject(memberUser)

                expect(result).toBe(false)
            })
        })
    })

    describe('Task Repository', () => {
        describe('createTask', () => {
            test('should create task with correct SQL query', async () => {
                const taskData: CreateTaskDTO = {
                    title: 'New Task',
                    description: 'New task description',
                    status: 'todo',
                    priority: 'high',
                    dueDate: new Date('2024-12-31'),
                    assigneeId: 'user-123',
                    projectId: 'project-123',
                }

                mockClient.query.mockResolvedValueOnce({
                    rows: [{ ...mockTask, ...taskData, id: 'new-task-id' }],
                })

                const result = await taskRepository.createTask(taskData, 'user-123')

                expect(mockClient.query).toHaveBeenCalledWith(
                    expect.stringContaining('INSERT INTO tasks'),
                    expect.arrayContaining([
                        taskData.title,
                        taskData.description,
                        taskData.status,
                        taskData.priority,
                        taskData.dueDate,
                        taskData.assigneeId,
                        taskData.projectId,
                        'user-123',
                    ])
                )
                expect(result.title).toBe(taskData.title)
            })

            test('should handle database errors', async () => {
                const taskData: CreateTaskDTO = {
                    title: 'New Task',
                    description: 'New task description',
                    status: 'todo',
                    priority: 'medium',
                }

                mockClient.query.mockRejectedValueOnce(new Error('Database error'))

                await expect(taskRepository.createTask(taskData, 'user-123')).rejects.toThrow('Database error')
            })
        })

        describe('findTasksByFilters', () => {
            test('should build correct query with filters', async () => {
                const filters = {
                    status: 'todo',
                    priority: 'high',
                    assigneeId: 'user-123',
                }

                mockClient.query.mockResolvedValueOnce({
                    rows: [mockTask],
                    rowCount: 1,
                })

                await taskRepository.findTasksByFilters(filters, 1, 10, 'createdAt', 'desc')

                expect(mockClient.query).toHaveBeenCalledWith(
                    expect.stringContaining('WHERE status = $1 AND priority = $2 AND assignee_id = $3'),
                    expect.arrayContaining(['todo', 'high', 'user-123'])
                )
            })

            test('should handle empty filters', async () => {
                mockClient.query.mockResolvedValueOnce({
                    rows: [mockTask],
                    rowCount: 1,
                })

                await taskRepository.findTasksByFilters({}, 1, 10, 'createdAt', 'desc')

                expect(mockClient.query).toHaveBeenCalledWith(
                    expect.not.stringContaining('WHERE'),
                    expect.any(Array)
                )
            })
        })

        describe('updateTaskStatus', () => {
            test('should update task status and set completion date', async () => {
                mockClient.query.mockResolvedValueOnce({
                    rows: [{ ...mockTask, status: 'completed', completedAt: new Date() }],
                })

                const result = await taskRepository.updateTaskStatus('task-123', 'completed')

                expect(mockClient.query).toHaveBeenCalledWith(
                    expect.stringContaining('UPDATE tasks SET status = $1'),
                    expect.arrayContaining(['completed', 'task-123'])
                )
                expect(result.status).toBe('completed')
                expect(result.completedAt).toBeDefined()
            })
        })
    })

    describe('Project Repository', () => {
        describe('createProject', () => {
            test('should create project and add creator as member', async () => {
                const projectData: CreateProjectDTO = {
                    name: 'New Project',
                    description: 'New project description',
                }

                mockClient.query
                    .mockResolvedValueOnce({ rows: [{ ...mockProject, ...projectData, id: 'new-project-id' }] })
                    .mockResolvedValueOnce({ rows: [] }) // Add member query

                const result = await projectRepository.createProject(projectData, 'user-123')

                expect(mockClient.query).toHaveBeenCalledTimes(2)
                expect(mockClient.query).toHaveBeenNthCalledWith(
                    1,
                    expect.stringContaining('INSERT INTO projects'),
                    expect.arrayContaining([projectData.name, projectData.description, 'user-123'])
                )
                expect(mockClient.query).toHaveBeenNthCalledWith(
                    2,
                    expect.stringContaining('INSERT INTO project_members'),
                    expect.arrayContaining(['new-project-id', 'user-123'])
                )
            })
        })

        describe('addProjectMember', () => {
            test('should add user to project', async () => {
                mockClient.query.mockResolvedValueOnce({ rows: [] })

                await projectRepository.addProjectMember('project-123', 'user-456')

                expect(mockClient.query).toHaveBeenCalledWith(
                    expect.stringContaining('INSERT INTO project_members'),
                    ['project-123', 'user-456']
                )
            })

            test('should handle duplicate member addition', async () => {
                mockClient.query.mockRejectedValueOnce({
                    code: '23505', // PostgreSQL unique violation
                    constraint: 'project_members_pkey',
                })

                await expect(
                    projectRepository.addProjectMember('project-123', 'user-123')
                ).rejects.toThrow('User is already a member of this project')
            })
        })
    })

    describe('User Repository', () => {
        describe('createUser', () => {
            test('should create user with hashed password', async () => {
                const userData: CreateUserDTO = {
                    name: 'New User',
                    email: 'newuser@example.com',
                    password: 'password123',
                    role: 'member',
                }

                mockClient.query.mockResolvedValueOnce({
                    rows: [{ ...mockUser, ...userData, id: 'new-user-id' }],
                })

                const result = await userRepository.createUser(userData)

                expect(mockClient.query).toHaveBeenCalledWith(
                    expect.stringContaining('INSERT INTO users'),
                    expect.arrayContaining([
                        userData.name,
                        userData.email,
                        expect.any(String), // hashed password
                        userData.role,
                        'ja', // default language
                    ])
                )
                expect(result.email).toBe(userData.email)
            })
        })

        describe('findUserByEmail', () => {
            test('should find user by email', async () => {
                mockClient.query.mockResolvedValueOnce({
                    rows: [mockUser],
                })

                const result = await userRepository.findUserByEmail('test@example.com')

                expect(mockClient.query).toHaveBeenCalledWith(
                    expect.stringContaining('SELECT * FROM users WHERE email = $1'),
                    ['test@example.com']
                )
                expect(result).toEqual(mockUser)
            })

            test('should return null for non-existent user', async () => {
                mockClient.query.mockResolvedValueOnce({ rows: [] })

                const result = await userRepository.findUserByEmail('nonexistent@example.com')

                expect(result).toBeNull()
            })
        })
    })

    describe('Database Error Handler', () => {
        test('should handle unique constraint violations', () => {
            const error = {
                code: '23505',
                constraint: 'users_email_key',
                detail: 'Key (email)=(test@example.com) already exists.',
            }

            const result = databaseErrorHandler.handleDatabaseError(error)

            expect(result.code).toBe('DUPLICATE_ENTRY')
            expect(result.message).toContain('already exists')
        })

        test('should handle foreign key violations', () => {
            const error = {
                code: '23503',
                constraint: 'tasks_assignee_id_fkey',
                detail: 'Key (assignee_id)=(invalid-id) is not present in table "users".',
            }

            const result = databaseErrorHandler.handleDatabaseError(error)

            expect(result.code).toBe('FOREIGN_KEY_VIOLATION')
            expect(result.message).toContain('referenced record does not exist')
        })

        test('should handle connection errors', () => {
            const error = {
                code: 'ECONNREFUSED',
                message: 'Connection refused',
            }

            const result = databaseErrorHandler.handleDatabaseError(error)

            expect(result.code).toBe('DATABASE_CONNECTION_ERROR')
            expect(result.message).toContain('database connection')
        })

        test('should handle unknown errors', () => {
            const error = {
                code: 'UNKNOWN_ERROR',
                message: 'Something went wrong',
            }

            const result = databaseErrorHandler.handleDatabaseError(error)

            expect(result.code).toBe('INTERNAL_ERROR')
            expect(result.message).toBe('An internal error occurred')
        })
    })

    describe('Logger Utility', () => {
        let consoleSpy: jest.SpyInstance

        beforeEach(() => {
            consoleSpy = jest.spyOn(console, 'log').mockImplementation()
        })

        afterEach(() => {
            consoleSpy.mockRestore()
        })

        test('should log info messages with timestamp', () => {
            logger.info('Test info message')

            expect(consoleSpy).toHaveBeenCalledWith(
                expect.stringContaining('[INFO]'),
                expect.stringContaining('Test info message')
            )
        })

        test('should log error messages with stack trace', () => {
            const error = new Error('Test error')
            logger.error('Test error message', error)

            expect(consoleSpy).toHaveBeenCalledWith(
                expect.stringContaining('[ERROR]'),
                expect.stringContaining('Test error message'),
                expect.stringContaining(error.stack)
            )
        })

        test('should log debug messages only in development', () => {
            const originalEnv = process.env.NODE_ENV
            process.env.NODE_ENV = 'development'

            logger.debug('Test debug message')

            expect(consoleSpy).toHaveBeenCalledWith(
                expect.stringContaining('[DEBUG]'),
                expect.stringContaining('Test debug message')
            )

            process.env.NODE_ENV = originalEnv
        })

        test('should not log debug messages in production', () => {
            const originalEnv = process.env.NODE_ENV
            process.env.NODE_ENV = 'production'

            logger.debug('Test debug message')

            expect(consoleSpy).not.toHaveBeenCalled()

            process.env.NODE_ENV = originalEnv
        })
    })
})