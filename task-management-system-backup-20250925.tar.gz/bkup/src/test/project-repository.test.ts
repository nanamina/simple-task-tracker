/**
 * Unit tests for Project Repository
 */

import { Pool, PoolClient } from 'pg'
import { ProjectRepository } from '../server/repositories/project-repository'
import { CreateProjectDTO, UpdateProjectDTO } from '../shared/types/validation'

// Mock pg module
jest.mock('pg', () => ({
    Pool: jest.fn()
}))

describe('ProjectRepository', () => {
    let mockPool: jest.Mocked<Pool>
    let mockClient: jest.Mocked<PoolClient>
    let projectRepository: ProjectRepository

    beforeEach(() => {
        // Create mock client
        mockClient = {
            query: jest.fn(),
            release: jest.fn()
        } as any

        // Create mock pool
        mockPool = {
            connect: jest.fn().mockResolvedValue(mockClient)
        } as any

            // Mock Pool constructor
            ; (Pool as jest.MockedClass<typeof Pool>).mockImplementation(() => mockPool)

        projectRepository = new ProjectRepository(mockPool)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    describe('createProject', () => {
        const mockProjectData: CreateProjectDTO = {
            name: 'Test Project',
            description: 'Test project description'
        }

        const createdBy = 'creator-123'

        const mockProjectResult = {
            rows: [{
                id: 'project-123',
                name: 'Test Project',
                description: 'Test project description',
                created_by: 'creator-123',
                created_at: new Date('2024-01-01'),
                updated_at: new Date('2024-01-01')
            }]
        }

        it('should create a project successfully', async () => {
            mockClient.query
                .mockResolvedValueOnce(undefined) // BEGIN
                .mockResolvedValueOnce(mockProjectResult) // INSERT project
                .mockResolvedValueOnce(undefined) // INSERT member
                .mockResolvedValueOnce(undefined) // COMMIT

            const result = await projectRepository.createProject(mockProjectData, createdBy)

            expect(mockClient.query).toHaveBeenCalledWith('BEGIN')
            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/INSERT INTO projects/),
                expect.arrayContaining([
                    mockProjectData.name,
                    mockProjectData.description,
                    createdBy
                ])
            )
            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/INSERT INTO project_members/),
                ['project-123', createdBy]
            )
            expect(mockClient.query).toHaveBeenCalledWith('COMMIT')
            expect(mockClient.release).toHaveBeenCalled()

            expect(result).toEqual({
                id: 'project-123',
                name: 'Test Project',
                description: 'Test project description',
                createdBy: 'creator-123',
                createdAt: new Date('2024-01-01'),
                updatedAt: new Date('2024-01-01'),
                members: ['creator-123']
            })
        })

        it('should rollback on database failure', async () => {
            const dbError = new Error('Database connection failed')
            mockClient.query
                .mockResolvedValueOnce(undefined) // BEGIN
                .mockRejectedValueOnce(dbError) // INSERT project fails

            await expect(projectRepository.createProject(mockProjectData, createdBy)).rejects.toThrow('Failed to create project')
            expect(mockClient.query).toHaveBeenCalledWith('ROLLBACK')
            expect(mockClient.release).toHaveBeenCalled()
        })
    })

    describe('findById', () => {
        const projectId = 'project-123'
        const mockProjectResult = {
            rows: [{
                id: projectId,
                name: 'Test Project',
                description: 'Test project description',
                created_by: 'creator-123',
                created_at: new Date('2024-01-01'),
                updated_at: new Date('2024-01-01')
            }]
        }

        const mockMembersResult = {
            rows: [
                { user_id: 'user-1' },
                { user_id: 'user-2' }
            ]
        }

        it('should find project by ID successfully', async () => {
            mockClient.query
                .mockResolvedValueOnce(mockProjectResult) // SELECT project
                .mockResolvedValueOnce(mockMembersResult) // SELECT members

            const result = await projectRepository.findById(projectId)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/SELECT.*FROM projects.*WHERE id = \$1/s),
                [projectId]
            )
            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/SELECT user_id.*FROM project_members.*WHERE project_id = \$1/s),
                [projectId]
            )
            expect(result).toEqual({
                id: projectId,
                name: 'Test Project',
                description: 'Test project description',
                createdBy: 'creator-123',
                createdAt: new Date('2024-01-01'),
                updatedAt: new Date('2024-01-01'),
                members: ['user-1', 'user-2']
            })
        })

        it('should return null when project not found', async () => {
            mockClient.query.mockResolvedValueOnce({ rows: [] })

            const result = await projectRepository.findById(projectId)

            expect(result).toBeNull()
        })

        it('should throw error on database failure', async () => {
            mockClient.query.mockRejectedValue(new Error('Database error'))

            await expect(projectRepository.findById(projectId)).rejects.toThrow('Failed to find project by ID')
            expect(mockClient.release).toHaveBeenCalled()
        })
    })

    describe('updateProject', () => {
        const projectId = 'project-123'
        const updateData: UpdateProjectDTO = {
            name: 'Updated Project',
            description: 'Updated description'
        }

        const mockUpdateResult = {
            rows: [{
                id: projectId,
                name: 'Updated Project',
                description: 'Updated description',
                created_by: 'creator-123',
                created_at: new Date('2024-01-01'),
                updated_at: new Date('2024-01-02')
            }]
        }

        it('should update project successfully', async () => {
            mockClient.query.mockResolvedValueOnce(mockUpdateResult)

            // Mock findById call for returning updated project with members
            const findByIdSpy = jest.spyOn(projectRepository, 'findById').mockResolvedValue({
                id: projectId,
                name: 'Updated Project',
                description: 'Updated description',
                createdBy: 'creator-123',
                createdAt: new Date('2024-01-01'),
                updatedAt: new Date('2024-01-02'),
                members: ['creator-123']
            })

            const result = await projectRepository.updateProject(projectId, updateData)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/UPDATE projects[\s\S]*SET[\s\S]*WHERE id = \$\d+/),
                expect.arrayContaining(['Updated Project', 'Updated description', projectId])
            )
            expect(findByIdSpy).toHaveBeenCalledWith(projectId)
            expect(result?.name).toBe('Updated Project')
        })

        it('should return null when project not found', async () => {
            mockClient.query.mockResolvedValueOnce({ rows: [] })

            const result = await projectRepository.updateProject(projectId, updateData)

            expect(result).toBeNull()
        })

        it('should handle empty update data', async () => {
            const findByIdSpy = jest.spyOn(projectRepository, 'findById').mockResolvedValue({
                id: projectId,
                name: 'Test Project',
                description: 'Test description',
                createdBy: 'creator-123',
                createdAt: new Date('2024-01-01'),
                updatedAt: new Date('2024-01-01'),
                members: ['creator-123']
            })

            const result = await projectRepository.updateProject(projectId, {})

            expect(findByIdSpy).toHaveBeenCalledWith(projectId)
            expect(result).toBeDefined()
        })
    })

    describe('deleteProject', () => {
        const projectId = 'project-123'

        it('should delete project successfully', async () => {
            mockClient.query
                .mockResolvedValueOnce(undefined) // BEGIN
                .mockResolvedValueOnce(undefined) // DELETE members
                .mockResolvedValueOnce({ rowCount: 1 }) // DELETE project
                .mockResolvedValueOnce(undefined) // COMMIT

            const result = await projectRepository.deleteProject(projectId)

            expect(mockClient.query).toHaveBeenCalledWith('BEGIN')
            expect(mockClient.query).toHaveBeenCalledWith(
                'DELETE FROM project_members WHERE project_id = $1',
                [projectId]
            )
            expect(mockClient.query).toHaveBeenCalledWith(
                'DELETE FROM projects WHERE id = $1',
                [projectId]
            )
            expect(mockClient.query).toHaveBeenCalledWith('COMMIT')
            expect(result).toBe(true)
        })

        it('should return false when project not found', async () => {
            mockClient.query
                .mockResolvedValueOnce(undefined) // BEGIN
                .mockResolvedValueOnce(undefined) // DELETE members
                .mockResolvedValueOnce({ rowCount: 0 }) // DELETE project (not found)
                .mockResolvedValueOnce(undefined) // COMMIT

            const result = await projectRepository.deleteProject(projectId)

            expect(result).toBe(false)
        })

        it('should rollback on database failure', async () => {
            mockClient.query
                .mockResolvedValueOnce(undefined) // BEGIN
                .mockRejectedValueOnce(new Error('Database error')) // DELETE members fails

            await expect(projectRepository.deleteProject(projectId)).rejects.toThrow('Failed to delete project')
            expect(mockClient.query).toHaveBeenCalledWith('ROLLBACK')
            expect(mockClient.release).toHaveBeenCalled()
        })
    })

    describe('addMember', () => {
        const projectId = 'project-123'
        const userId = 'user-456'

        it('should add member successfully', async () => {
            mockClient.query.mockResolvedValue({ rowCount: 1 })

            const result = await projectRepository.addMember(projectId, userId)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/INSERT INTO project_members.*ON CONFLICT.*DO NOTHING/s),
                [projectId, userId]
            )
            expect(result).toBe(true)
        })

        it('should handle adding existing member', async () => {
            mockClient.query.mockResolvedValue({ rowCount: 0 }) // No new row inserted due to conflict

            const result = await projectRepository.addMember(projectId, userId)

            expect(result).toBe(true) // Still returns true as member exists
        })

        it('should throw error on database failure', async () => {
            mockClient.query.mockRejectedValue(new Error('Database error'))

            await expect(projectRepository.addMember(projectId, userId)).rejects.toThrow('Failed to add member to project')
            expect(mockClient.release).toHaveBeenCalled()
        })
    })

    describe('removeMember', () => {
        const projectId = 'project-123'
        const userId = 'user-456'

        it('should remove member successfully', async () => {
            mockClient.query.mockResolvedValue({ rowCount: 1 })

            const result = await projectRepository.removeMember(projectId, userId)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/DELETE FROM project_members[\s\S]*WHERE project_id = \$1 AND user_id = \$2/),
                [projectId, userId]
            )
            expect(result).toBe(true)
        })

        it('should return false when member not found', async () => {
            mockClient.query.mockResolvedValue({ rowCount: 0 })

            const result = await projectRepository.removeMember(projectId, userId)

            expect(result).toBe(false)
        })
    })

    describe('isMember', () => {
        const projectId = 'project-123'
        const userId = 'user-456'

        it('should return true when user is member', async () => {
            mockClient.query.mockResolvedValue({ rows: [{ exists: true }] })

            const result = await projectRepository.isMember(projectId, userId)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/SELECT 1 FROM project_members[\s\S]*WHERE project_id = \$1 AND user_id = \$2/),
                [projectId, userId]
            )
            expect(result).toBe(true)
        })

        it('should return false when user is not member', async () => {
            mockClient.query.mockResolvedValue({ rows: [] })

            const result = await projectRepository.isMember(projectId, userId)

            expect(result).toBe(false)
        })
    })

    describe('getProjectStats', () => {
        const projectId = 'project-123'

        it('should get project statistics successfully', async () => {
            const mockStatsResult = {
                rows: [{
                    total_tasks: '10',
                    completed_tasks: '7',
                    in_progress_tasks: '2',
                    todo_tasks: '1'
                }]
            }

            mockClient.query.mockResolvedValue(mockStatsResult)

            const result = await projectRepository.getProjectStats(projectId)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/SELECT.*COUNT.*FROM tasks.*WHERE project_id = \$1/s),
                [projectId]
            )
            expect(result).toEqual({
                totalTasks: 10,
                completedTasks: 7,
                inProgressTasks: 2,
                todoTasks: 1,
                completionRate: 70
            })
        })

        it('should handle project with no tasks', async () => {
            const mockStatsResult = {
                rows: [{
                    total_tasks: '0',
                    completed_tasks: '0',
                    in_progress_tasks: '0',
                    todo_tasks: '0'
                }]
            }

            mockClient.query.mockResolvedValue(mockStatsResult)

            const result = await projectRepository.getProjectStats(projectId)

            expect(result).toEqual({
                totalTasks: 0,
                completedTasks: 0,
                inProgressTasks: 0,
                todoTasks: 0,
                completionRate: 0
            })
        })
    })
})