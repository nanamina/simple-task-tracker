/**
 * Database integration tests
 * Tests actual database operations with a test database
 */

import { Pool, Client } from 'pg'
import { getPool, testConnection } from '@/server/config/database'
import { migrate } from '@/server/config/migrate'

// Import repositories for testing
import * as taskRepository from '@/server/repositories/task-repository'
import * as projectRepository from '@/server/repositories/project-repository'
import * as userRepository from '@/server/repositories/user-repository'

// Import types
import { CreateUserDTO, CreateProjectDTO, CreateTaskDTO } from '@/shared/types'

// Test database configuration
const TEST_DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://test:test@localhost:5432/test_db'

describe('Database Integration Tests', () => {
    let pool: Pool
    let testClient: Client

    beforeAll(async () => {
        // Create test database connection
        testClient = new Client({
            connectionString: TEST_DATABASE_URL,
        })

        try {
            await testClient.connect()

            // Run migrations on test database
            await migrate('up')

            // Get pool for testing
            pool = getPool()
        } catch (error) {
            console.warn('Test database not available, skipping database integration tests')
            console.warn('To run these tests, set up a test PostgreSQL database and set TEST_DATABASE_URL')
            return
        }
    })

    afterAll(async () => {
        if (testClient) {
            await testClient.end()
        }
        if (pool) {
            await pool.end()
        }
    })

    beforeEach(async () => {
        if (!testClient) return

        // Clean up test data before each test
        await testClient.query('DELETE FROM tasks')
        await testClient.query('DELETE FROM project_members')
        await testClient.query('DELETE FROM projects')
        await testClient.query('DELETE FROM users')
    })

    describe('Database Connection', () => {
        test('should connect to test database successfully', async () => {
            if (!testClient) {
                console.log('Skipping test - no database connection')
                return
            }

            const result = await testConnection()
            expect(result).toBe(true)
        })

        test('should execute basic queries', async () => {
            if (!testClient) return

            const result = await testClient.query('SELECT 1 as test')
            expect(result.rows[0].test).toBe(1)
        })
    })

    describe('User Repository Integration', () => {
        test('should create and retrieve user', async () => {
            if (!testClient) return

            const userData: CreateUserDTO = {
                name: 'Test User',
                email: 'test@example.com',
                password: 'password123',
                role: 'member',
            }

            // Create user
            const createdUser = await userRepository.createUser(userData)
            expect(createdUser.id).toBeDefined()
            expect(createdUser.email).toBe(userData.email)
            expect(createdUser.name).toBe(userData.name)
            expect(createdUser.role).toBe(userData.role)

            // Retrieve user by email
            const foundUser = await userRepository.findUserByEmail(userData.email)
            expect(foundUser).toBeTruthy()
            expect(foundUser!.id).toBe(createdUser.id)
            expect(foundUser!.email).toBe(userData.email)

            // Retrieve user by ID
            const userById = await userRepository.findUserById(createdUser.id)
            expect(userById).toBeTruthy()
            expect(userById!.id).toBe(createdUser.id)
        })

        test('should handle duplicate email constraint', async () => {
            if (!testClient) return

            const userData: CreateUserDTO = {
                name: 'Test User',
                email: 'duplicate@example.com',
                password: 'password123',
                role: 'member',
            }

            // Create first user
            await userRepository.createUser(userData)

            // Try to create user with same email
            await expect(userRepository.createUser(userData)).rejects.toThrow()
        })

        test('should update user profile', async () => {
            if (!testClient) return

            const userData: CreateUserDTO = {
                name: 'Test User',
                email: 'update@example.com',
                password: 'password123',
                role: 'member',
            }

            const createdUser = await userRepository.createUser(userData)

            // Update user
            const updatedUser = await userRepository.updateUser(createdUser.id, {
                name: 'Updated Name',
                preferredLanguage: 'en',
            })

            expect(updatedUser.name).toBe('Updated Name')
            expect(updatedUser.preferredLanguage).toBe('en')
            expect(updatedUser.email).toBe(userData.email) // Should remain unchanged
        })
    })

    describe('Project Repository Integration', () => {
        let testUser: any

        beforeEach(async () => {
            if (!testClient) return

            // Create a test user for project tests
            testUser = await userRepository.createUser({
                name: 'Project Test User',
                email: 'project@example.com',
                password: 'password123',
                role: 'manager',
            })
        })

        test('should create project with creator as member', async () => {
            if (!testClient) return

            const projectData: CreateProjectDTO = {
                name: 'Test Project',
                description: 'Test project description',
            }

            const createdProject = await projectRepository.createProject(projectData, testUser.id)

            expect(createdProject.id).toBeDefined()
            expect(createdProject.name).toBe(projectData.name)
            expect(createdProject.description).toBe(projectData.description)
            expect(createdProject.createdBy).toBe(testUser.id)

            // Verify creator is added as member
            const projectMembers = await projectRepository.getProjectMembers(createdProject.id)
            expect(projectMembers).toHaveLength(1)
            expect(projectMembers[0].id).toBe(testUser.id)
        })

        test('should add and remove project members', async () => {
            if (!testClient) return

            // Create another user
            const memberUser = await userRepository.createUser({
                name: 'Member User',
                email: 'member@example.com',
                password: 'password123',
                role: 'member',
            })

            const project = await projectRepository.createProject({
                name: 'Member Test Project',
                description: 'Testing member management',
            }, testUser.id)

            // Add member
            await projectRepository.addProjectMember(project.id, memberUser.id)

            let members = await projectRepository.getProjectMembers(project.id)
            expect(members).toHaveLength(2) // Creator + added member

            // Remove member
            await projectRepository.removeProjectMember(project.id, memberUser.id)

            members = await projectRepository.getProjectMembers(project.id)
            expect(members).toHaveLength(1) // Only creator remains
        })

        test('should get user projects', async () => {
            if (!testClient) return

            // Create multiple projects
            const project1 = await projectRepository.createProject({
                name: 'User Project 1',
                description: 'First project',
            }, testUser.id)

            const project2 = await projectRepository.createProject({
                name: 'User Project 2',
                description: 'Second project',
            }, testUser.id)

            const userProjects = await projectRepository.getUserProjects(testUser.id)

            expect(userProjects).toHaveLength(2)
            expect(userProjects.map(p => p.id)).toContain(project1.id)
            expect(userProjects.map(p => p.id)).toContain(project2.id)
        })
    })

    describe('Task Repository Integration', () => {
        let testUser: any
        let testProject: any

        beforeEach(async () => {
            if (!testClient) return

            // Create test user and project
            testUser = await userRepository.createUser({
                name: 'Task Test User',
                email: 'task@example.com',
                password: 'password123',
                role: 'member',
            })

            testProject = await projectRepository.createProject({
                name: 'Task Test Project',
                description: 'Project for task testing',
            }, testUser.id)
        })

        test('should create and retrieve task', async () => {
            if (!testClient) return

            const taskData: CreateTaskDTO = {
                title: 'Test Task',
                description: 'Test task description',
                status: 'todo',
                priority: 'medium',
                dueDate: new Date('2024-12-31'),
                assigneeId: testUser.id,
                projectId: testProject.id,
            }

            const createdTask = await taskRepository.createTask(taskData, testUser.id)

            expect(createdTask.id).toBeDefined()
            expect(createdTask.title).toBe(taskData.title)
            expect(createdTask.description).toBe(taskData.description)
            expect(createdTask.status).toBe(taskData.status)
            expect(createdTask.priority).toBe(taskData.priority)
            expect(createdTask.assigneeId).toBe(testUser.id)
            expect(createdTask.projectId).toBe(testProject.id)
            expect(createdTask.createdBy).toBe(testUser.id)

            // Retrieve task by ID
            const foundTask = await taskRepository.findTaskById(createdTask.id)
            expect(foundTask).toBeTruthy()
            expect(foundTask!.id).toBe(createdTask.id)
        })

        test('should update task', async () => {
            if (!testClient) return

            const task = await taskRepository.createTask({
                title: 'Original Task',
                description: 'Original description',
                status: 'todo',
                priority: 'low',
            }, testUser.id)

            const updatedTask = await taskRepository.updateTask(task.id, {
                title: 'Updated Task',
                description: 'Updated description',
                priority: 'high',
            })

            expect(updatedTask.title).toBe('Updated Task')
            expect(updatedTask.description).toBe('Updated description')
            expect(updatedTask.priority).toBe('high')
            expect(updatedTask.status).toBe('todo') // Should remain unchanged
        })

        test('should update task status with completion tracking', async () => {
            if (!testClient) return

            const task = await taskRepository.createTask({
                title: 'Status Test Task',
                description: 'Testing status updates',
                status: 'todo',
                priority: 'medium',
            }, testUser.id)

            // Update to in-progress
            let updatedTask = await taskRepository.updateTaskStatus(task.id, 'in-progress')
            expect(updatedTask.status).toBe('in-progress')
            expect(updatedTask.completedAt).toBeNull()

            // Update to completed
            updatedTask = await taskRepository.updateTaskStatus(task.id, 'completed')
            expect(updatedTask.status).toBe('completed')
            expect(updatedTask.completedAt).toBeTruthy()
        })

        test('should filter tasks by various criteria', async () => {
            if (!testClient) return

            // Create multiple tasks with different properties
            await taskRepository.createTask({
                title: 'High Priority Task',
                description: 'High priority task',
                status: 'todo',
                priority: 'high',
                assigneeId: testUser.id,
            }, testUser.id)

            await taskRepository.createTask({
                title: 'Completed Task',
                description: 'Completed task',
                status: 'completed',
                priority: 'medium',
                assigneeId: testUser.id,
            }, testUser.id)

            await taskRepository.createTask({
                title: 'Project Task',
                description: 'Task in project',
                status: 'in-progress',
                priority: 'low',
                projectId: testProject.id,
            }, testUser.id)

            // Filter by status
            const todoTasks = await taskRepository.findTasksByFilters(
                { status: 'todo' },
                1, 10, 'createdAt', 'desc'
            )
            expect(todoTasks.tasks).toHaveLength(1)
            expect(todoTasks.tasks[0].status).toBe('todo')

            // Filter by priority
            const highPriorityTasks = await taskRepository.findTasksByFilters(
                { priority: 'high' },
                1, 10, 'createdAt', 'desc'
            )
            expect(highPriorityTasks.tasks).toHaveLength(1)
            expect(highPriorityTasks.tasks[0].priority).toBe('high')

            // Filter by assignee
            const assignedTasks = await taskRepository.findTasksByFilters(
                { assigneeId: testUser.id },
                1, 10, 'createdAt', 'desc'
            )
            expect(assignedTasks.tasks).toHaveLength(2) // Two tasks assigned to testUser

            // Filter by project
            const projectTasks = await taskRepository.findTasksByFilters(
                { projectId: testProject.id },
                1, 10, 'createdAt', 'desc'
            )
            expect(projectTasks.tasks).toHaveLength(1)
            expect(projectTasks.tasks[0].projectId).toBe(testProject.id)
        })

        test('should handle task pagination', async () => {
            if (!testClient) return

            // Create multiple tasks
            const taskPromises = Array.from({ length: 15 }, (_, i) =>
                taskRepository.createTask({
                    title: `Task ${i + 1}`,
                    description: `Description ${i + 1}`,
                    status: 'todo',
                    priority: 'medium',
                }, testUser.id)
            )
            await Promise.all(taskPromises)

            // Test first page
            const firstPage = await taskRepository.findTasksByFilters(
                {},
                1, 10, 'createdAt', 'desc'
            )
            expect(firstPage.tasks).toHaveLength(10)
            expect(firstPage.totalCount).toBe(15)

            // Test second page
            const secondPage = await taskRepository.findTasksByFilters(
                {},
                2, 10, 'createdAt', 'desc'
            )
            expect(secondPage.tasks).toHaveLength(5)
            expect(secondPage.totalCount).toBe(15)
        })

        test('should delete task', async () => {
            if (!testClient) return

            const task = await taskRepository.createTask({
                title: 'Task to Delete',
                description: 'This task will be deleted',
                status: 'todo',
                priority: 'medium',
            }, testUser.id)

            // Verify task exists
            let foundTask = await taskRepository.findTaskById(task.id)
            expect(foundTask).toBeTruthy()

            // Delete task
            await taskRepository.deleteTask(task.id)

            // Verify task is deleted
            foundTask = await taskRepository.findTaskById(task.id)
            expect(foundTask).toBeNull()
        })
    })

    describe('Complex Queries and Relationships', () => {
        let users: any[]
        let projects: any[]
        let tasks: any[]

        beforeEach(async () => {
            if (!testClient) return

            // Create test data with relationships
            users = await Promise.all([
                userRepository.createUser({
                    name: 'Manager User',
                    email: 'manager@example.com',
                    password: 'password123',
                    role: 'manager',
                }),
                userRepository.createUser({
                    name: 'Developer User',
                    email: 'developer@example.com',
                    password: 'password123',
                    role: 'member',
                }),
                userRepository.createUser({
                    name: 'Designer User',
                    email: 'designer@example.com',
                    password: 'password123',
                    role: 'member',
                }),
            ])

            projects = await Promise.all([
                projectRepository.createProject({
                    name: 'Web Application',
                    description: 'Main web application project',
                }, users[0].id),
                projectRepository.createProject({
                    name: 'Mobile App',
                    description: 'Mobile application project',
                }, users[0].id),
            ])

            // Add members to projects
            await projectRepository.addProjectMember(projects[0].id, users[1].id)
            await projectRepository.addProjectMember(projects[0].id, users[2].id)
            await projectRepository.addProjectMember(projects[1].id, users[1].id)

            // Create tasks with various assignments
            tasks = await Promise.all([
                taskRepository.createTask({
                    title: 'Setup Database',
                    description: 'Setup PostgreSQL database',
                    status: 'completed',
                    priority: 'high',
                    assigneeId: users[1].id,
                    projectId: projects[0].id,
                }, users[0].id),
                taskRepository.createTask({
                    title: 'Design UI Mockups',
                    description: 'Create UI mockups for main pages',
                    status: 'in-progress',
                    priority: 'medium',
                    assigneeId: users[2].id,
                    projectId: projects[0].id,
                }, users[0].id),
                taskRepository.createTask({
                    title: 'Implement Authentication',
                    description: 'Implement user authentication system',
                    status: 'todo',
                    priority: 'high',
                    assigneeId: users[1].id,
                    projectId: projects[0].id,
                }, users[0].id),
                taskRepository.createTask({
                    title: 'Mobile App Setup',
                    description: 'Setup React Native project',
                    status: 'todo',
                    priority: 'medium',
                    assigneeId: users[1].id,
                    projectId: projects[1].id,
                }, users[0].id),
            ])
        })

        test('should get project statistics', async () => {
            if (!testClient) return

            const stats = await projectRepository.getProjectStatistics(projects[0].id)

            expect(stats.totalTasks).toBe(3)
            expect(stats.completedTasks).toBe(1)
            expect(stats.inProgressTasks).toBe(1)
            expect(stats.todoTasks).toBe(1)
            expect(stats.completionRate).toBeCloseTo(33.33, 1)
        })

        test('should get user task summary', async () => {
            if (!testClient) return

            const summary = await taskRepository.getUserTaskSummary(users[1].id)

            expect(summary.totalTasks).toBe(3) // Developer has 3 tasks
            expect(summary.completedTasks).toBe(1)
            expect(summary.inProgressTasks).toBe(0)
            expect(summary.todoTasks).toBe(2)
        })

        test('should find overdue tasks', async () => {
            if (!testClient) return

            // Create an overdue task
            await taskRepository.createTask({
                title: 'Overdue Task',
                description: 'This task is overdue',
                status: 'todo',
                priority: 'critical',
                dueDate: new Date('2023-01-01'), // Past date
                assigneeId: users[1].id,
                projectId: projects[0].id,
            }, users[0].id)

            const overdueTasks = await taskRepository.findOverdueTasks()

            expect(overdueTasks).toHaveLength(1)
            expect(overdueTasks[0].title).toBe('Overdue Task')
            expect(overdueTasks[0].dueDate).toEqual(new Date('2023-01-01'))
        })

        test('should get tasks by project with user details', async () => {
            if (!testClient) return

            const projectTasks = await taskRepository.getProjectTasksWithDetails(projects[0].id)

            expect(projectTasks).toHaveLength(3)

            // Verify task details include user information
            const taskWithAssignee = projectTasks.find(t => t.assigneeId === users[1].id)
            expect(taskWithAssignee).toBeTruthy()
            expect(taskWithAssignee!.assigneeName).toBe('Developer User')
            expect(taskWithAssignee!.assigneeEmail).toBe('developer@example.com')
        })
    })

    describe('Transaction Handling', () => {
        let testUser: any

        beforeEach(async () => {
            if (!testClient) return

            testUser = await userRepository.createUser({
                name: 'Transaction Test User',
                email: 'transaction@example.com',
                password: 'password123',
                role: 'manager',
            })
        })

        test('should handle successful transaction', async () => {
            if (!testClient) return

            const client = await pool.connect()

            try {
                await client.query('BEGIN')

                // Create project
                const project = await projectRepository.createProject({
                    name: 'Transaction Test Project',
                    description: 'Testing transactions',
                }, testUser.id)

                // Create task in the same transaction
                const task = await taskRepository.createTask({
                    title: 'Transaction Test Task',
                    description: 'Task created in transaction',
                    status: 'todo',
                    priority: 'medium',
                    projectId: project.id,
                }, testUser.id)

                await client.query('COMMIT')

                // Verify both records exist
                const foundProject = await projectRepository.findProjectById(project.id)
                const foundTask = await taskRepository.findTaskById(task.id)

                expect(foundProject).toBeTruthy()
                expect(foundTask).toBeTruthy()
                expect(foundTask!.projectId).toBe(project.id)

            } catch (error) {
                await client.query('ROLLBACK')
                throw error
            } finally {
                client.release()
            }
        })

        test('should handle failed transaction rollback', async () => {
            if (!testClient) return

            const client = await pool.connect()

            try {
                await client.query('BEGIN')

                // Create project
                const project = await projectRepository.createProject({
                    name: 'Rollback Test Project',
                    description: 'Testing rollback',
                }, testUser.id)

                // Try to create task with invalid foreign key (should fail)
                await expect(
                    taskRepository.createTask({
                        title: 'Invalid Task',
                        description: 'Task with invalid project ID',
                        status: 'todo',
                        priority: 'medium',
                        projectId: 'invalid-project-id',
                    }, testUser.id)
                ).rejects.toThrow()

                await client.query('ROLLBACK')

                // Verify project was not created due to rollback
                const foundProject = await projectRepository.findProjectById(project.id)
                expect(foundProject).toBeNull()

            } catch (error) {
                await client.query('ROLLBACK')
                // This is expected for this test
            } finally {
                client.release()
            }
        })
    })
})