/**
 * Tests for advanced search functionality
 */

import React from 'react'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { AdvancedSearch, SearchFilters } from '@/client/components/AdvancedSearch'
import { highlightSearchTerm, createSearchExcerpt } from '@/client/utils/searchHighlight'

// Mock the translation hook
jest.mock('@/client/hooks/useTranslation', () => ({
    useTranslation: () => ({
        t: (key: string, params?: any) => {
            const translations: Record<string, string> = {
                'common.search': 'Search',
                'common.searching': 'Searching...',
                'search.placeholder': 'Search tasks and projects...',
                'search.advanced': 'Advanced',
                'search.relevance': 'Relevance',
                'search.sortOrder': 'Sort Order',
                'search.clearFilters': 'Clear Filters',
                'tasks.fields.status': 'Status',
                'tasks.fields.priority': 'Priority',
                'tasks.fields.assignee': 'Assignee',
                'tasks.fields.project': 'Project',
                'tasks.fields.createdAt': 'Created',
                'tasks.fields.updatedAt': 'Updated',
                'tasks.fields.dueDate': 'Due Date',
                'tasks.fields.title': 'Title',
                'tasks.filters.all': 'All',
                'tasks.filters.overdue': 'Overdue',
                'tasks.filters.unassigned': 'Unassigned',
                'tasks.status.todo': 'To Do',
                'tasks.status.inProgress': 'In Progress',
                'tasks.status.completed': 'Completed',
                'tasks.priority.low': 'Low',
                'tasks.priority.medium': 'Medium',
                'tasks.priority.high': 'High',
                'tasks.priority.critical': 'Critical'
            }
            return params ? translations[key]?.replace(/\{\{(\w+)\}\}/g, (_, key) => params[key]) : translations[key] || key
        }
    })
}))

describe('AdvancedSearch', () => {
    const mockOnSearch = jest.fn()
    const mockOnClear = jest.fn()

    beforeEach(() => {
        jest.clearAllMocks()
    })

    test('renders basic search interface', () => {
        render(
            <AdvancedSearch
                onSearch={mockOnSearch}
                onClear={mockOnClear}
            />
        )

        expect(screen.getByPlaceholderText('Search tasks and projects...')).toBeInTheDocument()
        expect(screen.getByText('Advanced')).toBeInTheDocument()
        expect(screen.getByRole('button', { name: 'Search' })).toBeInTheDocument()
    })

    test('handles basic search input', () => {
        render(
            <AdvancedSearch
                onSearch={mockOnSearch}
                onClear={mockOnClear}
            />
        )

        const searchInput = screen.getByPlaceholderText('Search tasks and projects...')
        const searchButton = screen.getByRole('button', { name: 'Search' })

        fireEvent.change(searchInput, { target: { value: 'test search' } })
        fireEvent.click(searchButton)

        expect(mockOnSearch).toHaveBeenCalledWith({
            search: 'test search'
        })
    })

    test('expands advanced filters when clicked', () => {
        render(
            <AdvancedSearch
                onSearch={mockOnSearch}
                onClear={mockOnClear}
            />
        )

        const advancedButton = screen.getByText('Advanced')
        fireEvent.click(advancedButton)

        expect(screen.getByLabelText('Status')).toBeInTheDocument()
        expect(screen.getByLabelText('Priority')).toBeInTheDocument()
        expect(screen.getByText('Overdue')).toBeInTheDocument()
        expect(screen.getByText('Unassigned')).toBeInTheDocument()
    })

    test('handles advanced filter selection', () => {
        render(
            <AdvancedSearch
                onSearch={mockOnSearch}
                onClear={mockOnClear}
            />
        )

        // Expand advanced filters
        const advancedButton = screen.getByText('Advanced')
        fireEvent.click(advancedButton)

        // Set filters
        const statusSelect = screen.getByLabelText('Status')
        const prioritySelect = screen.getByLabelText('Priority')
        const overdueCheckbox = screen.getByText('Overdue').previousElementSibling as HTMLInputElement

        fireEvent.change(statusSelect, { target: { value: 'in-progress' } })
        fireEvent.change(prioritySelect, { target: { value: 'high' } })
        fireEvent.click(overdueCheckbox)

        // Submit search
        const searchButton = screen.getByRole('button', { name: 'Search' })
        fireEvent.click(searchButton)

        expect(mockOnSearch).toHaveBeenCalledWith({
            status: 'in-progress',
            priority: 'high',
            isOverdue: true
        })
    })

    test('shows relevance sort option when search term is present', () => {
        render(
            <AdvancedSearch
                onSearch={mockOnSearch}
                onClear={mockOnClear}
            />
        )

        const searchInput = screen.getByPlaceholderText('Search tasks and projects...')
        fireEvent.change(searchInput, { target: { value: 'test' } })

        const sortSelect = screen.getByDisplayValue('Created')
        expect(sortSelect).toBeInTheDocument()

        // Check if relevance option appears (it should be added dynamically)
        fireEvent.click(sortSelect)
        // Note: This test might need adjustment based on how the select options are rendered
    })

    test('clears all filters when clear button is clicked', () => {
        const initialFilters: SearchFilters = {
            search: 'test',
            status: 'completed',
            priority: 'high'
        }

        render(
            <AdvancedSearch
                onSearch={mockOnSearch}
                onClear={mockOnClear}
                initialFilters={initialFilters}
            />
        )

        // Expand advanced filters to see clear button
        const advancedButton = screen.getByText('Advanced')
        fireEvent.click(advancedButton)

        const clearButton = screen.getByText('Clear Filters')
        fireEvent.click(clearButton)

        expect(mockOnClear).toHaveBeenCalled()
    })
})

describe('Search Highlighting Utilities', () => {
    test('highlights search terms in text', () => {
        const text = 'This is a test string with test words'
        const searchTerm = 'test'
        const result = highlightSearchTerm(text, searchTerm)

        expect(result).toContain('<mark class="bg-yellow-200 px-1 rounded">test</mark>')
        expect(result).toMatch(/This is a <mark[^>]*>test<\/mark> string with <mark[^>]*>test<\/mark> words/)
    })

    test('handles empty search term', () => {
        const text = 'This is a test string'
        const result = highlightSearchTerm(text, '')

        expect(result).toBe(text)
    })

    test('handles empty text', () => {
        const result = highlightSearchTerm('', 'test')

        expect(result).toBe('')
    })

    test('creates search excerpt with highlighted terms', () => {
        const text = 'This is a very long text that contains the search term somewhere in the middle and should be truncated properly'
        const searchTerm = 'search term'
        const result = createSearchExcerpt(text, searchTerm, 50)

        expect(result).toContain('<mark class="bg-yellow-200 px-1 rounded">search term</mark>')
        expect(result.length).toBeLessThanOrEqual(100) // Accounting for HTML tags
        expect(result).toMatch(/\.\.\.*<mark[^>]*>search term<\/mark>.*\.\.\./)
    })

    test('handles search term not found in excerpt', () => {
        const text = 'This is a text without the target word'
        const searchTerm = 'missing'
        const result = createSearchExcerpt(text, searchTerm, 20)

        expect(result).toBe('This is a text with...')
        expect(result).not.toContain('<mark')
    })

    test('escapes special regex characters', () => {
        const text = 'This contains special chars: [test] (test) {test}'
        const searchTerm = '[test]'
        const result = highlightSearchTerm(text, searchTerm)

        expect(result).toContain('<mark class="bg-yellow-200 px-1 rounded">[test]</mark>')
    })
})