/**
 * Unit tests for permission service
 */

import { PermissionService } from '../server/services/permissions'
import { UserRole } from '../shared/types/index'

describe('PermissionService', () => {
    describe('hasPermission', () => {
        it('should correctly check permissions for different roles', () => {
            expect(PermissionService.hasPermission('admin', 'users:create')).toBe(true)
            expect(PermissionService.hasPermission('manager', 'projects:create')).toBe(true)
            expect(PermissionService.hasPermission('member', 'tasks:create')).toBe(true)

            expect(PermissionService.hasPermission('member', 'users:create')).toBe(false)
            expect(PermissionService.hasPermission('member', 'projects:delete')).toBe(false)
        })
    })

    describe('canAccess', () => {
        it('should check resource access correctly', () => {
            expect(PermissionService.canAccess('admin', 'users', 'create')).toBe(true)
            expect(PermissionService.canAccess('manager', 'projects', 'update')).toBe(true)
            expect(PermissionService.canAccess('member', 'tasks', 'read')).toBe(true)

            expect(PermissionService.canAccess('member', 'users', 'delete')).toBe(false)
        })
    })

    describe('getUserPermissions', () => {
        it('should return all permissions for admin', () => {
            const permissions = PermissionService.getUserPermissions('admin')
            expect(permissions.length).toBeGreaterThan(10)
            expect(permissions).toContain('users:create')
            expect(permissions).toContain('projects:delete')
        })

        it('should return limited permissions for member', () => {
            const permissions = PermissionService.getUserPermissions('member')
            expect(permissions).toContain('tasks:create')
            expect(permissions).toContain('projects:read')
            expect(permissions).not.toContain('users:create')
            expect(permissions).not.toContain('projects:delete')
        })
    })

    describe('hasRoleLevel', () => {
        it('should validate role hierarchy correctly', () => {
            expect(PermissionService.hasRoleLevel('admin', 'member')).toBe(true)
            expect(PermissionService.hasRoleLevel('admin', 'manager')).toBe(true)
            expect(PermissionService.hasRoleLevel('manager', 'member')).toBe(true)

            expect(PermissionService.hasRoleLevel('member', 'manager')).toBe(false)
            expect(PermissionService.hasRoleLevel('member', 'admin')).toBe(false)
        })
    })

    describe('getUserPermissionContext', () => {
        it('should return comprehensive permission context for admin', () => {
            const context = PermissionService.getUserPermissionContext('admin')

            expect(context.role).toBe('admin')
            expect(context.canCreateTasks).toBe(true)
            expect(context.canManageProjects).toBe(true)
            expect(context.canManageUsers).toBe(true)
            expect(context.canViewReports).toBe(true)
            expect(context.isAdmin).toBe(true)
            expect(context.isManager).toBe(true)
            expect(context.isMember).toBe(true)
        })

        it('should return limited permission context for member', () => {
            const context = PermissionService.getUserPermissionContext('member')

            expect(context.role).toBe('member')
            expect(context.canCreateTasks).toBe(true)
            expect(context.canManageProjects).toBe(false)
            expect(context.canManageUsers).toBe(false)
            expect(context.canViewReports).toBe(false)
            expect(context.isAdmin).toBe(false)
            expect(context.isManager).toBe(false)
            expect(context.isMember).toBe(true)
        })

        it('should include additional context when provided', () => {
            const context = PermissionService.getUserPermissionContext('member', {
                isProjectMember: true,
                projectId: 'project123'
            })

            expect(context.context.isProjectMember).toBe(true)
            expect(context.context.projectId).toBe('project123')
        })
    })

    describe('validatePermissions', () => {
        it('should validate multiple permissions for admin', () => {
            const result = PermissionService.validatePermissions('admin', [
                'users:create',
                'projects:delete',
                'tasks:assign'
            ])

            expect(result.hasAllPermissions).toBe(true)
            expect(result.granted).toHaveLength(3)
            expect(result.denied).toHaveLength(0)
            expect(result.results['users:create']).toBe(true)
        })

        it('should validate multiple permissions for member', () => {
            const result = PermissionService.validatePermissions('member', [
                'tasks:create',
                'users:create',
                'projects:read'
            ])

            expect(result.hasAllPermissions).toBe(false)
            expect(result.hasAnyPermission).toBe(true)
            expect(result.granted).toContain('tasks:create')
            expect(result.granted).toContain('projects:read')
            expect(result.denied).toContain('users:create')
        })

        it('should handle empty permission list', () => {
            const result = PermissionService.validatePermissions('member', [])

            expect(result.hasAllPermissions).toBe(true)
            expect(result.hasAnyPermission).toBe(false)
            expect(result.granted).toHaveLength(0)
            expect(result.denied).toHaveLength(0)
        })
    })

    describe('getPermissionRequirements', () => {
        it('should return permission requirements for valid resource/action', () => {
            const requirements = PermissionService.getPermissionRequirements('users', 'create')

            expect(requirements).not.toBeNull()
            expect(requirements?.key).toBe('users:create')
            expect(requirements?.resource).toBe('users')
            expect(requirements?.action).toBe('create')
            expect(requirements?.requiredRoles).toContain('admin')
            expect(requirements?.minimumRole).toBe('admin')
        })

        it('should return null for invalid resource/action', () => {
            const requirements = PermissionService.getPermissionRequirements('invalid', 'action')
            expect(requirements).toBeNull()
        })

        it('should return correct minimum role for multi-role permissions', () => {
            const requirements = PermissionService.getPermissionRequirements('tasks', 'create')

            expect(requirements).not.toBeNull()
            expect(requirements?.minimumRole).toBe('member')
            expect(requirements?.requiredRoles).toContain('member')
            expect(requirements?.requiredRoles).toContain('manager')
            expect(requirements?.requiredRoles).toContain('admin')
        })
    })

    describe('validateBulkOperations', () => {
        it('should validate multiple operations for admin', () => {
            const operations = [
                { resource: 'users', action: 'create' },
                { resource: 'projects', action: 'delete' },
                { resource: 'tasks', action: 'assign' }
            ]

            const result = PermissionService.validateBulkOperations('admin', operations)

            expect(result.allAllowed).toBe(true)
            expect(result.allowedCount).toBe(3)
            expect(result.deniedCount).toBe(0)
            expect(result.operations).toHaveLength(3)
            expect(result.operations[0].allowed).toBe(true)
        })

        it('should validate multiple operations for member', () => {
            const operations = [
                { resource: 'tasks', action: 'create' },
                { resource: 'users', action: 'create' },
                { resource: 'projects', action: 'read' }
            ]

            const result = PermissionService.validateBulkOperations('member', operations)

            expect(result.allAllowed).toBe(false)
            expect(result.allowedCount).toBe(2)
            expect(result.deniedCount).toBe(1)

            const taskCreate = result.operations.find(op => op.resource === 'tasks' && op.action === 'create')
            const userCreate = result.operations.find(op => op.resource === 'users' && op.action === 'create')

            expect(taskCreate?.allowed).toBe(true)
            expect(userCreate?.allowed).toBe(false)
        })

        it('should handle empty operations list', () => {
            const result = PermissionService.validateBulkOperations('member', [])

            expect(result.allAllowed).toBe(true)
            expect(result.allowedCount).toBe(0)
            expect(result.deniedCount).toBe(0)
            expect(result.operations).toHaveLength(0)
        })
    })

    describe('getResourcePermissions', () => {
        it('should return all permissions for users resource', () => {
            const permissions = PermissionService.getResourcePermissions('users')

            expect(permissions.length).toBeGreaterThan(0)
            expect(permissions.every(p => p.resource === 'users')).toBe(true)

            const actions = permissions.map(p => p.action)
            expect(actions).toContain('create')
            expect(actions).toContain('read')
            expect(actions).toContain('update')
            expect(actions).toContain('delete')
        })

        it('should return all permissions for tasks resource', () => {
            const permissions = PermissionService.getResourcePermissions('tasks')

            expect(permissions.length).toBeGreaterThan(0)
            expect(permissions.every(p => p.resource === 'tasks')).toBe(true)

            const actions = permissions.map(p => p.action)
            expect(actions).toContain('create')
            expect(actions).toContain('read')
            expect(actions).toContain('update')
            expect(actions).toContain('assign')
        })
    })
})