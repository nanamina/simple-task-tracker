import * as fs from 'fs';
import * as path from 'path';

describe('i18n Configuration', () => {
    let jaTranslations: any;
    let enTranslations: any;

    beforeAll(() => {
        // Read translation files directly
        const jaPath = path.join(__dirname, '../client/i18n/locales/ja.json');
        const enPath = path.join(__dirname, '../client/i18n/locales/en.json');

        jaTranslations = JSON.parse(fs.readFileSync(jaPath, 'utf8'));
        enTranslations = JSON.parse(fs.readFileSync(enPath, 'utf8'));
    });

    test('translation files should exist and be valid JSON', () => {
        expect(jaTranslations).toBeDefined();
        expect(enTranslations).toBeDefined();
        expect(typeof jaTranslations).toBe('object');
        expect(typeof enTranslations).toBe('object');
    });

    test('Japanese translations should have required keys', () => {
        expect(jaTranslations.common.save).toBe('保存');
        expect(jaTranslations.common.cancel).toBe('キャンセル');
        expect(jaTranslations.navigation.dashboard).toBe('ダッシュボード');
        expect(jaTranslations.tasks.status.todo).toBe('未着手');
        expect(jaTranslations.tasks.status.inProgress).toBe('進行中');
        expect(jaTranslations.tasks.status.completed).toBe('完了');
    });

    test('English translations should have required keys', () => {
        expect(enTranslations.common.save).toBe('Save');
        expect(enTranslations.common.cancel).toBe('Cancel');
        expect(enTranslations.navigation.dashboard).toBe('Dashboard');
        expect(enTranslations.tasks.status.todo).toBe('To Do');
        expect(enTranslations.tasks.status.inProgress).toBe('In Progress');
        expect(enTranslations.tasks.status.completed).toBe('Completed');
    });

    test('Both languages should have the same structure', () => {
        const jaKeys = Object.keys(jaTranslations);
        const enKeys = Object.keys(enTranslations);

        expect(jaKeys.sort()).toEqual(enKeys.sort());

        // Check nested structure for common sections
        expect(Object.keys(jaTranslations.common).sort()).toEqual(Object.keys(enTranslations.common).sort());
        expect(Object.keys(jaTranslations.navigation).sort()).toEqual(Object.keys(enTranslations.navigation).sort());
        expect(Object.keys(jaTranslations.tasks).sort()).toEqual(Object.keys(enTranslations.tasks).sort());
    });

    test('Task priority translations should be complete', () => {
        const priorities = ['low', 'medium', 'high', 'critical'];

        priorities.forEach(priority => {
            expect(jaTranslations.tasks.priority[priority]).toBeDefined();
            expect(enTranslations.tasks.priority[priority]).toBeDefined();
        });
    });

    test('Validation messages should be complete', () => {
        const validationKeys = ['required', 'email', 'minLength', 'maxLength', 'invalidDate', 'pastDate'];

        validationKeys.forEach(key => {
            expect(jaTranslations.validation[key]).toBeDefined();
            expect(enTranslations.validation[key]).toBeDefined();
        });
    });
});