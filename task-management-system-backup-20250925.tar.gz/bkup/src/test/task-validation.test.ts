/**
 * Unit tests for task validation functions
 */

import {
    validateTaskTitle,
    validateTaskDescription,
    validateTaskPriority,
    validateTaskStatus,
    validateTaskStatusTransition,
    validateDueDate,
    validateCreateTask,
    validateUpdateTask,
    CreateTaskDTO,
    UpdateTaskDTO
} from '../shared/types/validation'

describe('Task Validation Functions', () => {
    describe('validateTaskTitle', () => {
        it('should validate proper titles', () => {
            expect(validateTaskTitle('Valid Task Title')).toBe(true)
            expect(validateTaskTitle('A')).toBe(true)
            expect(validateTaskTitle('タスクのタイトル')).toBe(true)
        })

        it('should reject empty titles', () => {
            expect(validateTaskTitle('')).toBe(false)
            expect(validateTaskTitle('   ')).toBe(false)
        })

        it('should reject titles that are too long', () => {
            const longTitle = 'A'.repeat(256)
            expect(validateTaskTitle(longTitle)).toBe(false)
        })

        it('should handle titles with whitespace', () => {
            expect(validateTaskTitle('  Valid Title  ')).toBe(true)
        })
    })

    describe('validateTaskDescription', () => {
        it('should validate proper descriptions', () => {
            expect(validateTaskDescription('Valid description')).toBe(true)
            expect(validateTaskDescription('')).toBe(true) // Empty description is allowed
            expect(validateTaskDescription('詳細な説明')).toBe(true)
        })

        it('should reject descriptions that are too long', () => {
            const longDescription = 'A'.repeat(2001)
            expect(validateTaskDescription(longDescription)).toBe(false)
        })

        it('should handle descriptions with whitespace', () => {
            expect(validateTaskDescription('  Valid description  ')).toBe(true)
        })
    })

    describe('validateTaskPriority', () => {
        it('should validate correct priorities', () => {
            expect(validateTaskPriority('low')).toBe(true)
            expect(validateTaskPriority('medium')).toBe(true)
            expect(validateTaskPriority('high')).toBe(true)
            expect(validateTaskPriority('critical')).toBe(true)
        })

        it('should reject invalid priorities', () => {
            expect(validateTaskPriority('invalid')).toBe(false)
            expect(validateTaskPriority('urgent')).toBe(false)
            expect(validateTaskPriority('')).toBe(false)
            expect(validateTaskPriority('HIGH')).toBe(false)
        })
    })

    describe('validateTaskStatus', () => {
        it('should validate correct statuses', () => {
            expect(validateTaskStatus('todo')).toBe(true)
            expect(validateTaskStatus('in-progress')).toBe(true)
            expect(validateTaskStatus('completed')).toBe(true)
        })

        it('should reject invalid statuses', () => {
            expect(validateTaskStatus('invalid')).toBe(false)
            expect(validateTaskStatus('done')).toBe(false)
            expect(validateTaskStatus('')).toBe(false)
            expect(validateTaskStatus('TODO')).toBe(false)
        })
    })

    describe('validateTaskStatusTransition', () => {
        it('should allow valid transitions from todo', () => {
            expect(validateTaskStatusTransition('todo', 'in-progress').isValid).toBe(true)
            expect(validateTaskStatusTransition('todo', 'completed').isValid).toBe(true)
        })

        it('should allow valid transitions from in-progress', () => {
            expect(validateTaskStatusTransition('in-progress', 'todo').isValid).toBe(true)
            expect(validateTaskStatusTransition('in-progress', 'completed').isValid).toBe(true)
        })

        it('should allow valid transitions from completed', () => {
            expect(validateTaskStatusTransition('completed', 'todo').isValid).toBe(true)
            expect(validateTaskStatusTransition('completed', 'in-progress').isValid).toBe(true)
        })

        it('should allow same status transitions', () => {
            expect(validateTaskStatusTransition('todo', 'todo').isValid).toBe(true)
            expect(validateTaskStatusTransition('in-progress', 'in-progress').isValid).toBe(true)
            expect(validateTaskStatusTransition('completed', 'completed').isValid).toBe(true)
        })

        it('should provide error messages for invalid transitions', () => {
            // All transitions are actually allowed in our system, so this test is more for future extensibility
            const result = validateTaskStatusTransition('todo', 'todo')
            expect(result.isValid).toBe(true)
        })
    })

    describe('validateDueDate', () => {
        it('should validate future dates', () => {
            const futureDate = new Date()
            futureDate.setDate(futureDate.getDate() + 1)
            expect(validateDueDate(futureDate)).toBe(true)
        })

        it('should validate today\'s date', () => {
            const today = new Date()
            expect(validateDueDate(today)).toBe(true)
        })

        it('should reject past dates', () => {
            const pastDate = new Date()
            pastDate.setDate(pastDate.getDate() - 1)
            expect(validateDueDate(pastDate)).toBe(false)
        })
    })

    describe('validateCreateTask', () => {
        const validTaskData: CreateTaskDTO = {
            title: 'Test Task',
            description: 'Test description',
            priority: 'medium'
        }

        it('should validate complete valid task data', () => {
            const result = validateCreateTask(validTaskData)
            expect(result.isValid).toBe(true)
            expect(result.errors).toHaveLength(0)
        })

        it('should validate minimal task data', () => {
            const minimalData: CreateTaskDTO = {
                title: 'Test Task',
                description: 'Test description'
            }
            const result = validateCreateTask(minimalData)
            expect(result.isValid).toBe(true)
            expect(result.errors).toHaveLength(0)
        })

        it('should reject task with invalid title', () => {
            const taskData = { ...validTaskData, title: '' }
            const result = validateCreateTask(taskData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Title must be between 1 and 255 characters')
        })

        it('should reject task with invalid description', () => {
            const taskData = { ...validTaskData, description: 'A'.repeat(2001) }
            const result = validateCreateTask(taskData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Description must be 2000 characters or less')
        })

        it('should reject task with invalid priority', () => {
            const taskData = { ...validTaskData, priority: 'invalid' as any }
            const result = validateCreateTask(taskData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Invalid task priority')
        })

        it('should reject task with past due date', () => {
            const pastDate = new Date()
            pastDate.setDate(pastDate.getDate() - 1)
            const taskData = { ...validTaskData, dueDate: pastDate }
            const result = validateCreateTask(taskData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Due date must be today or in the future')
        })

        it('should return multiple errors for multiple invalid fields', () => {
            const taskData: CreateTaskDTO = {
                title: '',
                description: 'A'.repeat(2001),
                priority: 'invalid' as any
            }
            const result = validateCreateTask(taskData)
            expect(result.isValid).toBe(false)
            expect(result.errors.length).toBeGreaterThan(2)
        })
    })

    describe('validateUpdateTask', () => {
        it('should validate valid update data', () => {
            const updateData: UpdateTaskDTO = {
                title: 'Updated Title',
                priority: 'high'
            }
            const result = validateUpdateTask(updateData)
            expect(result.isValid).toBe(true)
            expect(result.errors).toHaveLength(0)
        })

        it('should validate empty update data', () => {
            const result = validateUpdateTask({})
            expect(result.isValid).toBe(true)
            expect(result.errors).toHaveLength(0)
        })

        it('should reject update with invalid title', () => {
            const updateData: UpdateTaskDTO = { title: '' }
            const result = validateUpdateTask(updateData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Title must be between 1 and 255 characters')
        })

        it('should reject update with invalid description', () => {
            const updateData: UpdateTaskDTO = { description: 'A'.repeat(2001) }
            const result = validateUpdateTask(updateData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Description must be 2000 characters or less')
        })

        it('should reject update with invalid priority', () => {
            const updateData: UpdateTaskDTO = { priority: 'invalid' as any }
            const result = validateUpdateTask(updateData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Invalid task priority')
        })

        it('should reject update with past due date', () => {
            const pastDate = new Date()
            pastDate.setDate(pastDate.getDate() - 1)
            const updateData: UpdateTaskDTO = { dueDate: pastDate }
            const result = validateUpdateTask(updateData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Due date must be today or in the future')
        })
    })
})