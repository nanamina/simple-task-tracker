/**
 * Unit tests for validation functions
 */

import {
    validateEmail,
    validatePassword,
    validateName,
    validateRole,
    validateLanguage,
    validateCreateUser,
    CreateUserDTO
} from '../shared/types/validation'

describe('Validation Functions', () => {
    describe('validateEmail', () => {
        it('should validate correct email formats', () => {
            expect(validateEmail('user@example.com')).toBe(true)
            expect(validateEmail('test.email+tag@domain.co.jp')).toBe(true)
            expect(validateEmail('user123@test-domain.org')).toBe(true)
        })

        it('should reject invalid email formats', () => {
            expect(validateEmail('invalid-email')).toBe(false)
            expect(validateEmail('user@')).toBe(false)
            expect(validateEmail('@domain.com')).toBe(false)
            expect(validateEmail('user@domain')).toBe(false)
            expect(validateEmail('')).toBe(false)
        })
    })

    describe('validatePassword', () => {
        it('should validate strong passwords', () => {
            const result = validatePassword('password123')
            expect(result.isValid).toBe(true)
            expect(result.errors).toHaveLength(0)
        })

        it('should validate complex passwords', () => {
            const result = validatePassword('MySecurePass123!')
            expect(result.isValid).toBe(true)
            expect(result.errors).toHaveLength(0)
        })

        it('should reject passwords that are too short', () => {
            const result = validatePassword('pass1')
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Password must be at least 8 characters long')
        })

        it('should reject passwords without letters', () => {
            const result = validatePassword('12345678')
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Password must contain at least one letter')
        })

        it('should reject passwords without numbers', () => {
            const result = validatePassword('password')
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Password must contain at least one number')
        })

        it('should return multiple errors for weak passwords', () => {
            const result = validatePassword('weak')
            expect(result.isValid).toBe(false)
            expect(result.errors.length).toBeGreaterThan(1) // Should have multiple errors
            expect(result.errors).toContain('Password must be at least 8 characters long')
            expect(result.errors).toContain('Password must contain at least one number')
        })
    })

    describe('validateName', () => {
        it('should validate proper names', () => {
            expect(validateName('John Doe')).toBe(true)
            expect(validateName('田中太郎')).toBe(true)
            expect(validateName('A B')).toBe(true)
        })

        it('should reject names that are too short', () => {
            expect(validateName('A')).toBe(false)
            expect(validateName('')).toBe(false)
            expect(validateName('  ')).toBe(false)
        })

        it('should reject names that are too long', () => {
            const longName = 'A'.repeat(101)
            expect(validateName(longName)).toBe(false)
        })

        it('should handle names with whitespace', () => {
            expect(validateName('  John Doe  ')).toBe(true)
        })
    })

    describe('validateRole', () => {
        it('should validate correct roles', () => {
            expect(validateRole('admin')).toBe(true)
            expect(validateRole('manager')).toBe(true)
            expect(validateRole('member')).toBe(true)
        })

        it('should reject invalid roles', () => {
            expect(validateRole('invalid')).toBe(false)
            expect(validateRole('user')).toBe(false)
            expect(validateRole('')).toBe(false)
            expect(validateRole('ADMIN')).toBe(false)
        })
    })

    describe('validateLanguage', () => {
        it('should validate supported languages', () => {
            expect(validateLanguage('ja')).toBe(true)
            expect(validateLanguage('en')).toBe(true)
        })

        it('should reject unsupported languages', () => {
            expect(validateLanguage('fr')).toBe(false)
            expect(validateLanguage('japanese')).toBe(false)
            expect(validateLanguage('')).toBe(false)
            expect(validateLanguage('JA')).toBe(false)
        })
    })

    describe('validateCreateUser', () => {
        const validUserData: CreateUserDTO = {
            email: 'test@example.com',
            name: 'Test User',
            password: 'password123',
            role: 'member',
            preferredLanguage: 'ja'
        }

        it('should validate complete valid user data', () => {
            const result = validateCreateUser(validUserData)
            expect(result.isValid).toBe(true)
            expect(result.errors).toHaveLength(0)
        })

        it('should validate user data without optional fields', () => {
            const userData: CreateUserDTO = {
                email: 'test@example.com',
                name: 'Test User',
                password: 'password123'
            }
            const result = validateCreateUser(userData)
            expect(result.isValid).toBe(true)
            expect(result.errors).toHaveLength(0)
        })

        it('should reject user data with invalid email', () => {
            const userData = { ...validUserData, email: 'invalid-email' }
            const result = validateCreateUser(userData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Invalid email format')
        })

        it('should reject user data with invalid name', () => {
            const userData = { ...validUserData, name: 'A' }
            const result = validateCreateUser(userData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Name must be between 2 and 100 characters')
        })

        it('should reject user data with weak password', () => {
            const userData = { ...validUserData, password: 'weak' }
            const result = validateCreateUser(userData)
            expect(result.isValid).toBe(false)
            expect(result.errors.length).toBeGreaterThan(0)
        })

        it('should reject user data with invalid role', () => {
            const userData = { ...validUserData, role: 'invalid' as any }
            const result = validateCreateUser(userData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Invalid user role')
        })

        it('should reject user data with invalid language', () => {
            const userData = { ...validUserData, preferredLanguage: 'fr' as any }
            const result = validateCreateUser(userData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Invalid language preference')
        })

        it('should return multiple errors for multiple invalid fields', () => {
            const userData: CreateUserDTO = {
                email: 'invalid',
                name: 'A',
                password: 'weak',
                role: 'invalid' as any
            }
            const result = validateCreateUser(userData)
            expect(result.isValid).toBe(false)
            expect(result.errors.length).toBeGreaterThan(3)
        })
    })
})