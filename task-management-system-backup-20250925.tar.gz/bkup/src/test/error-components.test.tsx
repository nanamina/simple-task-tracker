import React from 'react'
import { render, screen, fireEvent } from '@testing-library/react'
import { Provider } from 'react-redux'
import { BrowserRouter } from 'react-router-dom'
import { configureStore } from '@reduxjs/toolkit'

import ErrorBoundary from '@/client/components/ErrorBoundary'
import ErrorMessage from '@/client/components/ErrorMessage'
import authSlice from '@/client/store/slices/authSlice'
import uiSlice from '@/client/store/slices/uiSlice'

// Mock i18next
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => {
            const translations: Record<string, string> = {
                'error.boundary.title': 'Something went wrong',
                'error.boundary.description': 'An unexpected error occurred. Please try refreshing the page.',
                'error.boundary.refresh': 'Refresh Page',
                'error.boundary.reportIssue': 'Report Issue',
                'error.network.title': 'Network Error',
                'error.network.description': 'Unable to connect to the server. Please check your internet connection.',
                'error.validation.title': 'Validation Error',
                'error.validation.description': 'Please check your input and try again.',
                'error.authentication.title': 'Authentication Error',
                'error.authentication.description': 'Your session has expired. Please log in again.',
                'error.authorization.title': 'Access Denied',
                'error.authorization.description': 'You do not have permission to access this resource.',
                'error.notFound.title': 'Not Found',
                'error.notFound.description': 'The requested resource could not be found.',
                'error.server.title': 'Server Error',
                'error.server.description': 'An internal server error occurred. Please try again later.',
                'common.retry': 'Retry',
                'common.dismiss': 'Dismiss',
                'common.close': 'Close',
            }
            return translations[key] || key
        },
    }),
}))

// Test component that throws an error
const ThrowError: React.FC<{ shouldThrow: boolean }> = ({ shouldThrow }) => {
    if (shouldThrow) {
        throw new Error('Test error')
    }
    return <div>No error</div>
}

// Helper function to create test store
const createTestStore = (initialState = {}) => {
    const defaultState = {
        auth: {
            user: null,
            token: null,
            isAuthenticated: false,
            loading: false,
            error: null,
        },
        ui: {
            language: 'ja',
            theme: 'light',
            notifications: [],
        },
    }

    return configureStore({
        reducer: {
            auth: authSlice,
            ui: uiSlice,
        },
        preloadedState: { ...defaultState, ...initialState },
    })
}

// Helper function to render component with providers
const renderWithProviders = (component: React.ReactElement, store = createTestStore()) => {
    return render(
        <Provider store={store}>
            <BrowserRouter>
                {component}
            </BrowserRouter>
        </Provider>
    )
}

describe('Error Components', () => {
    // Suppress console.error for error boundary tests
    const originalError = console.error
    beforeAll(() => {
        console.error = jest.fn()
    })

    afterAll(() => {
        console.error = originalError
    })

    beforeEach(() => {
        jest.clearAllMocks()
    })

    describe('ErrorBoundary Component', () => {
        test('renders children when there is no error', () => {
            renderWithProviders(
                <ErrorBoundary>
                    <ThrowError shouldThrow={false} />
                </ErrorBoundary>
            )

            expect(screen.getByText('No error')).toBeInTheDocument()
        })

        test('renders error UI when child component throws', () => {
            renderWithProviders(
                <ErrorBoundary>
                    <ThrowError shouldThrow={true} />
                </ErrorBoundary>
            )

            expect(screen.getByText('Something went wrong')).toBeInTheDocument()
            expect(screen.getByText('An unexpected error occurred. Please try refreshing the page.')).toBeInTheDocument()
        })

        test('shows refresh button in error state', () => {
            renderWithProviders(
                <ErrorBoundary>
                    <ThrowError shouldThrow={true} />
                </ErrorBoundary>
            )

            expect(screen.getByText('Refresh Page')).toBeInTheDocument()
        })

        test('shows report issue button in error state', () => {
            renderWithProviders(
                <ErrorBoundary>
                    <ThrowError shouldThrow={true} />
                </ErrorBoundary>
            )

            expect(screen.getByText('Report Issue')).toBeInTheDocument()
        })

        test('refresh button reloads the page', () => {
            // Mock window.location.reload
            const mockReload = jest.fn()
            Object.defineProperty(window, 'location', {
                value: { reload: mockReload },
                writable: true,
            })

            renderWithProviders(
                <ErrorBoundary>
                    <ThrowError shouldThrow={true} />
                </ErrorBoundary>
            )

            const refreshButton = screen.getByText('Refresh Page')
            fireEvent.click(refreshButton)

            expect(mockReload).toHaveBeenCalled()
        })

        test('report issue button opens email client', () => {
            // Mock window.location.href
            const mockLocation = { href: '' }
            Object.defineProperty(window, 'location', {
                value: mockLocation,
                writable: true,
            })

            renderWithProviders(
                <ErrorBoundary>
                    <ThrowError shouldThrow={true} />
                </ErrorBoundary>
            )

            const reportButton = screen.getByText('Report Issue')
            fireEvent.click(reportButton)

            expect(mockLocation.href).toContain('mailto:')
        })

        test('can recover from error state', () => {
            const { rerender } = renderWithProviders(
                <ErrorBoundary>
                    <ThrowError shouldThrow={true} />
                </ErrorBoundary>
            )

            expect(screen.getByText('Something went wrong')).toBeInTheDocument()

            // Re-render with no error
            rerender(
                <Provider store={createTestStore()}>
                    <BrowserRouter>
                        <ErrorBoundary>
                            <ThrowError shouldThrow={false} />
                        </ErrorBoundary>
                    </BrowserRouter>
                </Provider>
            )

            // Error boundary should still show error state until reset
            expect(screen.getByText('Something went wrong')).toBeInTheDocument()
        })
    })

    describe('ErrorMessage Component', () => {
        test('renders network error message', () => {
            renderWithProviders(
                <ErrorMessage
                    type="network"
                    message="Connection failed"
                    onRetry={jest.fn()}
                />
            )

            expect(screen.getByText('Network Error')).toBeInTheDocument()
            expect(screen.getByText('Unable to connect to the server. Please check your internet connection.')).toBeInTheDocument()
        })

        test('renders validation error message', () => {
            renderWithProviders(
                <ErrorMessage
                    type="validation"
                    message="Invalid input"
                />
            )

            expect(screen.getByText('Validation Error')).toBeInTheDocument()
            expect(screen.getByText('Please check your input and try again.')).toBeInTheDocument()
        })

        test('renders authentication error message', () => {
            renderWithProviders(
                <ErrorMessage
                    type="authentication"
                    message="Session expired"
                />
            )

            expect(screen.getByText('Authentication Error')).toBeInTheDocument()
            expect(screen.getByText('Your session has expired. Please log in again.')).toBeInTheDocument()
        })

        test('renders authorization error message', () => {
            renderWithProviders(
                <ErrorMessage
                    type="authorization"
                    message="Access denied"
                />
            )

            expect(screen.getByText('Access Denied')).toBeInTheDocument()
            expect(screen.getByText('You do not have permission to access this resource.')).toBeInTheDocument()
        })

        test('renders not found error message', () => {
            renderWithProviders(
                <ErrorMessage
                    type="notFound"
                    message="Resource not found"
                />
            )

            expect(screen.getByText('Not Found')).toBeInTheDocument()
            expect(screen.getByText('The requested resource could not be found.')).toBeInTheDocument()
        })

        test('renders server error message', () => {
            renderWithProviders(
                <ErrorMessage
                    type="server"
                    message="Internal server error"
                />
            )

            expect(screen.getByText('Server Error')).toBeInTheDocument()
            expect(screen.getByText('An internal server error occurred. Please try again later.')).toBeInTheDocument()
        })

        test('shows retry button when onRetry is provided', () => {
            const mockRetry = jest.fn()

            renderWithProviders(
                <ErrorMessage
                    type="network"
                    message="Connection failed"
                    onRetry={mockRetry}
                />
            )

            const retryButton = screen.getByText('Retry')
            expect(retryButton).toBeInTheDocument()

            fireEvent.click(retryButton)
            expect(mockRetry).toHaveBeenCalled()
        })

        test('shows dismiss button when onDismiss is provided', () => {
            const mockDismiss = jest.fn()

            renderWithProviders(
                <ErrorMessage
                    type="validation"
                    message="Invalid input"
                    onDismiss={mockDismiss}
                />
            )

            const dismissButton = screen.getByText('Dismiss')
            expect(dismissButton).toBeInTheDocument()

            fireEvent.click(dismissButton)
            expect(mockDismiss).toHaveBeenCalled()
        })

        test('shows custom message when provided', () => {
            renderWithProviders(
                <ErrorMessage
                    type="network"
                    message="Custom error message"
                />
            )

            expect(screen.getByText('Custom error message')).toBeInTheDocument()
        })

        test('can be dismissed with close button', () => {
            const mockDismiss = jest.fn()

            renderWithProviders(
                <ErrorMessage
                    type="validation"
                    message="Invalid input"
                    onDismiss={mockDismiss}
                    dismissible={true}
                />
            )

            const closeButton = screen.getByLabelText('Close')
            fireEvent.click(closeButton)

            expect(mockDismiss).toHaveBeenCalled()
        })

        test('applies correct styling for different error types', () => {
            const { container } = renderWithProviders(
                <ErrorMessage
                    type="server"
                    message="Server error"
                />
            )

            // Check for error-specific CSS classes (implementation dependent)
            const errorElement = container.querySelector('[data-testid="error-message"]')
            expect(errorElement).toHaveClass('error-server')
        })

        test('shows loading state during retry', () => {
            const mockRetry = jest.fn(() => new Promise(resolve => setTimeout(resolve, 100)))

            renderWithProviders(
                <ErrorMessage
                    type="network"
                    message="Connection failed"
                    onRetry={mockRetry}
                    retrying={true}
                />
            )

            const retryButton = screen.getByText('Retry')
            expect(retryButton).toBeDisabled()
        })

        test('handles missing error type gracefully', () => {
            renderWithProviders(
                <ErrorMessage
                    type="unknown" as any
                    message="Unknown error"
                />
            )

            // Should still render the message even with unknown type
            expect(screen.getByText('Unknown error')).toBeInTheDocument()
        })
    })
})