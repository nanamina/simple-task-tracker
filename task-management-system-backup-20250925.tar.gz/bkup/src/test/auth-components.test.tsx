import React from 'react'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { Provider } from 'react-redux'
import { BrowserRouter } from 'react-router-dom'
import { configureStore } from '@reduxjs/toolkit'
import '@testing-library/jest-dom'
import LoginForm from '@/client/components/auth/LoginForm'
import RegisterForm from '@/client/components/auth/RegisterForm'
import ProtectedRoute from '@/client/components/auth/ProtectedRoute'
import authSlice from '@/client/store/slices/authSlice'
import { User } from '@/shared/types'

// Mock localStorage
const localStorageMock = {
    getItem: jest.fn(),
    setItem: jest.fn(),
    removeItem: jest.fn(),
    clear: jest.fn(),
}
Object.defineProperty(window, 'localStorage', {
    value: localStorageMock,
})

// Mock i18next
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string, options?: any) => {
            const translations: Record<string, string> = {
                'auth.login.title': 'Login',
                'auth.login.email': 'Email',
                'auth.login.password': 'Password',
                'auth.login.submit': 'Login',
                'auth.login.noAccount': "Don't have an account?",
                'auth.login.signUp': 'Sign Up',
                'auth.login.forgotPassword': 'Forgot Password?',
                'auth.register.title': 'Register',
                'auth.register.name': 'Name',
                'auth.register.email': 'Email',
                'auth.register.password': 'Password',
                'auth.register.confirmPassword': 'Confirm Password',
                'auth.register.submit': 'Register',
                'auth.register.hasAccount': 'Already have an account?',
                'auth.register.signIn': 'Sign In',
                'validation.required': `${options?.field} is required`,
                'validation.email': 'Please enter a valid email address',
                'validation.minLength': `${options?.field} must be at least ${options?.min} characters`,
                'validation.passwordMatch': 'Passwords do not match',
                'common.loading': 'Loading...',
            }
            return translations[key] || key
        },
    }),
}))

// Mock react-router-dom
const mockNavigate = jest.fn()
jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => mockNavigate,
    useLocation: () => ({ pathname: '/login' }),
}))

// Helper function to create test store
const createTestStore = (initialState = {}) => {
    return configureStore({
        reducer: {
            auth: authSlice,
        },
        preloadedState: {
            auth: {
                user: null,
                token: null,
                isLoading: false,
                error: null,
                isAuthenticated: false,
                ...initialState,
            },
        },
    })
}

// Helper function to render component with providers
const renderWithProviders = (component: React.ReactElement, initialState = {}) => {
    const store = createTestStore(initialState)
    return render(
        <Provider store={store}>
            <BrowserRouter>
                {component}
            </BrowserRouter>
        </Provider>
    )
}

describe('LoginForm', () => {
    beforeEach(() => {
        mockNavigate.mockClear()
        localStorageMock.getItem.mockReturnValue(null)
        // Mock fetch for API calls
        global.fetch = jest.fn()
    })

    afterEach(() => {
        jest.restoreAllMocks()
    })

    test('renders login form with all required fields', () => {
        renderWithProviders(<LoginForm />)

        expect(screen.getByText('Login')).toBeInTheDocument()
        expect(screen.getByLabelText('Email')).toBeInTheDocument()
        expect(screen.getByLabelText('Password')).toBeInTheDocument()
        expect(screen.getByRole('button', { name: 'Login' })).toBeInTheDocument()
        expect(screen.getByText("Don't have an account?")).toBeInTheDocument()
    })

    test('displays validation errors for empty fields', async () => {
        renderWithProviders(<LoginForm />)

        const submitButton = screen.getByRole('button', { name: 'Login' })
        fireEvent.click(submitButton)

        await waitFor(() => {
            expect(screen.getByText('Email is required')).toBeInTheDocument()
            expect(screen.getByText('Password is required')).toBeInTheDocument()
        })
    })

    test('displays validation error for invalid email format', async () => {
        renderWithProviders(<LoginForm />)

        const emailInput = screen.getByLabelText('Email')
        fireEvent.change(emailInput, { target: { value: 'invalid-email' } })

        const submitButton = screen.getByRole('button', { name: 'Login' })
        fireEvent.click(submitButton)

        await waitFor(() => {
            expect(screen.getByText('Please enter a valid email address')).toBeInTheDocument()
        })
    })

    test('redirects to dashboard when already authenticated', () => {
        const authenticatedState = {
            user: { id: '1', name: 'Test User', email: 'test@example.com' } as User,
            token: 'test-token',
            isAuthenticated: true,
        }

        renderWithProviders(<LoginForm />, authenticatedState)

        expect(mockNavigate).toHaveBeenCalledWith('/dashboard')
    })

    test('shows loading state during login', () => {
        const loadingState = {
            isLoading: true,
        }

        renderWithProviders(<LoginForm />, loadingState)

        expect(screen.getByText('Loading...')).toBeInTheDocument()
        expect(screen.getByRole('button', { name: 'Loading...' })).toBeDisabled()
    })

    test('displays error message when login fails', () => {
        const errorState = {
            error: 'Invalid credentials',
        }

        renderWithProviders(<LoginForm />, errorState)

        expect(screen.getByText('Invalid credentials')).toBeInTheDocument()
    })
})

describe('RegisterForm', () => {
    beforeEach(() => {
        mockNavigate.mockClear()
        localStorageMock.getItem.mockReturnValue(null)
        global.fetch = jest.fn()
    })

    afterEach(() => {
        jest.restoreAllMocks()
    })

    test('renders registration form with all required fields', () => {
        renderWithProviders(<RegisterForm />)

        expect(screen.getByText('Register')).toBeInTheDocument()
        expect(screen.getByLabelText('Name')).toBeInTheDocument()
        expect(screen.getByLabelText('Email')).toBeInTheDocument()
        expect(screen.getByLabelText('Password')).toBeInTheDocument()
        expect(screen.getByLabelText('Confirm Password')).toBeInTheDocument()
        expect(screen.getByRole('button', { name: 'Register' })).toBeInTheDocument()
    })

    test('displays validation errors for empty fields', async () => {
        renderWithProviders(<RegisterForm />)

        const submitButton = screen.getByRole('button', { name: 'Register' })
        fireEvent.click(submitButton)

        await waitFor(() => {
            expect(screen.getByText('Name is required')).toBeInTheDocument()
            expect(screen.getByText('Email is required')).toBeInTheDocument()
            expect(screen.getByText('Password is required')).toBeInTheDocument()
        })
    })

    test('displays password mismatch error', async () => {
        renderWithProviders(<RegisterForm />)

        const passwordInput = screen.getByLabelText('Password')
        const confirmPasswordInput = screen.getByLabelText('Confirm Password')

        fireEvent.change(passwordInput, { target: { value: 'password123' } })
        fireEvent.change(confirmPasswordInput, { target: { value: 'different123' } })

        const submitButton = screen.getByRole('button', { name: 'Register' })
        fireEvent.click(submitButton)

        await waitFor(() => {
            expect(screen.getByText('Passwords do not match')).toBeInTheDocument()
        })
    })

    test('redirects to dashboard when already authenticated', () => {
        const authenticatedState = {
            user: { id: '1', name: 'Test User', email: 'test@example.com' } as User,
            token: 'test-token',
            isAuthenticated: true,
        }

        renderWithProviders(<RegisterForm />, authenticatedState)

        expect(mockNavigate).toHaveBeenCalledWith('/dashboard')
    })
})

describe('ProtectedRoute', () => {
    const TestComponent = () => <div>Protected Content</div>

    test('renders children when user is authenticated', () => {
        const authenticatedState = {
            user: { id: '1', name: 'Test User', email: 'test@example.com', role: 'member' } as User,
            token: 'test-token',
            isAuthenticated: true,
        }

        renderWithProviders(
            <ProtectedRoute>
                <TestComponent />
            </ProtectedRoute>,
            authenticatedState
        )

        expect(screen.getByText('Protected Content')).toBeInTheDocument()
    })

    test('shows loading spinner when verifying token', () => {
        const loadingState = {
            token: 'test-token',
            isLoading: true,
        }

        renderWithProviders(
            <ProtectedRoute>
                <TestComponent />
            </ProtectedRoute>,
            loadingState
        )

        expect(screen.getByRole('status', { hidden: true })).toBeInTheDocument() // Loading spinner
    })

    test('redirects to login when not authenticated', () => {
        renderWithProviders(
            <ProtectedRoute>
                <TestComponent />
            </ProtectedRoute>
        )

        // Component should redirect, so protected content should not be visible
        expect(screen.queryByText('Protected Content')).not.toBeInTheDocument()
    })

    test('redirects to unauthorized when user lacks required role', () => {
        const memberState = {
            user: { id: '1', name: 'Test User', email: 'test@example.com', role: 'member' } as User,
            token: 'test-token',
            isAuthenticated: true,
        }

        renderWithProviders(
            <ProtectedRoute requiredRole="admin">
                <TestComponent />
            </ProtectedRoute>,
            memberState
        )

        // Component should redirect to unauthorized, so protected content should not be visible
        expect(screen.queryByText('Protected Content')).not.toBeInTheDocument()
    })

    test('allows access when user has required role', () => {
        const adminState = {
            user: { id: '1', name: 'Test User', email: 'test@example.com', role: 'admin' } as User,
            token: 'test-token',
            isAuthenticated: true,
        }

        renderWithProviders(
            <ProtectedRoute requiredRole="member">
                <TestComponent />
            </ProtectedRoute>,
            adminState
        )

        expect(screen.getByText('Protected Content')).toBeInTheDocument()
    })
})