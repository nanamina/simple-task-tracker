/**
 * End-to-End Integration Tests
 * 
 * These tests verify that all components work together correctly
 * and that the complete user workflows function as expected.
 */

import request from 'supertest'
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import { Pool } from 'pg'
import authRoutes from '../server/routes/auth'
import taskRoutes from '../server/routes/task'
import projectRoutes from '../server/routes/project'
import userRoutes from '../server/routes/user'
import { createAnalyticsRoutes } from '../server/routes/analytics'
import { errorHandler, notFoundHandler } from '../server/middleware/errorHandler'

// Mock database pool
const mockPool = {
    query: jest.fn(),
    connect: jest.fn(),
    end: jest.fn(),
} as unknown as Pool

// Mock database module
jest.mock('../server/config/database', () => ({
    getPool: jest.fn(() => mockPool),
    testConnection: jest.fn(() => Promise.resolve()),
}))

describe('End-to-End Integration Tests', () => {
    let app: express.Application
    let authToken: string

    beforeAll(() => {
        // Create Express app with all middleware and routes
        app = express()

        app.use(helmet())
        app.use(cors())
        app.use(express.json())
        app.use(express.urlencoded({ extended: true }))

        // Add all routes
        app.use('/api/auth', authRoutes)
        app.use('/api/tasks', taskRoutes)
        app.use('/api/projects', projectRoutes)
        app.use('/api/users', userRoutes)
        app.use('/api/analytics', createAnalyticsRoutes(mockPool))

        // Health check endpoint
        app.get('/api/health', (_req, res) => {
            res.json({
                status: 'ok',
                message: 'Task Management System API is running',
                database: 'connected',
                timestamp: new Date().toISOString()
            })
        })

        app.use(notFoundHandler)
        app.use(errorHandler)
    })

    beforeEach(() => {
        jest.clearAllMocks()
    })

    describe('System Health and Connectivity', () => {
        test('should respond to health check endpoint', async () => {
            const response = await request(app)
                .get('/api/health')
                .expect(200)

            expect(response.body).toMatchObject({
                status: 'ok',
                message: 'Task Management System API is running',
                database: 'connected'
            })
            expect(response.body.timestamp).toBeDefined()
        })

        test('should handle 404 for unknown routes', async () => {
            const response = await request(app)
                .get('/api/unknown-endpoint')
                .expect(404)

            expect(response.body).toMatchObject({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Route not found'
                }
            })
        })
    })

    describe('Complete User Workflow', () => {
        test('should complete full user registration and authentication flow', async () => {
            // Mock user registration
            mockPool.query = jest.fn()
                .mockResolvedValueOnce({ rows: [] }) // Check if user exists
                .mockResolvedValueOnce({
                    rows: [{
                        id: 'user-123',
                        email: 'test@example.com',
                        name: 'Test User',
                        role: 'member',
                        preferred_language: 'ja'
                    }]
                }) // Insert user

            // Register user
            const registerResponse = await request(app)
                .post('/api/auth/register')
                .send({
                    name: 'Test User',
                    email: 'test@example.com',
                    password: 'password123'
                })
                .expect(201)

            expect(registerResponse.body).toMatchObject({
                message: 'User registered successfully',
                user: {
                    id: 'user-123',
                    email: 'test@example.com',
                    name: 'Test User'
                }
            })

            // Mock user login
            mockPool.query = jest.fn()
                .mockResolvedValueOnce({
                    rows: [{
                        id: 'user-123',
                        email: 'test@example.com',
                        name: 'Test User',
                        password_hash: '$2b$10$hashedpassword',
                        role: 'member',
                        preferred_language: 'ja'
                    }]
                })

            // Mock bcrypt compare
            jest.doMock('bcrypt', () => ({
                compare: jest.fn().mockResolvedValue(true)
            }))

            // Login user
            const loginResponse = await request(app)
                .post('/api/auth/login')
                .send({
                    email: 'test@example.com',
                    password: 'password123'
                })
                .expect(200)

            expect(loginResponse.body).toHaveProperty('token')
            expect(loginResponse.body).toMatchObject({
                message: 'Login successful',
                user: {
                    id: 'user-123',
                    email: 'test@example.com',
                    name: 'Test User'
                }
            })

            authToken = loginResponse.body.token
        })

        test('should complete project and task management workflow', async () => {
            // Mock JWT verification
            jest.doMock('jsonwebtoken', () => ({
                sign: jest.fn().mockReturnValue('mock-jwt-token'),
                verify: jest.fn().mockReturnValue({
                    userId: 'user-123',
                    email: 'test@example.com'
                })
            }))

            // Mock project creation
            mockPool.query = jest.fn()
                .mockResolvedValueOnce({
                    rows: [{
                        id: 'project-123',
                        name: 'Test Project',
                        description: 'A test project',
                        created_by: 'user-123',
                        created_at: new Date(),
                        updated_at: new Date()
                    }]
                })
                .mockResolvedValueOnce({ rows: [] }) // Add creator as member

            // Create project
            const projectResponse = await request(app)
                .post('/api/projects')
                .set('Authorization', `Bearer ${authToken}`)
                .send({
                    name: 'Test Project',
                    description: 'A test project'
                })
                .expect(201)

            expect(projectResponse.body).toMatchObject({
                message: 'Project created successfully',
                project: {
                    id: 'project-123',
                    name: 'Test Project',
                    description: 'A test project'
                }
            })

            // Mock task creation
            mockPool.query = jest.fn()
                .mockResolvedValueOnce({
                    rows: [{
                        id: 'task-123',
                        title: 'Test Task',
                        description: 'A test task',
                        status: 'todo',
                        priority: 'medium',
                        project_id: 'project-123',
                        created_by: 'user-123',
                        created_at: new Date(),
                        updated_at: new Date()
                    }]
                })

            // Create task
            const taskResponse = await request(app)
                .post('/api/tasks')
                .set('Authorization', `Bearer ${authToken}`)
                .send({
                    title: 'Test Task',
                    description: 'A test task',
                    priority: 'medium',
                    projectId: 'project-123'
                })
                .expect(201)

            expect(taskResponse.body).toMatchObject({
                message: 'Task created successfully',
                task: {
                    id: 'task-123',
                    title: 'Test Task',
                    description: 'A test task',
                    status: 'todo',
                    priority: 'medium'
                }
            })

            // Mock task status update
            mockPool.query = jest.fn()
                .mockResolvedValueOnce({
                    rows: [{
                        id: 'task-123',
                        title: 'Test Task',
                        description: 'A test task',
                        status: 'in-progress',
                        priority: 'medium',
                        project_id: 'project-123',
                        updated_at: new Date()
                    }]
                })

            // Update task status
            const statusResponse = await request(app)
                .patch('/api/tasks/task-123/status')
                .set('Authorization', `Bearer ${authToken}`)
                .send({
                    status: 'in-progress'
                })
                .expect(200)

            expect(statusResponse.body).toMatchObject({
                message: 'Task status updated successfully',
                task: {
                    id: 'task-123',
                    status: 'in-progress'
                }
            })
        })

        test('should handle analytics and reporting workflow', async () => {
            // Mock analytics data
            mockPool.query = jest.fn()
                .mockResolvedValueOnce({
                    rows: [{
                        total_tasks: 10,
                        completed_tasks: 6,
                        in_progress_tasks: 3,
                        todo_tasks: 1,
                        completion_rate: 0.6
                    }]
                })

            // Get project analytics
            const analyticsResponse = await request(app)
                .get('/api/analytics/project/project-123')
                .set('Authorization', `Bearer ${authToken}`)
                .expect(200)

            expect(analyticsResponse.body).toMatchObject({
                projectId: 'project-123',
                metrics: {
                    totalTasks: 10,
                    completedTasks: 6,
                    inProgressTasks: 3,
                    todoTasks: 1,
                    completionRate: 0.6
                }
            })
        })
    })

    describe('Error Handling and Edge Cases', () => {
        test('should handle authentication errors gracefully', async () => {
            const response = await request(app)
                .get('/api/tasks')
                .expect(401)

            expect(response.body).toMatchObject({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Access token is required'
                }
            })
        })

        test('should handle validation errors properly', async () => {
            const response = await request(app)
                .post('/api/auth/register')
                .send({
                    name: '',
                    email: 'invalid-email',
                    password: '123'
                })
                .expect(400)

            expect(response.body).toHaveProperty('error')
            expect(response.body.error.code).toBe('VALIDATION_ERROR')
        })

        test('should handle database errors gracefully', async () => {
            // Mock database error
            mockPool.query = jest.fn().mockRejectedValue(new Error('Database connection failed'))

            const response = await request(app)
                .post('/api/auth/register')
                .send({
                    name: 'Test User',
                    email: 'test@example.com',
                    password: 'password123'
                })
                .expect(500)

            expect(response.body).toMatchObject({
                error: {
                    code: 'INTERNAL_ERROR',
                    message: 'Internal server error'
                }
            })
        })
    })

    describe('Internationalization Integration', () => {
        test('should handle Japanese language preferences', async () => {
            // Mock user with Japanese preference
            mockPool.query = jest.fn()
                .mockResolvedValueOnce({
                    rows: [{
                        id: 'user-123',
                        email: 'test@example.com',
                        name: 'テストユーザー',
                        preferred_language: 'ja'
                    }]
                })

            const response = await request(app)
                .get('/api/users/profile')
                .set('Authorization', `Bearer ${authToken}`)
                .set('Accept-Language', 'ja')
                .expect(200)

            expect(response.body.user.preferred_language).toBe('ja')
        })

        test('should handle English language preferences', async () => {
            // Mock user with English preference
            mockPool.query = jest.fn()
                .mockResolvedValueOnce({
                    rows: [{
                        id: 'user-123',
                        email: 'test@example.com',
                        name: 'Test User',
                        preferred_language: 'en'
                    }]
                })

            const response = await request(app)
                .get('/api/users/profile')
                .set('Authorization', `Bearer ${authToken}`)
                .set('Accept-Language', 'en')
                .expect(200)

            expect(response.body.user.preferred_language).toBe('en')
        })
    })
})