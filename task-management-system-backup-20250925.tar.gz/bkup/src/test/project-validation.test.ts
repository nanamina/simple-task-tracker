/**
 * Unit tests for project validation functions
 */

import {
    validateProjectName,
    validateProjectDescription,
    validateCreateProject,
    validateUpdateProject,
    CreateProjectDTO,
    UpdateProjectDTO
} from '../shared/types/validation'

describe('Project Validation Functions', () => {
    describe('validateProjectName', () => {
        it('should validate proper names', () => {
            expect(validateProjectName('Valid Project Name')).toBe(true)
            expect(validateProjectName('A')).toBe(true)
            expect(validateProjectName('プロジェクト名')).toBe(true)
        })

        it('should reject empty names', () => {
            expect(validateProjectName('')).toBe(false)
            expect(validateProjectName('   ')).toBe(false)
        })

        it('should reject names that are too long', () => {
            const longName = 'A'.repeat(256)
            expect(validateProjectName(longName)).toBe(false)
        })

        it('should handle names with whitespace', () => {
            expect(validateProjectName('  Valid Project Name  ')).toBe(true)
        })
    })

    describe('validateProjectDescription', () => {
        it('should validate proper descriptions', () => {
            expect(validateProjectDescription('Valid project description')).toBe(true)
            expect(validateProjectDescription('')).toBe(true) // Empty description is allowed
            expect(validateProjectDescription('プロジェクトの詳細な説明')).toBe(true)
        })

        it('should reject descriptions that are too long', () => {
            const longDescription = 'A'.repeat(2001)
            expect(validateProjectDescription(longDescription)).toBe(false)
        })

        it('should handle descriptions with whitespace', () => {
            expect(validateProjectDescription('  Valid project description  ')).toBe(true)
        })
    })

    describe('validateCreateProject', () => {
        const validProjectData: CreateProjectDTO = {
            name: 'Test Project',
            description: 'Test project description'
        }

        it('should validate complete valid project data', () => {
            const result = validateCreateProject(validProjectData)
            expect(result.isValid).toBe(true)
            expect(result.errors).toHaveLength(0)
        })

        it('should validate project with empty description', () => {
            const projectData: CreateProjectDTO = {
                name: 'Test Project',
                description: ''
            }
            const result = validateCreateProject(projectData)
            expect(result.isValid).toBe(true)
            expect(result.errors).toHaveLength(0)
        })

        it('should reject project with invalid name', () => {
            const projectData = { ...validProjectData, name: '' }
            const result = validateCreateProject(projectData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Name must be between 1 and 255 characters')
        })

        it('should reject project with invalid description', () => {
            const projectData = { ...validProjectData, description: 'A'.repeat(2001) }
            const result = validateCreateProject(projectData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Description must be 2000 characters or less')
        })

        it('should return multiple errors for multiple invalid fields', () => {
            const projectData: CreateProjectDTO = {
                name: '',
                description: 'A'.repeat(2001)
            }
            const result = validateCreateProject(projectData)
            expect(result.isValid).toBe(false)
            expect(result.errors.length).toBe(2)
            expect(result.errors).toContain('Name must be between 1 and 255 characters')
            expect(result.errors).toContain('Description must be 2000 characters or less')
        })
    })

    describe('validateUpdateProject', () => {
        it('should validate valid update data', () => {
            const updateData: UpdateProjectDTO = {
                name: 'Updated Project Name',
                description: 'Updated description'
            }
            const result = validateUpdateProject(updateData)
            expect(result.isValid).toBe(true)
            expect(result.errors).toHaveLength(0)
        })

        it('should validate empty update data', () => {
            const result = validateUpdateProject({})
            expect(result.isValid).toBe(true)
            expect(result.errors).toHaveLength(0)
        })

        it('should validate partial update data', () => {
            const updateData: UpdateProjectDTO = {
                name: 'Updated Name Only'
            }
            const result = validateUpdateProject(updateData)
            expect(result.isValid).toBe(true)
            expect(result.errors).toHaveLength(0)
        })

        it('should reject update with invalid name', () => {
            const updateData: UpdateProjectDTO = { name: '' }
            const result = validateUpdateProject(updateData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Name must be between 1 and 255 characters')
        })

        it('should reject update with invalid description', () => {
            const updateData: UpdateProjectDTO = { description: 'A'.repeat(2001) }
            const result = validateUpdateProject(updateData)
            expect(result.isValid).toBe(false)
            expect(result.errors).toContain('Description must be 2000 characters or less')
        })

        it('should reject update with multiple invalid fields', () => {
            const updateData: UpdateProjectDTO = {
                name: '',
                description: 'A'.repeat(2001)
            }
            const result = validateUpdateProject(updateData)
            expect(result.isValid).toBe(false)
            expect(result.errors.length).toBe(2)
        })
    })
})