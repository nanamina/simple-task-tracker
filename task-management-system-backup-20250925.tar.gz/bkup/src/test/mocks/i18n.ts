// Mock translations for testing
const mockTranslations = {
    'common.save': '保存',
    'common.cancel': 'キャンセル',
    'common.edit': '編集',
    'common.loading': '読み込み中...',
    'common.saving': '保存中...',
    'navigation.dashboard': 'ダッシュボード',
    'navigation.tasks': 'タスク',
    'navigation.projects': 'プロジェクト',
    'navigation.profile': 'プロフィール',
    'navigation.logout': 'ログアウト',
    'profile.title': 'プロフィール',
    'profile.edit': 'プロフィールを編集',
    'profile.fields.name': '名前',
    'profile.fields.email': 'メールアドレス',
    'profile.fields.role': '役割',
    'profile.fields.preferredLanguage': '優先言語',
    'profile.fields.joinedAt': '参加日',
    'profile.roles.admin': '管理者',
    'profile.roles.manager': 'マネージャー',
    'profile.roles.member': 'メンバー',
    'profile.languages.ja': '日本語',
    'profile.languages.en': 'English',
    'profile.messages.profileUpdated': 'プロフィールが更新されました',
    'users.role.admin': '管理者',
    'users.role.manager': 'マネージャー',
    'users.role.member': 'メンバー',
    'notifications.title': 'Notifications',
    'notifications.noNotifications': 'No notifications',
    'notifications.markAllRead': 'Mark all as read',
    'notifications.clearAll': 'Clear all',
    'notifications.showAll': 'Show all {{count}} notifications',
    'notifications.showLess': 'Show less'
};

// Mock i18n object
const mockI18n = {
    language: 'ja',
    changeLanguage: jest.fn(),
    t: jest.fn((key: string, options?: any) => {
        if (options && options.count !== undefined) {
            return mockTranslations[key]?.replace('{{count}}', options.count) || key;
        }
        return mockTranslations[key] || key;
    }),
    init: jest.fn(),
    use: jest.fn(() => mockI18n),
};

export default mockI18n;