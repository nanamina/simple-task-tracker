/**
 * Unit tests for User Repository
 */

import { Pool, PoolClient } from 'pg'
import { UserRepository } from '../server/repositories/user-repository'
import { CreateUserDTO, UpdateUserDTO } from '../shared/types/validation'

// Mock pg module
jest.mock('pg', () => ({
    Pool: jest.fn()
}))

describe('UserRepository', () => {
    let mockPool: jest.Mocked<Pool>
    let mockClient: jest.Mocked<PoolClient>
    let userRepository: UserRepository

    beforeEach(() => {
        // Create mock client
        mockClient = {
            query: jest.fn(),
            release: jest.fn()
        } as any

        // Create mock pool
        mockPool = {
            connect: jest.fn().mockResolvedValue(mockClient)
        } as any

            // Mock Pool constructor
            ; (Pool as jest.MockedClass<typeof Pool>).mockImplementation(() => mockPool)

        userRepository = new UserRepository(mockPool)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    describe('createUser', () => {
        const mockUserData: CreateUserDTO = {
            email: 'test@example.com',
            name: 'Test User',
            password: 'password123',
            role: 'member',
            preferredLanguage: 'ja'
        }

        const mockDbResult = {
            rows: [{
                id: '123e4567-e89b-12d3-a456-426614174000',
                email: 'test@example.com',
                name: 'Test User',
                role: 'member',
                preferred_language: 'ja',
                created_at: new Date('2024-01-01'),
                updated_at: new Date('2024-01-01')
            }]
        }

        it('should create a user successfully', async () => {
            mockClient.query.mockResolvedValue(mockDbResult)

            const result = await userRepository.createUser(mockUserData)

            expect(mockPool.connect).toHaveBeenCalled()
            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringContaining('INSERT INTO users'),
                expect.arrayContaining([
                    mockUserData.email,
                    mockUserData.name,
                    expect.any(String), // hashed password
                    mockUserData.role,
                    mockUserData.preferredLanguage
                ])
            )
            expect(mockClient.release).toHaveBeenCalled()
            expect(result).toEqual({
                id: '123e4567-e89b-12d3-a456-426614174000',
                email: 'test@example.com',
                name: 'Test User',
                role: 'member',
                preferredLanguage: 'ja',
                createdAt: new Date('2024-01-01'),
                updatedAt: new Date('2024-01-01')
            })
        })

        it('should use default values for optional fields', async () => {
            const minimalUserData: CreateUserDTO = {
                email: 'test@example.com',
                name: 'Test User',
                password: 'password123'
            }

            mockClient.query.mockResolvedValue(mockDbResult)

            await userRepository.createUser(minimalUserData)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringContaining('INSERT INTO users'),
                expect.arrayContaining([
                    minimalUserData.email,
                    minimalUserData.name,
                    expect.any(String), // hashed password
                    'member', // default role
                    'ja' // default language
                ])
            )
        })

        it('should throw error for duplicate email', async () => {
            const duplicateError = new Error('duplicate key value violates unique constraint')
            mockClient.query.mockRejectedValue(duplicateError)

            await expect(userRepository.createUser(mockUserData)).rejects.toThrow('User with this email already exists')
            expect(mockClient.release).toHaveBeenCalled()
        })

        it('should throw generic error for other database errors', async () => {
            const dbError = new Error('Database connection failed')
            mockClient.query.mockRejectedValue(dbError)

            await expect(userRepository.createUser(mockUserData)).rejects.toThrow('Failed to create user')
            expect(mockClient.release).toHaveBeenCalled()
        })
    })

    describe('findById', () => {
        const userId = '123e4567-e89b-12d3-a456-426614174000'
        const mockDbResult = {
            rows: [{
                id: userId,
                email: 'test@example.com',
                name: 'Test User',
                role: 'member',
                preferred_language: 'ja',
                created_at: new Date('2024-01-01'),
                updated_at: new Date('2024-01-01')
            }]
        }

        it('should find user by ID successfully', async () => {
            mockClient.query.mockResolvedValue(mockDbResult)

            const result = await userRepository.findById(userId)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/SELECT.*FROM users.*WHERE id = \$1/s),
                [userId]
            )
            expect(result).toEqual({
                id: userId,
                email: 'test@example.com',
                name: 'Test User',
                role: 'member',
                preferredLanguage: 'ja',
                createdAt: new Date('2024-01-01'),
                updatedAt: new Date('2024-01-01')
            })
        })

        it('should return null when user not found', async () => {
            mockClient.query.mockResolvedValue({ rows: [] })

            const result = await userRepository.findById(userId)

            expect(result).toBeNull()
        })

        it('should throw error on database failure', async () => {
            mockClient.query.mockRejectedValue(new Error('Database error'))

            await expect(userRepository.findById(userId)).rejects.toThrow('Failed to find user by ID')
            expect(mockClient.release).toHaveBeenCalled()
        })
    })

    describe('findByEmailWithPassword', () => {
        const email = 'test@example.com'
        const mockDbResult = {
            rows: [{
                id: '123e4567-e89b-12d3-a456-426614174000',
                email: 'test@example.com',
                name: 'Test User',
                password_hash: '$2b$12$hashedpassword',
                role: 'member',
                preferred_language: 'ja',
                created_at: new Date('2024-01-01'),
                updated_at: new Date('2024-01-01')
            }]
        }

        it('should find user with password by email', async () => {
            mockClient.query.mockResolvedValue(mockDbResult)

            const result = await userRepository.findByEmailWithPassword(email)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/SELECT.*password_hash.*FROM users.*WHERE email = \$1/s),
                [email]
            )
            expect(result).toEqual({
                id: '123e4567-e89b-12d3-a456-426614174000',
                email: 'test@example.com',
                name: 'Test User',
                passwordHash: '$2b$12$hashedpassword',
                role: 'member',
                preferredLanguage: 'ja',
                createdAt: new Date('2024-01-01'),
                updatedAt: new Date('2024-01-01')
            })
        })

        it('should return null when user not found', async () => {
            mockClient.query.mockResolvedValue({ rows: [] })

            const result = await userRepository.findByEmailWithPassword(email)

            expect(result).toBeNull()
        })
    })

    describe('updateUser', () => {
        const userId = '123e4567-e89b-12d3-a456-426614174000'
        const updateData: UpdateUserDTO = {
            name: 'Updated Name',
            preferredLanguage: 'en'
        }

        const mockDbResult = {
            rows: [{
                id: userId,
                email: 'test@example.com',
                name: 'Updated Name',
                role: 'member',
                preferred_language: 'en',
                created_at: new Date('2024-01-01'),
                updated_at: new Date('2024-01-02')
            }]
        }

        it('should update user successfully', async () => {
            mockClient.query.mockResolvedValue(mockDbResult)

            const result = await userRepository.updateUser(userId, updateData)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/UPDATE users[\s\S]*SET[\s\S]*WHERE id = \$\d+/),
                expect.arrayContaining(['Updated Name', 'en', userId])
            )
            expect(result).toEqual({
                id: userId,
                email: 'test@example.com',
                name: 'Updated Name',
                role: 'member',
                preferredLanguage: 'en',
                createdAt: new Date('2024-01-01'),
                updatedAt: new Date('2024-01-02')
            })
        })

        it('should return null when user not found', async () => {
            mockClient.query.mockResolvedValue({ rows: [] })

            const result = await userRepository.updateUser(userId, updateData)

            expect(result).toBeNull()
        })

        it('should handle empty update data', async () => {
            // Mock findById to return a user
            const findByIdSpy = jest.spyOn(userRepository, 'findById').mockResolvedValue({
                id: userId,
                email: 'test@example.com',
                name: 'Test User',
                role: 'member',
                preferredLanguage: 'ja',
                createdAt: new Date('2024-01-01'),
                updatedAt: new Date('2024-01-01')
            })

            const result = await userRepository.updateUser(userId, {})

            expect(findByIdSpy).toHaveBeenCalledWith(userId)
            expect(result).toBeDefined()
        })
    })

    describe('deleteUser', () => {
        const userId = '123e4567-e89b-12d3-a456-426614174000'

        it('should delete user successfully', async () => {
            mockClient.query.mockResolvedValue({ rowCount: 1 })

            const result = await userRepository.deleteUser(userId)

            expect(mockClient.query).toHaveBeenCalledWith(
                'DELETE FROM users WHERE id = $1',
                [userId]
            )
            expect(result).toBe(true)
        })

        it('should return false when user not found', async () => {
            mockClient.query.mockResolvedValue({ rowCount: 0 })

            const result = await userRepository.deleteUser(userId)

            expect(result).toBe(false)
        })
    })

    describe('listUsers', () => {
        const mockDbResult = {
            rows: [
                {
                    id: '123e4567-e89b-12d3-a456-426614174000',
                    email: 'user1@example.com',
                    name: 'User 1',
                    role: 'member',
                    preferred_language: 'ja',
                    created_at: new Date('2024-01-01'),
                    updated_at: new Date('2024-01-01')
                },
                {
                    id: '456e7890-e89b-12d3-a456-426614174001',
                    email: 'user2@example.com',
                    name: 'User 2',
                    role: 'admin',
                    preferred_language: 'en',
                    created_at: new Date('2024-01-02'),
                    updated_at: new Date('2024-01-02')
                }
            ]
        }

        it('should list users with default pagination', async () => {
            mockClient.query.mockResolvedValue(mockDbResult)

            const result = await userRepository.listUsers()

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringContaining('LIMIT $1 OFFSET $2'),
                [50, 0] // default limit and offset
            )
            expect(result).toHaveLength(2)
            expect(result[0].email).toBe('user1@example.com')
        })

        it('should list users with custom pagination', async () => {
            mockClient.query.mockResolvedValue(mockDbResult)

            const result = await userRepository.listUsers(10, 20)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringContaining('LIMIT $1 OFFSET $2'),
                [10, 20]
            )
        })
    })

    describe('existsByEmail', () => {
        const email = 'test@example.com'

        it('should return true when user exists', async () => {
            mockClient.query.mockResolvedValue({ rows: [{ exists: true }] })

            const result = await userRepository.existsByEmail(email)

            expect(mockClient.query).toHaveBeenCalledWith(
                'SELECT 1 FROM users WHERE email = $1',
                [email]
            )
            expect(result).toBe(true)
        })

        it('should return false when user does not exist', async () => {
            mockClient.query.mockResolvedValue({ rows: [] })

            const result = await userRepository.existsByEmail(email)

            expect(result).toBe(false)
        })
    })
})