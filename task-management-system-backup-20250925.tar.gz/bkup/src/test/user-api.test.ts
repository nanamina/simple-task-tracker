/**
 * Integration tests for user management API endpoints
 */

const request = require('supertest')
const express = require('express')
import { User } from '../shared/types/index'

// Mock the database pool
const mockPool = {
    connect: jest.fn(),
    query: jest.fn(),
    end: jest.fn()
}

const mockClient = {
    query: jest.fn(),
    release: jest.fn()
}

// Mock database configuration
jest.mock('../server/config/database', () => ({
    getPool: jest.fn(() => mockPool),
    testConnection: jest.fn()
}))

// Mock authentication middleware
jest.mock('../server/middleware/auth', () => ({
    authenticateToken: (req: any, res: any, next: any) => {
        // Mock authenticated user based on test scenario
        if (req.headers.authorization === 'Bearer valid-user-token') {
            req.user = mockUsers.user
        } else if (req.headers.authorization === 'Bearer valid-admin-token') {
            req.user = mockUsers.admin
        } else if (req.headers.authorization === 'Bearer valid-member-token') {
            req.user = mockUsers.member
        } else {
            return res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: new Date().toISOString()
                }
            })
        }
        next()
    }
}))

// Test app setup
const app = express()
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Import routes after mocking
import userRoutes from '../server/routes/user'
app.use('/api/users', userRoutes)

// Mock users for testing
const mockUsers = {
    user: {
        id: '123e4567-e89b-12d3-a456-426614174000',
        email: 'testuser@test.com',
        name: 'Test User',
        role: 'manager' as const,
        preferredLanguage: 'ja' as const,
        createdAt: new Date('2024-01-01'),
        updatedAt: new Date('2024-01-01')
    },
    admin: {
        id: '123e4567-e89b-12d3-a456-426614174001',
        email: 'admin@test.com',
        name: 'Admin User',
        role: 'admin' as const,
        preferredLanguage: 'en' as const,
        createdAt: new Date('2024-01-01'),
        updatedAt: new Date('2024-01-01')
    },
    member: {
        id: '123e4567-e89b-12d3-a456-426614174002',
        email: 'member@test.com',
        name: 'Member User',
        role: 'member' as const,
        preferredLanguage: 'ja' as const,
        createdAt: new Date('2024-01-01'),
        updatedAt: new Date('2024-01-01')
    }
}

describe('User API Integration Tests', () => {
    beforeEach(() => {
        // Reset mocks
        jest.clearAllMocks()

        // Setup default mock implementations
        mockPool.connect.mockResolvedValue(mockClient)
        mockClient.release.mockResolvedValue(undefined)
    })

    describe('GET /api/users/profile', () => {
        it('should get current user profile with valid token', async () => {
            // Mock database response with database column names
            mockClient.query.mockResolvedValueOnce({
                rows: [{
                    id: mockUsers.user.id,
                    email: mockUsers.user.email,
                    name: mockUsers.user.name,
                    role: mockUsers.user.role,
                    preferred_language: mockUsers.user.preferredLanguage,
                    created_at: mockUsers.user.createdAt,
                    updated_at: mockUsers.user.updatedAt
                }],
                rowCount: 1
            })

            const response = await request(app)
                .get('/api/users/profile')
                .set('Authorization', 'Bearer valid-user-token')
                .expect(200)

            expect(response.body).toHaveProperty('user')
            expect(response.body.user).toMatchObject({
                id: mockUsers.user.id,
                email: mockUsers.user.email,
                name: mockUsers.user.name,
                role: mockUsers.user.role,
                preferredLanguage: mockUsers.user.preferredLanguage
            })
            expect(response.body.user).not.toHaveProperty('passwordHash')
            expect(response.body).toHaveProperty('timestamp')
        })

        it('should return 401 without authentication token', async () => {
            const response = await request(app)
                .get('/api/users/profile')
                .expect(401)

            expect(response.body.error.code).toBe('UNAUTHORIZED')
        })

        it('should return 401 with invalid token', async () => {
            const response = await request(app)
                .get('/api/users/profile')
                .set('Authorization', 'Bearer invalid-token')
                .expect(401)

            expect(response.body.error.code).toBe('UNAUTHORIZED')
        })
    })

    describe('PUT /api/users/profile', () => {
        it('should update user profile with valid data', async () => {
            const updateData = {
                name: 'Updated Test User',
                preferredLanguage: 'en'
            }

            const updatedUser = {
                ...mockUsers.user,
                name: updateData.name,
                preferredLanguage: updateData.preferredLanguage,
                updatedAt: new Date()
            }

            // Mock database response for update with database column names
            mockClient.query.mockResolvedValueOnce({
                rows: [{
                    id: updatedUser.id,
                    email: updatedUser.email,
                    name: updatedUser.name,
                    role: updatedUser.role,
                    preferred_language: updatedUser.preferredLanguage,
                    created_at: updatedUser.createdAt,
                    updated_at: updatedUser.updatedAt
                }],
                rowCount: 1
            })

            const response = await request(app)
                .put('/api/users/profile')
                .set('Authorization', 'Bearer valid-user-token')
                .send(updateData)
                .expect(200)

            expect(response.body.message).toBe('Profile updated successfully')
            expect(response.body.user.name).toBe(updateData.name)
            expect(response.body.user.preferredLanguage).toBe(updateData.preferredLanguage)
            expect(response.body.user.email).toBe(mockUsers.user.email) // Should remain unchanged
        })

        it('should return 400 with invalid name', async () => {
            const updateData = {
                name: 'A' // Too short
            }

            const response = await request(app)
                .put('/api/users/profile')
                .set('Authorization', 'Bearer valid-user-token')
                .send(updateData)
                .expect(400)

            expect(response.body.error.code).toBe('VALIDATION_ERROR')
        })

        it('should return 401 without authentication', async () => {
            const response = await request(app)
                .put('/api/users/profile')
                .send({ name: 'New Name' })
                .expect(401)

            expect(response.body.error.code).toBe('UNAUTHORIZED')
        })
    })

    describe('PATCH /api/users/profile/language', () => {
        it('should update language preference to English', async () => {
            const updatedUser = {
                ...mockUsers.user,
                preferredLanguage: 'en' as const,
                updatedAt: new Date()
            }

            // Mock database response for update with database column names
            mockClient.query.mockResolvedValueOnce({
                rows: [{
                    id: updatedUser.id,
                    email: updatedUser.email,
                    name: updatedUser.name,
                    role: updatedUser.role,
                    preferred_language: updatedUser.preferredLanguage,
                    created_at: updatedUser.createdAt,
                    updated_at: updatedUser.updatedAt
                }],
                rowCount: 1
            })

            const response = await request(app)
                .patch('/api/users/profile/language')
                .set('Authorization', 'Bearer valid-user-token')
                .send({ preferredLanguage: 'en' })
                .expect(200)

            expect(response.body.message).toBe('Language preference updated successfully')
            expect(response.body.user.preferredLanguage).toBe('en')
        })

        it('should return 400 with invalid language', async () => {
            const response = await request(app)
                .patch('/api/users/profile/language')
                .set('Authorization', 'Bearer valid-user-token')
                .send({ preferredLanguage: 'fr' })
                .expect(400)

            expect(response.body.error.code).toBe('VALIDATION_ERROR')
        })

        it('should return 401 without authentication', async () => {
            const response = await request(app)
                .patch('/api/users/profile/language')
                .send({ preferredLanguage: 'en' })
                .expect(401)

            expect(response.body.error.code).toBe('UNAUTHORIZED')
        })
    })

    describe('GET /api/users/team', () => {
        it('should get team members list for admin', async () => {
            // Mock database response for listing users
            mockClient.query.mockResolvedValueOnce({
                rows: [mockUsers.user, mockUsers.admin, mockUsers.member],
                rowCount: 3
            })

            const response = await request(app)
                .get('/api/users/team')
                .set('Authorization', 'Bearer valid-admin-token')
                .expect(200)

            expect(response.body).toHaveProperty('users')
            expect(Array.isArray(response.body.users)).toBe(true)
            expect(response.body.users.length).toBeGreaterThan(0)
            expect(response.body).toHaveProperty('pagination')
            expect(response.body.pagination).toHaveProperty('limit')
            expect(response.body.pagination).toHaveProperty('offset')
        })

        it('should return 403 for member role', async () => {
            const response = await request(app)
                .get('/api/users/team')
                .set('Authorization', 'Bearer valid-member-token')
                .expect(403)

            expect(response.body.error.code).toBe('FORBIDDEN')
        })

        it('should return 401 without authentication', async () => {
            const response = await request(app)
                .get('/api/users/team')
                .expect(401)

            expect(response.body.error.code).toBe('UNAUTHORIZED')
        })
    })

    describe('GET /api/users/:id', () => {
        it('should allow user to get their own profile', async () => {
            // Mock database response with database column names
            mockClient.query.mockResolvedValueOnce({
                rows: [{
                    id: mockUsers.user.id,
                    email: mockUsers.user.email,
                    name: mockUsers.user.name,
                    role: mockUsers.user.role,
                    preferred_language: mockUsers.user.preferredLanguage,
                    created_at: mockUsers.user.createdAt,
                    updated_at: mockUsers.user.updatedAt
                }],
                rowCount: 1
            })

            const response = await request(app)
                .get(`/api/users/${mockUsers.user.id}`)
                .set('Authorization', 'Bearer valid-user-token')
                .expect(200)

            expect(response.body.user.id).toBe(mockUsers.user.id)
            expect(response.body.user.email).toBe(mockUsers.user.email)
        })

        it('should return 400 with invalid user ID format', async () => {
            const response = await request(app)
                .get('/api/users/invalid-id')
                .set('Authorization', 'Bearer valid-admin-token')
                .expect(400)

            expect(response.body.error.code).toBe('VALIDATION_ERROR')
        })

        it('should return 401 without authentication', async () => {
            const response = await request(app)
                .get(`/api/users/${mockUsers.user.id}`)
                .expect(401)

            expect(response.body.error.code).toBe('UNAUTHORIZED')
        })
    })
})