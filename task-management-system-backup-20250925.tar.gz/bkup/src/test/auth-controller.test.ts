/**
 * Unit tests for authentication controllers
 */

import { Request, Response } from 'express'

// Mock the dependencies before importing the controllers
const mockUserRepository = {
    existsByEmail: jest.fn(),
    createUser: jest.fn(),
    findByEmailWithPassword: jest.fn(),
    findById: jest.fn()
}

jest.mock('../server/repositories/user-repository', () => ({
    UserRepository: jest.fn().mockImplementation(() => mockUserRepository)
}))

jest.mock('../server/config/database', () => ({
    getPool: jest.fn().mockReturnValue({})
}))

// Mock auth service functions
jest.mock('../server/services/auth', () => ({
    ...jest.requireActual('../server/services/auth'),
    comparePassword: jest.fn()
}))

// Mock express-validator
const mockValidationResult = {
    isEmpty: jest.fn(),
    array: jest.fn()
}

jest.mock('express-validator', () => ({
    body: jest.fn(() => ({
        isEmail: jest.fn().mockReturnThis(),
        normalizeEmail: jest.fn().mockReturnThis(),
        withMessage: jest.fn().mockReturnThis(),
        trim: jest.fn().mockReturnThis(),
        isLength: jest.fn().mockReturnThis(),
        matches: jest.fn().mockReturnThis(),
        optional: jest.fn().mockReturnThis(),
        isIn: jest.fn().mockReturnThis(),
        notEmpty: jest.fn().mockReturnThis()
    })),
    validationResult: jest.fn(() => mockValidationResult)
}))

// Now import the controllers after mocking
import { register, login, getProfile, refreshToken } from '../server/controllers/auth'
import { comparePassword } from '../server/services/auth'
import { User, UserWithPassword } from '../shared/types/index'

const mockComparePassword = comparePassword as jest.MockedFunction<typeof comparePassword>

// Mock user data
const mockUser: User = {
    id: '123e4567-e89b-12d3-a456-426614174000',
    email: 'test@example.com',
    name: 'Test User',
    role: 'member',
    preferredLanguage: 'ja',
    createdAt: new Date(),
    updatedAt: new Date()
}

const mockUserWithPassword: UserWithPassword = {
    ...mockUser,
    passwordHash: '$2b$12$hashedpassword'
}

// Mock Express request and response objects
const createMockRequest = (body: any = {}, user?: any): Partial<Request> => ({
    body,
    user
})

const createMockResponse = (): Partial<Response> => {
    const res: Partial<Response> = {}
    res.status = jest.fn().mockReturnValue(res)
    res.json = jest.fn().mockReturnValue(res)
    return res
}

describe('Authentication Controllers', () => {
    beforeEach(() => {
        jest.clearAllMocks()
    })

    describe('register', () => {
        const validRegistrationData = {
            email: 'test@example.com',
            name: 'Test User',
            password: 'Password123',
            role: 'member',
            preferredLanguage: 'ja'
        }

        it('should register a new user successfully', async () => {
            // Mock validation success
            mockValidationResult.isEmpty.mockReturnValue(true)

            // Mock repository methods
            mockUserRepository.existsByEmail.mockResolvedValue(false)
            mockUserRepository.createUser.mockResolvedValue(mockUser)

            const req = createMockRequest(validRegistrationData) as Request
            const res = createMockResponse() as Response

            await register(req, res)

            expect(mockUserRepository.existsByEmail).toHaveBeenCalledWith('test@example.com')
            expect(mockUserRepository.createUser).toHaveBeenCalledWith(validRegistrationData)
            expect(res.status).toHaveBeenCalledWith(201)
            expect(res.json).toHaveBeenCalledWith({
                message: 'User registered successfully',
                user: mockUser,
                token: expect.any(String),
                timestamp: expect.any(String)
            })
        })

        it('should return validation error for invalid input', async () => {
            // Mock validation failure
            mockValidationResult.isEmpty.mockReturnValue(false)
            mockValidationResult.array.mockReturnValue([{ msg: 'Invalid email format' }])

            const req = createMockRequest({ email: 'invalid-email' }) as Request
            const res = createMockResponse() as Response

            await register(req, res)

            expect(res.status).toHaveBeenCalledWith(400)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid input data',
                    details: [{ msg: 'Invalid email format' }],
                    timestamp: expect.any(String)
                }
            })
        })

        it('should return conflict error if user already exists', async () => {
            // Mock validation success
            mockValidationResult.isEmpty.mockReturnValue(true)

            // Mock user already exists
            mockUserRepository.existsByEmail.mockResolvedValue(true)

            const req = createMockRequest(validRegistrationData) as Request
            const res = createMockResponse() as Response

            await register(req, res)

            expect(res.status).toHaveBeenCalledWith(409)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'CONFLICT',
                    message: 'User with this email already exists',
                    timestamp: expect.any(String)
                }
            })
        })
    })

    describe('login', () => {
        const validLoginData = {
            email: 'test@example.com',
            password: 'Password123'
        }

        it('should login user successfully with valid credentials', async () => {
            // Mock validation success
            mockValidationResult.isEmpty.mockReturnValue(true)

            // Mock repository method and password comparison
            mockUserRepository.findByEmailWithPassword.mockResolvedValue(mockUserWithPassword)
            mockComparePassword.mockResolvedValue(true)

            const req = createMockRequest(validLoginData) as Request
            const res = createMockResponse() as Response

            await login(req, res)

            expect(mockUserRepository.findByEmailWithPassword).toHaveBeenCalledWith('test@example.com')
            expect(mockComparePassword).toHaveBeenCalledWith('Password123', '$2b$12$hashedpassword')
            expect(res.json).toHaveBeenCalledWith({
                message: 'Login successful',
                user: mockUser,
                token: expect.any(String),
                timestamp: expect.any(String)
            })
        })

        it('should return validation error for invalid input', async () => {
            // Mock validation failure
            mockValidationResult.isEmpty.mockReturnValue(false)
            mockValidationResult.array.mockReturnValue([{ msg: 'Valid email is required' }])

            const req = createMockRequest({ email: 'invalid' }) as Request
            const res = createMockResponse() as Response

            await login(req, res)

            expect(res.status).toHaveBeenCalledWith(400)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid input data',
                    details: [{ msg: 'Valid email is required' }],
                    timestamp: expect.any(String)
                }
            })
        })

        it('should return unauthorized error for non-existent user', async () => {
            // Mock validation success
            mockValidationResult.isEmpty.mockReturnValue(true)

            // Mock user not found
            mockUserRepository.findByEmailWithPassword.mockResolvedValue(null)

            const req = createMockRequest(validLoginData) as Request
            const res = createMockResponse() as Response

            await login(req, res)

            expect(res.status).toHaveBeenCalledWith(401)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Invalid email or password',
                    timestamp: expect.any(String)
                }
            })
        })
    })

    describe('getProfile', () => {
        it('should return user profile for authenticated user', async () => {
            // Mock authenticated user
            const req = createMockRequest({}, { id: mockUser.id }) as Request
            const res = createMockResponse() as Response

            mockUserRepository.findById.mockResolvedValue(mockUser)

            await getProfile(req, res)

            expect(mockUserRepository.findById).toHaveBeenCalledWith(mockUser.id)
            expect(res.json).toHaveBeenCalledWith({
                user: mockUser,
                timestamp: expect.any(String)
            })
        })

        it('should return unauthorized error for unauthenticated user', async () => {
            const req = createMockRequest() as Request
            const res = createMockResponse() as Response

            await getProfile(req, res)

            expect(res.status).toHaveBeenCalledWith(401)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: expect.any(String)
                }
            })
        })

        it('should return not found error if user does not exist', async () => {
            const req = createMockRequest({}, { id: mockUser.id }) as Request
            const res = createMockResponse() as Response

            mockUserRepository.findById.mockResolvedValue(null)

            await getProfile(req, res)

            expect(res.status).toHaveBeenCalledWith(404)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'NOT_FOUND',
                    message: 'User not found',
                    timestamp: expect.any(String)
                }
            })
        })
    })

    describe('refreshToken', () => {
        it('should refresh token for authenticated user', async () => {
            const req = createMockRequest({}, { id: mockUser.id }) as Request
            const res = createMockResponse() as Response

            mockUserRepository.findById.mockResolvedValue(mockUser)

            await refreshToken(req, res)

            expect(mockUserRepository.findById).toHaveBeenCalledWith(mockUser.id)
            expect(res.json).toHaveBeenCalledWith({
                message: 'Token refreshed successfully',
                token: expect.any(String),
                timestamp: expect.any(String)
            })
        })

        it('should return unauthorized error for unauthenticated user', async () => {
            const req = createMockRequest() as Request
            const res = createMockResponse() as Response

            await refreshToken(req, res)

            expect(res.status).toHaveBeenCalledWith(401)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: expect.any(String)
                }
            })
        })
    })
})