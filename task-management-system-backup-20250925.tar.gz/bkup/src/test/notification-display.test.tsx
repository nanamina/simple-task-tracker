import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
// Mock the useTranslation hook
jest.mock('../client/hooks/useTranslation', () => ({
    useTranslation: () => ({
        t: (key: string) => {
            const translations = {
                'notifications.title': 'Notifications',
                'notifications.noNotifications': 'No notifications',
                'notifications.markAllRead': 'Mark all as read',
                'notifications.clearAll': 'Clear all',
                'notifications.showAll': 'Show all {{count}} notifications',
                'notifications.showLess': 'Show less'
            };
            return translations[key] || key;
        }
    })
}));
import NotificationDisplay, { Notification } from '../client/components/NotificationDisplay';

// Test wrapper component
const TestWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <div>{children}</div>
);

// Mock notification data
const createMockNotification = (overrides: Partial<Notification> = {}): Notification => ({
    id: '1',
    type: 'info',
    title: 'Test Notification',
    message: 'This is a test notification message',
    timestamp: new Date('2023-01-01T10:00:00Z'),
    read: false,
    ...overrides
});

const mockNotifications: Notification[] = [
    createMockNotification({
        id: '1',
        type: 'success',
        title: 'Task Completed',
        message: 'Your task has been completed successfully',
        read: false
    }),
    createMockNotification({
        id: '2',
        type: 'warning',
        title: 'Task Overdue',
        message: 'Your task is past its due date',
        read: true
    }),
    createMockNotification({
        id: '3',
        type: 'error',
        title: 'Error Occurred',
        message: 'An error occurred while processing your request',
        read: false,
        actionUrl: '/tasks/123',
        actionLabel: 'View Task'
    })
];

describe('NotificationDisplay Component', () => {
    const mockOnMarkAsRead = jest.fn();
    const mockOnDismiss = jest.fn();
    const mockOnMarkAllAsRead = jest.fn();
    const mockOnClearAll = jest.fn();

    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('renders empty state when no notifications', () => {
        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={[]}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                />
            </TestWrapper>
        );

        expect(screen.getByText('No notifications')).toBeInTheDocument();
    });

    it('renders notifications correctly', () => {
        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={mockNotifications}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                />
            </TestWrapper>
        );

        // Check if notifications are rendered
        expect(screen.getByText('Task Completed')).toBeInTheDocument();
        expect(screen.getByText('Task Overdue')).toBeInTheDocument();
        expect(screen.getByText('Error Occurred')).toBeInTheDocument();

        // Check if messages are rendered
        expect(screen.getByText('Your task has been completed successfully')).toBeInTheDocument();
        expect(screen.getByText('Your task is past its due date')).toBeInTheDocument();
    });

    it('displays unread count correctly', () => {
        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={mockNotifications}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                />
            </TestWrapper>
        );

        // Should show unread count (2 unread notifications)
        expect(screen.getByText('2')).toBeInTheDocument();
    });

    it('shows correct icons for different notification types', () => {
        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={mockNotifications}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                />
            </TestWrapper>
        );

        // Check for different colored icons (by checking SVG elements with specific classes)
        const successIcon = document.querySelector('.text-green-500');
        const warningIcon = document.querySelector('.text-yellow-500');
        const errorIcon = document.querySelector('.text-red-500');

        expect(successIcon).toBeInTheDocument();
        expect(warningIcon).toBeInTheDocument();
        expect(errorIcon).toBeInTheDocument();
    });

    it('calls onMarkAsRead when unread notification is clicked', () => {
        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={mockNotifications}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                />
            </TestWrapper>
        );

        // Click on unread notification
        const unreadNotification = screen.getByText('Task Completed').closest('div');
        fireEvent.click(unreadNotification!);

        expect(mockOnMarkAsRead).toHaveBeenCalledWith('1');
    });

    it('does not call onMarkAsRead when read notification is clicked', () => {
        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={mockNotifications}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                />
            </TestWrapper>
        );

        // Click on read notification
        const readNotification = screen.getByText('Task Overdue').closest('div');
        fireEvent.click(readNotification!);

        expect(mockOnMarkAsRead).not.toHaveBeenCalled();
    });

    it('calls onDismiss when dismiss button is clicked', () => {
        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={mockNotifications}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                />
            </TestWrapper>
        );

        // Click dismiss button on first notification
        const dismissButtons = screen.getAllByLabelText('Dismiss notification');
        fireEvent.click(dismissButtons[0]);

        expect(mockOnDismiss).toHaveBeenCalledWith('1');
    });

    it('calls onMarkAllAsRead when mark all as read is clicked', () => {
        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={mockNotifications}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                />
            </TestWrapper>
        );

        const markAllButton = screen.getByText('Mark all as read');
        fireEvent.click(markAllButton);

        expect(mockOnMarkAllAsRead).toHaveBeenCalled();
    });

    it('calls onClearAll when clear all is clicked', () => {
        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={mockNotifications}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                />
            </TestWrapper>
        );

        const clearAllButton = screen.getByText('Clear all');
        fireEvent.click(clearAllButton);

        expect(mockOnClearAll).toHaveBeenCalled();
    });

    it('handles action button clicks correctly', () => {
        // Mock window.location.href
        delete (window as any).location;
        window.location = { href: '' } as any;

        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={mockNotifications}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                />
            </TestWrapper>
        );

        const actionButton = screen.getByText('View Task');
        fireEvent.click(actionButton);

        expect(window.location.href).toBe('/tasks/123');
    });

    it('sorts notifications correctly (unread first, then by timestamp)', () => {
        const notifications = [
            createMockNotification({
                id: '1',
                title: 'Old Read',
                timestamp: new Date('2023-01-01'),
                read: true
            }),
            createMockNotification({
                id: '2',
                title: 'New Unread',
                timestamp: new Date('2023-01-03'),
                read: false
            }),
            createMockNotification({
                id: '3',
                title: 'Old Unread',
                timestamp: new Date('2023-01-02'),
                read: false
            })
        ];

        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={notifications}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                />
            </TestWrapper>
        );

        const titles = screen.getAllByRole('heading', { level: 4 });
        expect(titles[0]).toHaveTextContent('New Unread'); // Newest unread first
        expect(titles[1]).toHaveTextContent('Old Unread'); // Older unread second
        expect(titles[2]).toHaveTextContent('Old Read'); // Read notifications last
    });

    it('limits visible notifications based on maxVisible prop', () => {
        const manyNotifications = Array.from({ length: 15 }, (_, i) =>
            createMockNotification({
                id: `${i + 1}`,
                title: `Notification ${i + 1}`
            })
        );

        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={manyNotifications}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                    maxVisible={5}
                />
            </TestWrapper>
        );

        // Should only show 5 notifications initially
        expect(screen.getAllByRole('heading', { level: 4 })).toHaveLength(5);

        // Should show "Show all" button
        expect(screen.getByText('Show all 15 notifications')).toBeInTheDocument();
    });

    it('toggles show all functionality', () => {
        const manyNotifications = Array.from({ length: 15 }, (_, i) =>
            createMockNotification({
                id: `${i + 1}`,
                title: `Notification ${i + 1}`
            })
        );

        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={manyNotifications}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                    maxVisible={5}
                />
            </TestWrapper>
        );

        // Click show all
        const showAllButton = screen.getByText('Show all 15 notifications');
        fireEvent.click(showAllButton);

        // Should now show all notifications
        expect(screen.getAllByRole('heading', { level: 4 })).toHaveLength(15);

        // Button should change to "Show less"
        expect(screen.getByText('Show less')).toBeInTheDocument();
    });

    it('displays timestamps correctly', () => {
        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={mockNotifications}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                />
            </TestWrapper>
        );

        // Check if timestamp is formatted correctly
        const expectedTimestamp = new Date('2023-01-01T10:00:00Z').toLocaleString();
        expect(screen.getByText(expectedTimestamp)).toBeInTheDocument();
    });

    it('does not show mark all as read button when no unread notifications', () => {
        const readNotifications = mockNotifications.map(n => ({ ...n, read: true }));

        render(
            <TestWrapper>
                <NotificationDisplay
                    notifications={readNotifications}
                    onMarkAsRead={mockOnMarkAsRead}
                    onDismiss={mockOnDismiss}
                    onMarkAllAsRead={mockOnMarkAllAsRead}
                    onClearAll={mockOnClearAll}
                />
            </TestWrapper>
        );

        expect(screen.queryByText('Mark all as read')).not.toBeInTheDocument();
    });
});