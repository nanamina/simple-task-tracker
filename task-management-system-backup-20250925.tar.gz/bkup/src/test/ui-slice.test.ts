import { configureStore } from '@reduxjs/toolkit'
import uiSlice, {
    setLanguage,
    addNotification,
    removeNotification,
    clearAllNotifications,
    toggleSidebar,
    setSidebarOpen,
    setTheme,
    setGlobalLoading,
    initializeUIState,
} from '../client/store/slices/uiSlice'

// Mock localStorage for testing
const localStorageMock = {
    getItem: jest.fn(),
    setItem: jest.fn(),
    removeItem: jest.fn(),
    clear: jest.fn(),
}

// Replace the global localStorage with our mock
Object.defineProperty(window, 'localStorage', {
    value: localStorageMock,
})

describe('uiSlice', () => {
    let store: ReturnType<typeof configureStore>

    beforeEach(() => {
        // Create a fresh store for each test
        store = configureStore({
            reducer: {
                ui: uiSlice,
            },
        })

        // Clear all mocks
        jest.clearAllMocks()
    })

    describe('initial state', () => {
        it('should have correct initial state', () => {
            const state = store.getState().ui

            expect(state.language).toBe('ja') // Japanese as default
            expect(state.notifications).toEqual([])
            expect(state.sidebarOpen).toBe(true)
            expect(state.theme).toBe('light')
            expect(state.loading).toEqual({
                global: false,
                tasks: false,
                projects: false,
                auth: false,
            })
        })
    })

    describe('language management', () => {
        it('should set language to English', () => {
            store.dispatch(setLanguage('en'))

            const state = store.getState().ui
            expect(state.language).toBe('en')
            expect(localStorageMock.setItem).toHaveBeenCalledWith('preferredLanguage', 'en')
        })

        it('should set language to Japanese', () => {
            store.dispatch(setLanguage('ja'))

            const state = store.getState().ui
            expect(state.language).toBe('ja')
            expect(localStorageMock.setItem).toHaveBeenCalledWith('preferredLanguage', 'ja')
        })
    })

    describe('notification management', () => {
        it('should add a notification with auto-generated id and timestamp', () => {
            const notificationData = {
                type: 'success' as const,
                message: 'Task created successfully',
            }

            store.dispatch(addNotification(notificationData))

            const state = store.getState().ui
            expect(state.notifications).toHaveLength(1)

            const notification = state.notifications[0]
            expect(notification.type).toBe('success')
            expect(notification.message).toBe('Task created successfully')
            expect(notification.id).toMatch(/^notification-\d+-[a-z0-9]+$/)
            expect(typeof notification.timestamp).toBe('string')
            expect(new Date(notification.timestamp)).toBeInstanceOf(Date)
            expect(notification.autoHide).toBe(true)
            expect(notification.duration).toBe(5000)
        })

        it('should add notification with custom autoHide and duration', () => {
            const notificationData = {
                type: 'error' as const,
                message: 'Failed to save task',
                autoHide: false,
                duration: 10000,
            }

            store.dispatch(addNotification(notificationData))

            const state = store.getState().ui
            const notification = state.notifications[0]
            expect(notification.autoHide).toBe(false)
            expect(notification.duration).toBe(10000)
        })

        it('should remove notification by id', () => {
            // Add two notifications
            store.dispatch(addNotification({ type: 'info', message: 'First notification' }))
            store.dispatch(addNotification({ type: 'warning', message: 'Second notification' }))

            let state = store.getState().ui
            expect(state.notifications).toHaveLength(2)

            const firstNotificationId = state.notifications[0].id

            // Remove first notification
            store.dispatch(removeNotification(firstNotificationId))

            state = store.getState().ui
            expect(state.notifications).toHaveLength(1)
            expect(state.notifications[0].message).toBe('Second notification')
        })

        it('should clear all notifications', () => {
            // Add multiple notifications
            store.dispatch(addNotification({ type: 'info', message: 'First' }))
            store.dispatch(addNotification({ type: 'success', message: 'Second' }))
            store.dispatch(addNotification({ type: 'error', message: 'Third' }))

            let state = store.getState().ui
            expect(state.notifications).toHaveLength(3)

            // Clear all
            store.dispatch(clearAllNotifications())

            state = store.getState().ui
            expect(state.notifications).toHaveLength(0)
        })
    })

    describe('sidebar management', () => {
        it('should toggle sidebar state', () => {
            // Initial state is true
            let state = store.getState().ui
            expect(state.sidebarOpen).toBe(true)

            // Toggle to false
            store.dispatch(toggleSidebar())
            state = store.getState().ui
            expect(state.sidebarOpen).toBe(false)

            // Toggle back to true
            store.dispatch(toggleSidebar())
            state = store.getState().ui
            expect(state.sidebarOpen).toBe(true)
        })

        it('should set sidebar open state directly', () => {
            store.dispatch(setSidebarOpen(false))

            let state = store.getState().ui
            expect(state.sidebarOpen).toBe(false)

            store.dispatch(setSidebarOpen(true))

            state = store.getState().ui
            expect(state.sidebarOpen).toBe(true)
        })
    })

    describe('theme management', () => {
        it('should set theme and save to localStorage', () => {
            store.dispatch(setTheme('dark'))

            const state = store.getState().ui
            expect(state.theme).toBe('dark')
            expect(localStorageMock.setItem).toHaveBeenCalledWith('theme', 'dark')
        })
    })

    describe('loading state management', () => {
        it('should set global loading state', () => {
            store.dispatch(setGlobalLoading(true))

            const state = store.getState().ui
            expect(state.loading.global).toBe(true)
        })

        it('should manage individual loading states independently', () => {
            // Set different loading states
            store.dispatch(setGlobalLoading(true))

            const state = store.getState().ui
            expect(state.loading.global).toBe(true)
            expect(state.loading.tasks).toBe(false)
            expect(state.loading.projects).toBe(false)
            expect(state.loading.auth).toBe(false)
        })
    })

    describe('initialization from localStorage', () => {
        it('should initialize language from localStorage', () => {
            localStorageMock.getItem.mockImplementation((key) => {
                if (key === 'preferredLanguage') return 'en'
                if (key === 'theme') return 'dark'
                return null
            })

            store.dispatch(initializeUIState())

            const state = store.getState().ui
            expect(state.language).toBe('en')
            expect(state.theme).toBe('dark')
        })

        it('should ignore invalid values from localStorage', () => {
            localStorageMock.getItem.mockImplementation((key) => {
                if (key === 'preferredLanguage') return 'invalid-language'
                if (key === 'theme') return 'invalid-theme'
                return null
            })

            store.dispatch(initializeUIState())

            const state = store.getState().ui
            // Should keep default values when localStorage has invalid data
            expect(state.language).toBe('ja')
            expect(state.theme).toBe('light')
        })

        it('should handle missing localStorage values gracefully', () => {
            localStorageMock.getItem.mockReturnValue(null)

            store.dispatch(initializeUIState())

            const state = store.getState().ui
            // Should keep default values when localStorage is empty
            expect(state.language).toBe('ja')
            expect(state.theme).toBe('light')
        })
    })
})