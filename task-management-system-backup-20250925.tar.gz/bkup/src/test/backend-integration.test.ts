/**
 * Comprehensive backend integration tests
 * Tests the full API endpoints with database integration
 */

import request from 'supertest'
import express from 'express'
import { Pool } from 'pg'
import { Server } from 'http'

// Import routes
import authRoutes from '@/server/routes/auth'
import taskRoutes from '@/server/routes/task'
import projectRoutes from '@/server/routes/project'
import userRoutes from '@/server/routes/user'

// Import middleware
import { errorHandler } from '@/server/middleware/errorHandler'
import { authenticateToken } from '@/server/middleware/auth'

// Import types
import { User, Task, Project } from '@/shared/types'

// Mock database pool
const mockClient = {
    query: jest.fn(),
    release: jest.fn(),
}

const mockPool = {
    connect: jest.fn(() => Promise.resolve(mockClient)),
    query: jest.fn(),
    end: jest.fn(),
} as unknown as Pool

// Mock database module
jest.mock('@/server/config/database', () => ({
    getPool: jest.fn(() => mockPool),
    testConnection: jest.fn(() => Promise.resolve()),
}))

// Mock JWT for testing
jest.mock('jsonwebtoken', () => ({
    sign: jest.fn(() => 'mock-jwt-token'),
    verify: jest.fn(() => ({ userId: 'test-user-id', email: 'test@example.com' })),
}))

// Mock bcrypt
jest.mock('bcrypt', () => ({
    hash: jest.fn(() => Promise.resolve('hashed-password')),
    compare: jest.fn(() => Promise.resolve(true)),
}))

// Test data
const mockUser: User = {
    id: 'user-123',
    email: 'test@example.com',
    name: 'Test User',
    role: 'manager',
    preferredLanguage: 'ja',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
}

const mockTask: Task = {
    id: 'task-123',
    title: 'Test Task',
    description: 'Test task description',
    status: 'todo',
    priority: 'medium',
    dueDate: new Date('2024-12-31'),
    assigneeId: 'user-123',
    projectId: 'project-123',
    createdBy: 'user-123',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
}

const mockProject: Project = {
    id: 'project-123',
    name: 'Test Project',
    description: 'Test project description',
    createdBy: 'user-123',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
    members: ['user-123'],
}

// Create Express app for testing
const createTestApp = () => {
    const app = express()
    app.use(express.json())

    // Add routes
    app.use('/api/auth', authRoutes)
    app.use('/api/tasks', taskRoutes)
    app.use('/api/projects', projectRoutes)
    app.use('/api/users', userRoutes)

    // Add error handler
    app.use(errorHandler)

    return app
}

describe('Backend Integration Tests', () => {
    let app: express.Application
    let server: Server

    beforeAll(() => {
        app = createTestApp()
        server = app.listen(0) // Use random available port
    })

    afterAll((done) => {
        server.close(done)
    })

    beforeEach(() => {
        jest.clearAllMocks()
        mockClient.query.mockClear()
        mockPool.query.mockClear()
    })

    describe('Authentication Endpoints', () => {
        describe('POST /api/auth/register', () => {
            test('should register a new user successfully', async () => {
                mockClient.query
                    .mockResolvedValueOnce({ rows: [] }) // Check if user exists
                    .mockResolvedValueOnce({ rows: [{ ...mockUser, id: 'new-user-id' }] }) // Insert user

                const response = await request(app)
                    .post('/api/auth/register')
                    .send({
                        name: 'New User',
                        email: 'newuser@example.com',
                        password: 'password123',
                        role: 'member',
                    })

                expect(response.status).toBe(201)
                expect(response.body.success).toBe(true)
                expect(response.body.data.user).toBeDefined()
                expect(response.body.data.token).toBeDefined()
                expect(mockClient.query).toHaveBeenCalledTimes(2)
            })

            test('should return error for duplicate email', async () => {
                mockClient.query.mockResolvedValueOnce({ rows: [mockUser] }) // User already exists

                const response = await request(app)
                    .post('/api/auth/register')
                    .send({
                        name: 'Test User',
                        email: 'test@example.com',
                        password: 'password123',
                        role: 'member',
                    })

                expect(response.status).toBe(409)
                expect(response.body.success).toBe(false)
                expect(response.body.error.code).toBe('USER_EXISTS')
            })

            test('should validate required fields', async () => {
                const response = await request(app)
                    .post('/api/auth/register')
                    .send({
                        name: 'Test User',
                        // Missing email and password
                    })

                expect(response.status).toBe(400)
                expect(response.body.success).toBe(false)
                expect(response.body.error.code).toBe('VALIDATION_ERROR')
            })
        })

        describe('POST /api/auth/login', () => {
            test('should login user with valid credentials', async () => {
                mockClient.query.mockResolvedValueOnce({
                    rows: [{ ...mockUser, password_hash: 'hashed-password' }]
                })

                const response = await request(app)
                    .post('/api/auth/login')
                    .send({
                        email: 'test@example.com',
                        password: 'password123',
                    })

                expect(response.status).toBe(200)
                expect(response.body.success).toBe(true)
                expect(response.body.data.user).toBeDefined()
                expect(response.body.data.token).toBeDefined()
            })

            test('should return error for invalid credentials', async () => {
                mockClient.query.mockResolvedValueOnce({ rows: [] }) // User not found

                const response = await request(app)
                    .post('/api/auth/login')
                    .send({
                        email: 'nonexistent@example.com',
                        password: 'password123',
                    })

                expect(response.status).toBe(401)
                expect(response.body.success).toBe(false)
                expect(response.body.error.code).toBe('INVALID_CREDENTIALS')
            })
        })
    })

    describe('Task Endpoints', () => {
        // Mock authentication middleware for task tests
        beforeEach(() => {
            jest.doMock('@/server/middleware/auth', () => ({
                authenticateToken: (req: any, res: any, next: any) => {
                    req.user = { id: 'user-123', email: 'test@example.com' }
                    next()
                },
            }))
        })

        describe('GET /api/tasks', () => {
            test('should return paginated tasks', async () => {
                mockClient.query.mockResolvedValueOnce({
                    rows: [mockTask],
                    rowCount: 1,
                })

                const response = await request(app)
                    .get('/api/tasks')
                    .set('Authorization', 'Bearer mock-token')

                expect(response.status).toBe(200)
                expect(response.body.success).toBe(true)
                expect(response.body.data).toHaveLength(1)
                expect(response.body.data[0].title).toBe('Test Task')
                expect(response.body.meta.count).toBe(1)
            })

            test('should filter tasks by status', async () => {
                mockClient.query.mockResolvedValueOnce({
                    rows: [{ ...mockTask, status: 'completed' }],
                    rowCount: 1,
                })

                const response = await request(app)
                    .get('/api/tasks?status=completed')
                    .set('Authorization', 'Bearer mock-token')

                expect(response.status).toBe(200)
                expect(response.body.data[0].status).toBe('completed')
                expect(mockClient.query).toHaveBeenCalledWith(
                    expect.stringContaining('WHERE'),
                    expect.arrayContaining(['completed'])
                )
            })

            test('should sort tasks by due date', async () => {
                mockClient.query.mockResolvedValueOnce({
                    rows: [mockTask],
                    rowCount: 1,
                })

                const response = await request(app)
                    .get('/api/tasks?sortBy=dueDate&sortOrder=asc')
                    .set('Authorization', 'Bearer mock-token')

                expect(response.status).toBe(200)
                expect(mockClient.query).toHaveBeenCalledWith(
                    expect.stringContaining('ORDER BY due_date ASC'),
                    expect.any(Array)
                )
            })
        })

        describe('POST /api/tasks', () => {
            test('should create a new task', async () => {
                mockClient.query.mockResolvedValueOnce({
                    rows: [{ ...mockTask, id: 'new-task-id' }],
                })

                const response = await request(app)
                    .post('/api/tasks')
                    .set('Authorization', 'Bearer mock-token')
                    .send({
                        title: 'New Task',
                        description: 'New task description',
                        priority: 'high',
                        dueDate: '2024-12-31',
                    })

                expect(response.status).toBe(201)
                expect(response.body.success).toBe(true)
                expect(response.body.data.title).toBe('New Task')
                expect(mockClient.query).toHaveBeenCalledWith(
                    expect.stringContaining('INSERT INTO tasks'),
                    expect.arrayContaining(['New Task', 'New task description'])
                )
            })

            test('should validate required fields', async () => {
                const response = await request(app)
                    .post('/api/tasks')
                    .set('Authorization', 'Bearer mock-token')
                    .send({
                        // Missing title and description
                        priority: 'medium',
                    })

                expect(response.status).toBe(400)
                expect(response.body.success).toBe(false)
                expect(response.body.error.code).toBe('VALIDATION_ERROR')
            })
        })

        describe('PUT /api/tasks/:id', () => {
            test('should update an existing task', async () => {
                mockClient.query
                    .mockResolvedValueOnce({ rows: [mockTask] }) // Check if task exists
                    .mockResolvedValueOnce({ rows: [{ ...mockTask, title: 'Updated Task' }] }) // Update task

                const response = await request(app)
                    .put('/api/tasks/task-123')
                    .set('Authorization', 'Bearer mock-token')
                    .send({
                        title: 'Updated Task',
                        description: 'Updated description',
                        priority: 'critical',
                    })

                expect(response.status).toBe(200)
                expect(response.body.success).toBe(true)
                expect(response.body.data.title).toBe('Updated Task')
            })

            test('should return 404 for non-existent task', async () => {
                mockClient.query.mockResolvedValueOnce({ rows: [] }) // Task not found

                const response = await request(app)
                    .put('/api/tasks/non-existent-id')
                    .set('Authorization', 'Bearer mock-token')
                    .send({
                        title: 'Updated Task',
                    })

                expect(response.status).toBe(404)
                expect(response.body.success).toBe(false)
                expect(response.body.error.code).toBe('TASK_NOT_FOUND')
            })
        })

        describe('DELETE /api/tasks/:id', () => {
            test('should delete an existing task', async () => {
                mockClient.query
                    .mockResolvedValueOnce({ rows: [mockTask] }) // Check if task exists
                    .mockResolvedValueOnce({ rowCount: 1 }) // Delete task

                const response = await request(app)
                    .delete('/api/tasks/task-123')
                    .set('Authorization', 'Bearer mock-token')

                expect(response.status).toBe(200)
                expect(response.body.success).toBe(true)
                expect(mockClient.query).toHaveBeenCalledWith(
                    expect.stringContaining('DELETE FROM tasks'),
                    ['task-123']
                )
            })
        })

        describe('PATCH /api/tasks/:id/status', () => {
            test('should update task status', async () => {
                mockClient.query
                    .mockResolvedValueOnce({ rows: [mockTask] }) // Check if task exists
                    .mockResolvedValueOnce({ rows: [{ ...mockTask, status: 'completed' }] }) // Update status

                const response = await request(app)
                    .patch('/api/tasks/task-123/status')
                    .set('Authorization', 'Bearer mock-token')
                    .send({
                        status: 'completed',
                    })

                expect(response.status).toBe(200)
                expect(response.body.success).toBe(true)
                expect(response.body.data.status).toBe('completed')
            })

            test('should validate status value', async () => {
                const response = await request(app)
                    .patch('/api/tasks/task-123/status')
                    .set('Authorization', 'Bearer mock-token')
                    .send({
                        status: 'invalid-status',
                    })

                expect(response.status).toBe(400)
                expect(response.body.success).toBe(false)
                expect(response.body.error.code).toBe('VALIDATION_ERROR')
            })
        })
    })

    describe('Project Endpoints', () => {
        beforeEach(() => {
            jest.doMock('@/server/middleware/auth', () => ({
                authenticateToken: (req: any, res: any, next: any) => {
                    req.user = { id: 'user-123', email: 'test@example.com', role: 'manager' }
                    next()
                },
            }))
        })

        describe('GET /api/projects', () => {
            test('should return user projects', async () => {
                mockClient.query.mockResolvedValueOnce({
                    rows: [mockProject],
                    rowCount: 1,
                })

                const response = await request(app)
                    .get('/api/projects')
                    .set('Authorization', 'Bearer mock-token')

                expect(response.status).toBe(200)
                expect(response.body.success).toBe(true)
                expect(response.body.data).toHaveLength(1)
                expect(response.body.data[0].name).toBe('Test Project')
            })
        })

        describe('POST /api/projects', () => {
            test('should create a new project', async () => {
                mockClient.query.mockResolvedValueOnce({
                    rows: [{ ...mockProject, id: 'new-project-id' }],
                })

                const response = await request(app)
                    .post('/api/projects')
                    .set('Authorization', 'Bearer mock-token')
                    .send({
                        name: 'New Project',
                        description: 'New project description',
                    })

                expect(response.status).toBe(201)
                expect(response.body.success).toBe(true)
                expect(response.body.data.name).toBe('New Project')
            })

            test('should require manager role or higher', async () => {
                jest.doMock('@/server/middleware/auth', () => ({
                    authenticateToken: (req: any, res: any, next: any) => {
                        req.user = { id: 'user-123', email: 'test@example.com', role: 'member' }
                        next()
                    },
                }))

                const response = await request(app)
                    .post('/api/projects')
                    .set('Authorization', 'Bearer mock-token')
                    .send({
                        name: 'New Project',
                        description: 'New project description',
                    })

                expect(response.status).toBe(403)
                expect(response.body.success).toBe(false)
                expect(response.body.error.code).toBe('INSUFFICIENT_PERMISSIONS')
            })
        })
    })

    describe('User Endpoints', () => {
        beforeEach(() => {
            jest.doMock('@/server/middleware/auth', () => ({
                authenticateToken: (req: any, res: any, next: any) => {
                    req.user = { id: 'user-123', email: 'test@example.com' }
                    next()
                },
            }))
        })

        describe('GET /api/users/profile', () => {
            test('should return user profile', async () => {
                mockClient.query.mockResolvedValueOnce({
                    rows: [mockUser],
                })

                const response = await request(app)
                    .get('/api/users/profile')
                    .set('Authorization', 'Bearer mock-token')

                expect(response.status).toBe(200)
                expect(response.body.success).toBe(true)
                expect(response.body.data.email).toBe('test@example.com')
            })
        })

        describe('PUT /api/users/profile', () => {
            test('should update user profile', async () => {
                mockClient.query
                    .mockResolvedValueOnce({ rows: [mockUser] }) // Get current user
                    .mockResolvedValueOnce({ rows: [{ ...mockUser, name: 'Updated Name' }] }) // Update user

                const response = await request(app)
                    .put('/api/users/profile')
                    .set('Authorization', 'Bearer mock-token')
                    .send({
                        name: 'Updated Name',
                        preferredLanguage: 'en',
                    })

                expect(response.status).toBe(200)
                expect(response.body.success).toBe(true)
                expect(response.body.data.name).toBe('Updated Name')
            })
        })
    })

    describe('Error Handling', () => {
        test('should handle database connection errors', async () => {
            mockClient.query.mockRejectedValueOnce(new Error('Database connection failed'))

            const response = await request(app)
                .get('/api/tasks')
                .set('Authorization', 'Bearer mock-token')

            expect(response.status).toBe(500)
            expect(response.body.success).toBe(false)
            expect(response.body.error.code).toBe('INTERNAL_ERROR')
        })

        test('should handle invalid JSON in request body', async () => {
            const response = await request(app)
                .post('/api/tasks')
                .set('Authorization', 'Bearer mock-token')
                .set('Content-Type', 'application/json')
                .send('invalid json')

            expect(response.status).toBe(400)
            expect(response.body.success).toBe(false)
        })

        test('should handle missing authorization header', async () => {
            const response = await request(app)
                .get('/api/tasks')

            expect(response.status).toBe(401)
            expect(response.body.success).toBe(false)
            expect(response.body.error.code).toBe('UNAUTHORIZED')
        })
    })

    describe('Performance Tests', () => {
        test('should handle large number of tasks efficiently', async () => {
            const largeMockData = Array.from({ length: 1000 }, (_, i) => ({
                ...mockTask,
                id: `task-${i}`,
                title: `Task ${i}`,
            }))

            mockClient.query.mockResolvedValueOnce({
                rows: largeMockData,
                rowCount: 1000,
            })

            const startTime = Date.now()
            const response = await request(app)
                .get('/api/tasks')
                .set('Authorization', 'Bearer mock-token')

            const endTime = Date.now()
            const responseTime = endTime - startTime

            expect(response.status).toBe(200)
            expect(response.body.data).toHaveLength(1000)
            expect(responseTime).toBeLessThan(1000) // Should respond within 1 second
        })

        test('should handle concurrent requests', async () => {
            mockClient.query.mockResolvedValue({
                rows: [mockTask],
                rowCount: 1,
            })

            const requests = Array.from({ length: 10 }, () =>
                request(app)
                    .get('/api/tasks')
                    .set('Authorization', 'Bearer mock-token')
            )

            const responses = await Promise.all(requests)

            responses.forEach(response => {
                expect(response.status).toBe(200)
                expect(response.body.success).toBe(true)
            })
        })
    })
})