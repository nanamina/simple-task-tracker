import { configureStore } from '@reduxjs/toolkit'
import { store } from '../client/store'
import authSlice from '../client/store/slices/authSlice'
import taskSlice from '../client/store/slices/taskSlice'
import projectSlice from '../client/store/slices/projectSlice'
import uiSlice, {
    addNotification,
    setLanguage,
    toggleSidebar,
    setTheme
} from '../client/store/slices/uiSlice'

// Mock localStorage
const localStorageMock = {
    getItem: jest.fn(),
    setItem: jest.fn(),
    removeItem: jest.fn(),
    clear: jest.fn(),
}
Object.defineProperty(window, 'localStorage', { value: localStorageMock })

describe('Redux Store Integration', () => {
    beforeEach(() => {
        jest.clearAllMocks()
    })

    describe('store configuration', () => {
        it('should have all required slices', () => {
            const state = store.getState()

            expect(state.auth).toBeDefined()
            expect(state.tasks).toBeDefined()
            expect(state.projects).toBeDefined()
            expect(state.ui).toBeDefined()
        })

        it('should have correct initial state structure', () => {
            const state = store.getState()

            // Auth slice
            expect(state.auth.user).toBeNull()
            expect(state.auth.isAuthenticated).toBe(false)

            // Tasks slice
            expect(state.tasks.tasks).toEqual([])
            expect(state.tasks.loading).toBe(false)

            // Projects slice
            expect(state.projects.projects).toEqual([])
            expect(state.projects.currentProject).toBeNull()

            // UI slice
            expect(state.ui.language).toBe('ja')
            expect(state.ui.notifications).toEqual([])
            expect(state.ui.sidebarOpen).toBe(true)
            expect(state.ui.theme).toBe('light')
        })
    })

    describe('cross-slice interactions', () => {
        let testStore: ReturnType<typeof configureStore>

        beforeEach(() => {
            testStore = configureStore({
                reducer: {
                    auth: authSlice,
                    tasks: taskSlice,
                    projects: projectSlice,
                    ui: uiSlice,
                },
            })
        })

        it('should handle UI state changes independently', () => {
            // Change language
            testStore.dispatch(setLanguage('en'))
            let state = testStore.getState()
            expect(state.ui.language).toBe('en')

            // Toggle sidebar
            testStore.dispatch(toggleSidebar())
            state = testStore.getState()
            expect(state.ui.sidebarOpen).toBe(false)

            // Change theme
            testStore.dispatch(setTheme('dark'))
            state = testStore.getState()
            expect(state.ui.theme).toBe('dark')

            // Verify other slices are unaffected
            expect(state.auth.user).toBeNull()
            expect(state.tasks.tasks).toEqual([])
            expect(state.projects.projects).toEqual([])
        })

        it('should manage notifications correctly', () => {
            // Add multiple notifications
            testStore.dispatch(addNotification({
                type: 'success',
                message: 'Task created successfully'
            }))

            testStore.dispatch(addNotification({
                type: 'error',
                message: 'Failed to save project',
                autoHide: false
            }))

            const state = testStore.getState()
            expect(state.ui.notifications).toHaveLength(2)

            const successNotification = state.ui.notifications.find(n => n.type === 'success')
            const errorNotification = state.ui.notifications.find(n => n.type === 'error')

            expect(successNotification?.message).toBe('Task created successfully')
            expect(successNotification?.autoHide).toBe(true)
            expect(successNotification?.duration).toBe(5000)

            expect(errorNotification?.message).toBe('Failed to save project')
            expect(errorNotification?.autoHide).toBe(false)
        })

        it('should persist language preference to localStorage', () => {
            testStore.dispatch(setLanguage('en'))

            expect(localStorageMock.setItem).toHaveBeenCalledWith('preferredLanguage', 'en')
        })

        it('should persist theme preference to localStorage', () => {
            testStore.dispatch(setTheme('dark'))

            expect(localStorageMock.setItem).toHaveBeenCalledWith('theme', 'dark')
        })
    })

    describe('type safety', () => {
        it('should provide correct TypeScript types', () => {
            const state = store.getState()

            // Test that TypeScript correctly infers types
            const language: 'ja' | 'en' = state.ui.language
            const isAuthenticated: boolean = state.auth.isAuthenticated
            const taskCount: number = state.tasks.tasks.length
            const projectCount: number = state.projects.projects.length

            expect(typeof language).toBe('string')
            expect(typeof isAuthenticated).toBe('boolean')
            expect(typeof taskCount).toBe('number')
            expect(typeof projectCount).toBe('number')
        })
    })
})