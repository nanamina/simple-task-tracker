/**
 * Unit tests for authorization middleware and utilities
 */

import { Request, Response, NextFunction } from 'express'
import {
    PERMISSIONS,
    hasPermission,
    canAccess,
    requirePermission,
    requireOwnershipOrPermission,
    requireRoleLevel,
    getUserPermissions,
    getResourcePermissions,
    hasRoleLevel
} from '../server/middleware/authorization'
import { UserRole } from '../shared/types/index'

// Mock Express request and response objects
const createMockRequest = (user?: any, params?: any, body?: any): Partial<Request> => ({
    user,
    params: params || {},
    body: body || {}
})

const createMockResponse = (): Partial<Response> => {
    const res: Partial<Response> = {}
    res.status = jest.fn().mockReturnValue(res)
    res.json = jest.fn().mockReturnValue(res)
    return res
}

const mockNext: NextFunction = jest.fn()

describe('Authorization System', () => {
    beforeEach(() => {
        jest.clearAllMocks()
    })

    describe('hasPermission', () => {
        it('should return true for admin with any permission', () => {
            expect(hasPermission('admin', 'users:create')).toBe(true)
            expect(hasPermission('admin', 'projects:delete')).toBe(true)
            expect(hasPermission('admin', 'tasks:assign')).toBe(true)
        })

        it('should return true for manager with manager permissions', () => {
            expect(hasPermission('manager', 'projects:create')).toBe(true)
            expect(hasPermission('manager', 'tasks:assign')).toBe(true)
            expect(hasPermission('manager', 'reports:view')).toBe(true)
        })

        it('should return false for manager with admin-only permissions', () => {
            expect(hasPermission('manager', 'users:create')).toBe(false)
            expect(hasPermission('manager', 'users:delete')).toBe(false)
            expect(hasPermission('manager', 'projects:delete')).toBe(false)
        })

        it('should return true for member with basic permissions', () => {
            expect(hasPermission('member', 'tasks:create')).toBe(true)
            expect(hasPermission('member', 'tasks:read')).toBe(true)
            expect(hasPermission('member', 'projects:read')).toBe(true)
        })

        it('should return false for member with restricted permissions', () => {
            expect(hasPermission('member', 'users:create')).toBe(false)
            expect(hasPermission('member', 'projects:create')).toBe(false)
            expect(hasPermission('member', 'tasks:delete')).toBe(false)
            expect(hasPermission('member', 'reports:view')).toBe(false)
        })

        it('should return false for non-existent permission', () => {
            expect(hasPermission('admin', 'nonexistent:permission')).toBe(false)
        })
    })

    describe('canAccess', () => {
        it('should return correct access for resource and action combinations', () => {
            expect(canAccess('admin', 'users', 'create')).toBe(true)
            expect(canAccess('manager', 'projects', 'create')).toBe(true)
            expect(canAccess('member', 'tasks', 'create')).toBe(true)

            expect(canAccess('member', 'users', 'create')).toBe(false)
            expect(canAccess('member', 'projects', 'delete')).toBe(false)
        })
    })

    describe('requirePermission middleware', () => {
        it('should allow access for user with required permission', () => {
            const req = createMockRequest({ id: '1', role: 'admin' }) as Request
            const res = createMockResponse() as Response
            const middleware = requirePermission('users:create')

            middleware(req, res, mockNext)

            expect(mockNext).toHaveBeenCalled()
            expect(res.status).not.toHaveBeenCalled()
        })

        it('should deny access for user without required permission', () => {
            const req = createMockRequest({ id: '1', role: 'member' }) as Request
            const res = createMockResponse() as Response
            const middleware = requirePermission('users:create')

            middleware(req, res, mockNext)

            expect(res.status).toHaveBeenCalledWith(403)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied. Required permission: users:create',
                    details: {
                        resource: 'users',
                        action: 'create',
                        requiredRoles: ['admin']
                    },
                    timestamp: expect.any(String)
                }
            })
            expect(mockNext).not.toHaveBeenCalled()
        })

        it('should deny access for unauthenticated user', () => {
            const req = createMockRequest() as Request
            const res = createMockResponse() as Response
            const middleware = requirePermission('users:create')

            middleware(req, res, mockNext)

            expect(res.status).toHaveBeenCalledWith(401)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: expect.any(String)
                }
            })
            expect(mockNext).not.toHaveBeenCalled()
        })
    })

    describe('requireOwnershipOrPermission middleware', () => {
        const getResourceOwnerId = (req: Request) => req.params.userId

        it('should allow access for resource owner', () => {
            const req = createMockRequest(
                { id: 'user123', role: 'member' },
                { userId: 'user123' }
            ) as Request
            const res = createMockResponse() as Response
            const middleware = requireOwnershipOrPermission(getResourceOwnerId, 'users:update')

            middleware(req, res, mockNext)

            expect(mockNext).toHaveBeenCalled()
            expect(res.status).not.toHaveBeenCalled()
        })

        it('should allow access for user with general permission', () => {
            const req = createMockRequest(
                { id: 'admin123', role: 'admin' },
                { userId: 'user123' }
            ) as Request
            const res = createMockResponse() as Response
            const middleware = requireOwnershipOrPermission(getResourceOwnerId, 'users:update')

            middleware(req, res, mockNext)

            expect(mockNext).toHaveBeenCalled()
            expect(res.status).not.toHaveBeenCalled()
        })

        it('should deny access for non-owner without permission', () => {
            const req = createMockRequest(
                { id: 'user123', role: 'member' },
                { userId: 'user456' }
            ) as Request
            const res = createMockResponse() as Response
            const middleware = requireOwnershipOrPermission(getResourceOwnerId, 'users:update')

            middleware(req, res, mockNext)

            expect(res.status).toHaveBeenCalledWith(403)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied. You can only access your own resources or need higher permissions.',
                    details: {
                        resource: 'users',
                        action: 'update',
                        requiredRoles: ['admin']
                    },
                    timestamp: expect.any(String)
                }
            })
            expect(mockNext).not.toHaveBeenCalled()
        })
    })

    describe('hasRoleLevel', () => {
        it('should return true for equal or higher role levels', () => {
            expect(hasRoleLevel('admin', 'member')).toBe(true)
            expect(hasRoleLevel('admin', 'manager')).toBe(true)
            expect(hasRoleLevel('admin', 'admin')).toBe(true)

            expect(hasRoleLevel('manager', 'member')).toBe(true)
            expect(hasRoleLevel('manager', 'manager')).toBe(true)

            expect(hasRoleLevel('member', 'member')).toBe(true)
        })

        it('should return false for lower role levels', () => {
            expect(hasRoleLevel('member', 'manager')).toBe(false)
            expect(hasRoleLevel('member', 'admin')).toBe(false)
            expect(hasRoleLevel('manager', 'admin')).toBe(false)
        })
    })

    describe('requireRoleLevel middleware', () => {
        it('should allow access for user with sufficient role level', () => {
            const req = createMockRequest({ id: '1', role: 'admin' }) as Request
            const res = createMockResponse() as Response
            const middleware = requireRoleLevel('manager')

            middleware(req, res, mockNext)

            expect(mockNext).toHaveBeenCalled()
            expect(res.status).not.toHaveBeenCalled()
        })

        it('should deny access for user with insufficient role level', () => {
            const req = createMockRequest({ id: '1', role: 'member' }) as Request
            const res = createMockResponse() as Response
            const middleware = requireRoleLevel('manager')

            middleware(req, res, mockNext)

            expect(res.status).toHaveBeenCalledWith(403)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied. Required role level: manager or higher',
                    details: {
                        userRole: 'member',
                        requiredRole: 'manager'
                    },
                    timestamp: expect.any(String)
                }
            })
            expect(mockNext).not.toHaveBeenCalled()
        })
    })

    describe('getUserPermissions', () => {
        it('should return correct permissions for admin', () => {
            const permissions = getUserPermissions('admin')
            expect(permissions).toContain('users:create')
            expect(permissions).toContain('projects:delete')
            expect(permissions).toContain('tasks:delete')
            expect(permissions).toContain('reports:view')
        })

        it('should return correct permissions for manager', () => {
            const permissions = getUserPermissions('manager')
            expect(permissions).toContain('projects:create')
            expect(permissions).toContain('tasks:assign')
            expect(permissions).toContain('reports:view')
            expect(permissions).not.toContain('users:create')
            expect(permissions).not.toContain('projects:delete')
        })

        it('should return correct permissions for member', () => {
            const permissions = getUserPermissions('member')
            expect(permissions).toContain('tasks:create')
            expect(permissions).toContain('tasks:read')
            expect(permissions).toContain('projects:read')
            expect(permissions).not.toContain('users:create')
            expect(permissions).not.toContain('projects:create')
            expect(permissions).not.toContain('reports:view')
        })
    })

    describe('getResourcePermissions', () => {
        it('should return all permissions for a resource', () => {
            const userPermissions = getResourcePermissions('users')
            expect(userPermissions).toHaveLength(5) // create, read, update, delete, list

            const taskPermissions = getResourcePermissions('tasks')
            expect(taskPermissions.length).toBeGreaterThan(0)

            expect(userPermissions.every(p => p.resource === 'users')).toBe(true)
            expect(taskPermissions.every(p => p.resource === 'tasks')).toBe(true)
        })

        it('should return empty array for non-existent resource', () => {
            const permissions = getResourcePermissions('nonexistent')
            expect(permissions).toHaveLength(0)
        })
    })

    describe('PERMISSIONS configuration', () => {
        it('should have all required permission keys', () => {
            const requiredPermissions = [
                'users:create', 'users:read', 'users:update', 'users:delete', 'users:list',
                'projects:create', 'projects:read', 'projects:update', 'projects:delete', 'projects:manage_members',
                'tasks:create', 'tasks:read', 'tasks:update', 'tasks:delete', 'tasks:assign', 'tasks:update_status',
                'reports:view', 'reports:export'
            ]

            requiredPermissions.forEach(permission => {
                expect(PERMISSIONS[permission]).toBeDefined()
                expect(PERMISSIONS[permission].resource).toBeDefined()
                expect(PERMISSIONS[permission].action).toBeDefined()
                expect(Array.isArray(PERMISSIONS[permission].roles)).toBe(true)
            })
        })

        it('should have valid role assignments', () => {
            const validRoles: UserRole[] = ['admin', 'manager', 'member']

            Object.values(PERMISSIONS).forEach(permission => {
                permission.roles.forEach(role => {
                    expect(validRoles).toContain(role)
                })
            })
        })
    })
})