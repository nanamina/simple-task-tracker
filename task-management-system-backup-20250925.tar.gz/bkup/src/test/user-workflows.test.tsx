import React from 'react'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { Provider } from 'react-redux'
import { BrowserRouter } from 'react-router-dom'
import { configureStore } from '@reduxjs/toolkit'

// Import components
import App from '@/client/App'
import TaskList from '@/client/components/TaskList'
import ProjectList from '@/client/components/ProjectList'
import Dashboard from '@/client/components/Dashboard'

// Import slices
import authSlice from '@/client/store/slices/authSlice'
import taskSlice from '@/client/store/slices/taskSlice'
import projectSlice from '@/client/store/slices/projectSlice'
import uiSlice from '@/client/store/slices/uiSlice'

// Import types
import { User, Task, Project } from '@/shared/types'

// Mock i18next
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string, options?: any) => {
            const translations: Record<string, string> = {
                'common.loading': 'Loading...',
                'common.save': 'Save',
                'common.cancel': 'Cancel',
                'common.edit': 'Edit',
                'common.delete': 'Delete',
                'common.create': 'Create',
                'common.update': 'Update',
                'common.search': 'Search',
                'navigation.dashboard': 'Dashboard',
                'navigation.tasks': 'Tasks',
                'navigation.projects': 'Projects',
                'tasks.title': 'Tasks',
                'tasks.create': 'New Task',
                'tasks.edit': 'Edit Task',
                'tasks.fields.title': 'Title',
                'tasks.fields.description': 'Description',
                'tasks.fields.status': 'Status',
                'tasks.fields.priority': 'Priority',
                'tasks.fields.dueDate': 'Due Date',
                'tasks.fields.assignee': 'Assignee',
                'tasks.fields.project': 'Project',
                'tasks.status.todo': 'To Do',
                'tasks.status.inProgress': 'In Progress',
                'tasks.status.completed': 'Completed',
                'tasks.priority.low': 'Low',
                'tasks.priority.medium': 'Medium',
                'tasks.priority.high': 'High',
                'tasks.priority.critical': 'Critical',
                'tasks.messages.confirmDelete': 'Are you sure you want to delete this task?',
                'tasks.messages.noTasks': 'No tasks found',
                'projects.title': 'Projects',
                'projects.create': 'New Project',
                'projects.edit': 'Edit Project',
                'projects.name': 'Project Name',
                'projects.description': 'Description',
                'projects.messages.confirmDelete': 'Are you sure you want to delete this project?',
                'dashboard.title': 'Dashboard',
                'dashboard.welcome': 'Welcome back',
                'dashboard.recentTasks': 'Recent Tasks',
                'dashboard.projectOverview': 'Project Overview',
                'auth.login.title': 'Login',
                'auth.login.email': 'Email',
                'auth.login.password': 'Password',
                'auth.login.submit': 'Login',
                'validation.required': `${options?.field || 'Field'} is required`,
                'validation.email': 'Please enter a valid email address',
                'validation.minLength': `${options?.field || 'Field'} must be at least ${options?.min || 1} characters`,
            }
            return translations[key] || key
        },
    }),
}))

// Mock hooks
jest.mock('@/client/hooks/useFormatting', () => ({
    useFormatting: () => ({
        formatDate: (date: Date) => date.toLocaleDateString('ja-JP'),
        formatDateTime: (date: Date) => date.toLocaleString('ja-JP'),
    }),
}))

// Mock data
const mockUser: User = {
    id: 'user-1',
    email: 'test@example.com',
    name: 'Test User',
    role: 'manager',
    preferredLanguage: 'ja',
    createdAt: new Date(),
    updatedAt: new Date(),
}

const mockTasks: Task[] = [
    {
        id: 'task-1',
        title: 'Test Task 1',
        description: 'First test task',
        status: 'todo',
        priority: 'high',
        createdBy: 'user-1',
        createdAt: new Date(),
        updatedAt: new Date(),
    },
    {
        id: 'task-2',
        title: 'Test Task 2',
        description: 'Second test task',
        status: 'in-progress',
        priority: 'medium',
        createdBy: 'user-1',
        createdAt: new Date(),
        updatedAt: new Date(),
    },
]

const mockProjects: Project[] = [
    {
        id: 'project-1',
        name: 'Test Project 1',
        description: 'First test project',
        createdBy: 'user-1',
        createdAt: new Date(),
        updatedAt: new Date(),
        members: ['user-1'],
    },
]

// Helper function to create test store
const createTestStore = (initialState = {}) => {
    const defaultState = {
        auth: {
            user: mockUser,
            token: 'test-token',
            isAuthenticated: true,
            loading: false,
            error: null,
        },
        tasks: {
            tasks: mockTasks,
            loading: false,
            error: null,
            filters: {},
            sortBy: 'createdAt',
            sortOrder: 'desc',
        },
        projects: {
            projects: mockProjects,
            currentProject: mockProjects[0],
            projectTasks: mockTasks,
            projectMetrics: {
                totalTasks: 2,
                completedTasks: 0,
                inProgressTasks: 1,
                todoTasks: 1,
                completionRate: 0,
                overdueTasksCount: 0,
            },
            availableUsers: [mockUser],
            loading: false,
            error: null,
        },
        ui: {
            language: 'ja',
            theme: 'light',
            notifications: [],
        },
    }

    return configureStore({
        reducer: {
            auth: authSlice,
            tasks: taskSlice,
            projects: projectSlice,
            ui: uiSlice,
        },
        preloadedState: { ...defaultState, ...initialState },
    })
}

// Helper function to render component with providers
const renderWithProviders = (component: React.ReactElement, store = createTestStore()) => {
    return render(
        <Provider store={store}>
            <BrowserRouter>
                {component}
            </BrowserRouter>
        </Provider>
    )
}

// Mock fetch globally
global.fetch = jest.fn()

describe('User Workflow Integration Tests', () => {
    const user = userEvent.setup()

    beforeEach(() => {
        jest.clearAllMocks()
            ; (fetch as jest.Mock).mockResolvedValue({
                ok: true,
                json: () => Promise.resolve({}),
            })
    })

    afterEach(() => {
        jest.restoreAllMocks()
    })

    describe('Task Management Workflow', () => {
        test('User can create a new task', async () => {
            const newTask = {
                id: 'task-3',
                title: 'New Task',
                description: 'New task description',
                status: 'todo',
                priority: 'medium',
                createdBy: 'user-1',
                createdAt: new Date(),
                updatedAt: new Date(),
            }

                ; (fetch as jest.Mock).mockResolvedValueOnce({
                    ok: true,
                    json: () => Promise.resolve(newTask),
                })

            renderWithProviders(<TaskList />)

            // Click create task button
            const createButton = screen.getByText('New Task')
            await user.click(createButton)

            // Fill out the form
            const titleInput = screen.getByLabelText(/Title/)
            const descriptionInput = screen.getByLabelText(/Description/)

            await user.type(titleInput, 'New Task')
            await user.type(descriptionInput, 'New task description')

            // Submit the form
            const submitButton = screen.getByText('Create')
            await user.click(submitButton)

            // Verify API call was made
            await waitFor(() => {
                expect(fetch).toHaveBeenCalledWith('/api/tasks', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer test-token',
                    },
                    body: JSON.stringify({
                        title: 'New Task',
                        description: 'New task description',
                        status: 'todo',
                        priority: 'medium',
                        dueDate: undefined,
                        assigneeId: undefined,
                        projectId: undefined,
                    }),
                })
            })
        })

        test('User can edit an existing task', async () => {
            const updatedTask = {
                ...mockTasks[0],
                title: 'Updated Task Title',
                description: 'Updated description',
            }

                ; (fetch as jest.Mock).mockResolvedValueOnce({
                    ok: true,
                    json: () => Promise.resolve(updatedTask),
                })

            renderWithProviders(<TaskList />)

            // Find and click edit button for first task
            const editButtons = screen.getAllByTitle('Edit')
            await user.click(editButtons[0])

            // Update the form
            const titleInput = screen.getByDisplayValue('Test Task 1')
            await user.clear(titleInput)
            await user.type(titleInput, 'Updated Task Title')

            const descriptionInput = screen.getByDisplayValue('First test task')
            await user.clear(descriptionInput)
            await user.type(descriptionInput, 'Updated description')

            // Submit the form
            const updateButton = screen.getByText('Update')
            await user.click(updateButton)

            // Verify API call was made
            await waitFor(() => {
                expect(fetch).toHaveBeenCalledWith('/api/tasks/task-1', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer test-token',
                    },
                    body: JSON.stringify({
                        title: 'Updated Task Title',
                        description: 'Updated description',
                        status: 'todo',
                        priority: 'high',
                        dueDate: undefined,
                        assigneeId: undefined,
                        projectId: undefined,
                    }),
                })
            })
        })

        test('User can change task status', async () => {
            const updatedTask = { ...mockTasks[0], status: 'in-progress' }

                ; (fetch as jest.Mock).mockResolvedValueOnce({
                    ok: true,
                    json: () => Promise.resolve(updatedTask),
                })

            renderWithProviders(<TaskList />)

            // Find status dropdown for first task
            const statusSelects = screen.getAllByDisplayValue('To Do')
            await user.selectOptions(statusSelects[0], 'in-progress')

            // Verify API call was made
            await waitFor(() => {
                expect(fetch).toHaveBeenCalledWith('/api/tasks/task-1/status', {
                    method: 'PATCH',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer test-token',
                    },
                    body: JSON.stringify({ status: 'in-progress' }),
                })
            })
        })

        test('User can delete a task', async () => {
            // Mock window.confirm
            const confirmSpy = jest.spyOn(window, 'confirm').mockReturnValue(true)

                ; (fetch as jest.Mock).mockResolvedValueOnce({
                    ok: true,
                    json: () => Promise.resolve({}),
                })

            renderWithProviders(<TaskList />)

            // Find and click delete button for first task
            const deleteButtons = screen.getAllByTitle('Delete')
            await user.click(deleteButtons[0])

            // Verify confirmation dialog was shown
            expect(confirmSpy).toHaveBeenCalledWith('Are you sure you want to delete this task?')

            // Verify API call was made
            await waitFor(() => {
                expect(fetch).toHaveBeenCalledWith('/api/tasks/task-1', {
                    method: 'DELETE',
                    headers: {
                        'Authorization': 'Bearer test-token',
                    },
                })
            })

            confirmSpy.mockRestore()
        })

        test('User can filter and search tasks', async () => {
            renderWithProviders(<TaskList />)

            // Test search functionality
            const searchInput = screen.getByPlaceholderText('Search')
            await user.type(searchInput, 'Test Task 1')

            // Verify first task is still visible
            expect(screen.getByText('Test Task 1')).toBeInTheDocument()

            // Clear search and search for non-existent task
            await user.clear(searchInput)
            await user.type(searchInput, 'Non-existent task')

            // Both tasks should be filtered out (in a real implementation)
            // This would depend on the actual filtering logic
        })
    })

    describe('Project Management Workflow', () => {
        test('User can create a new project', async () => {
            const newProject = {
                id: 'project-2',
                name: 'New Project',
                description: 'New project description',
                createdBy: 'user-1',
                createdAt: new Date(),
                updatedAt: new Date(),
                members: ['user-1'],
            }

                ; (fetch as jest.Mock).mockResolvedValueOnce({
                    ok: true,
                    json: () => Promise.resolve(newProject),
                })

            renderWithProviders(<ProjectList />)

            // Click create project button
            const createButton = screen.getByText('New Project')
            await user.click(createButton)

            // Fill out the form
            const nameInput = screen.getByLabelText(/Project Name/)
            const descriptionInput = screen.getByLabelText(/Description/)

            await user.type(nameInput, 'New Project')
            await user.type(descriptionInput, 'New project description')

            // Submit the form
            const submitButton = screen.getByText('Create')
            await user.click(submitButton)

            // Verify API call was made
            await waitFor(() => {
                expect(fetch).toHaveBeenCalledWith('/api/projects', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer test-token',
                    },
                    body: JSON.stringify({
                        name: 'New Project',
                        description: 'New project description',
                    }),
                })
            })
        })

        test('User can view project dashboard', async () => {
            ; (fetch as jest.Mock)
                .mockResolvedValueOnce({
                    ok: true,
                    json: () => Promise.resolve(mockProjects[0]),
                })
                .mockResolvedValueOnce({
                    ok: true,
                    json: () => Promise.resolve(mockTasks),
                })

            renderWithProviders(<Dashboard />)

            // Verify project information is displayed
            expect(screen.getByText('Dashboard')).toBeInTheDocument()
            expect(screen.getByText('Welcome back')).toBeInTheDocument()
        })
    })

    describe('Navigation Workflow', () => {
        test('User can navigate between different sections', async () => {
            const store = createTestStore()

            renderWithProviders(<App />, store)

            // Test navigation to tasks
            const tasksLink = screen.getByText('Tasks')
            await user.click(tasksLink)

            // Test navigation to projects
            const projectsLink = screen.getByText('Projects')
            await user.click(projectsLink)

            // Test navigation to dashboard
            const dashboardLink = screen.getByText('Dashboard')
            await user.click(dashboardLink)
        })
    })

    describe('Error Handling Workflow', () => {
        test('User sees error message when API call fails', async () => {
            ; (fetch as jest.Mock).mockRejectedValueOnce(new Error('Network error'))

            renderWithProviders(<TaskList />)

            // Try to create a task
            const createButton = screen.getByText('New Task')
            await user.click(createButton)

            const titleInput = screen.getByLabelText(/Title/)
            await user.type(titleInput, 'Test Task')

            const submitButton = screen.getByText('Create')
            await user.click(submitButton)

            // Verify error handling (this would depend on actual error handling implementation)
            await waitFor(() => {
                expect(fetch).toHaveBeenCalled()
            })
        })

        test('User sees validation errors for invalid form data', async () => {
            renderWithProviders(<TaskList />)

            // Try to create a task without required fields
            const createButton = screen.getByText('New Task')
            await user.click(createButton)

            const submitButton = screen.getByText('Create')
            await user.click(submitButton)

            // Verify validation errors are shown
            await waitFor(() => {
                expect(screen.getByText('Title is required')).toBeInTheDocument()
            })
        })
    })

    describe('Loading States Workflow', () => {
        test('User sees loading indicators during API calls', async () => {
            // Mock a delayed response
            ; (fetch as jest.Mock).mockImplementation(
                () =>
                    new Promise(resolve =>
                        setTimeout(
                            () =>
                                resolve({
                                    ok: true,
                                    json: () => Promise.resolve({}),
                                }),
                            100
                        )
                    )
            )

            const store = createTestStore({
                tasks: {
                    tasks: [],
                    loading: true,
                    error: null,
                    filters: {},
                    sortBy: 'createdAt',
                    sortOrder: 'desc',
                },
            })

            renderWithProviders(<TaskList />, store)

            // Verify loading state is shown
            expect(screen.getByText('Loading...')).toBeInTheDocument()
        })
    })
})