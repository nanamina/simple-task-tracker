import {
    formatDate,
    formatDateTime,
    formatTime,
    formatRelativeTime,
    formatNumber,
    formatCurrency,
    formatPercentage,
    getCurrentLocale,
    uses24HourFormat,
    getDateSeparator,
    formatFileSize,
} from '../client/utils/formatting';

// Mock the i18n utility
jest.mock('../client/utils/i18n', () => ({
    getCurrentLanguage: jest.fn(),
}));

import { getCurrentLanguage } from '../client/utils/i18n';
const mockGetCurrentLanguage = getCurrentLanguage as jest.MockedFunction<typeof getCurrentLanguage>;

describe('Formatting Utilities', () => {
    const testDate = new Date('2024-03-15T14:30:00Z');

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('formatDate', () => {
        test('should format date in Japanese locale (YYYY/MM/DD)', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            const result = formatDate(testDate);
            expect(result).toMatch(/2024\/03\/15/);
        });

        test('should format date in English locale (MM/DD/YYYY)', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            const result = formatDate(testDate);
            expect(result).toMatch(/03\/15\/2024/);
        });

        test('should handle string dates', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            const result = formatDate('2024-03-15');
            expect(result).toMatch(/2024\/03\/15/);
        });

        test('should return empty string for invalid dates', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            const result = formatDate('invalid-date');
            expect(result).toBe('');
        });
    });

    describe('formatDateTime', () => {
        test('should format datetime in Japanese locale with 24-hour format', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            const result = formatDateTime(testDate);
            expect(result).toContain('2024');
            expect(result).toContain('03');
            expect(result).toContain('15');
        });

        test('should format datetime in English locale with 12-hour format', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            const result = formatDateTime(testDate);
            expect(result).toContain('2024');
            expect(result).toContain('03');
            expect(result).toContain('15');
        });

        test('should return empty string for invalid dates', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            const result = formatDateTime('invalid-date');
            expect(result).toBe('');
        });
    });

    describe('formatTime', () => {
        test('should format time in Japanese locale (24-hour)', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            const result = formatTime(testDate);
            expect(result).toMatch(/\d{2}:\d{2}/);
        });

        test('should format time in English locale (12-hour)', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            const result = formatTime(testDate);
            expect(result).toMatch(/\d{1,2}:\d{2}/);
        });

        test('should return empty string for invalid dates', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            const result = formatTime('invalid-date');
            expect(result).toBe('');
        });
    });

    describe('formatRelativeTime', () => {
        test('should format relative time for past dates', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            const pastDate = new Date(Date.now() - 2 * 60 * 60 * 1000); // 2 hours ago
            const result = formatRelativeTime(pastDate);
            expect(result).toContain('hour');
        });

        test('should format relative time for future dates', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            const futureDate = new Date(Date.now() + 2 * 60 * 60 * 1000); // 2 hours from now
            const result = formatRelativeTime(futureDate);
            expect(result).toContain('hour');
        });

        test('should return empty string for invalid dates', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            const result = formatRelativeTime('invalid-date');
            expect(result).toBe('');
        });
    });

    describe('formatNumber', () => {
        test('should format numbers in Japanese locale', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            const result = formatNumber(1234.56);
            expect(result).toBeDefined();
            expect(typeof result).toBe('string');
        });

        test('should format numbers in English locale', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            const result = formatNumber(1234.56);
            expect(result).toBeDefined();
            expect(typeof result).toBe('string');
        });

        test('should handle large numbers', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            const result = formatNumber(1234567.89);
            expect(result).toBeDefined();
            expect(typeof result).toBe('string');
        });
    });

    describe('formatCurrency', () => {
        test('should format currency in Japanese locale (JPY)', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            const result = formatCurrency(1000);
            expect(result).toBeDefined();
            expect(typeof result).toBe('string');
        });

        test('should format currency in English locale (USD)', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            const result = formatCurrency(1000);
            expect(result).toBeDefined();
            expect(typeof result).toBe('string');
        });

        test('should accept custom currency', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            const result = formatCurrency(1000, 'EUR');
            expect(result).toBeDefined();
            expect(typeof result).toBe('string');
        });
    });

    describe('formatPercentage', () => {
        test('should format percentage in Japanese locale', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            const result = formatPercentage(0.75);
            expect(result).toBeDefined();
            expect(typeof result).toBe('string');
        });

        test('should format percentage in English locale', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            const result = formatPercentage(0.75);
            expect(result).toBeDefined();
            expect(typeof result).toBe('string');
        });

        test('should handle zero percentage', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            const result = formatPercentage(0);
            expect(result).toBeDefined();
            expect(typeof result).toBe('string');
        });
    });

    describe('getCurrentLocale', () => {
        test('should return ja-JP for Japanese language', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            const result = getCurrentLocale();
            expect(result).toBe('ja-JP');
        });

        test('should return en-US for English language', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            const result = getCurrentLocale();
            expect(result).toBe('en-US');
        });
    });

    describe('uses24HourFormat', () => {
        test('should return true for Japanese locale', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            const result = uses24HourFormat();
            expect(result).toBe(true);
        });

        test('should return false for English locale', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            const result = uses24HourFormat();
            expect(result).toBe(false);
        });
    });

    describe('getDateSeparator', () => {
        test('should return "/" for both locales', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            expect(getDateSeparator()).toBe('/');

            mockGetCurrentLanguage.mockReturnValue('en');
            expect(getDateSeparator()).toBe('/');
        });
    });

    describe('formatFileSize', () => {
        test('should format bytes correctly', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            expect(formatFileSize(0)).toBe('0 Bytes');
            expect(formatFileSize(1024)).toContain('KB');
            expect(formatFileSize(1024 * 1024)).toContain('MB');
            expect(formatFileSize(1024 * 1024 * 1024)).toContain('GB');
        });

        test('should format bytes in Japanese locale', () => {
            mockGetCurrentLanguage.mockReturnValue('ja');
            expect(formatFileSize(0)).toBe('0 Bytes');
            expect(formatFileSize(1024)).toContain('KB');
        });

        test('should handle custom decimal places', () => {
            mockGetCurrentLanguage.mockReturnValue('en');
            const result = formatFileSize(1536, 1); // 1.5 KB
            expect(result).toBeDefined();
            expect(typeof result).toBe('string');
        });
    });
});