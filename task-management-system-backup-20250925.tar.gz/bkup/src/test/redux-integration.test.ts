import { configureStore } from '@reduxjs/toolkit'
import { store } from '../client/store'
import {
    extractErrorMessage,
    withRetry
} from '../client/store/utils/asyncThunks'

// Mock fetch for testing
global.fetch = jest.fn()

describe('Redux Integration Tests', () => {
    describe('store configuration', () => {
        it('should have all required slices in the main store', () => {
            const state = store.getState()

            expect(state.auth).toBeDefined()
            expect(state.tasks).toBeDefined()
            expect(state.projects).toBeDefined()
            expect(state.ui).toBeDefined()
            expect(state.api).toBeDefined()
        })

        it('should have correct initial state structure', () => {
            const state = store.getState()

            // Auth slice
            expect(state.auth.user).toBeNull()
            expect(state.auth.isAuthenticated).toBe(false)

            // Tasks slice
            expect(state.tasks.tasks).toEqual([])
            expect(state.tasks.loading).toBe(false)

            // Projects slice
            expect(state.projects.projects).toEqual([])
            expect(state.projects.currentProject).toBeNull()

            // UI slice
            expect(state.ui.language).toBe('ja')
            expect(state.ui.notifications).toEqual([])
            expect(state.ui.sidebarOpen).toBe(true)
            expect(state.ui.theme).toBe('light')

            // API slice
            expect(state.api.queries).toBeDefined()
            expect(state.api.mutations).toBeDefined()
        })
    })

    describe('error handling utilities', () => {
        describe('extractErrorMessage', () => {
            it('should handle network errors', () => {
                const networkError = new TypeError('Failed to fetch')
                const message = extractErrorMessage(networkError)

                expect(message).toBe('Network error. Please check your connection and try again.')
            })

            it('should handle HTTP response errors', () => {
                const httpError = {
                    response: {
                        status: 400,
                        data: {
                            error: {
                                message: 'Invalid input data'
                            }
                        }
                    }
                }

                const message = extractErrorMessage(httpError)
                expect(message).toBe('Invalid input data')
            })

            it('should handle different HTTP status codes', () => {
                const testCases = [
                    { status: 401, expected: 'Authentication required. Please log in again.' },
                    { status: 403, expected: 'You do not have permission to perform this action.' },
                    { status: 404, expected: 'The requested resource was not found.' },
                    { status: 500, expected: 'Server error. Please try again later.' },
                ]

                testCases.forEach(({ status, expected }) => {
                    const error = { response: { status, data: {} } }
                    const message = extractErrorMessage(error)
                    expect(message).toBe(expected)
                })
            })

            it('should handle string errors', () => {
                const message = extractErrorMessage('Custom error message')
                expect(message).toBe('Custom error message')
            })

            it('should handle Error objects', () => {
                const error = new Error('Something went wrong')
                const message = extractErrorMessage(error)
                expect(message).toBe('Something went wrong')
            })

            it('should provide fallback for unknown error types', () => {
                const message = extractErrorMessage({ unknown: 'error' })
                expect(message).toBe('An unexpected error occurred. Please try again.')
            })
        })

        describe('withRetry', () => {
            it('should succeed on first attempt', async () => {
                const operation = jest.fn().mockResolvedValue('success')

                const result = await withRetry(operation, 3, 10)

                expect(result).toBe('success')
                expect(operation).toHaveBeenCalledTimes(1)
            })

            it('should retry on failure and eventually succeed', async () => {
                const operation = jest.fn()
                    .mockRejectedValueOnce(new Error('First failure'))
                    .mockRejectedValueOnce(new Error('Second failure'))
                    .mockResolvedValueOnce('success')

                const result = await withRetry(operation, 3, 10)

                expect(result).toBe('success')
                expect(operation).toHaveBeenCalledTimes(3)
            })

            it('should not retry on client errors (4xx)', async () => {
                const operation = jest.fn().mockRejectedValue({
                    response: { status: 400 }
                })

                await expect(withRetry(operation, 3, 10)).rejects.toEqual({
                    response: { status: 400 }
                })

                expect(operation).toHaveBeenCalledTimes(1)
            })

            it('should retry on 408 and 429 errors', async () => {
                const operation = jest.fn()
                    .mockRejectedValueOnce({ response: { status: 429 } })
                    .mockResolvedValueOnce('success')

                const result = await withRetry(operation, 3, 10)

                expect(result).toBe('success')
                expect(operation).toHaveBeenCalledTimes(2)
            })

            it('should throw last error after max retries', async () => {
                const error = new Error('Persistent failure')
                const operation = jest.fn().mockRejectedValue(error)

                await expect(withRetry(operation, 2, 10)).rejects.toThrow('Persistent failure')

                expect(operation).toHaveBeenCalledTimes(2)
            })
        })
    })

    describe('type safety', () => {
        it('should provide correct TypeScript types for store state', () => {
            const state = store.getState()

            // Test that TypeScript correctly infers types
            const language: 'ja' | 'en' = state.ui.language
            const isAuthenticated: boolean = state.auth.isAuthenticated
            const taskCount: number = state.tasks.tasks.length
            const projectCount: number = state.projects.projects.length

            expect(typeof language).toBe('string')
            expect(typeof isAuthenticated).toBe('boolean')
            expect(typeof taskCount).toBe('number')
            expect(typeof projectCount).toBe('number')
        })

        it('should have proper middleware configuration', () => {
            // Verify the store has the expected middleware
            // This is tested indirectly by ensuring the store works correctly
            expect(store.dispatch).toBeDefined()
            expect(store.getState).toBeDefined()
            expect(store.subscribe).toBeDefined()
        })
    })

    describe('API slice integration', () => {
        it('should have API slice properly integrated', () => {
            const state = store.getState()

            expect(state.api).toBeDefined()
            expect(state.api.queries).toBeDefined()
            expect(state.api.mutations).toBeDefined()
            expect(state.api.provided).toBeDefined()
            expect(state.api.subscriptions).toBeDefined()
        })

        it('should have correct API configuration', () => {
            // Test that the API slice is configured correctly
            const { apiSlice } = require('../client/store/api/apiSlice')

            expect(apiSlice.reducerPath).toBe('api')
            expect(apiSlice.reducer).toBeDefined()
            expect(apiSlice.middleware).toBeDefined()
        })
    })
})