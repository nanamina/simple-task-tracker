/**
 * Unit tests for Task Repository
 */

import { Pool, PoolClient } from 'pg'
import { TaskRepository } from '../server/repositories/task-repository'
import { CreateTaskDTO, UpdateTaskDTO, TaskFilterOptions, TaskSortOptions } from '../shared/types/validation'

// Mock pg module
jest.mock('pg', () => ({
    Pool: jest.fn()
}))

describe('TaskRepository', () => {
    let mockPool: jest.Mocked<Pool>
    let mockClient: jest.Mocked<PoolClient>
    let taskRepository: TaskRepository

    beforeEach(() => {
        // Create mock client
        mockClient = {
            query: jest.fn(),
            release: jest.fn()
        } as any

        // Create mock pool
        mockPool = {
            connect: jest.fn().mockResolvedValue(mockClient)
        } as any

            // Mock Pool constructor
            ; (Pool as jest.MockedClass<typeof Pool>).mockImplementation(() => mockPool)

        taskRepository = new TaskRepository(mockPool)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    describe('createTask', () => {
        const mockTaskData: CreateTaskDTO = {
            title: 'Test Task',
            description: 'Test description',
            priority: 'high',
            assigneeId: 'user-123',
            projectId: 'project-456'
        }

        const createdBy = 'creator-789'

        const mockDbResult = {
            rows: [{
                id: 'task-123',
                title: 'Test Task',
                description: 'Test description',
                status: 'todo',
                priority: 'high',
                due_date: null,
                assignee_id: 'user-123',
                project_id: 'project-456',
                created_by: 'creator-789',
                created_at: new Date('2024-01-01'),
                updated_at: new Date('2024-01-01'),
                completed_at: null
            }]
        }

        it('should create a task successfully', async () => {
            mockClient.query.mockResolvedValue(mockDbResult)

            const result = await taskRepository.createTask(mockTaskData, createdBy)

            expect(mockPool.connect).toHaveBeenCalled()
            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/INSERT INTO tasks/),
                expect.arrayContaining([
                    mockTaskData.title,
                    mockTaskData.description,
                    mockTaskData.priority,
                    null, // dueDate
                    mockTaskData.assigneeId,
                    mockTaskData.projectId,
                    createdBy
                ])
            )
            expect(mockClient.release).toHaveBeenCalled()
            expect(result).toEqual({
                id: 'task-123',
                title: 'Test Task',
                description: 'Test description',
                status: 'todo',
                priority: 'high',
                dueDate: null,
                assigneeId: 'user-123',
                projectId: 'project-456',
                createdBy: 'creator-789',
                createdAt: new Date('2024-01-01'),
                updatedAt: new Date('2024-01-01'),
                completedAt: null
            })
        })

        it('should use default values for optional fields', async () => {
            const minimalTaskData: CreateTaskDTO = {
                title: 'Minimal Task',
                description: 'Minimal description'
            }

            mockClient.query.mockResolvedValue(mockDbResult)

            await taskRepository.createTask(minimalTaskData, createdBy)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/INSERT INTO tasks/),
                expect.arrayContaining([
                    minimalTaskData.title,
                    minimalTaskData.description,
                    'medium', // default priority
                    null, // no dueDate
                    null, // no assigneeId
                    null, // no projectId
                    createdBy
                ])
            )
        })

        it('should throw error on database failure', async () => {
            const dbError = new Error('Database connection failed')
            mockClient.query.mockRejectedValue(dbError)

            await expect(taskRepository.createTask(mockTaskData, createdBy)).rejects.toThrow('Failed to create task')
            expect(mockClient.release).toHaveBeenCalled()
        })
    })

    describe('findById', () => {
        const taskId = 'task-123'
        const mockDbResult = {
            rows: [{
                id: taskId,
                title: 'Test Task',
                description: 'Test description',
                status: 'todo',
                priority: 'medium',
                due_date: null,
                assignee_id: null,
                project_id: null,
                created_by: 'creator-789',
                created_at: new Date('2024-01-01'),
                updated_at: new Date('2024-01-01'),
                completed_at: null
            }]
        }

        it('should find task by ID successfully', async () => {
            mockClient.query.mockResolvedValue(mockDbResult)

            const result = await taskRepository.findById(taskId)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/SELECT.*FROM tasks.*WHERE id = \$1/s),
                [taskId]
            )
            expect(result).toEqual({
                id: taskId,
                title: 'Test Task',
                description: 'Test description',
                status: 'todo',
                priority: 'medium',
                dueDate: null,
                assigneeId: null,
                projectId: null,
                createdBy: 'creator-789',
                createdAt: new Date('2024-01-01'),
                updatedAt: new Date('2024-01-01'),
                completedAt: null
            })
        })

        it('should return null when task not found', async () => {
            mockClient.query.mockResolvedValue({ rows: [] })

            const result = await taskRepository.findById(taskId)

            expect(result).toBeNull()
        })

        it('should throw error on database failure', async () => {
            mockClient.query.mockRejectedValue(new Error('Database error'))

            await expect(taskRepository.findById(taskId)).rejects.toThrow('Failed to find task by ID')
            expect(mockClient.release).toHaveBeenCalled()
        })
    })

    describe('updateTask', () => {
        const taskId = 'task-123'
        const updateData: UpdateTaskDTO = {
            title: 'Updated Task',
            priority: 'critical'
        }

        const mockDbResult = {
            rows: [{
                id: taskId,
                title: 'Updated Task',
                description: 'Test description',
                status: 'todo',
                priority: 'critical',
                due_date: null,
                assignee_id: null,
                project_id: null,
                created_by: 'creator-789',
                created_at: new Date('2024-01-01'),
                updated_at: new Date('2024-01-02'),
                completed_at: null
            }]
        }

        it('should update task successfully', async () => {
            mockClient.query.mockResolvedValue(mockDbResult)

            const result = await taskRepository.updateTask(taskId, updateData)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/UPDATE tasks[\s\S]*SET[\s\S]*WHERE id = \$\d+/),
                expect.arrayContaining(['Updated Task', 'critical', taskId])
            )
            expect(result).toEqual({
                id: taskId,
                title: 'Updated Task',
                description: 'Test description',
                status: 'todo',
                priority: 'critical',
                dueDate: null,
                assigneeId: null,
                projectId: null,
                createdBy: 'creator-789',
                createdAt: new Date('2024-01-01'),
                updatedAt: new Date('2024-01-02'),
                completedAt: null
            })
        })

        it('should return null when task not found', async () => {
            mockClient.query.mockResolvedValue({ rows: [] })

            const result = await taskRepository.updateTask(taskId, updateData)

            expect(result).toBeNull()
        })

        it('should handle empty update data', async () => {
            const findByIdSpy = jest.spyOn(taskRepository, 'findById').mockResolvedValue({
                id: taskId,
                title: 'Test Task',
                description: 'Test description',
                status: 'todo',
                priority: 'medium',
                dueDate: null,
                assigneeId: null,
                projectId: null,
                createdBy: 'creator-789',
                createdAt: new Date('2024-01-01'),
                updatedAt: new Date('2024-01-01'),
                completedAt: null
            })

            const result = await taskRepository.updateTask(taskId, {})

            expect(findByIdSpy).toHaveBeenCalledWith(taskId)
            expect(result).toBeDefined()
        })
    })

    describe('updateTaskStatus', () => {
        const taskId = 'task-123'
        const newStatus = 'completed'

        const mockDbResult = {
            rows: [{
                id: taskId,
                title: 'Test Task',
                description: 'Test description',
                status: 'completed',
                priority: 'medium',
                due_date: null,
                assignee_id: null,
                project_id: null,
                created_by: 'creator-789',
                created_at: new Date('2024-01-01'),
                updated_at: new Date('2024-01-02'),
                completed_at: new Date('2024-01-02')
            }]
        }

        it('should update task status successfully', async () => {
            mockClient.query.mockResolvedValue(mockDbResult)

            const result = await taskRepository.updateTaskStatus(taskId, newStatus)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/UPDATE tasks[\s\S]*SET status = \$1[\s\S]*WHERE id = \$2/),
                [newStatus, taskId]
            )
            expect(result?.status).toBe('completed')
            expect(result?.completedAt).toEqual(new Date('2024-01-02'))
        })

        it('should return null when task not found', async () => {
            mockClient.query.mockResolvedValue({ rows: [] })

            const result = await taskRepository.updateTaskStatus(taskId, newStatus)

            expect(result).toBeNull()
        })
    })

    describe('deleteTask', () => {
        const taskId = 'task-123'

        it('should delete task successfully', async () => {
            mockClient.query.mockResolvedValue({ rowCount: 1 })

            const result = await taskRepository.deleteTask(taskId)

            expect(mockClient.query).toHaveBeenCalledWith(
                'DELETE FROM tasks WHERE id = $1',
                [taskId]
            )
            expect(result).toBe(true)
        })

        it('should return false when task not found', async () => {
            mockClient.query.mockResolvedValue({ rowCount: 0 })

            const result = await taskRepository.deleteTask(taskId)

            expect(result).toBe(false)
        })
    })

    describe('listTasks', () => {
        const mockDbResult = {
            rows: [
                {
                    id: 'task-1',
                    title: 'Task 1',
                    description: 'Description 1',
                    status: 'todo',
                    priority: 'high',
                    due_date: null,
                    assignee_id: 'user-1',
                    project_id: 'project-1',
                    created_by: 'creator-1',
                    created_at: new Date('2024-01-01'),
                    updated_at: new Date('2024-01-01'),
                    completed_at: null
                },
                {
                    id: 'task-2',
                    title: 'Task 2',
                    description: 'Description 2',
                    status: 'in-progress',
                    priority: 'medium',
                    due_date: null,
                    assignee_id: 'user-2',
                    project_id: 'project-1',
                    created_by: 'creator-1',
                    created_at: new Date('2024-01-02'),
                    updated_at: new Date('2024-01-02'),
                    completed_at: null
                }
            ]
        }

        it('should list tasks with default options', async () => {
            mockClient.query.mockResolvedValue(mockDbResult)

            const result = await taskRepository.listTasks()

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/SELECT.*FROM tasks.*ORDER BY.*LIMIT.*OFFSET/s),
                [50, 0] // default limit and offset
            )
            expect(result).toHaveLength(2)
            expect(result[0].title).toBe('Task 1')
        })

        it('should list tasks with filters', async () => {
            const filters: TaskFilterOptions = {
                status: 'todo',
                priority: 'high',
                assigneeId: 'user-1'
            }

            mockClient.query.mockResolvedValue(mockDbResult)

            const result = await taskRepository.listTasks(filters)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/WHERE.*status = \$1.*priority = \$2.*assignee_id = \$3/s),
                expect.arrayContaining(['todo', 'high', 'user-1', 50, 0])
            )
        })

        it('should list tasks with custom sort', async () => {
            const sort: TaskSortOptions = {
                field: 'title',
                direction: 'asc'
            }

            mockClient.query.mockResolvedValue(mockDbResult)

            const result = await taskRepository.listTasks({}, sort)

            expect(mockClient.query).toHaveBeenCalledWith(
                expect.stringMatching(/ORDER BY title ASC/),
                [50, 0]
            )
        })
    })

    describe('getTasksByProject', () => {
        it('should get tasks by project ID', async () => {
            const projectId = 'project-123'
            const listTasksSpy = jest.spyOn(taskRepository, 'listTasks').mockResolvedValue([])

            await taskRepository.getTasksByProject(projectId)

            expect(listTasksSpy).toHaveBeenCalledWith(
                { projectId },
                { field: 'createdAt', direction: 'desc' }
            )
        })
    })

    describe('getTasksByAssignee', () => {
        it('should get tasks by assignee ID', async () => {
            const assigneeId = 'user-123'
            const listTasksSpy = jest.spyOn(taskRepository, 'listTasks').mockResolvedValue([])

            await taskRepository.getTasksByAssignee(assigneeId)

            expect(listTasksSpy).toHaveBeenCalledWith(
                { assigneeId },
                { field: 'createdAt', direction: 'desc' }
            )
        })
    })

    describe('getOverdueTasks', () => {
        it('should get overdue tasks', async () => {
            const listTasksSpy = jest.spyOn(taskRepository, 'listTasks').mockResolvedValue([])

            await taskRepository.getOverdueTasks()

            expect(listTasksSpy).toHaveBeenCalledWith(
                expect.objectContaining({
                    status: 'todo',
                    dueBefore: expect.any(Date)
                })
            )
        })
    })
})