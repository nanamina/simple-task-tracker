import React from 'react'
import { render, screen, waitFor } from '@testing-library/react'
import { Provider } from 'react-redux'
import { BrowserRouter } from 'react-router-dom'
import { configureStore } from '@reduxjs/toolkit'

import Dashboard from '@/client/components/Dashboard'
import authSlice from '@/client/store/slices/authSlice'
import taskSlice from '@/client/store/slices/taskSlice'
import projectSlice from '@/client/store/slices/projectSlice'
import uiSlice from '@/client/store/slices/uiSlice'

import { User, Task, Project } from '@/shared/types'

// Mock i18next
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string, options?: any) => {
            const translations: Record<string, string> = {
                'dashboard.title': 'Dashboard',
                'dashboard.welcome': 'Welcome back',
                'dashboard.recentTasks': 'Recent Tasks',
                'dashboard.projectOverview': 'Project Overview',
                'dashboard.tasksSummary': 'Tasks Summary',
                'dashboard.upcomingDeadlines': 'Upcoming Deadlines',
                'dashboard.myTasks': 'My Tasks',
                'dashboard.noRecentTasks': 'No recent tasks',
                'dashboard.noUpcomingDeadlines': 'No upcoming deadlines',
                'tasks.status.todo': 'To Do',
                'tasks.status.inProgress': 'In Progress',
                'tasks.status.completed': 'Completed',
                'tasks.priority.low': 'Low',
                'tasks.priority.medium': 'Medium',
                'tasks.priority.high': 'High',
                'tasks.priority.critical': 'Critical',
                'projects.totalProjects': 'Total Projects',
                'projects.activeProjects': 'Active Projects',
                'common.loading': 'Loading...',
                'common.error': 'Error occurred',
                'common.viewAll': 'View All',
            }
            return translations[key] || key
        },
    }),
}))

// Mock hooks
jest.mock('@/client/hooks/useFormatting', () => ({
    useFormatting: () => ({
        formatDate: (date: Date) => date.toLocaleDateString('ja-JP'),
        formatDateTime: (date: Date) => date.toLocaleString('ja-JP'),
        formatRelativeTime: (date: Date) => {
            const now = new Date()
            const diffInHours = Math.floor((date.getTime() - now.getTime()) / (1000 * 60 * 60))
            if (diffInHours < 24) return `${diffInHours} hours`
            return `${Math.floor(diffInHours / 24)} days`
        },
    }),
}))

// Mock data
const mockUser: User = {
    id: 'user-1',
    email: 'test@example.com',
    name: 'Test User',
    role: 'manager',
    preferredLanguage: 'ja',
    createdAt: new Date(),
    updatedAt: new Date(),
}

const mockTasks: Task[] = [
    {
        id: 'task-1',
        title: 'Recent Task 1',
        description: 'First recent task',
        status: 'todo',
        priority: 'high',
        dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000), // Tomorrow
        assigneeId: 'user-1',
        createdBy: 'user-1',
        createdAt: new Date(),
        updatedAt: new Date(),
    },
    {
        id: 'task-2',
        title: 'Recent Task 2',
        description: 'Second recent task',
        status: 'in-progress',
        priority: 'medium',
        assigneeId: 'user-1',
        createdBy: 'user-1',
        createdAt: new Date(),
        updatedAt: new Date(),
    },
    {
        id: 'task-3',
        title: 'Completed Task',
        description: 'A completed task',
        status: 'completed',
        priority: 'low',
        assigneeId: 'user-1',
        createdBy: 'user-1',
        createdAt: new Date(),
        updatedAt: new Date(),
        completedAt: new Date(),
    },
]

const mockProjects: Project[] = [
    {
        id: 'project-1',
        name: 'Active Project 1',
        description: 'First active project',
        createdBy: 'user-1',
        createdAt: new Date(),
        updatedAt: new Date(),
        members: ['user-1'],
    },
    {
        id: 'project-2',
        name: 'Active Project 2',
        description: 'Second active project',
        createdBy: 'user-1',
        createdAt: new Date(),
        updatedAt: new Date(),
        members: ['user-1'],
    },
]

// Helper function to create test store
const createTestStore = (initialState = {}) => {
    const defaultState = {
        auth: {
            user: mockUser,
            token: 'test-token',
            isAuthenticated: true,
            loading: false,
            error: null,
        },
        tasks: {
            tasks: mockTasks,
            loading: false,
            error: null,
            filters: {},
            sortBy: 'createdAt',
            sortOrder: 'desc',
        },
        projects: {
            projects: mockProjects,
            currentProject: null,
            projectTasks: [],
            projectMetrics: {
                totalTasks: 3,
                completedTasks: 1,
                inProgressTasks: 1,
                todoTasks: 1,
                completionRate: 33,
                overdueTasksCount: 0,
            },
            availableUsers: [mockUser],
            loading: false,
            error: null,
        },
        ui: {
            language: 'ja',
            theme: 'light',
            notifications: [],
        },
    }

    return configureStore({
        reducer: {
            auth: authSlice,
            tasks: taskSlice,
            projects: projectSlice,
            ui: uiSlice,
        },
        preloadedState: { ...defaultState, ...initialState },
    })
}

// Helper function to render component with providers
const renderWithProviders = (component: React.ReactElement, store = createTestStore()) => {
    return render(
        <Provider store={store}>
            <BrowserRouter>
                {component}
            </BrowserRouter>
        </Provider>
    )
}

describe('Dashboard Component', () => {
    beforeEach(() => {
        // Mock fetch for API calls
        global.fetch = jest.fn().mockResolvedValue({
            ok: true,
            json: () => Promise.resolve({}),
        })
    })

    afterEach(() => {
        jest.restoreAllMocks()
    })

    test('renders dashboard with welcome message', () => {
        renderWithProviders(<Dashboard />)

        expect(screen.getByText('Dashboard')).toBeInTheDocument()
        expect(screen.getByText('Welcome back')).toBeInTheDocument()
        expect(screen.getByText('Test User')).toBeInTheDocument()
    })

    test('displays recent tasks section', () => {
        renderWithProviders(<Dashboard />)

        expect(screen.getByText('Recent Tasks')).toBeInTheDocument()
        expect(screen.getByText('Recent Task 1')).toBeInTheDocument()
        expect(screen.getByText('Recent Task 2')).toBeInTheDocument()
    })

    test('displays project overview section', () => {
        renderWithProviders(<Dashboard />)

        expect(screen.getByText('Project Overview')).toBeInTheDocument()
        expect(screen.getByText('Active Project 1')).toBeInTheDocument()
        expect(screen.getByText('Active Project 2')).toBeInTheDocument()
    })

    test('displays task summary statistics', () => {
        renderWithProviders(<Dashboard />)

        expect(screen.getByText('Tasks Summary')).toBeInTheDocument()
        expect(screen.getByText('3')).toBeInTheDocument() // Total tasks
        expect(screen.getByText('1')).toBeInTheDocument() // Completed tasks
    })

    test('displays upcoming deadlines', () => {
        renderWithProviders(<Dashboard />)

        expect(screen.getByText('Upcoming Deadlines')).toBeInTheDocument()
        expect(screen.getByText('Recent Task 1')).toBeInTheDocument() // Task with due date
    })

    test('shows loading state when data is loading', () => {
        const store = createTestStore({
            tasks: {
                tasks: [],
                loading: true,
                error: null,
                filters: {},
                sortBy: 'createdAt',
                sortOrder: 'desc',
            },
        })

        renderWithProviders(<Dashboard />, store)

        expect(screen.getByText('Loading...')).toBeInTheDocument()
    })

    test('shows error state when there is an error', () => {
        const store = createTestStore({
            tasks: {
                tasks: [],
                loading: false,
                error: 'Failed to load tasks',
                filters: {},
                sortBy: 'createdAt',
                sortOrder: 'desc',
            },
        })

        renderWithProviders(<Dashboard />, store)

        expect(screen.getByText('Failed to load tasks')).toBeInTheDocument()
    })

    test('shows empty state when no recent tasks', () => {
        const store = createTestStore({
            tasks: {
                tasks: [],
                loading: false,
                error: null,
                filters: {},
                sortBy: 'createdAt',
                sortOrder: 'desc',
            },
        })

        renderWithProviders(<Dashboard />, store)

        expect(screen.getByText('No recent tasks')).toBeInTheDocument()
    })

    test('shows empty state when no upcoming deadlines', () => {
        const tasksWithoutDeadlines = mockTasks.map(task => ({ ...task, dueDate: undefined }))
        const store = createTestStore({
            tasks: {
                tasks: tasksWithoutDeadlines,
                loading: false,
                error: null,
                filters: {},
                sortBy: 'createdAt',
                sortOrder: 'desc',
            },
        })

        renderWithProviders(<Dashboard />, store)

        expect(screen.getByText('No upcoming deadlines')).toBeInTheDocument()
    })

    test('displays task priority indicators', () => {
        renderWithProviders(<Dashboard />)

        expect(screen.getByText('High')).toBeInTheDocument()
        expect(screen.getByText('Medium')).toBeInTheDocument()
    })

    test('displays task status indicators', () => {
        renderWithProviders(<Dashboard />)

        expect(screen.getByText('To Do')).toBeInTheDocument()
        expect(screen.getByText('In Progress')).toBeInTheDocument()
        expect(screen.getByText('Completed')).toBeInTheDocument()
    })

    test('shows view all links for sections', () => {
        renderWithProviders(<Dashboard />)

        const viewAllLinks = screen.getAllByText('View All')
        expect(viewAllLinks.length).toBeGreaterThan(0)
    })

    test('displays correct completion rate', () => {
        renderWithProviders(<Dashboard />)

        expect(screen.getByText('33%')).toBeInTheDocument() // Completion rate
    })

    test('handles user with different roles correctly', () => {
        const memberUser = { ...mockUser, role: 'member' as const }
        const store = createTestStore({
            auth: {
                user: memberUser,
                token: 'test-token',
                isAuthenticated: true,
                loading: false,
                error: null,
            },
        })

        renderWithProviders(<Dashboard />, store)

        expect(screen.getByText('Test User')).toBeInTheDocument()
    })

    test('displays formatted dates correctly', () => {
        renderWithProviders(<Dashboard />)

        // Check that dates are formatted (exact format depends on implementation)
        const dateElements = screen.getAllByText(/\d+\/\d+\/\d+/)
        expect(dateElements.length).toBeGreaterThan(0)
    })

    test('shows overdue tasks with special styling', () => {
        const overdueTask = {
            ...mockTasks[0],
            dueDate: new Date(Date.now() - 24 * 60 * 60 * 1000), // Yesterday
        }
        const store = createTestStore({
            tasks: {
                tasks: [overdueTask, ...mockTasks.slice(1)],
                loading: false,
                error: null,
                filters: {},
                sortBy: 'createdAt',
                sortOrder: 'desc',
            },
        })

        renderWithProviders(<Dashboard />, store)

        // Check for overdue styling (implementation dependent)
        expect(screen.getByText('Recent Task 1')).toBeInTheDocument()
    })

    test('handles empty projects list', () => {
        const store = createTestStore({
            projects: {
                projects: [],
                currentProject: null,
                projectTasks: [],
                projectMetrics: {
                    totalTasks: 0,
                    completedTasks: 0,
                    inProgressTasks: 0,
                    todoTasks: 0,
                    completionRate: 0,
                    overdueTasksCount: 0,
                },
                availableUsers: [],
                loading: false,
                error: null,
            },
        })

        renderWithProviders(<Dashboard />, store)

        expect(screen.getByText('Project Overview')).toBeInTheDocument()
    })

    test('displays user role information', () => {
        renderWithProviders(<Dashboard />)

        // Check if user role is displayed somewhere in the dashboard
        expect(screen.getByText('Test User')).toBeInTheDocument()
    })
})