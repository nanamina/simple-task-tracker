import React from 'react'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { Provider } from 'react-redux'
import { BrowserRouter } from 'react-router-dom'
import { configureStore } from '@reduxjs/toolkit'
import { I18nextProvider } from 'react-i18next'
import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'

// Import components
import LanguageSwitcher from '@/client/components/LanguageSwitcher'
import TaskList from '@/client/components/TaskList'
import ProjectList from '@/client/components/ProjectList'
import Navigation from '@/client/components/Navigation'
import UserProfile from '@/client/components/UserProfile'
import LoginForm from '@/client/components/auth/LoginForm'

// Import slices
import authSlice from '@/client/store/slices/authSlice'
import taskSlice from '@/client/store/slices/taskSlice'
import projectSlice from '@/client/store/slices/projectSlice'
import uiSlice from '@/client/store/slices/uiSlice'

// Import types
import { User, Task, Project } from '@/shared/types'

// Translation resources
const jaTranslations = {
    common: {
        save: '保存',
        cancel: 'キャンセル',
        edit: '編集',
        delete: '削除',
        create: '作成',
        update: '更新',
        loading: '読み込み中...',
        search: '検索',
        sort: '並び替え',
    },
    navigation: {
        dashboard: 'ダッシュボード',
        tasks: 'タスク',
        projects: 'プロジェクト',
        profile: 'プロフィール',
        logout: 'ログアウト',
    },
    tasks: {
        title: 'タスク',
        create: 'タスクを作成',
        edit: 'タスクを編集',
        fields: {
            title: 'タイトル',
            description: '説明',
            status: 'ステータス',
            priority: '優先度',
            dueDate: '期限',
            assignee: '担当者',
            project: 'プロジェクト',
        },
        status: {
            todo: '未着手',
            inProgress: '進行中',
            completed: '完了',
        },
        priority: {
            low: '低',
            medium: '中',
            high: '高',
            critical: '緊急',
        },
        messages: {
            noTasks: 'タスクがありません',
            confirmDelete: 'このタスクを削除してもよろしいですか？',
        },
    },
    projects: {
        title: 'プロジェクト',
        create: 'プロジェクトを作成',
        edit: 'プロジェクトを編集',
        name: 'プロジェクト名',
        description: '説明',
        messages: {
            noProjects: 'プロジェクトがありません',
            confirmDelete: 'このプロジェクトを削除してもよろしいですか？',
        },
    },
    auth: {
        login: {
            title: 'ログイン',
            email: 'メールアドレス',
            password: 'パスワード',
            submit: 'ログイン',
        },
        register: {
            title: '新規登録',
            name: '名前',
            email: 'メールアドレス',
            password: 'パスワード',
            confirmPassword: 'パスワード確認',
            submit: '登録',
        },
    },
    profile: {
        title: 'プロフィール',
        edit: 'プロフィールを編集',
        fields: {
            name: '名前',
            email: 'メールアドレス',
            preferredLanguage: '優先言語',
        },
        languages: {
            ja: '日本語',
            en: 'English',
        },
    },
    validation: {
        required: '{{field}}は必須です',
        email: '有効なメールアドレスを入力してください',
        minLength: '{{field}}は{{min}}文字以上で入力してください',
    },
}

const enTranslations = {
    common: {
        save: 'Save',
        cancel: 'Cancel',
        edit: 'Edit',
        delete: 'Delete',
        create: 'Create',
        update: 'Update',
        loading: 'Loading...',
        search: 'Search',
        sort: 'Sort',
    },
    navigation: {
        dashboard: 'Dashboard',
        tasks: 'Tasks',
        projects: 'Projects',
        profile: 'Profile',
        logout: 'Logout',
    },
    tasks: {
        title: 'Tasks',
        create: 'New Task',
        edit: 'Edit Task',
        fields: {
            title: 'Title',
            description: 'Description',
            status: 'Status',
            priority: 'Priority',
            dueDate: 'Due Date',
            assignee: 'Assignee',
            project: 'Project',
        },
        status: {
            todo: 'To Do',
            inProgress: 'In Progress',
            completed: 'Completed',
        },
        priority: {
            low: 'Low',
            medium: 'Medium',
            high: 'High',
            critical: 'Critical',
        },
        messages: {
            noTasks: 'No tasks found',
            confirmDelete: 'Are you sure you want to delete this task?',
        },
    },
    projects: {
        title: 'Projects',
        create: 'New Project',
        edit: 'Edit Project',
        name: 'Project Name',
        description: 'Description',
        messages: {
            noProjects: 'No projects found',
            confirmDelete: 'Are you sure you want to delete this project?',
        },
    },
    auth: {
        login: {
            title: 'Login',
            email: 'Email',
            password: 'Password',
            submit: 'Login',
        },
        register: {
            title: 'Register',
            name: 'Name',
            email: 'Email',
            password: 'Password',
            confirmPassword: 'Confirm Password',
            submit: 'Register',
        },
    },
    profile: {
        title: 'Profile',
        edit: 'Edit Profile',
        fields: {
            name: 'Name',
            email: 'Email',
            preferredLanguage: 'Preferred Language',
        },
        languages: {
            ja: '日本語',
            en: 'English',
        },
    },
    validation: {
        required: '{{field}} is required',
        email: 'Please enter a valid email address',
        minLength: '{{field}} must be at least {{min}} characters',
    },
}

// Initialize i18n for testing
const createI18nInstance = (language = 'ja') => {
    const i18nInstance = i18n.createInstance()
    i18nInstance.use(initReactI18next).init({
        lng: language,
        fallbackLng: 'en',
        debug: false,
        resources: {
            ja: { translation: jaTranslations },
            en: { translation: enTranslations },
        },
        interpolation: {
            escapeValue: false,
        },
    })
    return i18nInstance
}

// Mock hooks
jest.mock('@/client/hooks/useTasks', () => ({
    useTasks: () => ({
        tasks: [],
        filteredTasks: [],
        loading: false,
        error: null,
        filters: {},
        sortBy: 'createdAt',
        sortOrder: 'desc',
        loadTasks: jest.fn(),
        addTask: jest.fn(),
        editTask: jest.fn(),
        changeTaskStatus: jest.fn(),
        removeTask: jest.fn(),
        updateFilters: jest.fn(),
        updateSorting: jest.fn(),
        clearTaskError: jest.fn(),
    }),
}))

jest.mock('@/client/hooks/useFormatting', () => ({
    useFormatting: () => ({
        formatDate: (date: Date) => date.toLocaleDateString('ja-JP'),
        formatDateTime: (date: Date) => date.toLocaleString('ja-JP'),
    }),
}))

// Mock data
const mockUser: User = {
    id: 'user-1',
    email: 'test@example.com',
    name: 'Test User',
    role: 'member',
    preferredLanguage: 'ja',
    createdAt: new Date(),
    updatedAt: new Date(),
}

const mockTask: Task = {
    id: 'task-1',
    title: 'Test Task',
    description: 'Test Description',
    status: 'todo',
    priority: 'medium',
    createdBy: 'user-1',
    createdAt: new Date(),
    updatedAt: new Date(),
}

const mockProject: Project = {
    id: 'project-1',
    name: 'Test Project',
    description: 'Test Description',
    createdBy: 'user-1',
    createdAt: new Date(),
    updatedAt: new Date(),
    members: ['user-1'],
}

// Helper function to create test store
const createTestStore = (initialState = {}) => {
    const defaultState = {
        auth: {
            user: mockUser,
            token: 'test-token',
            isAuthenticated: true,
            loading: false,
            error: null,
        },
        tasks: {
            tasks: [mockTask],
            loading: false,
            error: null,
            filters: {},
            sortBy: 'createdAt',
            sortOrder: 'desc',
        },
        projects: {
            projects: [mockProject],
            currentProject: mockProject,
            projectTasks: [mockTask],
            projectMetrics: {
                totalTasks: 1,
                completedTasks: 0,
                inProgressTasks: 0,
                todoTasks: 1,
                completionRate: 0,
                overdueTasksCount: 0,
            },
            availableUsers: [mockUser],
            loading: false,
            error: null,
        },
        ui: {
            language: 'ja',
            theme: 'light',
            notifications: [],
        },
    }

    return configureStore({
        reducer: {
            auth: authSlice,
            tasks: taskSlice,
            projects: projectSlice,
            ui: uiSlice,
        },
        preloadedState: { ...defaultState, ...initialState },
    })
}

// Helper function to render component with providers
const renderWithProviders = (
    component: React.ReactElement,
    store = createTestStore(),
    language = 'ja'
) => {
    const i18nInstance = createI18nInstance(language)
    return render(
        <Provider store={store}>
            <I18nextProvider i18n={i18nInstance}>
                <BrowserRouter>
                    {component}
                </BrowserRouter>
            </I18nextProvider>
        </Provider>
    )
}

describe('Internationalization Tests', () => {
    beforeEach(() => {
        // Mock fetch for API calls
        global.fetch = jest.fn().mockResolvedValue({
            ok: true,
            json: () => Promise.resolve({}),
        })
    })

    afterEach(() => {
        jest.restoreAllMocks()
    })

    describe('Language Switching', () => {
        test('Components display Japanese text by default', () => {
            renderWithProviders(<Navigation />)

            expect(screen.getByText('ダッシュボード')).toBeInTheDocument()
            expect(screen.getByText('タスク')).toBeInTheDocument()
            expect(screen.getByText('プロジェクト')).toBeInTheDocument()
        })

        test('Components display English text when language is switched', () => {
            renderWithProviders(<Navigation />, createTestStore(), 'en')

            expect(screen.getByText('Dashboard')).toBeInTheDocument()
            expect(screen.getByText('Tasks')).toBeInTheDocument()
            expect(screen.getByText('Projects')).toBeInTheDocument()
        })

        test('LanguageSwitcher component changes language', async () => {
            const i18nInstance = createI18nInstance('ja')
            const store = createTestStore()

            render(
                <Provider store={store}>
                    <I18nextProvider i18n={i18nInstance}>
                        <BrowserRouter>
                            <LanguageSwitcher />
                        </BrowserRouter>
                    </I18nextProvider>
                </Provider>
            )

            // Find language switcher
            const languageSelect = screen.getByDisplayValue('日本語')
            expect(languageSelect).toBeInTheDocument()

            // Change to English
            fireEvent.change(languageSelect, { target: { value: 'en' } })

            await waitFor(() => {
                expect(i18nInstance.language).toBe('en')
            })
        })
    })

    describe('Task Component Translations', () => {
        test('TaskList displays Japanese translations', () => {
            renderWithProviders(<TaskList />)

            expect(screen.getByText('タスクを作成')).toBeInTheDocument()
            expect(screen.getByPlaceholderText('検索')).toBeInTheDocument()
        })

        test('TaskList displays English translations', () => {
            renderWithProviders(<TaskList />, createTestStore(), 'en')

            expect(screen.getByText('New Task')).toBeInTheDocument()
            expect(screen.getByPlaceholderText('Search')).toBeInTheDocument()
        })

        test('Task status options are translated correctly', () => {
            renderWithProviders(<TaskList />)

            // Check if Japanese status options are present
            expect(screen.getByText('未着手')).toBeInTheDocument()
        })

        test('Task priority options are translated correctly', () => {
            renderWithProviders(<TaskList />)

            // Check if Japanese priority options are present
            expect(screen.getByText('中')).toBeInTheDocument() // Medium priority
        })
    })

    describe('Project Component Translations', () => {
        test('ProjectList displays Japanese translations', () => {
            renderWithProviders(<ProjectList />)

            expect(screen.getByText('プロジェクトを作成')).toBeInTheDocument()
        })

        test('ProjectList displays English translations', () => {
            renderWithProviders(<ProjectList />, createTestStore(), 'en')

            expect(screen.getByText('New Project')).toBeInTheDocument()
        })
    })

    describe('Authentication Component Translations', () => {
        test('LoginForm displays Japanese translations', () => {
            const store = createTestStore({
                auth: {
                    user: null,
                    token: null,
                    isAuthenticated: false,
                    loading: false,
                    error: null,
                },
            })

            renderWithProviders(<LoginForm />, store)

            expect(screen.getByText('ログイン')).toBeInTheDocument()
            expect(screen.getByLabelText('メールアドレス')).toBeInTheDocument()
            expect(screen.getByLabelText('パスワード')).toBeInTheDocument()
        })

        test('LoginForm displays English translations', () => {
            const store = createTestStore({
                auth: {
                    user: null,
                    token: null,
                    isAuthenticated: false,
                    loading: false,
                    error: null,
                },
            })

            renderWithProviders(<LoginForm />, store, 'en')

            expect(screen.getByText('Login')).toBeInTheDocument()
            expect(screen.getByLabelText('Email')).toBeInTheDocument()
            expect(screen.getByLabelText('Password')).toBeInTheDocument()
        })
    })

    describe('User Profile Component Translations', () => {
        test('UserProfile displays Japanese translations', () => {
            renderWithProviders(<UserProfile />)

            expect(screen.getByText('プロフィール')).toBeInTheDocument()
            expect(screen.getByText('プロフィールを編集')).toBeInTheDocument()
        })

        test('UserProfile displays English translations', () => {
            renderWithProviders(<UserProfile />, createTestStore(), 'en')

            expect(screen.getByText('Profile')).toBeInTheDocument()
            expect(screen.getByText('Edit Profile')).toBeInTheDocument()
        })

        test('Language preference options are displayed correctly', () => {
            renderWithProviders(<UserProfile />)

            // Enter edit mode
            const editButton = screen.getByText('プロフィールを編集')
            fireEvent.click(editButton)

            // Check language options
            expect(screen.getByText('日本語')).toBeInTheDocument()
            expect(screen.getByText('English')).toBeInTheDocument()
        })
    })

    describe('Validation Message Translations', () => {
        test('Validation messages are translated to Japanese', async () => {
            renderWithProviders(<TaskList />)

            // Open task form
            const createButton = screen.getByText('タスクを作成')
            fireEvent.click(createButton)

            // Submit without filling required fields
            const submitButton = screen.getByText('作成')
            fireEvent.click(submitButton)

            // Check for Japanese validation messages
            await waitFor(() => {
                expect(screen.getByText('タイトルは必須です')).toBeInTheDocument()
            })
        })

        test('Validation messages are translated to English', async () => {
            renderWithProviders(<TaskList />, createTestStore(), 'en')

            // Open task form
            const createButton = screen.getByText('New Task')
            fireEvent.click(createButton)

            // Submit without filling required fields
            const submitButton = screen.getByText('Create')
            fireEvent.click(submitButton)

            // Check for English validation messages
            await waitFor(() => {
                expect(screen.getByText('Title is required')).toBeInTheDocument()
            })
        })
    })

    describe('Date and Time Formatting', () => {
        test('Dates are formatted according to Japanese locale', () => {
            const testDate = new Date('2024-01-15')
            const expectedFormat = testDate.toLocaleDateString('ja-JP')

            renderWithProviders(<TaskList />)

            // This would test actual date formatting in components
            // The exact implementation depends on how dates are displayed
            expect(expectedFormat).toMatch(/2024\/1\/15/)
        })

        test('Dates are formatted according to English locale when language is English', () => {
            const testDate = new Date('2024-01-15')
            const expectedFormat = testDate.toLocaleDateString('en-US')

            renderWithProviders(<TaskList />, createTestStore(), 'en')

            // This would test actual date formatting in components
            expect(expectedFormat).toMatch(/1\/15\/2024/)
        })
    })

    describe('Pluralization', () => {
        test('Pluralization works correctly for Japanese (no plural forms)', () => {
            // Japanese doesn't have plural forms, so this test ensures
            // that the same form is used regardless of count
            const i18nInstance = createI18nInstance('ja')

            expect(i18nInstance.t('tasks.title')).toBe('タスク')
            // In a real implementation, you might have count-based translations
        })

        test('Pluralization works correctly for English', () => {
            const i18nInstance = createI18nInstance('en')

            expect(i18nInstance.t('tasks.title')).toBe('Tasks')
            // In a real implementation, you might test singular vs plural forms
        })
    })

    describe('Missing Translation Handling', () => {
        test('Falls back to English when Japanese translation is missing', () => {
            const i18nInstance = createI18nInstance('ja')

            // Test with a key that doesn't exist in Japanese
            const result = i18nInstance.t('nonexistent.key')
            expect(result).toBe('nonexistent.key') // i18next default behavior
        })

        test('Shows translation key when both languages are missing translation', () => {
            const i18nInstance = createI18nInstance('ja')

            const result = i18nInstance.t('completely.missing.key')
            expect(result).toBe('completely.missing.key')
        })
    })
})