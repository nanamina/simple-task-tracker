import React from 'react'
import { render } from '@testing-library/react'
import { Provider } from 'react-redux'
import { BrowserRouter } from 'react-router-dom'
import { configureStore } from '@reduxjs/toolkit'
import { axe, toHaveNoViolations } from 'jest-axe'

// Import components to test
import Dashboard from '@/client/components/Dashboard'
import TaskList from '@/client/components/TaskList'
import TaskForm from '@/client/components/TaskForm'
import ProjectList from '@/client/components/ProjectList'
import ProjectForm from '@/client/components/ProjectForm'
import Navigation from '@/client/components/Navigation'
import UserProfile from '@/client/components/UserProfile'
import LoginForm from '@/client/components/auth/LoginForm'
import RegisterForm from '@/client/components/auth/RegisterForm'

// Import slices
import authSlice from '@/client/store/slices/authSlice'
import taskSlice from '@/client/store/slices/taskSlice'
import projectSlice from '@/client/store/slices/projectSlice'
import uiSlice from '@/client/store/slices/uiSlice'

// Import types
import { User, Task, Project } from '@/shared/types'

// Extend Jest matchers
expect.extend(toHaveNoViolations)

// Mock i18next
jest.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string, options?: any) => {
            const translations: Record<string, string> = {
                'common.loading': 'Loading...',
                'common.save': 'Save',
                'common.cancel': 'Cancel',
                'common.edit': 'Edit',
                'common.delete': 'Delete',
                'common.create': 'Create',
                'navigation.dashboard': 'Dashboard',
                'navigation.tasks': 'Tasks',
                'navigation.projects': 'Projects',
                'navigation.profile': 'Profile',
                'navigation.logout': 'Logout',
                'tasks.title': 'Tasks',
                'tasks.create': 'New Task',
                'tasks.fields.title': 'Title',
                'tasks.fields.description': 'Description',
                'tasks.fields.status': 'Status',
                'tasks.fields.priority': 'Priority',
                'tasks.fields.dueDate': 'Due Date',
                'tasks.status.todo': 'To Do',
                'tasks.status.inProgress': 'In Progress',
                'tasks.status.completed': 'Completed',
                'tasks.priority.low': 'Low',
                'tasks.priority.medium': 'Medium',
                'tasks.priority.high': 'High',
                'tasks.priority.critical': 'Critical',
                'projects.title': 'Projects',
                'projects.create': 'New Project',
                'projects.name': 'Project Name',
                'projects.description': 'Description',
                'auth.login.title': 'Login',
                'auth.login.email': 'Email',
                'auth.login.password': 'Password',
                'auth.login.submit': 'Login',
                'auth.register.title': 'Register',
                'auth.register.name': 'Name',
                'auth.register.email': 'Email',
                'auth.register.password': 'Password',
                'auth.register.confirmPassword': 'Confirm Password',
                'auth.register.submit': 'Register',
                'profile.title': 'Profile',
                'profile.fields.name': 'Name',
                'profile.fields.email': 'Email',
                'profile.fields.preferredLanguage': 'Preferred Language',
                'dashboard.title': 'Dashboard',
                'dashboard.welcome': 'Welcome back',
                'validation.required': `${options?.field || 'Field'} is required`,
            }
            return translations[key] || key
        },
    }),
}))

// Mock hooks
jest.mock('@/client/hooks/useTasks', () => ({
    useTasks: () => ({
        tasks: [],
        filteredTasks: [],
        loading: false,
        error: null,
        filters: {},
        sortBy: 'createdAt',
        sortOrder: 'desc',
        loadTasks: jest.fn(),
        addTask: jest.fn(),
        editTask: jest.fn(),
        changeTaskStatus: jest.fn(),
        removeTask: jest.fn(),
        updateFilters: jest.fn(),
        updateSorting: jest.fn(),
        clearTaskError: jest.fn(),
    }),
}))

jest.mock('@/client/hooks/useFormatting', () => ({
    useFormatting: () => ({
        formatDate: (date: Date) => date.toLocaleDateString('ja-JP'),
        formatDateTime: (date: Date) => date.toLocaleString('ja-JP'),
    }),
}))

// Mock data
const mockUser: User = {
    id: 'user-1',
    email: 'test@example.com',
    name: 'Test User',
    role: 'member',
    preferredLanguage: 'ja',
    createdAt: new Date(),
    updatedAt: new Date(),
}

const mockTask: Task = {
    id: 'task-1',
    title: 'Test Task',
    description: 'Test Description',
    status: 'todo',
    priority: 'medium',
    createdBy: 'user-1',
    createdAt: new Date(),
    updatedAt: new Date(),
}

const mockProject: Project = {
    id: 'project-1',
    name: 'Test Project',
    description: 'Test Description',
    createdBy: 'user-1',
    createdAt: new Date(),
    updatedAt: new Date(),
    members: ['user-1'],
}

// Helper function to create test store
const createTestStore = (initialState = {}) => {
    const defaultState = {
        auth: {
            user: mockUser,
            token: 'test-token',
            isAuthenticated: true,
            loading: false,
            error: null,
        },
        tasks: {
            tasks: [mockTask],
            loading: false,
            error: null,
            filters: {},
            sortBy: 'createdAt',
            sortOrder: 'desc',
        },
        projects: {
            projects: [mockProject],
            currentProject: mockProject,
            projectTasks: [mockTask],
            projectMetrics: {
                totalTasks: 1,
                completedTasks: 0,
                inProgressTasks: 0,
                todoTasks: 1,
                completionRate: 0,
                overdueTasksCount: 0,
            },
            availableUsers: [mockUser],
            loading: false,
            error: null,
        },
        ui: {
            language: 'ja',
            theme: 'light',
            notifications: [],
        },
    }

    return configureStore({
        reducer: {
            auth: authSlice,
            tasks: taskSlice,
            projects: projectSlice,
            ui: uiSlice,
        },
        preloadedState: { ...defaultState, ...initialState },
    })
}

// Helper function to render component with providers
const renderWithProviders = (component: React.ReactElement, store = createTestStore()) => {
    return render(
        <Provider store={store}>
            <BrowserRouter>
                {component}
            </BrowserRouter>
        </Provider>
    )
}

describe('Accessibility Tests', () => {
    beforeEach(() => {
        // Mock fetch for API calls
        global.fetch = jest.fn().mockResolvedValue({
            ok: true,
            json: () => Promise.resolve({}),
        })
    })

    afterEach(() => {
        jest.restoreAllMocks()
    })

    test('Dashboard component should have no accessibility violations', async () => {
        const { container } = renderWithProviders(<Dashboard />)
        const results = await axe(container)
        expect(results).toHaveNoViolations()
    })

    test('Navigation component should have no accessibility violations', async () => {
        const { container } = renderWithProviders(<Navigation />)
        const results = await axe(container)
        expect(results).toHaveNoViolations()
    })

    test('TaskList component should have no accessibility violations', async () => {
        const { container } = renderWithProviders(<TaskList />)
        const results = await axe(container)
        expect(results).toHaveNoViolations()
    })

    test('TaskForm component should have no accessibility violations', async () => {
        const { container } = renderWithProviders(
            <TaskForm onSubmit={jest.fn()} onCancel={jest.fn()} loading={false} />
        )
        const results = await axe(container)
        expect(results).toHaveNoViolations()
    })

    test('ProjectList component should have no accessibility violations', async () => {
        const { container } = renderWithProviders(<ProjectList />)
        const results = await axe(container)
        expect(results).toHaveNoViolations()
    })

    test('ProjectForm component should have no accessibility violations', async () => {
        const { container } = renderWithProviders(<ProjectForm />)
        const results = await axe(container)
        expect(results).toHaveNoViolations()
    })

    test('UserProfile component should have no accessibility violations', async () => {
        const { container } = renderWithProviders(<UserProfile />)
        const results = await axe(container)
        expect(results).toHaveNoViolations()
    })

    test('LoginForm component should have no accessibility violations', async () => {
        const store = createTestStore({
            auth: {
                user: null,
                token: null,
                isAuthenticated: false,
                loading: false,
                error: null,
            },
        })
        const { container } = renderWithProviders(<LoginForm />, store)
        const results = await axe(container)
        expect(results).toHaveNoViolations()
    })

    test('RegisterForm component should have no accessibility violations', async () => {
        const store = createTestStore({
            auth: {
                user: null,
                token: null,
                isAuthenticated: false,
                loading: false,
                error: null,
            },
        })
        const { container } = renderWithProviders(<RegisterForm />, store)
        const results = await axe(container)
        expect(results).toHaveNoViolations()
    })

    test('Components should have proper ARIA labels and roles', async () => {
        const { container } = renderWithProviders(<Navigation />)

        // Check for proper navigation landmarks
        const nav = container.querySelector('nav')
        expect(nav).toBeInTheDocument()

        // Check for proper button roles and labels
        const buttons = container.querySelectorAll('button')
        buttons.forEach(button => {
            expect(button).toHaveAttribute('type')
        })
    })

    test('Form components should have proper labels and descriptions', async () => {
        const { container } = renderWithProviders(
            <TaskForm onSubmit={jest.fn()} onCancel={jest.fn()} loading={false} />
        )

        // Check that all form inputs have associated labels
        const inputs = container.querySelectorAll('input, select, textarea')
        inputs.forEach(input => {
            const id = input.getAttribute('id')
            if (id) {
                const label = container.querySelector(`label[for="${id}"]`)
                expect(label).toBeInTheDocument()
            }
        })
    })

    test('Interactive elements should be keyboard accessible', async () => {
        const { container } = renderWithProviders(<Navigation />)

        // Check that interactive elements can receive focus
        const interactiveElements = container.querySelectorAll('button, a, input, select, textarea')
        interactiveElements.forEach(element => {
            expect(element).not.toHaveAttribute('tabindex', '-1')
        })
    })
})