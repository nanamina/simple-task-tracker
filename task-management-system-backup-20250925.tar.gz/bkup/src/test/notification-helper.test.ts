/**
 * Unit tests for notification helper service utility functions
 */

import {
    areNotificationsEnabled,
    logNotificationAttempt
} from '../server/services/notification-helper'

describe('Notification Helper Service', () => {
    beforeEach(() => {
        jest.clearAllMocks()

        // Mock console methods to avoid noise in tests
        jest.spyOn(console, 'log').mockImplementation()
        jest.spyOn(console, 'warn').mockImplementation()
        jest.spyOn(console, 'error').mockImplementation()
    })

    afterEach(() => {
        jest.restoreAllMocks()
    })

    describe('areNotificationsEnabled', () => {
        it('should return true when all SMTP variables are set', () => {
            process.env.SMTP_HOST = 'smtp.test.com'
            process.env.SMTP_USER = 'test@smtp.com'
            process.env.SMTP_PASSWORD = 'password'

            expect(areNotificationsEnabled()).toBe(true)
        })

        it('should return false when SMTP variables are missing', () => {
            delete process.env.SMTP_HOST
            delete process.env.SMTP_USER
            delete process.env.SMTP_PASSWORD

            expect(areNotificationsEnabled()).toBe(false)
        })

        it('should return false when only some SMTP variables are set', () => {
            process.env.SMTP_HOST = 'smtp.test.com'
            delete process.env.SMTP_USER
            delete process.env.SMTP_PASSWORD

            expect(areNotificationsEnabled()).toBe(false)
        })
    })

    describe('logNotificationAttempt', () => {
        it('should log notification attempts', () => {
            const consoleSpy = jest.spyOn(console, 'log').mockImplementation()

            logNotificationAttempt('assignment', 'task-123', ['user1@test.com', 'user2@test.com'])

            expect(consoleSpy).toHaveBeenCalledWith(
                'Notification attempt: assignment for task task-123 to recipients: user1@test.com, user2@test.com'
            )
        })
    })
})