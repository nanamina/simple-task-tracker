/**
 * Unit tests for authentication middleware
 */

import { Request, Response, NextFunction } from 'express'
import { authenticateToken, optionalAuth, requireRole, requireAdmin, requireManagerOrAdmin } from '../server/middleware/auth'
import { generateToken } from '../server/services/auth'
import { User } from '../shared/types/index'

// Mock user data for testing
const mockUser: User = {
    id: '123e4567-e89b-12d3-a456-426614174000',
    email: 'test@example.com',
    name: 'Test User',
    role: 'member',
    preferredLanguage: 'ja',
    createdAt: new Date(),
    updatedAt: new Date()
}

const mockAdminUser: User = {
    ...mockUser,
    id: '123e4567-e89b-12d3-a456-426614174001',
    email: 'admin@example.com',
    name: 'Admin User',
    role: 'admin'
}

const mockManagerUser: User = {
    ...mockUser,
    id: '123e4567-e89b-12d3-a456-426614174002',
    email: 'manager@example.com',
    name: 'Manager User',
    role: 'manager'
}

// Mock Express request and response objects
const createMockRequest = (authHeader?: string): Partial<Request> => ({
    headers: {
        authorization: authHeader
    }
})

const createMockResponse = (): Partial<Response> => {
    const res: Partial<Response> = {}
    res.status = jest.fn().mockReturnValue(res)
    res.json = jest.fn().mockReturnValue(res)
    return res
}

const mockNext: NextFunction = jest.fn()

describe('Authentication Middleware', () => {
    beforeEach(() => {
        jest.clearAllMocks()
    })

    describe('authenticateToken', () => {
        it('should authenticate valid token and add user to request', () => {
            const token = generateToken(mockUser)
            const req = createMockRequest(`Bearer ${token}`) as Request
            const res = createMockResponse() as Response

            authenticateToken(req, res, mockNext)

            expect(req.user).toBeDefined()
            expect(req.user?.id).toBe(mockUser.id)
            expect(req.user?.email).toBe(mockUser.email)
            expect(req.user?.role).toBe(mockUser.role)
            expect(mockNext).toHaveBeenCalled()
        })

        it('should reject request without authorization header', () => {
            const req = createMockRequest() as Request
            const res = createMockResponse() as Response

            authenticateToken(req, res, mockNext)

            expect(res.status).toHaveBeenCalledWith(401)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Access token is required',
                    timestamp: expect.any(String)
                }
            })
            expect(mockNext).not.toHaveBeenCalled()
        })

        it('should reject request with invalid token format', () => {
            const req = createMockRequest('InvalidToken') as Request
            const res = createMockResponse() as Response

            authenticateToken(req, res, mockNext)

            expect(res.status).toHaveBeenCalledWith(401)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Access token is required',
                    timestamp: expect.any(String)
                }
            })
            expect(mockNext).not.toHaveBeenCalled()
        })

        it('should reject request with invalid token', () => {
            const req = createMockRequest('Bearer invalid-token') as Request
            const res = createMockResponse() as Response

            authenticateToken(req, res, mockNext)

            expect(res.status).toHaveBeenCalledWith(401)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Invalid or expired token',
                    timestamp: expect.any(String)
                }
            })
            expect(mockNext).not.toHaveBeenCalled()
        })
    })

    describe('optionalAuth', () => {
        it('should add user to request if valid token provided', () => {
            const token = generateToken(mockUser)
            const req = createMockRequest(`Bearer ${token}`) as Request
            const res = createMockResponse() as Response

            optionalAuth(req, res, mockNext)

            expect(req.user).toBeDefined()
            expect(req.user?.id).toBe(mockUser.id)
            expect(mockNext).toHaveBeenCalled()
        })

        it('should continue without user if no token provided', () => {
            const req = createMockRequest() as Request
            const res = createMockResponse() as Response

            optionalAuth(req, res, mockNext)

            expect(req.user).toBeUndefined()
            expect(mockNext).toHaveBeenCalled()
        })

        it('should continue without user if invalid token provided', () => {
            const req = createMockRequest('Bearer invalid-token') as Request
            const res = createMockResponse() as Response

            optionalAuth(req, res, mockNext)

            expect(req.user).toBeUndefined()
            expect(mockNext).toHaveBeenCalled()
        })
    })

    describe('requireRole', () => {
        it('should allow access for user with required role', () => {
            const req = createMockRequest() as Request
            req.user = { id: mockUser.id, email: mockUser.email, role: 'member' }
            const res = createMockResponse() as Response
            const middleware = requireRole(['member', 'admin'])

            middleware(req, res, mockNext)

            expect(mockNext).toHaveBeenCalled()
        })

        it('should deny access for user without required role', () => {
            const req = createMockRequest() as Request
            req.user = { id: mockUser.id, email: mockUser.email, role: 'member' }
            const res = createMockResponse() as Response
            const middleware = requireRole(['admin'])

            middleware(req, res, mockNext)

            expect(res.status).toHaveBeenCalledWith(403)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied. Required roles: admin',
                    timestamp: expect.any(String)
                }
            })
            expect(mockNext).not.toHaveBeenCalled()
        })

        it('should deny access for unauthenticated user', () => {
            const req = createMockRequest() as Request
            const res = createMockResponse() as Response
            const middleware = requireRole(['member'])

            middleware(req, res, mockNext)

            expect(res.status).toHaveBeenCalledWith(401)
            expect(res.json).toHaveBeenCalledWith({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: expect.any(String)
                }
            })
            expect(mockNext).not.toHaveBeenCalled()
        })
    })

    describe('requireAdmin', () => {
        it('should allow access for admin user', () => {
            const req = createMockRequest() as Request
            req.user = { id: mockAdminUser.id, email: mockAdminUser.email, role: 'admin' }
            const res = createMockResponse() as Response

            requireAdmin(req, res, mockNext)

            expect(mockNext).toHaveBeenCalled()
        })

        it('should deny access for non-admin user', () => {
            const req = createMockRequest() as Request
            req.user = { id: mockUser.id, email: mockUser.email, role: 'member' }
            const res = createMockResponse() as Response

            requireAdmin(req, res, mockNext)

            expect(res.status).toHaveBeenCalledWith(403)
            expect(mockNext).not.toHaveBeenCalled()
        })
    })

    describe('requireManagerOrAdmin', () => {
        it('should allow access for admin user', () => {
            const req = createMockRequest() as Request
            req.user = { id: mockAdminUser.id, email: mockAdminUser.email, role: 'admin' }
            const res = createMockResponse() as Response

            requireManagerOrAdmin(req, res, mockNext)

            expect(mockNext).toHaveBeenCalled()
        })

        it('should allow access for manager user', () => {
            const req = createMockRequest() as Request
            req.user = { id: mockManagerUser.id, email: mockManagerUser.email, role: 'manager' }
            const res = createMockResponse() as Response

            requireManagerOrAdmin(req, res, mockNext)

            expect(mockNext).toHaveBeenCalled()
        })

        it('should deny access for member user', () => {
            const req = createMockRequest() as Request
            req.user = { id: mockUser.id, email: mockUser.email, role: 'member' }
            const res = createMockResponse() as Response

            requireManagerOrAdmin(req, res, mockNext)

            expect(res.status).toHaveBeenCalledWith(403)
            expect(mockNext).not.toHaveBeenCalled()
        })
    })
})