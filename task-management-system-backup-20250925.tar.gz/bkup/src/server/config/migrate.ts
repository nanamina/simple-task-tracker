import { readFileSync } from 'fs'
import { join } from 'path'
import { getPool } from './database'

/**
 * Migration file interface
 */
interface Migration {
    id: string
    filename: string
    sql: string
}

/**
 * Migration runner class for handling database migrations
 */
export class MigrationRunner {
    private pool = getPool()
    private migrationsPath = join(__dirname, '..', '..', '..', 'migrations')

    /**
     * Initialize migration tracking table
     */
    private async initializeMigrationTable(): Promise<void> {
        const createTableSQL = `
      CREATE TABLE IF NOT EXISTS migrations (
        id SERIAL PRIMARY KEY,
        filename VARCHAR(255) UNIQUE NOT NULL,
        executed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `

        await this.pool.query(createTableSQL)
    }

    /**
     * Get list of executed migrations
     */
    private async getExecutedMigrations(): Promise<string[]> {
        const result = await this.pool.query(
            'SELECT filename FROM migrations ORDER BY id'
        )
        return result.rows.map(row => row.filename)
    }

    /**
     * Load migration files from disk
     */
    private loadMigrations(): Migration[] {
        const fs = require('fs')
        const files = fs.readdirSync(this.migrationsPath)
            .filter((file: string) => file.endsWith('.sql'))
            .sort()

        return files.map((filename: string) => {
            const filepath = join(this.migrationsPath, filename)
            const sql = readFileSync(filepath, 'utf8')
            const id = filename.replace('.sql', '')

            return { id, filename, sql }
        })
    }

    /**
     * Execute a single migration
     */
    private async executeMigration(migration: Migration): Promise<void> {
        const client = await this.pool.connect()

        try {
            await client.query('BEGIN')

            // Execute the migration SQL
            await client.query(migration.sql)

            // Record the migration as executed
            await client.query(
                'INSERT INTO migrations (filename) VALUES ($1)',
                [migration.filename]
            )

            await client.query('COMMIT')
            console.log(`✓ Executed migration: ${migration.filename}`)
        } catch (error) {
            await client.query('ROLLBACK')
            console.error(`✗ Failed to execute migration: ${migration.filename}`)
            throw error
        } finally {
            client.release()
        }
    }

    /**
     * Run all pending migrations
     */
    async runMigrations(): Promise<void> {
        try {
            console.log('Starting database migrations...')

            // Initialize migration tracking
            await this.initializeMigrationTable()

            // Get executed migrations
            const executedMigrations = await this.getExecutedMigrations()

            // Load all migration files
            const allMigrations = this.loadMigrations()

            // Filter out already executed migrations
            const pendingMigrations = allMigrations.filter(
                migration => !executedMigrations.includes(migration.filename)
            )

            if (pendingMigrations.length === 0) {
                console.log('No pending migrations found.')
                return
            }

            console.log(`Found ${pendingMigrations.length} pending migrations`)

            // Execute pending migrations
            for (const migration of pendingMigrations) {
                await this.executeMigration(migration)
            }

            console.log('All migrations completed successfully!')
        } catch (error) {
            console.error('Migration failed:', error)
            throw error
        }
    }

    /**
     * Rollback the last migration (basic implementation)
     */
    async rollbackLastMigration(): Promise<void> {
        try {
            const result = await this.pool.query(
                'SELECT filename FROM migrations ORDER BY id DESC LIMIT 1'
            )

            if (result.rows.length === 0) {
                console.log('No migrations to rollback.')
                return
            }

            const lastMigration = result.rows[0].filename
            console.log(`Rolling back migration: ${lastMigration}`)

            // Remove from migrations table
            await this.pool.query(
                'DELETE FROM migrations WHERE filename = $1',
                [lastMigration]
            )

            console.log(`✓ Rolled back migration: ${lastMigration}`)
            console.log('Note: You may need to manually undo schema changes.')
        } catch (error) {
            console.error('Rollback failed:', error)
            throw error
        }
    }

    /**
     * Get migration status
     */
    async getMigrationStatus(): Promise<void> {
        try {
            await this.initializeMigrationTable()

            const executedMigrations = await this.getExecutedMigrations()
            const allMigrations = this.loadMigrations()

            console.log('\nMigration Status:')
            console.log('================')

            for (const migration of allMigrations) {
                const status = executedMigrations.includes(migration.filename) ? '✓' : '✗'
                console.log(`${status} ${migration.filename}`)
            }

            const pendingCount = allMigrations.length - executedMigrations.length
            console.log(`\nExecuted: ${executedMigrations.length}`)
            console.log(`Pending: ${pendingCount}`)
        } catch (error) {
            console.error('Failed to get migration status:', error)
            throw error
        }
    }
}

/**
 * Create and export migration runner instance
 */
export const migrationRunner = new MigrationRunner()