/**
 * Environment Configuration Management
 * 
 * Centralized configuration for different deployment environments
 */

import * as dotenv from 'dotenv'
import { productionPoolConfig } from './production'

// Load environment variables
dotenv.config()

export type Environment = 'development' | 'production' | 'test' | 'staging'

/**
 * Get current environment
 */
export const getEnvironment = (): Environment => {
    const env = process.env.NODE_ENV as Environment
    return env || 'development'
}

/**
 * Environment-specific configuration
 */
interface EnvironmentConfig {
    server: {
        port: number
        host: string
        cors: {
            origin: string | string[]
            credentials: boolean
        }
    }
    database: {
        url: string
        pool: {
            max: number
            idleTimeoutMillis: number
            connectionTimeoutMillis: number
            maxUses?: number
        }
        ssl: boolean
    }
    jwt: {
        secret: string
        expiresIn: string
    }
    email: {
        host: string
        port: number
        secure: boolean
        auth: {
            user: string
            pass: string
        }
    }
    logging: {
        level: string
        format: string
    }
    features: {
        rateLimiting: boolean
        compression: boolean
        securityHeaders: boolean
        detailedErrors: boolean
    }
}

/**
 * Development configuration
 */
const developmentConfig: EnvironmentConfig = {
    server: {
        port: parseInt(process.env.PORT || '3001'),
        host: process.env.HOST || 'localhost',
        cors: {
            origin: process.env.CLIENT_URL || 'http://localhost:3000',
            credentials: true
        }
    },
    database: {
        url: process.env.DATABASE_URL || 'postgresql://username:password@localhost:5432/task_management',
        pool: {
            max: 10,
            idleTimeoutMillis: 30000,
            connectionTimeoutMillis: 2000
        },
        ssl: false
    },
    jwt: {
        secret: process.env.JWT_SECRET || 'development-secret-key',
        expiresIn: process.env.JWT_EXPIRES_IN || '7d'
    },
    email: {
        host: process.env.SMTP_HOST || 'localhost',
        port: parseInt(process.env.SMTP_PORT || '587'),
        secure: false,
        auth: {
            user: process.env.SMTP_USER || '',
            pass: process.env.SMTP_PASSWORD || ''
        }
    },
    logging: {
        level: 'debug',
        format: 'dev'
    },
    features: {
        rateLimiting: false,
        compression: false,
        securityHeaders: false,
        detailedErrors: true
    }
}

/**
 * Production configuration
 */
const productionConfig: EnvironmentConfig = {
    server: {
        port: parseInt(process.env.PORT || '3001'),
        host: process.env.HOST || '0.0.0.0',
        cors: {
            origin: process.env.CLIENT_URL?.split(',') || ['https://yourdomain.com'],
            credentials: true
        }
    },
    database: {
        url: process.env.DATABASE_URL || '',
        pool: productionPoolConfig,
        ssl: true
    },
    jwt: {
        secret: process.env.JWT_SECRET || '',
        expiresIn: process.env.JWT_EXPIRES_IN || '24h'
    },
    email: {
        host: process.env.SMTP_HOST || '',
        port: parseInt(process.env.SMTP_PORT || '587'),
        secure: true,
        auth: {
            user: process.env.SMTP_USER || '',
            pass: process.env.SMTP_PASSWORD || ''
        }
    },
    logging: {
        level: 'info',
        format: 'combined'
    },
    features: {
        rateLimiting: true,
        compression: true,
        securityHeaders: true,
        detailedErrors: false
    }
}

/**
 * Test configuration
 */
const testConfig: EnvironmentConfig = {
    server: {
        port: parseInt(process.env.PORT || '3002'),
        host: 'localhost',
        cors: {
            origin: 'http://localhost:3000',
            credentials: true
        }
    },
    database: {
        url: process.env.TEST_DATABASE_URL || 'postgresql://test:test@localhost:5432/test_db',
        pool: {
            max: 5,
            idleTimeoutMillis: 1000,
            connectionTimeoutMillis: 1000
        },
        ssl: false
    },
    jwt: {
        secret: 'test-secret-key',
        expiresIn: '1h'
    },
    email: {
        host: 'localhost',
        port: 587,
        secure: false,
        auth: {
            user: 'test',
            pass: 'test'
        }
    },
    logging: {
        level: 'error',
        format: 'dev'
    },
    features: {
        rateLimiting: false,
        compression: false,
        securityHeaders: false,
        detailedErrors: true
    }
}

/**
 * Staging configuration
 */
const stagingConfig: EnvironmentConfig = {
    ...productionConfig,
    server: {
        ...productionConfig.server,
        cors: {
            origin: process.env.CLIENT_URL?.split(',') || ['https://staging.yourdomain.com'],
            credentials: true
        }
    },
    logging: {
        level: 'debug',
        format: 'combined'
    },
    features: {
        ...productionConfig.features,
        detailedErrors: true
    }
}

/**
 * Get configuration for current environment
 */
export const getConfig = (): EnvironmentConfig => {
    const env = getEnvironment()

    switch (env) {
        case 'production':
            return productionConfig
        case 'staging':
            return stagingConfig
        case 'test':
            return testConfig
        case 'development':
        default:
            return developmentConfig
    }
}

/**
 * Validate required environment variables
 */
export const validateEnvironment = (): void => {
    const env = getEnvironment()
    const config = getConfig()

    const requiredVars: string[] = []

    if (env === 'production') {
        requiredVars.push(
            'DATABASE_URL',
            'JWT_SECRET',
            'CLIENT_URL'
        )

        // Check if email is configured for notifications
        if (process.env.SMTP_HOST) {
            requiredVars.push('SMTP_USER', 'SMTP_PASSWORD')
        }
    }

    const missingVars = requiredVars.filter(varName => !process.env[varName])

    if (missingVars.length > 0) {
        throw new Error(`Missing required environment variables: ${missingVars.join(', ')}`)
    }

    // Validate JWT secret strength in production
    if (env === 'production' && config.jwt.secret.length < 32) {
        throw new Error('JWT_SECRET must be at least 32 characters long in production')
    }

    // Validate database URL format
    if (!config.database.url.startsWith('postgresql://')) {
        throw new Error('DATABASE_URL must be a valid PostgreSQL connection string')
    }
}

/**
 * Get database pool configuration
 */
export const getDatabaseConfig = () => {
    const config = getConfig()
    return {
        connectionString: config.database.url,
        ssl: config.database.ssl ? { rejectUnauthorized: false } : false,
        ...config.database.pool
    }
}

/**
 * Check if feature is enabled
 */
export const isFeatureEnabled = (feature: keyof EnvironmentConfig['features']): boolean => {
    const config = getConfig()
    return config.features[feature]
}

/**
 * Get server configuration
 */
export const getServerConfig = () => {
    const config = getConfig()
    return config.server
}

/**
 * Get JWT configuration
 */
export const getJWTConfig = () => {
    const config = getConfig()
    return config.jwt
}

/**
 * Get email configuration
 */
export const getEmailConfig = () => {
    const config = getConfig()
    return config.email
}

/**
 * Get logging configuration
 */
export const getLoggingConfig = () => {
    const config = getConfig()
    return config.logging
}