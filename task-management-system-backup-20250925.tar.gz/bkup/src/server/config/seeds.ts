import bcrypt from 'bcrypt'
import { getPool } from './database'

/**
 * Seed data interface definitions
 */
interface SeedUser {
    email: string
    name: string
    password: string
    role: 'admin' | 'manager' | 'member'
    preferredLanguage: 'ja' | 'en'
}

interface SeedProject {
    name: string
    description: string
    createdByEmail: string
}

interface SeedTask {
    title: string
    description: string
    status: 'todo' | 'in-progress' | 'completed'
    priority: 'low' | 'medium' | 'high' | 'critical'
    dueDate?: string
    assigneeEmail?: string
    projectName?: string
    createdByEmail: string
}

/**
 * Database seeder class for development and testing data
 */
export class DatabaseSeeder {
    private pool = getPool()

    /**
     * Hash password for user creation
     */
    private async hashPassword(password: string): Promise<string> {
        const saltRounds = 10
        return bcrypt.hash(password, saltRounds)
    }

    /**
     * Clear all data from tables (for testing)
     */
    async clearAllData(): Promise<void> {
        const client = await this.pool.connect()

        try {
            await client.query('BEGIN')

            // Delete in reverse order of dependencies
            await client.query('DELETE FROM project_members')
            await client.query('DELETE FROM tasks')
            await client.query('DELETE FROM projects')
            await client.query('DELETE FROM users')

            await client.query('COMMIT')
            console.log('✓ Cleared all seed data')
        } catch (error) {
            await client.query('ROLLBACK')
            console.error('✗ Failed to clear data:', error)
            throw error
        } finally {
            client.release()
        }
    }

    /**
     * Seed users table with sample data
     */
    async seedUsers(): Promise<Map<string, string>> {
        const users: SeedUser[] = [
            {
                email: 'admin@example.com',
                name: '管理者 太郎',
                password: 'admin123',
                role: 'admin',
                preferredLanguage: 'ja'
            },
            {
                email: 'manager@example.com',
                name: 'マネージャー 花子',
                password: 'manager123',
                role: 'manager',
                preferredLanguage: 'ja'
            },
            {
                email: 'developer1@example.com',
                name: '開発者 一郎',
                password: 'dev123',
                role: 'member',
                preferredLanguage: 'ja'
            },
            {
                email: 'developer2@example.com',
                name: 'John Smith',
                password: 'dev123',
                role: 'member',
                preferredLanguage: 'en'
            },
            {
                email: 'tester@example.com',
                name: 'テスター 次郎',
                password: 'test123',
                role: 'member',
                preferredLanguage: 'ja'
            }
        ]

        const userIdMap = new Map<string, string>()

        for (const user of users) {
            const hashedPassword = await this.hashPassword(user.password)

            const result = await this.pool.query(`
        INSERT INTO users (email, name, password_hash, role, preferred_language)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING id
      `, [user.email, user.name, hashedPassword, user.role, user.preferredLanguage])

            userIdMap.set(user.email, result.rows[0].id)
        }

        console.log(`✓ Seeded ${users.length} users`)
        return userIdMap
    }

    /**
     * Seed projects table with sample data
     */
    async seedProjects(userIdMap: Map<string, string>): Promise<Map<string, string>> {
        const projects: SeedProject[] = [
            {
                name: 'ウェブサイトリニューアル',
                description: '会社のウェブサイトを新しいデザインでリニューアルするプロジェクト',
                createdByEmail: 'manager@example.com'
            },
            {
                name: 'Mobile App Development',
                description: 'Development of a new mobile application for task management',
                createdByEmail: 'manager@example.com'
            },
            {
                name: 'データベース最適化',
                description: 'システムのパフォーマンス向上のためのデータベース最適化',
                createdByEmail: 'admin@example.com'
            },
            {
                name: 'User Testing Project',
                description: 'Comprehensive user testing for the new features',
                createdByEmail: 'manager@example.com'
            }
        ]

        const projectIdMap = new Map<string, string>()

        for (const project of projects) {
            const createdById = userIdMap.get(project.createdByEmail)
            if (!createdById) {
                throw new Error(`User not found: ${project.createdByEmail}`)
            }

            const result = await this.pool.query(`
        INSERT INTO projects (name, description, created_by)
        VALUES ($1, $2, $3)
        RETURNING id
      `, [project.name, project.description, createdById])

            projectIdMap.set(project.name, result.rows[0].id)
        }

        console.log(`✓ Seeded ${projects.length} projects`)
        return projectIdMap
    }

    /**
     * Seed tasks table with sample data
     */
    async seedTasks(userIdMap: Map<string, string>, projectIdMap: Map<string, string>): Promise<void> {
        const tasks: SeedTask[] = [
            {
                title: 'デザインモックアップ作成',
                description: '新しいウェブサイトのデザインモックアップを作成する',
                status: 'completed',
                priority: 'high',
                dueDate: '2024-01-15',
                assigneeEmail: 'developer1@example.com',
                projectName: 'ウェブサイトリニューアル',
                createdByEmail: 'manager@example.com'
            },
            {
                title: 'フロントエンド実装',
                description: 'React コンポーネントの実装とスタイリング',
                status: 'in-progress',
                priority: 'high',
                dueDate: '2024-02-01',
                assigneeEmail: 'developer1@example.com',
                projectName: 'ウェブサイトリニューアル',
                createdByEmail: 'manager@example.com'
            },
            {
                title: 'API エンドポイント設計',
                description: 'RESTful API の設計と仕様書作成',
                status: 'todo',
                priority: 'medium',
                dueDate: '2024-01-25',
                assigneeEmail: 'developer2@example.com',
                projectName: 'Mobile App Development',
                createdByEmail: 'manager@example.com'
            },
            {
                title: 'Database Schema Review',
                description: 'Review and optimize database schema for better performance',
                status: 'todo',
                priority: 'critical',
                dueDate: '2024-01-20',
                assigneeEmail: 'developer2@example.com',
                projectName: 'データベース最適化',
                createdByEmail: 'admin@example.com'
            },
            {
                title: 'ユーザビリティテスト計画',
                description: 'ユーザビリティテストの計画と準備',
                status: 'todo',
                priority: 'medium',
                assigneeEmail: 'tester@example.com',
                projectName: 'User Testing Project',
                createdByEmail: 'manager@example.com'
            },
            {
                title: 'パフォーマンステスト',
                description: 'システムのパフォーマンステストの実行',
                status: 'todo',
                priority: 'low',
                assigneeEmail: 'tester@example.com',
                projectName: 'データベース最適化',
                createdByEmail: 'admin@example.com'
            }
        ]

        for (const task of tasks) {
            const createdById = userIdMap.get(task.createdByEmail)
            const assigneeId = task.assigneeEmail ? userIdMap.get(task.assigneeEmail) : null
            const projectId = task.projectName ? projectIdMap.get(task.projectName) : null

            if (!createdById) {
                throw new Error(`Creator not found: ${task.createdByEmail}`)
            }

            await this.pool.query(`
        INSERT INTO tasks (title, description, status, priority, due_date, assignee_id, project_id, created_by)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      `, [
                task.title,
                task.description,
                task.status,
                task.priority,
                task.dueDate ? new Date(task.dueDate) : null,
                assigneeId,
                projectId,
                createdById
            ])
        }

        console.log(`✓ Seeded ${tasks.length} tasks`)
    }

    /**
     * Add additional project members
     */
    async seedProjectMembers(userIdMap: Map<string, string>, projectIdMap: Map<string, string>): Promise<void> {
        const memberships = [
            { projectName: 'ウェブサイトリニューアル', memberEmail: 'developer1@example.com' },
            { projectName: 'ウェブサイトリニューアル', memberEmail: 'developer2@example.com' },
            { projectName: 'Mobile App Development', memberEmail: 'developer1@example.com' },
            { projectName: 'Mobile App Development', memberEmail: 'developer2@example.com' },
            { projectName: 'データベース最適化', memberEmail: 'developer2@example.com' },
            { projectName: 'User Testing Project', memberEmail: 'tester@example.com' },
            { projectName: 'User Testing Project', memberEmail: 'developer1@example.com' }
        ]

        for (const membership of memberships) {
            const projectId = projectIdMap.get(membership.projectName)
            const userId = userIdMap.get(membership.memberEmail)

            if (projectId && userId) {
                await this.pool.query(`
          INSERT INTO project_members (project_id, user_id, added_by)
          VALUES ($1, $2, $3)
          ON CONFLICT (project_id, user_id) DO NOTHING
        `, [projectId, userId, userIdMap.get('manager@example.com')])
            }
        }

        console.log(`✓ Seeded project memberships`)
    }

    /**
     * Run all seed operations
     */
    async seedAll(): Promise<void> {
        try {
            console.log('Starting database seeding...')

            const userIdMap = await this.seedUsers()
            const projectIdMap = await this.seedProjects(userIdMap)
            await this.seedTasks(userIdMap, projectIdMap)
            await this.seedProjectMembers(userIdMap, projectIdMap)

            console.log('✓ Database seeding completed successfully!')
        } catch (error) {
            console.error('✗ Database seeding failed:', error)
            throw error
        }
    }

    /**
     * Seed minimal data for testing
     */
    async seedMinimal(): Promise<void> {
        try {
            console.log('Seeding minimal test data...')

            // Create one admin user
            const hashedPassword = await this.hashPassword('test123')
            await this.pool.query(`
        INSERT INTO users (email, name, password_hash, role, preferred_language)
        VALUES ($1, $2, $3, $4, $5)
      `, ['test@example.com', 'Test User', hashedPassword, 'admin', 'ja'])

            console.log('✓ Minimal seeding completed')
        } catch (error) {
            console.error('✗ Minimal seeding failed:', error)
            throw error
        }
    }
}

/**
 * Create and export seeder instance
 */
export const databaseSeeder = new DatabaseSeeder()