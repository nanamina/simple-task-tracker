/**
 * Production Configuration
 * 
 * Optimized settings for production deployment
 */

import { Request, Response, NextFunction } from 'express'

/**
 * Production middleware configuration
 * Note: These middleware require additional packages to be installed
 */
export const productionMiddleware: any[] = [
    // Placeholder for compression middleware
    // Uncomment when compression package is installed:
    // compression({
    //     level: 6,
    //     threshold: 1024,
    //     filter: (req: Request, res: Response) => {
    //         if (req.headers['x-no-compression']) {
    //             return false
    //         }
    //         return compression.filter(req, res)
    //     }
    // }),

    // Placeholder for rate limiting middleware
    // Uncomment when express-rate-limit package is installed:
    // rateLimit({
    //     windowMs: 15 * 60 * 1000, // 15 minutes
    //     max: 100, // Limit each IP to 100 requests per windowMs
    //     message: {
    //         error: {
    //             code: 'RATE_LIMIT_EXCEEDED',
    //             message: 'Too many requests from this IP, please try again later.',
    //             timestamp: new Date().toISOString()
    //         }
    //     },
    //     standardHeaders: true,
    //     legacyHeaders: false,
    // }),
]

/**
 * Production security headers
 */
export const securityHeaders = (_req: Request, res: Response, next: NextFunction) => {
    // Security headers
    res.setHeader('X-Content-Type-Options', 'nosniff')
    res.setHeader('X-Frame-Options', 'DENY')
    res.setHeader('X-XSS-Protection', '1; mode=block')
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin')
    res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()')

    // Content Security Policy
    res.setHeader('Content-Security-Policy', [
        "default-src 'self'",
        "script-src 'self' 'unsafe-inline'",
        "style-src 'self' 'unsafe-inline'",
        "img-src 'self' data: https:",
        "font-src 'self'",
        "connect-src 'self'",
        "frame-ancestors 'none'"
    ].join('; '))

    next()
}

/**
 * Production logging configuration
 */
export const productionLogLevel = 'info'

/**
 * Production database connection pool settings
 */
export const productionPoolConfig = {
    max: 20, // Maximum number of clients in the pool
    idleTimeoutMillis: 30000, // Close idle clients after 30 seconds
    connectionTimeoutMillis: 2000, // Return an error after 2 seconds if connection could not be established
    maxUses: 7500, // Close (and replace) a connection after it has been used 7500 times
}

/**
 * Production cache headers for static assets
 */
export const staticAssetHeaders = (req: Request, res: Response, next: NextFunction) => {
    // Cache static assets for 1 year
    if (req.path.match(/\.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$/)) {
        res.setHeader('Cache-Control', 'public, max-age=31536000, immutable')
    }
    // Cache HTML files for 1 hour
    else if (req.path.match(/\.html$/)) {
        res.setHeader('Cache-Control', 'public, max-age=3600')
    }
    // No cache for API endpoints
    else if (req.path.startsWith('/api/')) {
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate')
        res.setHeader('Pragma', 'no-cache')
        res.setHeader('Expires', '0')
    }

    next()
}

/**
 * Health check configuration for production
 */
export const healthCheckConfig = {
    // Detailed health checks for production monitoring
    checks: {
        database: true,
        memory: true,
        disk: true,
        uptime: true
    },
    // Response format for monitoring systems
    format: 'json'
}