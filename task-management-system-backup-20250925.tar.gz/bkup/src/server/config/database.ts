import { Pool, PoolConfig } from 'pg'
import * as dotenv from 'dotenv'

// Load environment variables
dotenv.config()

/**
 * Database configuration interface
 */
interface DatabaseConfig extends PoolConfig {
    host: string
    port: number
    database: string
    user: string
    password: string
}

/**
 * Get database configuration from environment variables
 * @returns Database configuration object
 */
export const getDatabaseConfig = (): DatabaseConfig => {
    return {
        host: process.env.DB_HOST || 'localhost',
        port: parseInt(process.env.DB_PORT || '5432'),
        database: process.env.DB_NAME || 'task_management',
        user: process.env.DB_USER || 'postgres',
        password: process.env.DB_PASSWORD || 'password',
        max: parseInt(process.env.DB_POOL_MAX || '20'),
        idleTimeoutMillis: parseInt(process.env.DB_IDLE_TIMEOUT || '30000'),
        connectionTimeoutMillis: parseInt(process.env.DB_CONNECTION_TIMEOUT || '2000'),
    }
}

/**
 * Database connection pool instance
 */
let pool: Pool | null = null

/**
 * Get or create database connection pool
 * @returns PostgreSQL connection pool
 */
export const getPool = (): Pool => {
    if (!pool) {
        const config = getDatabaseConfig()
        pool = new Pool(config)

        // Handle pool errors
        pool.on('error', (err) => {
            console.error('Unexpected error on idle client', err)
            process.exit(-1)
        })
    }

    return pool
}

/**
 * Test database connection
 * @returns Promise that resolves if connection is successful
 */
export const testConnection = async (): Promise<void> => {
    const client = getPool()

    try {
        const result = await client.query('SELECT NOW()')
        console.log('Database connection successful:', result.rows[0])
    } catch (error) {
        console.error('Database connection failed:', error)
        throw error
    }
}

/**
 * Close database connection pool
 */
export const closePool = async (): Promise<void> => {
    if (pool) {
        await pool.end()
        pool = null
    }
}