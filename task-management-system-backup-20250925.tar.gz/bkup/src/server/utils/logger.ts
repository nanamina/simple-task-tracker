import { Request } from 'express'

/**
 * Logging levels
 */
export enum LogLevel {
    ERROR = 'error',
    WARN = 'warn',
    INFO = 'info',
    DEBUG = 'debug',
}

/**
 * Log entry structure
 */
export interface LogEntry {
    level: LogLevel
    message: string
    timestamp: string
    requestId?: string
    userId?: string
    context?: string
    metadata?: Record<string, any>
    error?: {
        name: string
        message: string
        stack?: string
        code?: string
        statusCode?: number
    }
}

/**
 * Logger class for structured logging
 */
class Logger {
    private isDevelopment: boolean
    private isProduction: boolean

    constructor() {
        this.isDevelopment = process.env.NODE_ENV === 'development'
        this.isProduction = process.env.NODE_ENV === 'production'
    }

    /**
     * Log an error
     */
    error(message: string, error?: Error, context?: string, metadata?: Record<string, any>): void {
        const logEntry: LogEntry = {
            level: LogLevel.ERROR,
            message,
            timestamp: new Date().toISOString(),
            context,
            metadata,
        }

        if (error) {
            logEntry.error = {
                name: error.name,
                message: error.message,
                stack: this.isDevelopment ? error.stack : undefined,
                ...(error as any).code && { code: (error as any).code },
                ...(error as any).statusCode && { statusCode: (error as any).statusCode },
            }
        }

        this.writeLog(logEntry)
    }

    /**
     * Log a warning
     */
    warn(message: string, context?: string, metadata?: Record<string, any>): void {
        const logEntry: LogEntry = {
            level: LogLevel.WARN,
            message,
            timestamp: new Date().toISOString(),
            context,
            metadata,
        }

        this.writeLog(logEntry)
    }

    /**
     * Log an info message
     */
    info(message: string, context?: string, metadata?: Record<string, any>): void {
        const logEntry: LogEntry = {
            level: LogLevel.INFO,
            message,
            timestamp: new Date().toISOString(),
            context,
            metadata,
        }

        this.writeLog(logEntry)
    }

    /**
     * Log a debug message (only in development)
     */
    debug(message: string, context?: string, metadata?: Record<string, any>): void {
        if (!this.isDevelopment) return

        const logEntry: LogEntry = {
            level: LogLevel.DEBUG,
            message,
            timestamp: new Date().toISOString(),
            context,
            metadata,
        }

        this.writeLog(logEntry)
    }

    /**
     * Log a request
     */
    request(req: Request, responseTime?: number, statusCode?: number): void {
        const logEntry: LogEntry = {
            level: LogLevel.INFO,
            message: `${req.method} ${req.path}`,
            timestamp: new Date().toISOString(),
            context: 'HTTP_REQUEST',
            userId: req.user?.id,
            metadata: {
                method: req.method,
                path: req.path,
                query: req.query,
                userAgent: req.get('User-Agent'),
                ip: req.ip,
                responseTime,
                statusCode,
            },
        }

        this.writeLog(logEntry)
    }

    /**
     * Log database operations
     */
    database(operation: string, table?: string, duration?: number, error?: Error): void {
        const logEntry: LogEntry = {
            level: error ? LogLevel.ERROR : LogLevel.DEBUG,
            message: `Database ${operation}${table ? ` on ${table}` : ''}`,
            timestamp: new Date().toISOString(),
            context: 'DATABASE',
            metadata: {
                operation,
                table,
                duration,
            },
        }

        if (error) {
            logEntry.error = {
                name: error.name,
                message: error.message,
                stack: this.isDevelopment ? error.stack : undefined,
                ...(error as any).code && { code: (error as any).code },
            }
        }

        this.writeLog(logEntry)
    }

    /**
     * Log authentication events
     */
    auth(event: string, userId?: string, email?: string, success: boolean = true, metadata?: Record<string, any>): void {
        const logEntry: LogEntry = {
            level: success ? LogLevel.INFO : LogLevel.WARN,
            message: `Authentication ${event}${success ? ' successful' : ' failed'}`,
            timestamp: new Date().toISOString(),
            context: 'AUTHENTICATION',
            userId,
            metadata: {
                event,
                email,
                success,
                ...metadata,
            },
        }

        this.writeLog(logEntry)
    }

    /**
     * Log security events
     */
    security(event: string, severity: 'low' | 'medium' | 'high' | 'critical', metadata?: Record<string, any>): void {
        const level = severity === 'critical' || severity === 'high' ? LogLevel.ERROR : LogLevel.WARN

        const logEntry: LogEntry = {
            level,
            message: `Security event: ${event}`,
            timestamp: new Date().toISOString(),
            context: 'SECURITY',
            metadata: {
                event,
                severity,
                ...metadata,
            },
        }

        this.writeLog(logEntry)
    }

    /**
     * Write log entry to appropriate output
     */
    private writeLog(logEntry: LogEntry): void {
        if (this.isDevelopment) {
            // Pretty print for development
            this.prettyPrint(logEntry)
        } else {
            // JSON format for production
            console.log(JSON.stringify(logEntry))
        }

        // In production, you might want to send logs to external service
        if (this.isProduction && logEntry.level === LogLevel.ERROR) {
            // Example: sendToLogService(logEntry)
        }
    }

    /**
     * Pretty print log entry for development
     */
    private prettyPrint(logEntry: LogEntry): void {
        const colors = {
            [LogLevel.ERROR]: '\x1b[31m', // Red
            [LogLevel.WARN]: '\x1b[33m',  // Yellow
            [LogLevel.INFO]: '\x1b[36m',  // Cyan
            [LogLevel.DEBUG]: '\x1b[37m', // White
        }

        const reset = '\x1b[0m'
        const color = colors[logEntry.level]

        const timestamp = new Date(logEntry.timestamp).toLocaleTimeString()
        const level = logEntry.level.toUpperCase().padEnd(5)
        const context = logEntry.context ? `[${logEntry.context}]` : ''
        const userId = logEntry.userId ? `(User: ${logEntry.userId})` : ''

        console.log(`${color}${timestamp} ${level}${reset} ${context} ${logEntry.message} ${userId}`)

        if (logEntry.error) {
            console.log(`${color}  Error: ${logEntry.error.message}${reset}`)
            if (logEntry.error.stack) {
                console.log(`${color}  Stack: ${logEntry.error.stack}${reset}`)
            }
        }

        if (logEntry.metadata && Object.keys(logEntry.metadata).length > 0) {
            console.log(`${color}  Metadata:${reset}`, logEntry.metadata)
        }
    }
}

/**
 * Global logger instance
 */
export const logger = new Logger()

/**
 * Request logging middleware
 */
export function requestLogger(req: Request, res: any, next: any): void {
    const startTime = Date.now()

    // Log request
    logger.request(req)

    // Override res.end to log response
    const originalEnd = res.end
    res.end = function (chunk: any, encoding: any) {
        const responseTime = Date.now() - startTime
        logger.request(req, responseTime, res.statusCode)
        originalEnd.call(res, chunk, encoding)
    }

    next()
}

/**
 * Error logging helper
 */
export function logError(error: Error, context?: string, metadata?: Record<string, any>): void {
    logger.error(error.message, error, context, metadata)
}

/**
 * Performance logging helper
 */
export function logPerformance(operation: string, duration: number, context?: string): void {
    const level = duration > 1000 ? LogLevel.WARN : LogLevel.DEBUG

    if (level === LogLevel.WARN) {
        logger.warn(`Slow operation: ${operation} took ${duration}ms`, context, { duration })
    } else {
        logger.debug(`Operation: ${operation} took ${duration}ms`, context, { duration })
    }
}

/**
 * Async operation wrapper with performance logging
 */
export async function withPerformanceLogging<T>(
    operation: () => Promise<T>,
    operationName: string,
    context?: string
): Promise<T> {
    const startTime = Date.now()

    try {
        const result = await operation()
        const duration = Date.now() - startTime
        logPerformance(operationName, duration, context)
        return result
    } catch (error) {
        const duration = Date.now() - startTime
        logger.error(`Failed operation: ${operationName} (${duration}ms)`, error as Error, context)
        throw error
    }
}