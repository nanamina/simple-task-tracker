import { DatabaseError, ConflictError, ValidationAppError, NotFoundError } from '../middleware/errorHandler'

/**
 * Database error handling utilities for PostgreSQL
 */

/**
 * PostgreSQL error codes and their meanings
 */
export const PostgreSQLErrorCodes = {
    // Class 23 - Integrity Constraint Violation
    UNIQUE_VIOLATION: '23505',
    FOREIGN_KEY_VIOLATION: '23503',
    NOT_NULL_VIOLATION: '23502',
    CHECK_VIOLATION: '23514',

    // Class 42 - Syntax Error or Access Rule Violation
    UNDEFINED_TABLE: '42P01',
    UNDEFINED_COLUMN: '42703',
    UNDEFINED_FUNCTION: '42883',

    // Class 08 - Connection Exception
    CONNECTION_EXCEPTION: '08000',
    CONNECTION_FAILURE: '08006',

    // Class 53 - Insufficient Resources
    INSUFFICIENT_RESOURCES: '53000',
    DISK_FULL: '53100',
    OUT_OF_MEMORY: '53200',

    // Class 57 - Operator Intervention
    ADMIN_SHUTDOWN: '57P01',
    CRASH_SHUTDOWN: '57P02',
    CANNOT_CONNECT_NOW: '57P03',
} as const

/**
 * Handle PostgreSQL database errors and convert to appropriate AppError
 */
export function handlePostgreSQLError(error: any): DatabaseError | ConflictError | ValidationAppError | NotFoundError {
    const code = error.code
    const message = error.message || 'Database error occurred'
    const detail = error.detail
    const constraint = error.constraint
    const table = error.table
    const column = error.column

    switch (code) {
        case PostgreSQLErrorCodes.UNIQUE_VIOLATION:
            return new ConflictError(
                getUniqueViolationMessage(constraint, table, detail),
                {
                    constraint,
                    table,
                    detail,
                    type: 'unique_violation'
                }
            )

        case PostgreSQLErrorCodes.FOREIGN_KEY_VIOLATION:
            return new ValidationAppError(
                getForeignKeyViolationMessage(constraint, table, detail),
                {
                    constraint,
                    table,
                    detail,
                    type: 'foreign_key_violation'
                }
            )

        case PostgreSQLErrorCodes.NOT_NULL_VIOLATION:
            return new ValidationAppError(
                getNotNullViolationMessage(column, table),
                {
                    column,
                    table,
                    type: 'not_null_violation'
                }
            )

        case PostgreSQLErrorCodes.CHECK_VIOLATION:
            return new ValidationAppError(
                getCheckViolationMessage(constraint, table),
                {
                    constraint,
                    table,
                    type: 'check_violation'
                }
            )

        case PostgreSQLErrorCodes.UNDEFINED_TABLE:
            return new DatabaseError(
                'Database table does not exist',
                {
                    code,
                    message,
                    type: 'schema_error'
                }
            )

        case PostgreSQLErrorCodes.UNDEFINED_COLUMN:
            return new DatabaseError(
                'Database column does not exist',
                {
                    code,
                    message,
                    type: 'schema_error'
                }
            )

        case PostgreSQLErrorCodes.CONNECTION_EXCEPTION:
        case PostgreSQLErrorCodes.CONNECTION_FAILURE:
            return new DatabaseError(
                'Database connection failed',
                {
                    code,
                    message,
                    type: 'connection_error'
                }
            )

        case PostgreSQLErrorCodes.INSUFFICIENT_RESOURCES:
        case PostgreSQLErrorCodes.DISK_FULL:
        case PostgreSQLErrorCodes.OUT_OF_MEMORY:
            return new DatabaseError(
                'Database server is experiencing resource issues',
                {
                    code,
                    message,
                    type: 'resource_error'
                }
            )

        default:
            return new DatabaseError(
                'Database operation failed',
                {
                    code,
                    message,
                    detail,
                    type: 'unknown_database_error'
                }
            )
    }
}

/**
 * Generate user-friendly message for unique constraint violations
 */
function getUniqueViolationMessage(constraint: string, _table: string, _detail: string): string {
    // Map common constraints to user-friendly messages
    const constraintMessages: Record<string, string> = {
        'users_email_key': 'An account with this email address already exists',
        'projects_name_key': 'A project with this name already exists',
        'tasks_title_project_key': 'A task with this title already exists in this project',
    }

    if (constraint && constraintMessages[constraint]) {
        return constraintMessages[constraint]
    }

    // Extract field name from constraint if possible
    if (constraint && constraint.includes('_')) {
        const parts = constraint.split('_')
        if (parts.length >= 2) {
            const field = parts[1]
            return `This ${field} is already in use`
        }
    }

    // Fallback message
    return 'This resource already exists'
}

/**
 * Generate user-friendly message for foreign key violations
 */
function getForeignKeyViolationMessage(constraint: string, _table: string, detail: string): string {
    const constraintMessages: Record<string, string> = {
        'tasks_assignee_id_fkey': 'The assigned user does not exist',
        'tasks_project_id_fkey': 'The specified project does not exist',
        'tasks_created_by_fkey': 'The user creating this task does not exist',
        'projects_created_by_fkey': 'The user creating this project does not exist',
        'project_members_user_id_fkey': 'The specified user does not exist',
        'project_members_project_id_fkey': 'The specified project does not exist',
    }

    if (constraint && constraintMessages[constraint]) {
        return constraintMessages[constraint]
    }

    // Check if it's a deletion that would violate foreign key
    if (detail && detail.includes('still referenced')) {
        return 'Cannot delete this resource because it is still being used'
    }

    return 'Referenced resource does not exist'
}

/**
 * Generate user-friendly message for not null violations
 */
function getNotNullViolationMessage(column: string, _table: string): string {
    const fieldMessages: Record<string, string> = {
        'email': 'Email address is required',
        'name': 'Name is required',
        'title': 'Title is required',
        'password_hash': 'Password is required',
        'status': 'Status is required',
        'priority': 'Priority is required',
        'created_by': 'Creator information is required',
    }

    if (column && fieldMessages[column]) {
        return fieldMessages[column]
    }

    // Format column name for display
    const displayName = column
        ? column.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
        : 'Required field'

    return `${displayName} is required`
}

/**
 * Generate user-friendly message for check constraint violations
 */
function getCheckViolationMessage(constraint: string, _table: string): string {
    const constraintMessages: Record<string, string> = {
        'tasks_status_check': 'Invalid task status',
        'tasks_priority_check': 'Invalid task priority',
        'users_role_check': 'Invalid user role',
        'users_preferred_language_check': 'Invalid preferred language',
    }

    if (constraint && constraintMessages[constraint]) {
        return constraintMessages[constraint]
    }

    return 'Invalid data format'
}

/**
 * Wrap database operations with error handling
 */
export async function withDatabaseErrorHandling<T>(
    operation: () => Promise<T>,
    context?: string
): Promise<T> {
    try {
        return await operation()
    } catch (error: any) {
        // Log the original error for debugging
        console.error(`Database error in ${context || 'unknown operation'}:`, {
            code: error.code,
            message: error.message,
            detail: error.detail,
            constraint: error.constraint,
            table: error.table,
            column: error.column,
        })

        // Convert and throw appropriate error
        throw handlePostgreSQLError(error)
    }
}

/**
 * Check if error is a database connection error
 */
export function isDatabaseConnectionError(error: any): boolean {
    return error.code === PostgreSQLErrorCodes.CONNECTION_EXCEPTION ||
        error.code === PostgreSQLErrorCodes.CONNECTION_FAILURE ||
        error.code === PostgreSQLErrorCodes.CANNOT_CONNECT_NOW
}

/**
 * Check if error is a resource constraint error
 */
export function isDatabaseResourceError(error: any): boolean {
    return error.code === PostgreSQLErrorCodes.INSUFFICIENT_RESOURCES ||
        error.code === PostgreSQLErrorCodes.DISK_FULL ||
        error.code === PostgreSQLErrorCodes.OUT_OF_MEMORY
}

/**
 * Check if error is a schema-related error
 */
export function isDatabaseSchemaError(error: any): boolean {
    return error.code === PostgreSQLErrorCodes.UNDEFINED_TABLE ||
        error.code === PostgreSQLErrorCodes.UNDEFINED_COLUMN ||
        error.code === PostgreSQLErrorCodes.UNDEFINED_FUNCTION
}