/**
 * Task repository for database operations
 */

import { Pool, PoolClient } from 'pg'
import { Task, TaskStatus, TaskPriority } from '../../shared/types/index'
import { CreateTaskDTO, UpdateTaskDTO, TaskFilterOptions, TaskSortOptions } from '../../shared/types/validation'

export class TaskRepository {
    constructor(private db: Pool) { }

    /**
     * Create a new task in the database
     * @param taskData - Task creation data
     * @param createdBy - ID of user creating the task
     * @returns Promise resolving to created task
     */
    async createTask(taskData: CreateTaskDTO, createdBy: string): Promise<Task> {
        const client: PoolClient = await this.db.connect()

        try {
            const query = `
                INSERT INTO tasks (title, description, priority, due_date, assignee_id, project_id, created_by)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING id, title, description, status, priority, due_date, assignee_id, project_id, created_by, created_at, updated_at, completed_at
            `

            const values = [
                taskData.title,
                taskData.description,
                taskData.priority || 'medium',
                taskData.dueDate || null,
                taskData.assigneeId || null,
                taskData.projectId || null,
                createdBy
            ]

            const result = await client.query(query, values)
            const row = result.rows[0]

            return {
                id: row.id,
                title: row.title,
                description: row.description,
                status: row.status as TaskStatus,
                priority: row.priority as TaskPriority,
                dueDate: row.due_date,
                assigneeId: row.assignee_id,
                projectId: row.project_id,
                createdBy: row.created_by,
                createdAt: row.created_at,
                updatedAt: row.updated_at,
                completedAt: row.completed_at
            }
        } catch (error) {
            throw new Error('Failed to create task')
        } finally {
            client.release()
        }
    }

    /**
     * Find task by ID
     * @param id - Task ID
     * @returns Promise resolving to task or null if not found
     */
    async findById(id: string): Promise<Task | null> {
        const client: PoolClient = await this.db.connect()

        try {
            const query = `
                SELECT id, title, description, status, priority, due_date, assignee_id, project_id, created_by, created_at, updated_at, completed_at
                FROM tasks
                WHERE id = $1
            `

            const result = await client.query(query, [id])

            if (result.rows.length === 0) {
                return null
            }

            const row = result.rows[0]
            return {
                id: row.id,
                title: row.title,
                description: row.description,
                status: row.status as TaskStatus,
                priority: row.priority as TaskPriority,
                dueDate: row.due_date,
                assigneeId: row.assignee_id,
                projectId: row.project_id,
                createdBy: row.created_by,
                createdAt: row.created_at,
                updatedAt: row.updated_at,
                completedAt: row.completed_at
            }
        } catch (error) {
            throw new Error('Failed to find task by ID')
        } finally {
            client.release()
        }
    }

    /**
     * Update task information
     * @param id - Task ID
     * @param updates - Fields to update
     * @returns Promise resolving to updated task or null if not found
     */
    async updateTask(id: string, updates: UpdateTaskDTO): Promise<Task | null> {
        const client: PoolClient = await this.db.connect()

        try {
            const updateFields: string[] = []
            const values: any[] = []
            let paramCount = 1

            if (updates.title !== undefined) {
                updateFields.push(`title = $${paramCount}`)
                values.push(updates.title)
                paramCount++
            }

            if (updates.description !== undefined) {
                updateFields.push(`description = $${paramCount}`)
                values.push(updates.description)
                paramCount++
            }

            if (updates.priority !== undefined) {
                updateFields.push(`priority = $${paramCount}`)
                values.push(updates.priority)
                paramCount++
            }

            if (updates.dueDate !== undefined) {
                updateFields.push(`due_date = $${paramCount}`)
                values.push(updates.dueDate)
                paramCount++
            }

            if (updates.assigneeId !== undefined) {
                updateFields.push(`assignee_id = $${paramCount}`)
                values.push(updates.assigneeId)
                paramCount++
            }

            if (updates.projectId !== undefined) {
                updateFields.push(`project_id = $${paramCount}`)
                values.push(updates.projectId)
                paramCount++
            }

            if (updateFields.length === 0) {
                // No fields to update, return current task
                return this.findById(id)
            }

            updateFields.push(`updated_at = CURRENT_TIMESTAMP`)
            values.push(id) // Add ID as last parameter

            const query = `
                UPDATE tasks
                SET ${updateFields.join(', ')}
                WHERE id = $${paramCount}
                RETURNING id, title, description, status, priority, due_date, assignee_id, project_id, created_by, created_at, updated_at, completed_at
            `

            const result = await client.query(query, values)

            if (result.rows.length === 0) {
                return null
            }

            const row = result.rows[0]
            return {
                id: row.id,
                title: row.title,
                description: row.description,
                status: row.status as TaskStatus,
                priority: row.priority as TaskPriority,
                dueDate: row.due_date,
                assigneeId: row.assignee_id,
                projectId: row.project_id,
                createdBy: row.created_by,
                createdAt: row.created_at,
                updatedAt: row.updated_at,
                completedAt: row.completed_at
            }
        } catch (error) {
            throw new Error('Failed to update task')
        } finally {
            client.release()
        }
    }

    /**
     * Update task status with completion tracking
     * @param id - Task ID
     * @param status - New status
     * @returns Promise resolving to updated task or null if not found
     */
    async updateTaskStatus(id: string, status: TaskStatus): Promise<Task | null> {
        const client: PoolClient = await this.db.connect()

        try {
            const completedAt = status === 'completed' ? 'CURRENT_TIMESTAMP' : 'NULL'

            const query = `
                UPDATE tasks
                SET status = $1, completed_at = ${completedAt}, updated_at = CURRENT_TIMESTAMP
                WHERE id = $2
                RETURNING id, title, description, status, priority, due_date, assignee_id, project_id, created_by, created_at, updated_at, completed_at
            `

            const result = await client.query(query, [status, id])

            if (result.rows.length === 0) {
                return null
            }

            const row = result.rows[0]
            return {
                id: row.id,
                title: row.title,
                description: row.description,
                status: row.status as TaskStatus,
                priority: row.priority as TaskPriority,
                dueDate: row.due_date,
                assigneeId: row.assignee_id,
                projectId: row.project_id,
                createdBy: row.created_by,
                createdAt: row.created_at,
                updatedAt: row.updated_at,
                completedAt: row.completed_at
            }
        } catch (error) {
            throw new Error('Failed to update task status')
        } finally {
            client.release()
        }
    }

    /**
     * Delete task by ID
     * @param id - Task ID
     * @returns Promise resolving to boolean indicating success
     */
    async deleteTask(id: string): Promise<boolean> {
        const client: PoolClient = await this.db.connect()

        try {
            const query = 'DELETE FROM tasks WHERE id = $1'
            const result = await client.query(query, [id])

            return result.rowCount !== null && result.rowCount > 0
        } catch (error) {
            throw new Error('Failed to delete task')
        } finally {
            client.release()
        }
    }

    /**
     * List tasks with filtering and sorting
     * @param filters - Filter options
     * @param sort - Sort options
     * @param limit - Maximum number of tasks to return
     * @param offset - Number of tasks to skip
     * @returns Promise resolving to array of tasks
     */
    async listTasks(
        filters: TaskFilterOptions = {},
        sort: TaskSortOptions = { field: 'createdAt', direction: 'desc' },
        limit: number = 50,
        offset: number = 0
    ): Promise<Task[]> {
        const client: PoolClient = await this.db.connect()

        try {
            const whereConditions: string[] = []
            const values: any[] = []
            let paramCount = 1
            let selectFields = 'id, title, description, status, priority, due_date, assignee_id, project_id, created_by, created_at, updated_at, completed_at'
            let orderByClause = ''

            // Full-text search
            if (filters.search && filters.search.trim()) {
                const searchTerm = filters.search.trim()
                // Use PostgreSQL full-text search with ranking
                selectFields += ', ts_rank(to_tsvector(\'english\', title || \' \' || description), plainto_tsquery(\'english\', $' + paramCount + ')) as search_rank'
                whereConditions.push(`(
                    to_tsvector('english', title || ' ' || description) @@ plainto_tsquery('english', $${paramCount})
                    OR title ILIKE $${paramCount + 1}
                    OR description ILIKE $${paramCount + 1}
                )`)
                values.push(searchTerm, `%${searchTerm}%`)
                paramCount += 2
            }

            // Build WHERE conditions
            if (filters.status) {
                whereConditions.push(`status = $${paramCount}`)
                values.push(filters.status)
                paramCount++
            }

            if (filters.priority) {
                whereConditions.push(`priority = $${paramCount}`)
                values.push(filters.priority)
                paramCount++
            }

            if (filters.assigneeId) {
                whereConditions.push(`assignee_id = $${paramCount}`)
                values.push(filters.assigneeId)
                paramCount++
            }

            if (filters.projectId) {
                whereConditions.push(`project_id = $${paramCount}`)
                values.push(filters.projectId)
                paramCount++
            }

            if (filters.createdBy) {
                whereConditions.push(`created_by = $${paramCount}`)
                values.push(filters.createdBy)
                paramCount++
            }

            if (filters.dueBefore) {
                whereConditions.push(`due_date <= $${paramCount}`)
                values.push(filters.dueBefore)
                paramCount++
            }

            if (filters.dueAfter) {
                whereConditions.push(`due_date >= $${paramCount}`)
                values.push(filters.dueAfter)
                paramCount++
            }

            // Overdue filter
            if (filters.isOverdue) {
                whereConditions.push(`due_date < CURRENT_DATE AND status != 'completed'`)
            }

            // Unassigned filter
            if (filters.isUnassigned) {
                whereConditions.push(`assignee_id IS NULL`)
            }

            // Build ORDER BY clause
            if (filters.search && sort.field === 'relevance') {
                orderByClause = `ORDER BY search_rank DESC, created_at DESC`
            } else {
                const orderByField = this.mapSortField(sort.field)
                const orderDirection = sort.direction.toUpperCase()
                orderByClause = `ORDER BY ${orderByField} ${orderDirection}`
            }

            // Add pagination parameters
            values.push(limit, offset)

            const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : ''

            const query = `
                SELECT ${selectFields}
                FROM tasks
                ${whereClause}
                ${orderByClause}
                LIMIT $${paramCount} OFFSET $${paramCount + 1}
            `

            const result = await client.query(query, values)

            return result.rows.map(row => ({
                id: row.id,
                title: row.title,
                description: row.description,
                status: row.status as TaskStatus,
                priority: row.priority as TaskPriority,
                dueDate: row.due_date,
                assigneeId: row.assignee_id,
                projectId: row.project_id,
                createdBy: row.created_by,
                createdAt: row.created_at,
                updatedAt: row.updated_at,
                completedAt: row.completed_at
            }))
        } catch (error) {
            throw new Error('Failed to list tasks')
        } finally {
            client.release()
        }
    }

    /**
     * Get tasks by project ID
     * @param projectId - Project ID
     * @param sort - Sort options
     * @returns Promise resolving to array of tasks
     */
    async getTasksByProject(projectId: string, sort: TaskSortOptions = { field: 'createdAt', direction: 'desc' }): Promise<Task[]> {
        return this.listTasks({ projectId }, sort)
    }

    /**
     * Get tasks by assignee ID
     * @param assigneeId - Assignee ID
     * @param sort - Sort options
     * @returns Promise resolving to array of tasks
     */
    async getTasksByAssignee(assigneeId: string, sort: TaskSortOptions = { field: 'createdAt', direction: 'desc' }): Promise<Task[]> {
        return this.listTasks({ assigneeId }, sort)
    }

    /**
     * Get overdue tasks
     * @returns Promise resolving to array of overdue tasks
     */
    async getOverdueTasks(): Promise<Task[]> {
        const today = new Date()
        return this.listTasks({
            dueBefore: today,
            status: 'todo' // Only incomplete tasks can be overdue
        })
    }

    /**
     * Get all tasks (for analytics)
     * @returns Promise resolving to array of all tasks
     */
    async getAllTasks(): Promise<Task[]> {
        return this.listTasks({}, { field: 'createdAt', direction: 'desc' }, 10000, 0)
    }

    /**
     * Map sort field to database column
     * @param field - Sort field
     * @returns Database column name
     */
    private mapSortField(field: TaskSortOptions['field']): string {
        const fieldMap: Record<TaskSortOptions['field'], string> = {
            'createdAt': 'created_at',
            'updatedAt': 'updated_at',
            'dueDate': 'due_date',
            'priority': 'priority',
            'title': 'title',
            'relevance': 'search_rank'
        }

        return fieldMap[field]
    }
}