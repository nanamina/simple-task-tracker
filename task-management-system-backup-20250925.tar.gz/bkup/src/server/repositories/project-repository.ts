/**
 * Project repository for database operations
 */

import { Pool, PoolClient } from 'pg'
import { Project } from '../../shared/types/index'
import { CreateProjectDTO, UpdateProjectDTO } from '../../shared/types/validation'

export class ProjectRepository {
    constructor(private db: Pool) { }

    /**
     * Create a new project in the database
     * @param projectData - Project creation data
     * @param createdBy - ID of user creating the project
     * @returns Promise resolving to created project
     */
    async createProject(projectData: CreateProjectDTO, createdBy: string): Promise<Project> {
        const client: PoolClient = await this.db.connect()

        try {
            await client.query('BEGIN')

            // Create the project
            const projectQuery = `
                INSERT INTO projects (name, description, created_by)
                VALUES ($1, $2, $3)
                RETURNING id, name, description, created_by, created_at, updated_at
            `

            const projectValues = [
                projectData.name,
                projectData.description,
                createdBy
            ]

            const projectResult = await client.query(projectQuery, projectValues)
            const projectRow = projectResult.rows[0]

            // Add creator as project member
            const memberQuery = `
                INSERT INTO project_members (project_id, user_id)
                VALUES ($1, $2)
            `

            await client.query(memberQuery, [projectRow.id, createdBy])

            await client.query('COMMIT')

            return {
                id: projectRow.id,
                name: projectRow.name,
                description: projectRow.description,
                createdBy: projectRow.created_by,
                createdAt: projectRow.created_at,
                updatedAt: projectRow.updated_at,
                members: [createdBy] // Creator is automatically a member
            }
        } catch (error) {
            await client.query('ROLLBACK')
            throw new Error('Failed to create project')
        } finally {
            client.release()
        }
    }

    /**
     * Find project by ID with members
     * @param id - Project ID
     * @returns Promise resolving to project or null if not found
     */
    async findById(id: string): Promise<Project | null> {
        const client: PoolClient = await this.db.connect()

        try {
            // Get project details
            const projectQuery = `
                SELECT id, name, description, created_by, created_at, updated_at
                FROM projects
                WHERE id = $1
            `

            const projectResult = await client.query(projectQuery, [id])

            if (projectResult.rows.length === 0) {
                return null
            }

            const projectRow = projectResult.rows[0]

            // Get project members
            const membersQuery = `
                SELECT user_id
                FROM project_members
                WHERE project_id = $1
            `

            const membersResult = await client.query(membersQuery, [id])
            const members = membersResult.rows.map(row => row.user_id)

            return {
                id: projectRow.id,
                name: projectRow.name,
                description: projectRow.description,
                createdBy: projectRow.created_by,
                createdAt: projectRow.created_at,
                updatedAt: projectRow.updated_at,
                members
            }
        } catch (error) {
            throw new Error('Failed to find project by ID')
        } finally {
            client.release()
        }
    }

    /**
     * Update project information
     * @param id - Project ID
     * @param updates - Fields to update
     * @returns Promise resolving to updated project or null if not found
     */
    async updateProject(id: string, updates: UpdateProjectDTO): Promise<Project | null> {
        const client: PoolClient = await this.db.connect()

        try {
            const updateFields: string[] = []
            const values: any[] = []
            let paramCount = 1

            if (updates.name !== undefined) {
                updateFields.push(`name = $${paramCount}`)
                values.push(updates.name)
                paramCount++
            }

            if (updates.description !== undefined) {
                updateFields.push(`description = $${paramCount}`)
                values.push(updates.description)
                paramCount++
            }

            if (updateFields.length === 0) {
                // No fields to update, return current project
                return this.findById(id)
            }

            updateFields.push(`updated_at = CURRENT_TIMESTAMP`)
            values.push(id) // Add ID as last parameter

            const query = `
                UPDATE projects
                SET ${updateFields.join(', ')}
                WHERE id = $${paramCount}
                RETURNING id, name, description, created_by, created_at, updated_at
            `

            const result = await client.query(query, values)

            if (result.rows.length === 0) {
                return null
            }

            // Get updated project with members
            return this.findById(id)
        } catch (error) {
            throw new Error('Failed to update project')
        } finally {
            client.release()
        }
    }

    /**
     * Delete project by ID
     * @param id - Project ID
     * @returns Promise resolving to boolean indicating success
     */
    async deleteProject(id: string): Promise<boolean> {
        const client: PoolClient = await this.db.connect()

        try {
            await client.query('BEGIN')

            // Delete project members first (due to foreign key constraint)
            await client.query('DELETE FROM project_members WHERE project_id = $1', [id])

            // Delete the project
            const result = await client.query('DELETE FROM projects WHERE id = $1', [id])

            await client.query('COMMIT')

            return result.rowCount !== null && result.rowCount > 0
        } catch (error) {
            await client.query('ROLLBACK')
            throw new Error('Failed to delete project')
        } finally {
            client.release()
        }
    }

    /**
     * List all projects with members and filtering
     * @param filters - Filter options
     * @param sort - Sort options
     * @param limit - Maximum number of projects to return
     * @param offset - Number of projects to skip
     * @returns Promise resolving to array of projects
     */
    async listProjects(
        filters: import('../../shared/types/validation').ProjectFilterOptions = {},
        sort: import('../../shared/types/validation').ProjectSortOptions = { field: 'createdAt', direction: 'desc' },
        limit: number = 50,
        offset: number = 0
    ): Promise<Project[]> {
        const client: PoolClient = await this.db.connect()

        try {
            const whereConditions: string[] = []
            const values: any[] = []
            let paramCount = 1
            let selectFields = `p.id, p.name, p.description, p.created_by, p.created_at, p.updated_at,
                       COALESCE(
                           ARRAY_AGG(pm.user_id) FILTER (WHERE pm.user_id IS NOT NULL),
                           ARRAY[]::uuid[]
                       ) as members`
            let orderByClause = ''

            // Full-text search
            if (filters.search && filters.search.trim()) {
                const searchTerm = filters.search.trim()
                selectFields += ', ts_rank(to_tsvector(\'english\', p.name || \' \' || p.description), plainto_tsquery(\'english\', $' + paramCount + ')) as search_rank'
                whereConditions.push(`(
                    to_tsvector('english', p.name || ' ' || p.description) @@ plainto_tsquery('english', $${paramCount})
                    OR p.name ILIKE $${paramCount + 1}
                    OR p.description ILIKE $${paramCount + 1}
                )`)
                values.push(searchTerm, `%${searchTerm}%`)
                paramCount += 2
            }

            // Filter by creator
            if (filters.createdBy) {
                whereConditions.push(`p.created_by = $${paramCount}`)
                values.push(filters.createdBy)
                paramCount++
            }

            // Build ORDER BY clause
            if (filters.search && sort.field === 'relevance') {
                orderByClause = `ORDER BY search_rank DESC, p.created_at DESC`
            } else {
                const orderByField = this.mapProjectSortField(sort.field)
                const orderDirection = sort.direction.toUpperCase()
                orderByClause = `ORDER BY ${orderByField} ${orderDirection}`
            }

            // Add pagination parameters
            values.push(limit, offset)

            const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : ''

            const query = `
                SELECT ${selectFields}
                FROM projects p
                LEFT JOIN project_members pm ON p.id = pm.project_id
                ${whereClause}
                GROUP BY p.id, p.name, p.description, p.created_by, p.created_at, p.updated_at
                ${orderByClause}
                LIMIT $${paramCount} OFFSET $${paramCount + 1}
            `

            const result = await client.query(query, values)

            return result.rows.map(row => ({
                id: row.id,
                name: row.name,
                description: row.description,
                createdBy: row.created_by,
                createdAt: row.created_at,
                updatedAt: row.updated_at,
                members: row.members || []
            }))
        } catch (error) {
            throw new Error('Failed to list projects')
        } finally {
            client.release()
        }
    }

    /**
     * Get projects where user is a member
     * @param userId - User ID
     * @returns Promise resolving to array of projects
     */
    async getProjectsByMember(userId: string): Promise<Project[]> {
        const client: PoolClient = await this.db.connect()

        try {
            const query = `
                SELECT p.id, p.name, p.description, p.created_by, p.created_at, p.updated_at,
                       COALESCE(
                           ARRAY_AGG(pm2.user_id) FILTER (WHERE pm2.user_id IS NOT NULL),
                           ARRAY[]::uuid[]
                       ) as members
                FROM projects p
                INNER JOIN project_members pm ON p.id = pm.project_id
                LEFT JOIN project_members pm2 ON p.id = pm2.project_id
                WHERE pm.user_id = $1
                GROUP BY p.id, p.name, p.description, p.created_by, p.created_at, p.updated_at
                ORDER BY p.created_at DESC
            `

            const result = await client.query(query, [userId])

            return result.rows.map(row => ({
                id: row.id,
                name: row.name,
                description: row.description,
                createdBy: row.created_by,
                createdAt: row.created_at,
                updatedAt: row.updated_at,
                members: row.members || []
            }))
        } catch (error) {
            throw new Error('Failed to get projects by member')
        } finally {
            client.release()
        }
    }

    /**
     * Add user to project
     * @param projectId - Project ID
     * @param userId - User ID to add
     * @returns Promise resolving to boolean indicating success
     */
    async addMember(projectId: string, userId: string): Promise<boolean> {
        const client: PoolClient = await this.db.connect()

        try {
            const query = `
                INSERT INTO project_members (project_id, user_id)
                VALUES ($1, $2)
                ON CONFLICT (project_id, user_id) DO NOTHING
            `

            await client.query(query, [projectId, userId])

            // Returns true if a new row was inserted or if the member already existed
            return true
        } catch (error) {
            throw new Error('Failed to add member to project')
        } finally {
            client.release()
        }
    }

    /**
     * Remove user from project
     * @param projectId - Project ID
     * @param userId - User ID to remove
     * @returns Promise resolving to boolean indicating success
     */
    async removeMember(projectId: string, userId: string): Promise<boolean> {
        const client: PoolClient = await this.db.connect()

        try {
            const query = `
                DELETE FROM project_members
                WHERE project_id = $1 AND user_id = $2
            `

            const result = await client.query(query, [projectId, userId])

            return result.rowCount !== null && result.rowCount > 0
        } catch (error) {
            throw new Error('Failed to remove member from project')
        } finally {
            client.release()
        }
    }

    /**
     * Check if user is a member of project
     * @param projectId - Project ID
     * @param userId - User ID
     * @returns Promise resolving to boolean
     */
    async isMember(projectId: string, userId: string): Promise<boolean> {
        const client: PoolClient = await this.db.connect()

        try {
            const query = `
                SELECT 1 FROM project_members
                WHERE project_id = $1 AND user_id = $2
            `

            const result = await client.query(query, [projectId, userId])

            return result.rows.length > 0
        } catch (error) {
            throw new Error('Failed to check project membership')
        } finally {
            client.release()
        }
    }

    /**
     * Get project members with user details
     * @param projectId - Project ID
     * @returns Promise resolving to array of user objects
     */
    async getProjectMembers(projectId: string): Promise<Array<{ id: string; name: string; email: string; role: string }>> {
        const client: PoolClient = await this.db.connect()

        try {
            const query = `
                SELECT u.id, u.name, u.email, u.role
                FROM users u
                INNER JOIN project_members pm ON u.id = pm.user_id
                WHERE pm.project_id = $1
                ORDER BY u.name
            `

            const result = await client.query(query, [projectId])

            return result.rows.map(row => ({
                id: row.id,
                name: row.name,
                email: row.email,
                role: row.role
            }))
        } catch (error) {
            throw new Error('Failed to get project members')
        } finally {
            client.release()
        }
    }

    /**
     * Get project task count and completion statistics
     * @param projectId - Project ID
     * @returns Promise resolving to project statistics
     */
    async getProjectStats(projectId: string): Promise<{
        totalTasks: number
        completedTasks: number
        inProgressTasks: number
        todoTasks: number
        completionRate: number
    }> {
        const client: PoolClient = await this.db.connect()

        try {
            const query = `
                SELECT 
                    COUNT(*) as total_tasks,
                    COUNT(*) FILTER (WHERE status = 'completed') as completed_tasks,
                    COUNT(*) FILTER (WHERE status = 'in-progress') as in_progress_tasks,
                    COUNT(*) FILTER (WHERE status = 'todo') as todo_tasks
                FROM tasks
                WHERE project_id = $1
            `

            const result = await client.query(query, [projectId])
            const row = result.rows[0]

            const totalTasks = parseInt(row.total_tasks) || 0
            const completedTasks = parseInt(row.completed_tasks) || 0
            const inProgressTasks = parseInt(row.in_progress_tasks) || 0
            const todoTasks = parseInt(row.todo_tasks) || 0

            const completionRate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0

            return {
                totalTasks,
                completedTasks,
                inProgressTasks,
                todoTasks,
                completionRate: Math.round(completionRate * 100) / 100 // Round to 2 decimal places
            }
        } catch (error) {
            throw new Error('Failed to get project statistics')
        } finally {
            client.release()
        }
    }

    /**
     * Map sort field to database column for projects
     * @param field - Sort field
     * @returns Database column name
     */
    private mapProjectSortField(field: import('../../shared/types/validation').ProjectSortOptions['field']): string {
        const fieldMap: Record<import('../../shared/types/validation').ProjectSortOptions['field'], string> = {
            'name': 'p.name',
            'createdAt': 'p.created_at',
            'updatedAt': 'p.updated_at',
            'relevance': 'search_rank'
        }

        return fieldMap[field]
    }
}