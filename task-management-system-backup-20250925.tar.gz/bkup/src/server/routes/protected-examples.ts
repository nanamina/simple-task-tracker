/**
 * Example routes demonstrating role-based access control
 * These routes show how to use the authorization middleware
 */

import { Router, Request, Response } from 'express'
import { authenticateToken } from '../middleware/auth'
import {
    requirePermission,
    requireOwnershipOrPermission,
    requireRoleLevel
} from '../middleware/authorization'
import { PermissionService } from '../services/permissions'

const router = Router()

// Apply authentication to all routes in this router
router.use(authenticateToken)

/**
 * GET /api/protected/admin-only
 * Example of admin-only route using permission-based access
 */
router.get('/admin-only',
    requirePermission('users:create'),
    (req: Request, res: Response) => {
        res.json({
            message: 'This is an admin-only endpoint',
            user: req.user,
            timestamp: new Date().toISOString()
        })
    }
)

/**
 * GET /api/protected/manager-or-admin
 * Example of manager+ route using role level
 */
router.get('/manager-or-admin',
    requireRoleLevel('manager'),
    (req: Request, res: Response) => {
        res.json({
            message: 'This endpoint requires manager or admin role',
            user: req.user,
            permissions: PermissionService.getUserPermissions(req.user!.role),
            timestamp: new Date().toISOString()
        })
    }
)

/**
 * GET /api/protected/projects/create
 * Example of project creation permission
 */
router.get('/projects/create',
    requirePermission('projects:create'),
    (req: Request, res: Response) => {
        res.json({
            message: 'User can create projects',
            user: req.user,
            timestamp: new Date().toISOString()
        })
    }
)

/**
 * GET /api/protected/tasks/manage
 * Example of task management permission
 */
router.get('/tasks/manage',
    requirePermission('tasks:assign'),
    (req: Request, res: Response) => {
        res.json({
            message: 'User can assign tasks',
            user: req.user,
            timestamp: new Date().toISOString()
        })
    }
)

/**
 * GET /api/protected/profile/:userId
 * Example of ownership-based access (users can access their own profile or admins can access any)
 */
router.get('/profile/:userId',
    requireOwnershipOrPermission(
        (req: Request) => req.params.userId,
        'users:read'
    ),
    (req: Request, res: Response) => {
        const { userId } = req.params
        const isOwnProfile = req.user!.id === userId

        res.json({
            message: isOwnProfile ? 'Accessing own profile' : 'Admin accessing user profile',
            userId,
            user: req.user,
            timestamp: new Date().toISOString()
        })
    }
)

/**
 * GET /api/protected/reports
 * Example of reporting access
 */
router.get('/reports',
    requirePermission('reports:view'),
    (req: Request, res: Response) => {
        res.json({
            message: 'User can view reports',
            user: req.user,
            availableReports: ['task-completion', 'project-progress', 'team-performance'],
            timestamp: new Date().toISOString()
        })
    }
)

/**
 * GET /api/protected/permissions
 * Get current user's permissions
 */
router.get('/permissions',
    (req: Request, res: Response) => {
        const userRole = req.user!.role
        const permissionContext = PermissionService.getUserPermissionContext(userRole)

        res.json({
            message: 'User permissions retrieved',
            ...permissionContext,
            timestamp: new Date().toISOString()
        })
    }
)

/**
 * POST /api/protected/validate-permissions
 * Validate multiple permissions at once
 */
router.post('/validate-permissions',
    (req: Request, res: Response) => {
        const { permissions } = req.body

        if (!Array.isArray(permissions)) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Permissions must be an array',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        const userRole = req.user!.role
        const validation = PermissionService.validatePermissions(userRole, permissions)

        res.json({
            message: 'Permission validation completed',
            user: req.user,
            validation,
            timestamp: new Date().toISOString()
        })
    }
)

/**
 * GET /api/protected/bulk-operations
 * Example of bulk operation validation
 */
router.post('/bulk-operations',
    (req: Request, res: Response) => {
        const { operations } = req.body

        if (!Array.isArray(operations)) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Operations must be an array of {resource, action} objects',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        const userRole = req.user!.role
        const validation = PermissionService.validateBulkOperations(userRole, operations)

        res.json({
            message: 'Bulk operation validation completed',
            user: req.user,
            validation,
            timestamp: new Date().toISOString()
        })
    }
)

export default router