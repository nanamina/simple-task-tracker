/**
 * Task management routes
 */

import { Router } from 'express'
import {
    listTasks,
    createTask,
    getTask,
    updateTask,
    deleteTask,
    updateTaskStatus,
    createTaskValidation,
    updateTaskValidation,
    updateTaskStatusValidation,
    taskQueryValidation
} from '../controllers/task'
import { authenticateToken } from '../middleware/auth'

const router = Router()

/**
 * GET /api/tasks
 * List tasks with filtering and sorting
 * Query parameters:
 * - status: Filter by task status (todo, in-progress, completed)
 * - priority: Filter by priority (low, medium, high, critical)
 * - assigneeId: Filter by assignee UUID
 * - projectId: Filter by project UUID
 * - sortBy: Sort field (createdAt, updatedAt, dueDate, priority, title)
 * - sortOrder: Sort direction (asc, desc)
 * - limit: Maximum number of results (1-100, default 50)
 * - offset: Number of results to skip (default 0)
 */
router.get('/', authenticateToken, taskQueryValidation, listTasks)

/**
 * POST /api/tasks
 * Create a new task
 * Body:
 * - title: Task title (required, 1-255 characters)
 * - description: Task description (required, max 2000 characters)
 * - priority: Task priority (optional, low/medium/high/critical)
 * - dueDate: Due date (optional, ISO 8601 format)
 * - assigneeId: Assignee UUID (optional)
 * - projectId: Project UUID (optional)
 */
router.post('/', authenticateToken, createTaskValidation, createTask)

/**
 * GET /api/tasks/:id
 * Get a specific task by ID
 */
router.get('/:id', authenticateToken, getTask)

/**
 * PUT /api/tasks/:id
 * Update a task
 * Body: Same as POST but all fields are optional
 */
router.put('/:id', authenticateToken, updateTaskValidation, updateTask)

/**
 * DELETE /api/tasks/:id
 * Delete a task
 */
router.delete('/:id', authenticateToken, deleteTask)

/**
 * PATCH /api/tasks/:id/status
 * Update task status
 * Body:
 * - status: New status (todo, in-progress, completed)
 */
router.patch('/:id/status', authenticateToken, updateTaskStatusValidation, updateTaskStatus)

export default router