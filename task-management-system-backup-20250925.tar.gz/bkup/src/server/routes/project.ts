/**
 * Project management routes
 */

import { Router } from 'express'
import {
    listProjects,
    createProject,
    getProject,
    updateProject,
    deleteProject,
    getProjectTasks,
    getProjectMembers,
    addProjectMember,
    removeProjectMember,
    getProjectMetrics,
    projectQueryValidation,
    createProjectValidation,
    updateProjectValidation,
    projectIdValidation,
    userIdValidation,
    addMemberValidation
} from '../controllers/project'
import { authenticateToken } from '../middleware/auth'

const router = Router()

/**
 * GET /api/projects
 * List projects with optional filtering
 * Query parameters:
 * - limit: Maximum number of results (1-100, default 50)
 * - offset: Number of results to skip (default 0)
 * - memberOnly: Only return projects where user is a member (boolean)
 */
router.get('/', authenticateToken, projectQueryValidation, listProjects)

/**
 * POST /api/projects
 * Create a new project
 * Body:
 * - name: Project name (required, 1-255 characters)
 * - description: Project description (required, max 2000 characters)
 */
router.post('/', authenticateToken, createProjectValidation, createProject)

/**
 * GET /api/projects/:id
 * Get a specific project by ID
 */
router.get('/:id', authenticateToken, projectIdValidation, getProject)

/**
 * PUT /api/projects/:id
 * Update a project
 * Body: Same as POST but all fields are optional
 */
router.put('/:id', authenticateToken, projectIdValidation, updateProjectValidation, updateProject)

/**
 * DELETE /api/projects/:id
 * Delete a project
 */
router.delete('/:id', authenticateToken, projectIdValidation, deleteProject)

/**
 * GET /api/projects/:id/tasks
 * Get all tasks for a specific project
 */
router.get('/:id/tasks', authenticateToken, projectIdValidation, getProjectTasks)

/**
 * GET /api/projects/:id/members
 * Get all members of a specific project
 */
router.get('/:id/members', authenticateToken, projectIdValidation, getProjectMembers)

/**
 * POST /api/projects/:id/members
 * Add a member to a project
 * Body:
 * - userId: UUID of user to add to project
 */
router.post('/:id/members', authenticateToken, projectIdValidation, addMemberValidation, addProjectMember)

/**
 * DELETE /api/projects/:id/members/:userId
 * Remove a member from a project
 */
router.delete('/:id/members/:userId', authenticateToken, projectIdValidation, userIdValidation, removeProjectMember)

/**
 * GET /api/projects/:id/metrics
 * Get project metrics and dashboard data
 */
router.get('/:id/metrics', authenticateToken, projectIdValidation, getProjectMetrics)

export default router