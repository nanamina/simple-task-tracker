/**
 * User management routes
 */

import { Router } from 'express'
import {
    getUserProfile,
    updateUserProfile,
    getTeamMembers,
    updateLanguagePreference,
    getUserById,
    updateProfileValidation
} from '../controllers/user'
import { authenticateToken } from '../middleware/auth'
import { requirePermission, requireOwnershipOrPermission } from '../middleware/authorization'

const router = Router()

/**
 * GET /api/users/profile
 * Get current user profile (requires authentication)
 */
router.get('/profile', authenticateToken, getUserProfile)

/**
 * PUT /api/users/profile
 * Update current user profile (requires authentication)
 */
router.put('/profile', authenticateToken, updateProfileValidation, updateUserProfile)

/**
 * PATCH /api/users/profile/language
 * Update user language preference (requires authentication)
 */
router.patch('/profile/language', authenticateToken, updateLanguagePreference)

/**
 * GET /api/users/team
 * Get list of team members (admin/manager only)
 */
router.get('/team', authenticateToken, requirePermission('users:list'), getTeamMembers)

/**
 * GET /api/users/:id
 * Get user by ID (admin/manager only, or own profile)
 */
router.get('/:id',
    authenticateToken,
    requireOwnershipOrPermission(
        (req) => req.params.id, // User can access their own profile
        'users:read' // Or need admin/manager permission
    ),
    getUserById
)

export default router