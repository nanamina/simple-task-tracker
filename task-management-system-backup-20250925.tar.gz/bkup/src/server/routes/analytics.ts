import { Router } from 'express';
import { Pool } from 'pg';
import { AnalyticsController } from '../controllers/analytics';
import { authenticateToken } from '../middleware/auth';
import { requirePermission } from '../middleware/authorization';

/**
 * Analytics routes for reporting and metrics endpoints
 */
export function createAnalyticsRoutes(db: Pool): Router {
    const router = Router();
    const analyticsController = new AnalyticsController(db);

    // All analytics routes require authentication
    router.use(authenticateToken);

    /**
     * GET /api/analytics/projects/:projectId/metrics
     * Get project metrics and analytics
     * Requires: manager or admin role
     */
    router.get('/projects/:projectId/metrics',
        requirePermission('reports:view'),
        (req, res) => analyticsController.getProjectMetrics(req, res)
    );

    /**
     * GET /api/analytics/workload
     * Get team workload distribution
     * Query params: projectId (optional)
     * Requires: manager or admin role
     */
    router.get('/workload',
        requirePermission('reports:view'),
        (req, res) => analyticsController.getTeamWorkload(req, res)
    );

    /**
     * GET /api/analytics/trends
     * Get task completion trends over time
     * Query params: projectId (optional), days (default: 30)
     * Requires: manager or admin role
     */
    router.get('/trends',
        requirePermission('reports:view'),
        (req, res) => analyticsController.getCompletionTrends(req, res)
    );

    /**
     * GET /api/analytics/projects/:projectId/report
     * Generate comprehensive project report
     * Requires: manager or admin role
     */
    router.get('/projects/:projectId/report',
        requirePermission('reports:view'),
        (req, res) => analyticsController.generateProjectReport(req, res)
    );

    /**
     * GET /api/analytics/projects/:projectId/export
     * Export project report as CSV or JSON
     * Query params: format (csv|json, default: csv)
     * Requires: manager or admin role
     */
    router.get('/projects/:projectId/export',
        requirePermission('reports:export'),
        (req, res) => analyticsController.exportProjectReport(req, res)
    );

    return router;
}