/**
 * Authentication routes
 */

import { Router } from 'express'
import {
    register,
    login,
    getProfile,
    refreshToken,
    registerValidation,
    loginValidation
} from '../controllers/auth'
import { authenticateToken } from '../middleware/auth'

const router = Router()

/**
 * POST /api/auth/register
 * Register a new user account
 */
router.post('/register', registerValidation, register)

/**
 * POST /api/auth/login
 * Login with email and password
 */
router.post('/login', loginValidation, login)

/**
 * GET /api/auth/profile
 * Get current user profile (requires authentication)
 */
router.get('/profile', authenticateToken, getProfile)

/**
 * POST /api/auth/refresh
 * Refresh JWT token (requires valid token)
 */
router.post('/refresh', authenticateToken, refreshToken)

export default router