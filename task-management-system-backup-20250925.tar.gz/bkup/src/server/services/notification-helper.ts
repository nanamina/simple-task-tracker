/**
 * Notification helper service for integrating notifications with controllers
 * Handles the logic of determining who to notify and when
 */

import { Task, User } from '../../shared/types/index'
import { UserRepository } from '../repositories/user-repository'
import { TaskRepository } from '../repositories/task-repository'
import { sendTaskAssignment, sendStatusUpdate, sendOverdueReminder } from './notification'
import { getPool } from '../config/database'

// Initialize repositories
const userRepository = new UserRepository(getPool())
const taskRepository = new TaskRepository(getPool())

/**
 * Handle task assignment notification
 * Sends notification when a task is assigned to a user
 * @param task - The task that was assigned
 * @param creatorId - ID of the user who created/assigned the task
 */
export async function handleTaskAssignmentNotification(task: Task, creatorId: string): Promise<void> {
    try {
        // Only send notification if task has an assignee
        if (!task.assigneeId) {
            return
        }

        // Get assignee and creator information
        const [assignee, creator] = await Promise.all([
            userRepository.findById(task.assigneeId),
            userRepository.findById(creatorId)
        ])

        if (!assignee || !creator) {
            console.warn('Could not find assignee or creator for task assignment notification')
            return
        }

        // Don't send notification if user assigned task to themselves
        if (assignee.id === creator.id) {
            return
        }

        await sendTaskAssignment(task, assignee, creator)
    } catch (error) {
        console.error('Failed to handle task assignment notification:', error)
        // Don't throw error to avoid breaking the main task creation flow
    }
}

/**
 * Handle task status update notification
 * Sends notification when a task status changes
 * @param task - The task that was updated
 * @param updaterId - ID of the user who updated the task
 */
export async function handleTaskStatusUpdateNotification(task: Task, updaterId: string): Promise<void> {
    try {
        // Get updater information
        const updater = await userRepository.findById(updaterId)
        if (!updater) {
            console.warn('Could not find updater for task status notification')
            return
        }

        // Determine stakeholders to notify
        const stakeholderIds = new Set<string>()

        // Add task creator
        if (task.createdBy) {
            stakeholderIds.add(task.createdBy)
        }

        // Add current assignee
        if (task.assigneeId) {
            stakeholderIds.add(task.assigneeId)
        }

        // Remove the updater from stakeholders (don't notify the person who made the change)
        stakeholderIds.delete(updaterId)

        if (stakeholderIds.size === 0) {
            return
        }

        // Get stakeholder information
        const stakeholders = await Promise.all(
            Array.from(stakeholderIds).map(id => userRepository.findById(id))
        )

        // Filter out null results
        const validStakeholders = stakeholders.filter((user): user is User => user !== null)

        if (validStakeholders.length > 0) {
            await sendStatusUpdate(task, validStakeholders, updater)
        }
    } catch (error) {
        console.error('Failed to handle task status update notification:', error)
        // Don't throw error to avoid breaking the main task update flow
    }
}

/**
 * Handle task reassignment notification
 * Sends notification when a task is reassigned to a different user
 * @param task - The updated task
 * @param previousAssigneeId - ID of the previous assignee (if any)
 * @param updaterId - ID of the user who made the reassignment
 */
export async function handleTaskReassignmentNotification(
    task: Task,
    previousAssigneeId: string | undefined,
    updaterId: string
): Promise<void> {
    try {
        // If task now has an assignee and it's different from before
        if (task.assigneeId && task.assigneeId !== previousAssigneeId) {
            // Send assignment notification to new assignee
            await handleTaskAssignmentNotification(task, updaterId)
        }

        // If there was a previous assignee and they're different from the new one
        if (previousAssigneeId && previousAssigneeId !== task.assigneeId) {
            // Send status update notification to previous assignee about reassignment
            const [previousAssignee, updater] = await Promise.all([
                userRepository.findById(previousAssigneeId),
                userRepository.findById(updaterId)
            ])

            if (previousAssignee && updater && previousAssignee.id !== updater.id) {
                await sendStatusUpdate(task, [previousAssignee], updater)
            }
        }
    } catch (error) {
        console.error('Failed to handle task reassignment notification:', error)
        // Don't throw error to avoid breaking the main task update flow
    }
}

/**
 * Send overdue task reminders
 * This function should be called periodically (e.g., daily) to send reminders
 * @param daysOverdue - Number of days overdue to consider (default: 0 for any overdue)
 */
export async function sendOverdueTaskReminders(daysOverdue: number = 0): Promise<void> {
    try {
        // Get all overdue tasks
        const now = new Date()
        const cutoffDate = new Date(now.getTime() - (daysOverdue * 24 * 60 * 60 * 1000))

        // Get overdue tasks from repository
        const overdueTasks = await taskRepository.listTasks(
            {
                status: 'todo' // Only notify about tasks that are still pending
            },
            { field: 'dueDate', direction: 'asc' },
            1000, // Large limit to get all overdue tasks
            0
        )

        // Filter tasks that are actually overdue
        const actuallyOverdueTasks = overdueTasks.filter(task =>
            task.dueDate && task.dueDate < cutoffDate
        )

        if (actuallyOverdueTasks.length === 0) {
            console.log('No overdue tasks found')
            return
        }

        // Get unique assignee IDs
        const assigneeIds = new Set<string>()
        actuallyOverdueTasks.forEach(task => {
            if (task.assigneeId) {
                assigneeIds.add(task.assigneeId)
            }
        })

        if (assigneeIds.size === 0) {
            console.log('No assigned overdue tasks found')
            return
        }

        // Get assignee information
        const assignees = await Promise.all(
            Array.from(assigneeIds).map(id => userRepository.findById(id))
        )

        // Filter out null results
        const validAssignees = assignees.filter((user): user is User => user !== null)

        if (validAssignees.length > 0) {
            await sendOverdueReminder(actuallyOverdueTasks, validAssignees)
            console.log(`Sent overdue reminders for ${actuallyOverdueTasks.length} tasks to ${validAssignees.length} users`)
        }
    } catch (error) {
        console.error('Failed to send overdue task reminders:', error)
        throw error // This is a standalone operation, so we can throw the error
    }
}

/**
 * Get project stakeholders for notifications
 * Returns users who should be notified about project-related changes
 * @param projectId - ID of the project
 * @returns Promise resolving to array of users
 */
export async function getProjectStakeholders(_projectId: string): Promise<User[]> {
    try {
        // This would require a project repository method to get project members
        // For now, we'll return an empty array since project member management
        // is not fully implemented in the current codebase

        // TODO: Implement project member retrieval when project repository is enhanced
        console.warn('Project stakeholder notification not yet implemented')
        return []
    } catch (error) {
        console.error('Failed to get project stakeholders:', error)
        return []
    }
}

/**
 * Utility function to check if notifications are enabled
 * @returns boolean indicating if email notifications are configured
 */
export function areNotificationsEnabled(): boolean {
    return !!(
        process.env.SMTP_HOST &&
        process.env.SMTP_USER &&
        process.env.SMTP_PASSWORD
    )
}

/**
 * Utility function to log notification attempts for debugging
 * @param type - Type of notification
 * @param taskId - ID of the task
 * @param recipients - Array of recipient emails
 */
export function logNotificationAttempt(
    type: 'assignment' | 'status_update' | 'overdue_reminder',
    taskId: string,
    recipients: string[]
): void {
    console.log(`Notification attempt: ${type} for task ${taskId} to recipients: ${recipients.join(', ')}`)
}