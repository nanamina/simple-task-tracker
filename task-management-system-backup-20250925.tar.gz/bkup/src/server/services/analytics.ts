import { TaskRepository } from '../repositories/task-repository';
import { ProjectRepository } from '../repositories/project-repository';
import { UserRepository } from '../repositories/user-repository';

/**
 * Analytics service for generating project metrics and reports
 */
export class AnalyticsService {
    constructor(
        private taskRepository: TaskRepository,
        private projectRepository: ProjectRepository,
        private userRepository: UserRepository
    ) { }

    /**
     * Get project progress metrics including task distribution by status
     * @param projectId - Project ID to analyze
     * @returns Project metrics with task distribution
     */
    async getProjectMetrics(projectId: string) {
        try {
            const tasks = await this.taskRepository.getTasksByProject(projectId);
            const project = await this.projectRepository.findById(projectId);

            if (!project) {
                throw new Error('Project not found');
            }

            // Calculate task distribution by status
            const statusDistribution = {
                todo: tasks.filter(task => task.status === 'todo').length,
                'in-progress': tasks.filter(task => task.status === 'in-progress').length,
                completed: tasks.filter(task => task.status === 'completed').length
            };

            // Calculate completion rate
            const totalTasks = tasks.length;
            const completedTasks = statusDistribution.completed;
            const completionRate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

            // Calculate average task duration for completed tasks
            const completedTasksWithDuration = tasks.filter(task =>
                task.status === 'completed' && task.completedAt && task.createdAt
            );

            const averageTaskDuration = completedTasksWithDuration.length > 0
                ? completedTasksWithDuration.reduce((sum, task) => {
                    const duration = new Date(task.completedAt!).getTime() - new Date(task.createdAt).getTime();
                    return sum + duration;
                }, 0) / completedTasksWithDuration.length / (1000 * 60 * 60 * 24) // Convert to days
                : 0;

            // Identify overdue tasks
            const now = new Date();
            const overdueTasks = tasks.filter(task =>
                task.dueDate &&
                new Date(task.dueDate) < now &&
                task.status !== 'completed'
            );

            return {
                projectId,
                projectName: project.name,
                totalTasks,
                statusDistribution,
                completionRate: Math.round(completionRate * 100) / 100,
                averageTaskDuration: Math.round(averageTaskDuration * 100) / 100,
                overdueTasksCount: overdueTasks.length,
                overdueTasks: overdueTasks.map(task => ({
                    id: task.id,
                    title: task.title,
                    dueDate: task.dueDate,
                    assigneeId: task.assigneeId,
                    priority: task.priority
                }))
            };
        } catch (error) {
            throw new Error(`Failed to get project metrics: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }

    /**
     * Get team workload distribution across team members
     * @param projectId - Optional project ID to filter by
     * @returns Team workload metrics
     */
    async getTeamWorkload(projectId?: string) {
        try {
            const tasks = projectId
                ? await this.taskRepository.getTasksByProject(projectId)
                : await this.taskRepository.getAllTasks();

            // Group tasks by assignee
            const workloadByUser = new Map<string, any>();

            for (const task of tasks) {
                if (!task.assigneeId) continue;

                if (!workloadByUser.has(task.assigneeId)) {
                    const user = await this.userRepository.findById(task.assigneeId);
                    workloadByUser.set(task.assigneeId, {
                        userId: task.assigneeId,
                        userName: user?.name || 'Unknown User',
                        totalTasks: 0,
                        completedTasks: 0,
                        inProgressTasks: 0,
                        todoTasks: 0,
                        overdueTasks: 0
                    });
                }

                const userWorkload = workloadByUser.get(task.assigneeId)!;
                userWorkload.totalTasks++;

                switch (task.status) {
                    case 'completed':
                        userWorkload.completedTasks++;
                        break;
                    case 'in-progress':
                        userWorkload.inProgressTasks++;
                        break;
                    case 'todo':
                        userWorkload.todoTasks++;
                        break;
                }

                // Check if task is overdue
                if (task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'completed') {
                    userWorkload.overdueTasks++;
                }
            }

            return Array.from(workloadByUser.values()).map(workload => ({
                ...workload,
                completionRate: workload.totalTasks > 0
                    ? Math.round((workload.completedTasks / workload.totalTasks) * 100)
                    : 0
            }));
        } catch (error) {
            throw new Error(`Failed to get team workload: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }

    /**
     * Get task completion trends over time
     * @param projectId - Optional project ID to filter by
     * @param days - Number of days to look back (default: 30)
     * @returns Task completion trends
     */
    async getCompletionTrends(projectId?: string, days: number = 30) {
        try {
            const endDate = new Date();
            const startDate = new Date();
            startDate.setDate(startDate.getDate() - days);

            const tasks = projectId
                ? await this.taskRepository.getTasksByProject(projectId)
                : await this.taskRepository.getAllTasks();

            // Filter completed tasks within date range
            const completedTasks = tasks.filter(task =>
                task.status === 'completed' &&
                task.completedAt &&
                new Date(task.completedAt) >= startDate &&
                new Date(task.completedAt) <= endDate
            );

            // Group by date
            const trendData = new Map<string, number>();

            // Initialize all dates with 0
            for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
                const dateKey = d.toISOString().split('T')[0];
                trendData.set(dateKey, 0);
            }

            // Count completions by date
            completedTasks.forEach(task => {
                const dateKey = new Date(task.completedAt!).toISOString().split('T')[0];
                if (trendData.has(dateKey)) {
                    trendData.set(dateKey, trendData.get(dateKey)! + 1);
                }
            });

            return Array.from(trendData.entries()).map(([date, count]) => ({
                date,
                completedTasks: count
            }));
        } catch (error) {
            throw new Error(`Failed to get completion trends: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }

    /**
     * Generate comprehensive project report data
     * @param projectId - Project ID to generate report for
     * @returns Complete project report data
     */
    async generateProjectReport(projectId: string) {
        try {
            const [metrics, workload, trends] = await Promise.all([
                this.getProjectMetrics(projectId),
                this.getTeamWorkload(projectId),
                this.getCompletionTrends(projectId)
            ]);

            return {
                generatedAt: new Date().toISOString(),
                project: {
                    id: projectId,
                    name: metrics.projectName
                },
                summary: {
                    totalTasks: metrics.totalTasks,
                    completionRate: metrics.completionRate,
                    averageTaskDuration: metrics.averageTaskDuration,
                    overdueTasksCount: metrics.overdueTasksCount
                },
                statusDistribution: metrics.statusDistribution,
                teamWorkload: workload,
                completionTrends: trends,
                overdueItems: metrics.overdueTasks
            };
        } catch (error) {
            throw new Error(`Failed to generate project report: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
}