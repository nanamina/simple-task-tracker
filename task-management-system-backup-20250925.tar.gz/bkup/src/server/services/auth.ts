/**
 * Authentication service with password hashing utilities
 */

import * as bcrypt from 'bcrypt'
import * as jwt from 'jsonwebtoken'
import { User } from '../../shared/types/index'

const SALT_ROUNDS = 12
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'
const JWT_EXPIRES_IN = '24h'

/**
 * Hash a plain text password using bcrypt
 * @param password - Plain text password to hash
 * @returns Promise resolving to hashed password
 */
export async function hashPassword(password: string): Promise<string> {
    try {
        const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS)
        return hashedPassword
    } catch (error) {
        throw new Error('Failed to hash password')
    }
}

/**
 * Compare a plain text password with a hashed password
 * @param password - Plain text password
 * @param hashedPassword - Hashed password to compare against
 * @returns Promise resolving to boolean indicating if passwords match
 */
export async function comparePassword(password: string, hashedPassword: string): Promise<boolean> {
    try {
        const isMatch = await bcrypt.compare(password, hashedPassword)
        return isMatch
    } catch (error) {
        throw new Error('Failed to compare passwords')
    }
}

/**
 * Generate JWT token for authenticated user
 * @param user - User object to encode in token
 * @returns JWT token string
 */
export function generateToken(user: User): string {
    try {
        const payload = {
            id: user.id,
            email: user.email,
            role: user.role
        }

        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN })
        return token
    } catch (error) {
        throw new Error('Failed to generate token')
    }
}

/**
 * Verify and decode JWT token
 * @param token - JWT token to verify
 * @returns Decoded token payload or null if invalid
 */
export function verifyToken(token: string): { id: string; email: string; role: string } | null {
    try {
        const decoded = jwt.verify(token, JWT_SECRET) as any
        return {
            id: decoded.id,
            email: decoded.email,
            role: decoded.role
        }
    } catch (error) {
        return null
    }
}

/**
 * Extract token from Authorization header
 * @param authHeader - Authorization header value
 * @returns Token string or null if not found
 */
export function extractTokenFromHeader(authHeader: string | undefined): string | null {
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return null
    }

    return authHeader.substring(7) // Remove 'Bearer ' prefix
}