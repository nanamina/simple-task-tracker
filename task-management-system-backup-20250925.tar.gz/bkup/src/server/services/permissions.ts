/**
 * Permission management service
 */

import { UserRole } from '../../shared/types/index'
import {
    PERMISSIONS,
    hasPermission,
    canAccess,
    getUserPermissions,
    getResourcePermissions,
    hasRoleLevel
} from '../middleware/authorization'

/**
 * Permission service for centralized permission management
 */
export class PermissionService {
    /**
     * Check if a user has a specific permission
     * @param userRole - User's role
     * @param permissionKey - Permission key
     * @returns Boolean indicating permission status
     */
    static hasPermission(userRole: UserRole, permissionKey: string): boolean {
        return hasPermission(userRole, permissionKey)
    }

    /**
     * Check if a user can perform an action on a resource
     * @param userRole - User's role
     * @param resource - Resource name
     * @param action - Action name
     * @returns Boolean indicating access status
     */
    static canAccess(userRole: UserRole, resource: string, action: string): boolean {
        return canAccess(userRole, resource, action)
    }

    /**
     * Get all permissions for a user role
     * @param userRole - User's role
     * @returns Array of permission keys
     */
    static getUserPermissions(userRole: UserRole): string[] {
        return getUserPermissions(userRole)
    }

    /**
     * Get permissions for a specific resource
     * @param resource - Resource name
     * @returns Array of permissions
     */
    static getResourcePermissions(resource: string) {
        return getResourcePermissions(resource)
    }

    /**
     * Check role hierarchy
     * @param userRole - User's role
     * @param requiredRole - Required minimum role
     * @returns Boolean indicating role level status
     */
    static hasRoleLevel(userRole: UserRole, requiredRole: UserRole): boolean {
        return hasRoleLevel(userRole, requiredRole)
    }

    /**
     * Get user's effective permissions with context
     * @param userRole - User's role
     * @param context - Additional context (e.g., project membership)
     * @returns Object with permission details
     */
    static getUserPermissionContext(userRole: UserRole, context?: {
        isProjectMember?: boolean
        isResourceOwner?: boolean
        projectId?: string
        resourceOwnerId?: string
    }) {
        const basePermissions = getUserPermissions(userRole)

        return {
            role: userRole,
            permissions: basePermissions,
            context: context || {},
            canCreateTasks: hasPermission(userRole, 'tasks:create'),
            canManageProjects: hasPermission(userRole, 'projects:update'),
            canManageUsers: hasPermission(userRole, 'users:update'),
            canViewReports: hasPermission(userRole, 'reports:view'),
            isAdmin: userRole === 'admin',
            isManager: userRole === 'manager' || userRole === 'admin',
            isMember: ['member', 'manager', 'admin'].includes(userRole)
        }
    }

    /**
     * Validate multiple permissions at once
     * @param userRole - User's role
     * @param permissionKeys - Array of permission keys to check
     * @returns Object with permission results
     */
    static validatePermissions(userRole: UserRole, permissionKeys: string[]) {
        const results: Record<string, boolean> = {}
        const granted: string[] = []
        const denied: string[] = []

        permissionKeys.forEach(key => {
            const hasAccess = hasPermission(userRole, key)
            results[key] = hasAccess

            if (hasAccess) {
                granted.push(key)
            } else {
                denied.push(key)
            }
        })

        return {
            results,
            granted,
            denied,
            hasAllPermissions: denied.length === 0,
            hasAnyPermission: granted.length > 0
        }
    }

    /**
     * Get permission requirements for a resource action
     * @param resource - Resource name
     * @param action - Action name
     * @returns Permission details or null if not found
     */
    static getPermissionRequirements(resource: string, action: string) {
        const permissionKey = `${resource}:${action}`
        const permission = PERMISSIONS[permissionKey]

        if (!permission) {
            return null
        }

        return {
            key: permissionKey,
            resource: permission.resource,
            action: permission.action,
            requiredRoles: permission.roles,
            minimumRole: this.getMinimumRole(permission.roles)
        }
    }

    /**
     * Get the minimum role from a list of roles
     * @param roles - Array of roles
     * @returns Minimum role or null
     */
    private static getMinimumRole(roles: UserRole[]): UserRole | null {
        const roleHierarchy: Record<UserRole, number> = {
            'member': 1,
            'manager': 2,
            'admin': 3
        }

        let minLevel = Infinity
        let minRole: UserRole | null = null

        roles.forEach(role => {
            const level = roleHierarchy[role]
            if (level < minLevel) {
                minLevel = level
                minRole = role
            }
        })

        return minRole
    }

    /**
     * Check if user can perform bulk operations
     * @param userRole - User's role
     * @param operations - Array of operations to check
     * @returns Validation results
     */
    static validateBulkOperations(userRole: UserRole, operations: Array<{ resource: string, action: string }>) {
        const results = operations.map(op => ({
            resource: op.resource,
            action: op.action,
            allowed: canAccess(userRole, op.resource, op.action),
            permissionKey: `${op.resource}:${op.action}`
        }))

        return {
            operations: results,
            allAllowed: results.every(r => r.allowed),
            allowedCount: results.filter(r => r.allowed).length,
            deniedCount: results.filter(r => !r.allowed).length
        }
    }
}