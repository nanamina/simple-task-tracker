/**
 * Authentication middleware for JWT token validation
 */

import { Request, Response, NextFunction } from 'express'
import { verifyToken, extractTokenFromHeader } from '../services/auth'
import { UserRole } from '../../shared/types/index'

// Extend Express Request interface to include user
declare global {
    namespace Express {
        interface Request {
            user?: {
                id: string
                email: string
                role: UserRole
            }
        }
    }
}

/**
 * Authentication middleware that validates JWT tokens
 * Adds user information to request object if token is valid
 */
export function authenticateToken(req: Request, res: Response, next: NextFunction): void {
    try {
        const authHeader = req.headers.authorization
        const token = extractTokenFromHeader(authHeader)

        if (!token) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Access token is required',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        const decoded = verifyToken(token)
        if (!decoded) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Invalid or expired token',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Add user information to request
        req.user = {
            id: decoded.id,
            email: decoded.email,
            role: decoded.role as UserRole
        }

        next()
    } catch (error) {
        console.error('Authentication error:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Authentication failed',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Optional authentication middleware that adds user info if token exists
 * Does not reject requests without tokens
 */
export function optionalAuth(req: Request, _res: Response, next: NextFunction): void {
    try {
        const authHeader = req.headers.authorization
        const token = extractTokenFromHeader(authHeader)

        if (token) {
            const decoded = verifyToken(token)
            if (decoded) {
                req.user = {
                    id: decoded.id,
                    email: decoded.email,
                    role: decoded.role as UserRole
                }
            }
        }

        next()
    } catch (error) {
        // Log error but don't fail the request
        console.error('Optional auth error:', error)
        next()
    }
}

/**
 * Role-based authorization middleware factory
 * @param allowedRoles - Array of roles that can access the route
 * @returns Middleware function that checks user role
 */
export function requireRole(allowedRoles: UserRole[]) {
    return (req: Request, res: Response, next: NextFunction): void => {
        if (!req.user) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        if (!allowedRoles.includes(req.user.role)) {
            res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: `Access denied. Required roles: ${allowedRoles.join(', ')}`,
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        next()
    }
}

/**
 * Admin-only access middleware
 */
export const requireAdmin = requireRole(['admin'])

/**
 * Manager or Admin access middleware
 */
export const requireManagerOrAdmin = requireRole(['manager', 'admin'])

/**
 * Any authenticated user access middleware
 */
export const requireAuth = authenticateToken