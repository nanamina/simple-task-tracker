import { Request, Response, NextFunction } from 'express'
import { ValidationError } from 'express-validator'

/**
 * Standard error response format
 */
export interface ErrorResponse {
    error: {
        code: string
        message: string
        details?: any
        timestamp: string
        requestId?: string
    }
}

/**
 * Error codes used throughout the application
 */
export enum ErrorCodes {
    VALIDATION_ERROR = 'VALIDATION_ERROR',
    UNAUTHORIZED = 'UNAUTHORIZED',
    FORBIDDEN = 'FORBIDDEN',
    NOT_FOUND = 'NOT_FOUND',
    CONFLICT = 'CONFLICT',
    INTERNAL_ERROR = 'INTERNAL_ERROR',
    DATABASE_ERROR = 'DATABASE_ERROR',
    RATE_LIMIT_ERROR = 'RATE_LIMIT_ERROR',
}

/**
 * Custom application error class
 */
export class AppError extends Error {
    public readonly statusCode: number
    public readonly code: string
    public readonly details?: any
    public readonly isOperational: boolean

    constructor(
        message: string,
        statusCode: number = 500,
        code: string = ErrorCodes.INTERNAL_ERROR,
        details?: any,
        isOperational: boolean = true
    ) {
        super(message)
        this.statusCode = statusCode
        this.code = code
        this.details = details
        this.isOperational = isOperational

        // Maintain proper stack trace
        Error.captureStackTrace(this, this.constructor)
    }
}

/**
 * Validation error class for form validation
 */
export class ValidationAppError extends AppError {
    constructor(message: string, details?: any) {
        super(message, 422, ErrorCodes.VALIDATION_ERROR, details)
    }
}

/**
 * Not found error class
 */
export class NotFoundError extends AppError {
    constructor(resource: string = 'Resource') {
        super(`${resource} not found`, 404, ErrorCodes.NOT_FOUND)
    }
}

/**
 * Unauthorized error class
 */
export class UnauthorizedError extends AppError {
    constructor(message: string = 'Authentication required') {
        super(message, 401, ErrorCodes.UNAUTHORIZED)
    }
}

/**
 * Forbidden error class
 */
export class ForbiddenError extends AppError {
    constructor(message: string = 'Access denied') {
        super(message, 403, ErrorCodes.FORBIDDEN)
    }
}

/**
 * Conflict error class
 */
export class ConflictError extends AppError {
    constructor(message: string, details?: any) {
        super(message, 409, ErrorCodes.CONFLICT, details)
    }
}

/**
 * Database error class
 */
export class DatabaseError extends AppError {
    constructor(message: string, details?: any) {
        super(message, 500, ErrorCodes.DATABASE_ERROR, details)
    }
}

/**
 * Generate unique request ID for error tracking
 */
function generateRequestId(): string {
    return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}

/**
 * Log error with context information
 */
function logError(error: Error, req: Request, requestId: string) {
    const logData = {
        requestId,
        timestamp: new Date().toISOString(),
        method: req.method,
        url: req.url,
        userAgent: req.get('User-Agent'),
        ip: req.ip,
        userId: req.user?.id,
        error: {
            name: error.name,
            message: error.message,
            stack: error.stack,
            ...(error instanceof AppError && {
                code: error.code,
                statusCode: error.statusCode,
                details: error.details,
                isOperational: error.isOperational,
            }),
        },
    }

    // Log based on error severity
    if (error instanceof AppError && error.isOperational) {
        // Operational errors (expected) - log as warning
        console.warn('Operational Error:', JSON.stringify(logData, null, 2))
    } else {
        // Programming errors (unexpected) - log as error
        console.error('Programming Error:', JSON.stringify(logData, null, 2))
    }

    // In production, send to error monitoring service
    if (process.env.NODE_ENV === 'production') {
        // Example: sendToErrorService(logData)
    }
}

/**
 * Handle database errors and convert to appropriate AppError
 */
function handleDatabaseError(error: any): AppError {
    // PostgreSQL error codes
    switch (error.code) {
        case '23505': // unique_violation
            return new ConflictError('Resource already exists', {
                constraint: error.constraint,
                detail: error.detail,
            })
        case '23503': // foreign_key_violation
            return new ValidationAppError('Referenced resource does not exist', {
                constraint: error.constraint,
                detail: error.detail,
            })
        case '23502': // not_null_violation
            return new ValidationAppError('Required field is missing', {
                column: error.column,
            })
        case '23514': // check_violation
            return new ValidationAppError('Invalid data format', {
                constraint: error.constraint,
            })
        case '42P01': // undefined_table
        case '42703': // undefined_column
            return new DatabaseError('Database schema error', {
                code: error.code,
                message: error.message,
            })
        default:
            return new DatabaseError('Database operation failed', {
                code: error.code,
                message: error.message,
            })
    }
}

/**
 * Convert express-validator errors to our format
 */
function formatValidationErrors(errors: ValidationError[]): any {
    return errors.map(error => ({
        field: error.type === 'field' ? error.path : error.type,
        message: error.msg,
        value: error.type === 'field' ? error.value : undefined,
    }))
}

/**
 * Main error handling middleware
 * Should be the last middleware in the chain
 */
export function errorHandler(
    error: Error,
    req: Request,
    res: Response,
    _next: NextFunction
): void {
    const requestId = generateRequestId()

    // Log the error
    logError(error, req, requestId)

    let appError: AppError

    // Convert different error types to AppError
    if (error instanceof AppError) {
        appError = error
    } else if (error.name === 'ValidationError' && 'errors' in error) {
        // Mongoose validation errors
        appError = new ValidationAppError('Validation failed', error)
    } else if (error.name === 'CastError') {
        // Database casting errors
        appError = new ValidationAppError('Invalid data format')
    } else if (error.message?.includes('duplicate key') || error.message?.includes('unique constraint')) {
        // Database unique constraint errors
        appError = new ConflictError('Resource already exists')
    } else if (error.name === 'JsonWebTokenError') {
        appError = new UnauthorizedError('Invalid token')
    } else if (error.name === 'TokenExpiredError') {
        appError = new UnauthorizedError('Token expired')
    } else if (error.name === 'SyntaxError' && 'body' in error) {
        appError = new ValidationAppError('Invalid JSON format')
    } else if ('code' in error && typeof error.code === 'string') {
        // Database errors
        appError = handleDatabaseError(error)
    } else {
        // Unknown errors
        appError = new AppError(
            process.env.NODE_ENV === 'production'
                ? 'Internal server error'
                : error.message,
            500,
            ErrorCodes.INTERNAL_ERROR,
            process.env.NODE_ENV === 'development' ? { stack: error.stack } : undefined,
            false
        )
    }

    // Create error response
    const errorResponse: ErrorResponse = {
        error: {
            code: appError.code,
            message: appError.message,
            timestamp: new Date().toISOString(),
            requestId,
            ...(appError.details && { details: appError.details }),
        },
    }

    // Send error response
    res.status(appError.statusCode).json(errorResponse)
}

/**
 * 404 handler for unmatched routes
 */
export function notFoundHandler(req: Request, res: Response, _next: NextFunction): void {
    const error = new NotFoundError(`Route ${req.method} ${req.path} not found`)
    const requestId = generateRequestId()

    const errorResponse: ErrorResponse = {
        error: {
            code: error.code,
            message: error.message,
            timestamp: new Date().toISOString(),
            requestId,
        },
    }

    res.status(404).json(errorResponse)
}

/**
 * Async error wrapper for route handlers
 * Catches async errors and passes them to error middleware
 */
export function asyncHandler<T extends Request, U extends Response>(
    fn: (req: T, res: U, next: NextFunction) => Promise<any>
) {
    return (req: T, res: U, next: NextFunction) => {
        Promise.resolve(fn(req, res, next)).catch(next)
    }
}

/**
 * Validation error handler for express-validator
 */
export function handleValidationErrors(req: Request, _res: Response, next: NextFunction): void {
    const { validationResult } = require('express-validator')
    const errors = validationResult(req)

    if (!errors.isEmpty()) {
        const formattedErrors = formatValidationErrors(errors.array())
        throw new ValidationAppError('Validation failed', formattedErrors)
    }

    next()
}