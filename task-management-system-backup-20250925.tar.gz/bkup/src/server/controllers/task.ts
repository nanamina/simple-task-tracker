/**
 * Task controller for handling task-related HTTP requests
 */

import { Request, Response } from 'express'
import { body, query, param, validationResult } from 'express-validator'
import { TaskRepository } from '../repositories/task-repository'
import { getPool } from '../config/database'
import {
    CreateTaskDTO,
    UpdateTaskDTO,
    TaskFilterOptions,
    TaskSortOptions,
    validateCreateTask,
    validateUpdateTask,
    validateTaskStatusTransition
} from '../../shared/types/validation'
import { TaskStatus } from '../../shared/types/index'
import {
    handleTaskAssignmentNotification,
    handleTaskStatusUpdateNotification,
    handleTaskReassignmentNotification,
    areNotificationsEnabled,
    logNotificationAttempt
} from '../services/notification-helper'

// Initialize task repository
const taskRepository = new TaskRepository(getPool())

/**
 * Validation middleware for creating tasks
 */
export const createTaskValidation = [
    body('title')
        .trim()
        .isLength({ min: 1, max: 255 })
        .withMessage('Title must be between 1 and 255 characters'),
    body('description')
        .trim()
        .isLength({ max: 2000 })
        .withMessage('Description must be 2000 characters or less'),
    body('priority')
        .optional()
        .isIn(['low', 'medium', 'high', 'critical'])
        .withMessage('Priority must be low, medium, high, or critical'),
    body('dueDate')
        .optional()
        .isISO8601()
        .withMessage('Due date must be a valid ISO 8601 date'),
    body('assigneeId')
        .optional()
        .isUUID()
        .withMessage('Assignee ID must be a valid UUID'),
    body('projectId')
        .optional()
        .isUUID()
        .withMessage('Project ID must be a valid UUID')
]

/**
 * Validation middleware for updating tasks
 */
export const updateTaskValidation = [
    param('id')
        .isUUID()
        .withMessage('Task ID must be a valid UUID'),
    body('title')
        .optional()
        .trim()
        .isLength({ min: 1, max: 255 })
        .withMessage('Title must be between 1 and 255 characters'),
    body('description')
        .optional()
        .trim()
        .isLength({ max: 2000 })
        .withMessage('Description must be 2000 characters or less'),
    body('priority')
        .optional()
        .isIn(['low', 'medium', 'high', 'critical'])
        .withMessage('Priority must be low, medium, high, or critical'),
    body('dueDate')
        .optional()
        .isISO8601()
        .withMessage('Due date must be a valid ISO 8601 date'),
    body('assigneeId')
        .optional()
        .isUUID()
        .withMessage('Assignee ID must be a valid UUID'),
    body('projectId')
        .optional()
        .isUUID()
        .withMessage('Project ID must be a valid UUID')
]

/**
 * Validation middleware for task status updates
 */
export const updateTaskStatusValidation = [
    param('id')
        .isUUID()
        .withMessage('Task ID must be a valid UUID'),
    body('status')
        .isIn(['todo', 'in-progress', 'completed'])
        .withMessage('Status must be todo, in-progress, or completed')
]

/**
 * Validation middleware for task queries
 */
export const taskQueryValidation = [
    query('status')
        .optional()
        .isIn(['todo', 'in-progress', 'completed'])
        .withMessage('Status must be todo, in-progress, or completed'),
    query('priority')
        .optional()
        .isIn(['low', 'medium', 'high', 'critical'])
        .withMessage('Priority must be low, medium, high, or critical'),
    query('assigneeId')
        .optional()
        .isUUID()
        .withMessage('Assignee ID must be a valid UUID'),
    query('projectId')
        .optional()
        .isUUID()
        .withMessage('Project ID must be a valid UUID'),
    query('search')
        .optional()
        .isLength({ min: 1, max: 255 })
        .withMessage('Search term must be between 1 and 255 characters'),
    query('isOverdue')
        .optional()
        .isBoolean()
        .withMessage('isOverdue must be a boolean'),
    query('isUnassigned')
        .optional()
        .isBoolean()
        .withMessage('isUnassigned must be a boolean'),
    query('sortBy')
        .optional()
        .isIn(['createdAt', 'updatedAt', 'dueDate', 'priority', 'title', 'relevance'])
        .withMessage('Sort field must be createdAt, updatedAt, dueDate, priority, title, or relevance'),
    query('sortOrder')
        .optional()
        .isIn(['asc', 'desc'])
        .withMessage('Sort order must be asc or desc'),
    query('limit')
        .optional()
        .isInt({ min: 1, max: 100 })
        .withMessage('Limit must be between 1 and 100'),
    query('offset')
        .optional()
        .isInt({ min: 0 })
        .withMessage('Offset must be 0 or greater')
]

/**
 * GET /api/tasks
 * List tasks with filtering and sorting
 */
export const listTasks = async (req: Request, res: Response): Promise<void> => {
    try {
        // Check for validation errors
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid request parameters',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Extract query parameters
        const {
            status,
            priority,
            assigneeId,
            projectId,
            search,
            isOverdue,
            isUnassigned,
            sortBy = 'createdAt',
            sortOrder = 'desc',
            limit = 50,
            offset = 0
        } = req.query

        // Build filter options
        const filters: TaskFilterOptions = {}
        if (status) filters.status = status as TaskStatus
        if (priority) filters.priority = priority as any
        if (assigneeId) filters.assigneeId = assigneeId as string
        if (projectId) filters.projectId = projectId as string
        if (search) filters.search = search as string
        if (isOverdue === 'true') filters.isOverdue = true
        if (isUnassigned === 'true') filters.isUnassigned = true

        // Build sort options
        const sort: TaskSortOptions = {
            field: sortBy as any,
            direction: sortOrder as 'asc' | 'desc'
        }

        // Get tasks from repository
        const tasks = await taskRepository.listTasks(
            filters,
            sort,
            parseInt(limit as string),
            parseInt(offset as string)
        )

        res.json({
            data: tasks,
            meta: {
                count: tasks.length,
                limit: parseInt(limit as string),
                offset: parseInt(offset as string)
            }
        })
    } catch (error) {
        console.error('Error listing tasks:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to retrieve tasks',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * POST /api/tasks
 * Create a new task
 */
export const createTask = async (req: Request, res: Response): Promise<void> => {
    try {
        // Check for validation errors
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid task data',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Extract task data from request body
        const taskData: CreateTaskDTO = {
            title: req.body.title,
            description: req.body.description,
            priority: req.body.priority,
            dueDate: req.body.dueDate ? new Date(req.body.dueDate) : undefined,
            assigneeId: req.body.assigneeId,
            projectId: req.body.projectId
        }

        // Additional validation
        const validation = validateCreateTask(taskData)
        if (!validation.isValid) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid task data',
                    details: validation.errors,
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Get user ID from authenticated request
        const userId = (req as any).user?.id
        if (!userId) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'User authentication required',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Create task
        const task = await taskRepository.createTask(taskData, userId)

        // Send assignment notification if task is assigned and notifications are enabled
        if (task.assigneeId && areNotificationsEnabled()) {
            try {
                logNotificationAttempt('assignment', task.id, [task.assigneeId])
                await handleTaskAssignmentNotification(task, userId)
            } catch (notificationError) {
                console.error('Failed to send task assignment notification:', notificationError)
                // Continue with response even if notification fails
            }
        }

        res.status(201).json({
            data: task,
            message: 'Task created successfully'
        })
    } catch (error) {
        console.error('Error creating task:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to create task',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * GET /api/tasks/:id
 * Get a specific task by ID
 */
export const getTask = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params

        // Validate UUID format
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid task ID format',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        const task = await taskRepository.findById(id)

        if (!task) {
            res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Task not found',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        res.json({
            data: task
        })
    } catch (error) {
        console.error('Error getting task:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to retrieve task',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * PUT /api/tasks/:id
 * Update a task
 */
export const updateTask = async (req: Request, res: Response): Promise<void> => {
    try {
        // Check for validation errors
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid task data',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        const { id } = req.params

        // Get current task to check for assignee changes
        const currentTask = await taskRepository.findById(id)
        if (!currentTask) {
            res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Task not found',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Extract update data from request body
        const updateData: UpdateTaskDTO = {}
        if (req.body.title !== undefined) updateData.title = req.body.title
        if (req.body.description !== undefined) updateData.description = req.body.description
        if (req.body.priority !== undefined) updateData.priority = req.body.priority
        if (req.body.dueDate !== undefined) updateData.dueDate = req.body.dueDate ? new Date(req.body.dueDate) : undefined
        if (req.body.assigneeId !== undefined) updateData.assigneeId = req.body.assigneeId
        if (req.body.projectId !== undefined) updateData.projectId = req.body.projectId

        // Additional validation
        const validation = validateUpdateTask(updateData)
        if (!validation.isValid) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid task data',
                    details: validation.errors,
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Get user ID from authenticated request
        const userId = (req as any).user?.id
        if (!userId) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'User authentication required',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Update task
        const task = await taskRepository.updateTask(id, updateData)

        if (!task) {
            res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Task not found',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Handle reassignment notifications if assignee changed and notifications are enabled
        if (areNotificationsEnabled() && updateData.assigneeId !== undefined &&
            currentTask.assigneeId !== task.assigneeId) {
            try {
                const recipients = [task.assigneeId, currentTask.assigneeId].filter(Boolean) as string[]
                logNotificationAttempt('assignment', task.id, recipients)
                await handleTaskReassignmentNotification(task, currentTask.assigneeId, userId)
            } catch (notificationError) {
                console.error('Failed to send task reassignment notification:', notificationError)
                // Continue with response even if notification fails
            }
        }

        res.json({
            data: task,
            message: 'Task updated successfully'
        })
    } catch (error) {
        console.error('Error updating task:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to update task',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * DELETE /api/tasks/:id
 * Delete a task
 */
export const deleteTask = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params

        // Validate UUID format
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid task ID format',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        const success = await taskRepository.deleteTask(id)

        if (!success) {
            res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Task not found',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        res.status(204).send()
    } catch (error) {
        console.error('Error deleting task:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to delete task',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * PATCH /api/tasks/:id/status
 * Update task status
 */
export const updateTaskStatus = async (req: Request, res: Response): Promise<void> => {
    try {
        // Check for validation errors
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid status data',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        const { id } = req.params
        const { status } = req.body

        // Get current task to validate status transition
        const currentTask = await taskRepository.findById(id)
        if (!currentTask) {
            res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Task not found',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Validate status transition
        const transitionValidation = validateTaskStatusTransition(currentTask.status, status)
        if (!transitionValidation.isValid) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: transitionValidation.error || 'Invalid status transition',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Get user ID from authenticated request
        const userId = (req as any).user?.id
        if (!userId) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'User authentication required',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Update task status
        const updatedTask = await taskRepository.updateTaskStatus(id, status)

        if (!updatedTask) {
            res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Task not found',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Send status update notification if notifications are enabled
        if (areNotificationsEnabled()) {
            try {
                const recipients = [updatedTask.assigneeId, updatedTask.createdBy].filter(Boolean) as string[]
                logNotificationAttempt('status_update', updatedTask.id, recipients)
                await handleTaskStatusUpdateNotification(updatedTask, userId)
            } catch (notificationError) {
                console.error('Failed to send task status update notification:', notificationError)
                // Continue with response even if notification fails
            }
        }

        res.json({
            data: updatedTask,
            message: 'Task status updated successfully'
        })
    } catch (error) {
        console.error('Error updating task status:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to update task status',
                timestamp: new Date().toISOString()
            }
        })
    }
}