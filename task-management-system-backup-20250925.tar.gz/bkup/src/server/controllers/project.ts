/**
 * Project management controllers
 */

import { Request, Response } from 'express'
import { body, query, param, validationResult } from 'express-validator'
import { ProjectRepository } from '../repositories/project-repository'
import { TaskRepository } from '../repositories/task-repository'
import { UserRepository } from '../repositories/user-repository'
import { getPool } from '../config/database'
import { validateCreateProject, validateUpdateProject } from '../../shared/types/validation'
import '../middleware/auth' // Import to ensure type augmentation is loaded

// Initialize repositories
const db = getPool()
const projectRepository = new ProjectRepository(db)
const taskRepository = new TaskRepository(db)
const userRepository = new UserRepository(db)

/**
 * List projects with optional filtering
 * GET /api/projects
 */
export async function listProjects(req: Request, res: Response) {
    try {
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid query parameters',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
        }

        const limit = parseInt(req.query.limit as string) || 50
        const offset = parseInt(req.query.offset as string) || 0
        const memberOnly = req.query.memberOnly === 'true'
        const search = req.query.search as string
        const sortBy = (req.query.sortBy as string) || 'createdAt'
        const sortOrder = (req.query.sortOrder as string) || 'desc'

        // Build filter options
        const filters: import('../../shared/types/validation').ProjectFilterOptions = {}
        if (search) filters.search = search

        // Build sort options
        const sort: import('../../shared/types/validation').ProjectSortOptions = {
            field: sortBy as any,
            direction: sortOrder as 'asc' | 'desc'
        }

        let projects
        if (memberOnly) {
            // Get only projects where user is a member
            projects = await projectRepository.getProjectsByMember(req.user!.id)
        } else {
            // Get all projects (admin/manager) or user's projects (member)
            if (req.user!.role === 'admin' || req.user!.role === 'manager') {
                projects = await projectRepository.listProjects(filters, sort, limit, offset)
            } else {
                projects = await projectRepository.getProjectsByMember(req.user!.id)
            }
        }

        res.json({
            projects,
            pagination: {
                limit,
                offset,
                total: projects.length
            }
        })
    } catch (error) {
        console.error('Error listing projects:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to list projects',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Create a new project
 * POST /api/projects
 */
export async function createProject(req: Request, res: Response) {
    try {
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project data',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
        }

        // Additional validation using shared validation functions
        const validation = validateCreateProject(req.body)
        if (!validation.isValid) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project data',
                    details: validation.errors,
                    timestamp: new Date().toISOString()
                }
            })
        }

        const project = await projectRepository.createProject(req.body, req.user!.id)

        res.status(201).json({
            message: 'Project created successfully',
            project
        })
    } catch (error) {
        console.error('Error creating project:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to create project',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Get a specific project by ID
 * GET /api/projects/:id
 */
export async function getProject(req: Request, res: Response) {
    try {
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project ID',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
        }

        const projectId = req.params.id
        const project = await projectRepository.findById(projectId)

        if (!project) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            })
        }

        // Check if user has access to this project
        const isAdmin = req.user!.role === 'admin'
        const isManager = req.user!.role === 'manager'

        if (!isAdmin && !isManager) {
            const isMember = await projectRepository.isMember(projectId, req.user!.id)
            if (!isMember) {
                return res.status(403).json({
                    error: {
                        code: 'FORBIDDEN',
                        message: 'Access denied to this project',
                        timestamp: new Date().toISOString()
                    }
                })
            }
        }

        res.json({ project })
    } catch (error) {
        console.error('Error getting project:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to get project',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Update a project
 * PUT /api/projects/:id
 */
export async function updateProject(req: Request, res: Response) {
    try {
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project data',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
        }

        // Additional validation using shared validation functions
        const validation = validateUpdateProject(req.body)
        if (!validation.isValid) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project data',
                    details: validation.errors,
                    timestamp: new Date().toISOString()
                }
            })
        }

        const projectId = req.params.id

        // Check if project exists and user has access
        const existingProject = await projectRepository.findById(projectId)
        if (!existingProject) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            })
        }

        // Check permissions - only project creator, managers, or admins can update
        const isCreator = existingProject.createdBy === req.user!.id
        const isAdmin = req.user!.role === 'admin'
        const isManager = req.user!.role === 'manager'

        if (!isCreator && !isAdmin && !isManager) {
            return res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied to update this project',
                    timestamp: new Date().toISOString()
                }
            })
        }

        const updatedProject = await projectRepository.updateProject(projectId, req.body)

        if (!updatedProject) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            })
        }

        res.json({
            message: 'Project updated successfully',
            project: updatedProject
        })
    } catch (error) {
        console.error('Error updating project:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to update project',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Delete a project
 * DELETE /api/projects/:id
 */
export async function deleteProject(req: Request, res: Response) {
    try {
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project ID',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
        }

        const projectId = req.params.id

        // Check if project exists and user has access
        const existingProject = await projectRepository.findById(projectId)
        if (!existingProject) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            })
        }

        // Check permissions - only project creator or admins can delete
        const isCreator = existingProject.createdBy === req.user!.id
        const isAdmin = req.user!.role === 'admin'

        if (!isCreator && !isAdmin) {
            return res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied to delete this project',
                    timestamp: new Date().toISOString()
                }
            })
        }

        const deleted = await projectRepository.deleteProject(projectId)

        if (!deleted) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            })
        }

        res.json({
            message: 'Project deleted successfully'
        })
    } catch (error) {
        console.error('Error deleting project:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to delete project',
                timestamp: new Date().toISOString()
            }
        })
    }
}/**

 * Get project tasks
 * GET /api/projects/:id/tasks
 */
export async function getProjectTasks(req: Request, res: Response) {
    try {
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project ID',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
        }

        const projectId = req.params.id

        // Check if project exists and user has access
        const project = await projectRepository.findById(projectId)
        if (!project) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            })
        }

        const isMember = await projectRepository.isMember(projectId, req.user!.id)
        const isAdmin = req.user!.role === 'admin'
        const isManager = req.user!.role === 'manager'

        if (!isMember && !isAdmin && !isManager) {
            return res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied to this project',
                    timestamp: new Date().toISOString()
                }
            })
        }

        const tasks = await taskRepository.getTasksByProject(projectId)

        res.json({
            project: {
                id: project.id,
                name: project.name
            },
            tasks
        })
    } catch (error) {
        console.error('Error getting project tasks:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to get project tasks',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Get project members
 * GET /api/projects/:id/members
 */
export async function getProjectMembers(req: Request, res: Response) {
    try {
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project ID',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
        }

        const projectId = req.params.id

        // Check if project exists and user has access
        const project = await projectRepository.findById(projectId)
        if (!project) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            })
        }

        const isMember = await projectRepository.isMember(projectId, req.user!.id)
        const isAdmin = req.user!.role === 'admin'
        const isManager = req.user!.role === 'manager'

        if (!isMember && !isAdmin && !isManager) {
            return res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied to this project',
                    timestamp: new Date().toISOString()
                }
            })
        }

        const members = await projectRepository.getProjectMembers(projectId)

        res.json({
            project: {
                id: project.id,
                name: project.name
            },
            members
        })
    } catch (error) {
        console.error('Error getting project members:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to get project members',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Add member to project
 * POST /api/projects/:id/members
 */
export async function addProjectMember(req: Request, res: Response) {
    try {
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid request data',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
        }

        const projectId = req.params.id
        const { userId } = req.body

        // Check if project exists
        const project = await projectRepository.findById(projectId)
        if (!project) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            })
        }

        // Check permissions - only project creator, managers, or admins can add members
        const isCreator = project.createdBy === req.user!.id
        const isAdmin = req.user!.role === 'admin'
        const isManager = req.user!.role === 'manager'

        if (!isCreator && !isAdmin && !isManager) {
            return res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied to manage project members',
                    timestamp: new Date().toISOString()
                }
            })
        }

        // Check if user exists
        const user = await userRepository.findById(userId)
        if (!user) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'User not found',
                    timestamp: new Date().toISOString()
                }
            })
        }

        // Check if user is already a member
        const isAlreadyMember = await projectRepository.isMember(projectId, userId)
        if (isAlreadyMember) {
            return res.status(409).json({
                error: {
                    code: 'CONFLICT',
                    message: 'User is already a member of this project',
                    timestamp: new Date().toISOString()
                }
            })
        }

        await projectRepository.addMember(projectId, userId)

        res.status(201).json({
            message: 'Member added to project successfully',
            member: {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role
            }
        })
    } catch (error) {
        console.error('Error adding project member:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to add project member',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Remove member from project
 * DELETE /api/projects/:id/members/:userId
 */
export async function removeProjectMember(req: Request, res: Response) {
    try {
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid request data',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
        }

        const projectId = req.params.id
        const userId = req.params.userId

        // Check if project exists
        const project = await projectRepository.findById(projectId)
        if (!project) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            })
        }

        // Check permissions - only project creator, managers, or admins can remove members
        // Users can also remove themselves
        const isCreator = project.createdBy === req.user!.id
        const isAdmin = req.user!.role === 'admin'
        const isManager = req.user!.role === 'manager'
        const isSelf = userId === req.user!.id

        if (!isCreator && !isAdmin && !isManager && !isSelf) {
            return res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied to manage project members',
                    timestamp: new Date().toISOString()
                }
            })
        }

        // Prevent removing the project creator
        if (userId === project.createdBy) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Cannot remove project creator from project',
                    timestamp: new Date().toISOString()
                }
            })
        }

        // Check if user is a member
        const isMember = await projectRepository.isMember(projectId, userId)
        if (!isMember) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'User is not a member of this project',
                    timestamp: new Date().toISOString()
                }
            })
        }

        const removed = await projectRepository.removeMember(projectId, userId)

        if (!removed) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Member not found in project',
                    timestamp: new Date().toISOString()
                }
            })
        }

        res.json({
            message: 'Member removed from project successfully'
        })
    } catch (error) {
        console.error('Error removing project member:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to remove project member',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Get project metrics and dashboard data
 * GET /api/projects/:id/metrics
 */
export async function getProjectMetrics(req: Request, res: Response) {
    try {
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid project ID',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
        }

        const projectId = req.params.id

        // Check if project exists and user has access
        const project = await projectRepository.findById(projectId)
        if (!project) {
            return res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'Project not found',
                    timestamp: new Date().toISOString()
                }
            })
        }

        const isMember = await projectRepository.isMember(projectId, req.user!.id)
        const isAdmin = req.user!.role === 'admin'
        const isManager = req.user!.role === 'manager'

        if (!isMember && !isAdmin && !isManager) {
            return res.status(403).json({
                error: {
                    code: 'FORBIDDEN',
                    message: 'Access denied to this project',
                    timestamp: new Date().toISOString()
                }
            })
        }

        // Get project statistics
        const stats = await projectRepository.getProjectStats(projectId)

        // Get member count
        const members = await projectRepository.getProjectMembers(projectId)

        // Calculate additional metrics
        const metrics = {
            project: {
                id: project.id,
                name: project.name,
                description: project.description,
                createdAt: project.createdAt
            },
            taskStats: stats,
            memberCount: members.length,
            members: members.map(member => ({
                id: member.id,
                name: member.name,
                role: member.role
            })),
            lastUpdated: new Date().toISOString()
        }

        res.json({ metrics })
    } catch (error) {
        console.error('Error getting project metrics:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to get project metrics',
                timestamp: new Date().toISOString()
            }
        })
    }
}

// Validation middleware
export const projectQueryValidation = [
    query('limit')
        .optional()
        .isInt({ min: 1, max: 100 })
        .withMessage('Limit must be between 1 and 100'),
    query('offset')
        .optional()
        .isInt({ min: 0 })
        .withMessage('Offset must be a non-negative integer'),
    query('memberOnly')
        .optional()
        .isBoolean()
        .withMessage('memberOnly must be a boolean'),
    query('search')
        .optional()
        .isLength({ min: 1, max: 255 })
        .withMessage('Search term must be between 1 and 255 characters'),
    query('sortBy')
        .optional()
        .isIn(['name', 'createdAt', 'updatedAt', 'relevance'])
        .withMessage('Sort field must be name, createdAt, updatedAt, or relevance'),
    query('sortOrder')
        .optional()
        .isIn(['asc', 'desc'])
        .withMessage('Sort order must be asc or desc')
]

export const createProjectValidation = [
    body('name')
        .trim()
        .isLength({ min: 1, max: 255 })
        .withMessage('Name must be between 1 and 255 characters'),
    body('description')
        .trim()
        .isLength({ max: 2000 })
        .withMessage('Description must be 2000 characters or less')
]

export const updateProjectValidation = [
    body('name')
        .optional()
        .trim()
        .isLength({ min: 1, max: 255 })
        .withMessage('Name must be between 1 and 255 characters'),
    body('description')
        .optional()
        .trim()
        .isLength({ max: 2000 })
        .withMessage('Description must be 2000 characters or less')
]

export const projectIdValidation = [
    param('id')
        .isUUID()
        .withMessage('Project ID must be a valid UUID')
]

export const userIdValidation = [
    param('userId')
        .isUUID()
        .withMessage('User ID must be a valid UUID')
]

export const addMemberValidation = [
    body('userId')
        .isUUID()
        .withMessage('User ID must be a valid UUID')
]