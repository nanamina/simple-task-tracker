/**
 * Authentication controllers for login and registration
 */

import { Request, Response } from 'express'
import { body, validationResult } from 'express-validator'
import { comparePassword, generateToken } from '../services/auth'
import { UserRepository } from '../repositories/user-repository'
import { getPool } from '../config/database'

const userRepository = new UserRepository(getPool())

/**
 * Validation rules for user registration
 */
export const registerValidation = [
    body('email')
        .isEmail()
        .normalizeEmail()
        .withMessage('Valid email is required'),
    body('name')
        .trim()
        .isLength({ min: 2, max: 100 })
        .withMessage('Name must be between 2 and 100 characters'),
    body('password')
        .isLength({ min: 6 })
        .withMessage('Password must be at least 6 characters long'),
    body('role')
        .optional()
        .isIn(['admin', 'manager', 'member'])
        .withMessage('Role must be admin, manager, or member'),
    body('preferredLanguage')
        .optional()
        .isIn(['ja', 'en'])
        .withMessage('Preferred language must be ja or en')
]

/**
 * Validation rules for user login
 */
export const loginValidation = [
    body('email')
        .isEmail()
        .normalizeEmail()
        .withMessage('Valid email is required'),
    body('password')
        .notEmpty()
        .withMessage('Password is required')
]

/**
 * Register a new user
 */
export async function register(req: Request, res: Response): Promise<void> {
    try {
        // Check validation results
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid input data',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        const { email, name, password, role = 'member', preferredLanguage = 'ja' } = req.body

        // Check if user already exists
        const existingUser = await userRepository.existsByEmail(email)
        if (existingUser) {
            res.status(409).json({
                error: {
                    code: 'CONFLICT',
                    message: 'User with this email already exists',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Create user (password hashing is handled in repository)
        const userData = {
            email,
            name,
            password,
            role,
            preferredLanguage
        }

        const user = await userRepository.createUser(userData)

        // Generate JWT token
        const token = generateToken(user)

        // Return user data (without password) and token
        const { ...userWithoutPassword } = user
        res.status(201).json({
            message: 'User registered successfully',
            user: userWithoutPassword,
            token,
            timestamp: new Date().toISOString()
        })

    } catch (error) {
        console.error('Registration error:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to register user',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Login user with email and password
 */
export async function login(req: Request, res: Response): Promise<void> {
    try {
        // Check validation results
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid input data',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        const { email, password } = req.body

        // Find user by email (with password hash)
        const user = await userRepository.findByEmailWithPassword(email)
        if (!user) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Invalid email or password',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Verify password
        const isValidPassword = await comparePassword(password, user.passwordHash)
        if (!isValidPassword) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Invalid email or password',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Generate JWT token
        const token = generateToken(user)

        // Return user data (without password) and token
        const { ...userWithoutPassword } = user
        res.json({
            message: 'Login successful',
            user: userWithoutPassword,
            token,
            timestamp: new Date().toISOString()
        })

    } catch (error) {
        console.error('Login error:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to login',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Get current user profile (requires authentication)
 */
export async function getProfile(req: Request, res: Response): Promise<void> {
    try {
        if (!req.user) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Get full user data from database
        const user = await userRepository.findById(req.user.id)
        if (!user) {
            res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'User not found',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Return user data (already without password from findById)
        res.json({
            user,
            timestamp: new Date().toISOString()
        })

    } catch (error) {
        console.error('Get profile error:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to get user profile',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Refresh JWT token (requires valid token)
 */
export async function refreshToken(req: Request, res: Response): Promise<void> {
    try {
        if (!req.user) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Get fresh user data from database
        const user = await userRepository.findById(req.user.id)
        if (!user) {
            res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'User not found',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Generate new token
        const token = generateToken(user)

        res.json({
            message: 'Token refreshed successfully',
            token,
            timestamp: new Date().toISOString()
        })

    } catch (error) {
        console.error('Token refresh error:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to refresh token',
                timestamp: new Date().toISOString()
            }
        })
    }
}