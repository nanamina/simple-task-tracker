/**
 * User management controllers for profile and team member operations
 */

import { Request, Response } from 'express'
import { body, validationResult } from 'express-validator'
import { UserRepository } from '../repositories/user-repository'
import { UpdateUserDTO } from '../../shared/types/validation'
import { getPool } from '../config/database'

const userRepository = new UserRepository(getPool())

/**
 * Validation rules for user profile updates
 */
export const updateProfileValidation = [
    body('name')
        .optional()
        .trim()
        .isLength({ min: 2, max: 100 })
        .withMessage('Name must be between 2 and 100 characters'),
    body('email')
        .optional()
        .isEmail()
        .normalizeEmail()
        .withMessage('Valid email is required'),
    body('preferredLanguage')
        .optional()
        .isIn(['ja', 'en'])
        .withMessage('Preferred language must be ja or en')
]

/**
 * Get current user profile
 * GET /api/users/profile
 */
export async function getUserProfile(req: Request, res: Response): Promise<void> {
    try {
        if (!req.user) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Get full user data from database
        const user = await userRepository.findById(req.user.id)
        if (!user) {
            res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'User profile not found',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        res.json({
            user,
            timestamp: new Date().toISOString()
        })

    } catch (error) {
        console.error('Get user profile error:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to get user profile',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Update current user profile
 * PUT /api/users/profile
 */
export async function updateUserProfile(req: Request, res: Response): Promise<void> {
    try {
        // Check validation results
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid input data',
                    details: errors.array(),
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        if (!req.user) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        const { name, email, preferredLanguage } = req.body
        const updates: UpdateUserDTO = {}

        // Only include fields that are provided
        if (name !== undefined) updates.name = name
        if (email !== undefined) updates.email = email
        if (preferredLanguage !== undefined) updates.preferredLanguage = preferredLanguage

        // Check if there are any updates to make
        if (Object.keys(updates).length === 0) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'No valid fields provided for update',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Update user profile
        const updatedUser = await userRepository.updateUser(req.user.id, updates)
        if (!updatedUser) {
            res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'User not found',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        res.json({
            message: 'Profile updated successfully',
            user: updatedUser,
            timestamp: new Date().toISOString()
        })

    } catch (error) {
        console.error('Update user profile error:', error)

        // Handle specific database errors
        if (error instanceof Error && error.message.includes('Email already exists')) {
            res.status(409).json({
                error: {
                    code: 'CONFLICT',
                    message: 'Email address is already in use',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to update user profile',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Get list of team members (admin/manager only)
 * GET /api/users/team
 */
export async function getTeamMembers(req: Request, res: Response): Promise<void> {
    try {
        if (!req.user) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Parse pagination parameters
        const limit = Math.min(parseInt(req.query.limit as string) || 50, 100) // Max 100 users per request
        const offset = Math.max(parseInt(req.query.offset as string) || 0, 0)

        // Get team members list
        const users = await userRepository.listUsers(limit, offset)

        res.json({
            users,
            pagination: {
                limit,
                offset,
                total: users.length // Note: In production, you'd want to get actual total count
            },
            timestamp: new Date().toISOString()
        })

    } catch (error) {
        console.error('Get team members error:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to get team members',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Update user language preference
 * PATCH /api/users/profile/language
 */
export async function updateLanguagePreference(req: Request, res: Response): Promise<void> {
    try {
        if (!req.user) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        const { preferredLanguage } = req.body

        // Validate language preference
        if (!preferredLanguage || !['ja', 'en'].includes(preferredLanguage)) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid language preference. Must be "ja" or "en"',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Update language preference
        const updatedUser = await userRepository.updateUser(req.user.id, { preferredLanguage })
        if (!updatedUser) {
            res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'User not found',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        res.json({
            message: 'Language preference updated successfully',
            user: updatedUser,
            timestamp: new Date().toISOString()
        })

    } catch (error) {
        console.error('Update language preference error:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to update language preference',
                timestamp: new Date().toISOString()
            }
        })
    }
}

/**
 * Get user by ID (admin/manager only)
 * GET /api/users/:id
 */
export async function getUserById(req: Request, res: Response): Promise<void> {
    try {
        if (!req.user) {
            res.status(401).json({
                error: {
                    code: 'UNAUTHORIZED',
                    message: 'Authentication required',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        const { id } = req.params

        // Validate UUID format
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
        if (!uuidRegex.test(id)) {
            res.status(400).json({
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Invalid user ID format',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        // Get user by ID
        const user = await userRepository.findById(id)
        if (!user) {
            res.status(404).json({
                error: {
                    code: 'NOT_FOUND',
                    message: 'User not found',
                    timestamp: new Date().toISOString()
                }
            })
            return
        }

        res.json({
            user,
            timestamp: new Date().toISOString()
        })

    } catch (error) {
        console.error('Get user by ID error:', error)
        res.status(500).json({
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to get user',
                timestamp: new Date().toISOString()
            }
        })
    }
}