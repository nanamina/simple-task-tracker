import express, { Request, Response } from 'express'
import cors from 'cors'
import helmet from 'helmet'
import path from 'path'
import { testConnection } from './config/database'
import {
    getEnvironment,
    validateEnvironment,
    getServerConfig,
    isFeatureEnabled
} from './config/environment'
import {
    productionMiddleware,
    securityHeaders,
    staticAssetHeaders
} from './config/production'
import authRoutes from './routes/auth'
import protectedExampleRoutes from './routes/protected-examples'
import taskRoutes from './routes/task'
import projectRoutes from './routes/project'
import userRoutes from './routes/user'
import { createAnalyticsRoutes } from './routes/analytics'
import { getPool } from './config/database'
import { errorHandler, notFoundHandler } from './middleware/errorHandler'
import { requestLogger, logger } from './utils/logger'

// Validate environment configuration
try {
    validateEnvironment()
} catch (error) {
    console.error('Environment validation failed:', error)
    process.exit(1)
}

const app = express()
const environment = getEnvironment()
const serverConfig = getServerConfig()

// Security middleware
app.use(helmet({
    contentSecurityPolicy: environment === 'production' ? undefined : false,
    crossOriginEmbedderPolicy: environment === 'production'
}))

// Production-specific middleware
if (isFeatureEnabled('securityHeaders')) {
    app.use(securityHeaders)
}

if (isFeatureEnabled('compression') || isFeatureEnabled('rateLimiting')) {
    app.use(...productionMiddleware)
}

// CORS configuration
app.use(cors(serverConfig.cors))

// Body parsing middleware
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true, limit: '10mb' }))

// Static asset headers
app.use(staticAssetHeaders)

// Request logging middleware
app.use(requestLogger)

// Routes
app.use('/api/auth', authRoutes)
app.use('/api/protected', protectedExampleRoutes)
app.use('/api/tasks', taskRoutes)
app.use('/api/projects', projectRoutes)
app.use('/api/users', userRoutes)
app.use('/api/analytics', createAnalyticsRoutes(getPool()))

// Serve static files in production
if (environment === 'production') {
    const clientPath = path.join(__dirname, '../client')
    app.use(express.static(clientPath, {
        maxAge: '1y',
        etag: true,
        lastModified: true
    }))

    // Serve React app for all non-API routes
    app.get('*', (req: Request, res: Response) => {
        if (!req.path.startsWith('/api/')) {
            res.sendFile(path.join(clientPath, 'index.html'))
        }
    })
}

// Enhanced health check endpoint
app.get('/api/health', async (_req: Request, res: Response) => {
    try {
        // Test database connection
        await testConnection()

        const healthData: any = {
            status: 'ok',
            message: 'Task Management System API is running',
            environment,
            database: 'connected',
            timestamp: new Date().toISOString(),
            uptime: process.uptime(),
            version: process.env.npm_package_version || '1.0.0'
        }

        // Add memory usage in production
        if (environment === 'production') {
            const memUsage = process.memoryUsage()
            healthData.memory = {
                rss: Math.round(memUsage.rss / 1024 / 1024) + ' MB',
                heapTotal: Math.round(memUsage.heapTotal / 1024 / 1024) + ' MB',
                heapUsed: Math.round(memUsage.heapUsed / 1024 / 1024) + ' MB'
            }
        }

        res.json(healthData)
    } catch (error) {
        res.status(503).json({
            status: 'error',
            message: 'Database connection failed',
            environment,
            database: 'disconnected',
            timestamp: new Date().toISOString(),
            error: isFeatureEnabled('detailedErrors') && error instanceof Error ? error.message : undefined
        })
    }
})

// Database health check endpoint
app.get('/api/health/db', async (_req: Request, res: Response) => {
    try {
        await testConnection()
        res.json({
            status: 'ok',
            message: 'Database connection successful',
            timestamp: new Date().toISOString()
        })
    } catch (error) {
        res.status(503).json({
            status: 'error',
            message: 'Database connection failed',
            error: isFeatureEnabled('detailedErrors') && error instanceof Error ? error.message : 'Database unavailable',
            timestamp: new Date().toISOString()
        })
    }
})

// 404 handler for unmatched routes
app.use(notFoundHandler)

// Global error handling middleware (must be last)
app.use(errorHandler)

// Initialize database connection and start server
async function startServer() {
    try {
        // Test database connection on startup
        logger.info('Testing database connection...', 'STARTUP')
        await testConnection()
        logger.info('Database connection successful', 'STARTUP')

        // Start server
        const server = app.listen(serverConfig.port, serverConfig.host, () => {
            logger.info(`Server started successfully`, 'STARTUP', {
                port: serverConfig.port,
                host: serverConfig.host,
                environment,
                database: 'connected',
                features: {
                    rateLimiting: isFeatureEnabled('rateLimiting'),
                    compression: isFeatureEnabled('compression'),
                    securityHeaders: isFeatureEnabled('securityHeaders')
                }
            })
        })

        // Graceful shutdown handling
        const gracefulShutdown = (signal: string) => {
            logger.info(`Received ${signal}, shutting down gracefully...`, 'SHUTDOWN')

            server.close(() => {
                logger.info('HTTP server closed', 'SHUTDOWN')

                // Close database connections
                const pool = getPool()
                pool.end(() => {
                    logger.info('Database connections closed', 'SHUTDOWN')
                    process.exit(0)
                })
            })

            // Force close after 10 seconds
            setTimeout(() => {
                logger.error('Could not close connections in time, forcefully shutting down', new Error('Shutdown timeout'), 'SHUTDOWN')
                process.exit(1)
            }, 10000)
        }

        // Listen for termination signals
        process.on('SIGTERM', () => gracefulShutdown('SIGTERM'))
        process.on('SIGINT', () => gracefulShutdown('SIGINT'))

    } catch (error) {
        logger.error('Failed to start server', error as Error, 'STARTUP')
        logger.error('Please check your database configuration and ensure PostgreSQL is running')
        process.exit(1)
    }
}

// Start the server
startServer()