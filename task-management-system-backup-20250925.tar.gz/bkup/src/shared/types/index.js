"use strict";
// Shared type definitions for both client and server
Object.defineProperty(exports, "__esModule", { value: true });
