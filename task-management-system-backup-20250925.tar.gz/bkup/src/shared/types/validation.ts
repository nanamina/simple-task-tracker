/**
 * Validation schemas and utilities for data models
 */

import { User, UserRole, Language, TaskStatus, TaskPriority } from './index'

// User validation schemas
export interface CreateUserDTO {
    email: string
    name: string
    password: string
    role?: UserRole
    preferredLanguage?: Language
}

export interface UpdateUserDTO {
    email?: string
    name?: string
    role?: UserRole
    preferredLanguage?: Language
}

export interface LoginDTO {
    email: string
    password: string
}

export interface UserWithPassword extends User {
    passwordHash: string
}

// Task validation schemas
export interface CreateTaskDTO {
    title: string
    description: string
    priority?: TaskPriority
    dueDate?: Date
    assigneeId?: string
    projectId?: string
}

export interface UpdateTaskDTO {
    title?: string
    description?: string
    priority?: TaskPriority
    dueDate?: Date
    assigneeId?: string
    projectId?: string
}

export interface TaskFilterOptions {
    status?: TaskStatus
    priority?: TaskPriority
    assigneeId?: string
    projectId?: string
    dueBefore?: Date
    dueAfter?: Date
    createdBy?: string
    search?: string
    isOverdue?: boolean
    isUnassigned?: boolean
}

export interface TaskSortOptions {
    field: 'createdAt' | 'updatedAt' | 'dueDate' | 'priority' | 'title' | 'relevance'
    direction: 'asc' | 'desc'
}

// Project filtering and sorting
export interface ProjectFilterOptions {
    search?: string
    memberOnly?: boolean
    createdBy?: string
}

export interface ProjectSortOptions {
    field: 'name' | 'createdAt' | 'updatedAt' | 'relevance'
    direction: 'asc' | 'desc'
}

/**
 * Validates email format
 */
export function validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
}

/**
 * Validates password strength
 * Requirements: At least 8 characters, contains letter and number
 */
export function validatePassword(password: string): { isValid: boolean; errors: string[] } {
    const errors: string[] = []

    if (password.length < 8) {
        errors.push('Password must be at least 8 characters long')
    }

    if (!/[a-zA-Z]/.test(password)) {
        errors.push('Password must contain at least one letter')
    }

    if (!/\d/.test(password)) {
        errors.push('Password must contain at least one number')
    }

    return {
        isValid: errors.length === 0,
        errors
    }
}

/**
 * Validates user name
 */
export function validateName(name: string): boolean {
    return name.trim().length >= 2 && name.trim().length <= 100
}

/**
 * Validates user role
 */
export function validateRole(role: string): role is UserRole {
    return ['admin', 'manager', 'member'].includes(role)
}

/**
 * Validates language preference
 */
export function validateLanguage(language: string): language is Language {
    return ['ja', 'en'].includes(language)
}

/**
 * Validates complete user creation data
 */
export function validateCreateUser(data: CreateUserDTO): { isValid: boolean; errors: string[] } {
    const errors: string[] = []

    if (!validateEmail(data.email)) {
        errors.push('Invalid email format')
    }

    if (!validateName(data.name)) {
        errors.push('Name must be between 2 and 100 characters')
    }

    const passwordValidation = validatePassword(data.password)
    if (!passwordValidation.isValid) {
        errors.push(...passwordValidation.errors)
    }

    if (data.role && !validateRole(data.role)) {
        errors.push('Invalid user role')
    }

    if (data.preferredLanguage && !validateLanguage(data.preferredLanguage)) {
        errors.push('Invalid language preference')
    }

    return {
        isValid: errors.length === 0,
        errors
    }
}

/**
 * Validates task title
 */
export function validateTaskTitle(title: string): boolean {
    return title.trim().length >= 1 && title.trim().length <= 255
}

/**
 * Validates task description
 */
export function validateTaskDescription(description: string): boolean {
    return description.trim().length <= 2000
}

/**
 * Validates task priority
 */
export function validateTaskPriority(priority: string): priority is TaskPriority {
    return ['low', 'medium', 'high', 'critical'].includes(priority)
}

/**
 * Validates task status
 */
export function validateTaskStatus(status: string): status is TaskStatus {
    return ['todo', 'in-progress', 'completed'].includes(status)
}

/**
 * Validates task status transition
 */
export function validateTaskStatusTransition(fromStatus: TaskStatus, toStatus: TaskStatus): { isValid: boolean; error?: string } {
    // Define allowed transitions
    const allowedTransitions: Record<TaskStatus, TaskStatus[]> = {
        'todo': ['in-progress', 'completed'],
        'in-progress': ['todo', 'completed'],
        'completed': ['todo', 'in-progress']
    }

    if (fromStatus === toStatus) {
        return { isValid: true } // Same status is always valid
    }

    if (allowedTransitions[fromStatus].includes(toStatus)) {
        return { isValid: true }
    }

    return {
        isValid: false,
        error: `Cannot transition from ${fromStatus} to ${toStatus}`
    }
}

/**
 * Validates due date (must be in the future or today)
 */
export function validateDueDate(dueDate: Date): boolean {
    const today = new Date()
    today.setHours(0, 0, 0, 0) // Start of today
    return dueDate >= today
}

/**
 * Validates complete task creation data
 */
export function validateCreateTask(data: CreateTaskDTO): { isValid: boolean; errors: string[] } {
    const errors: string[] = []

    if (!validateTaskTitle(data.title)) {
        errors.push('Title must be between 1 and 255 characters')
    }

    if (!validateTaskDescription(data.description)) {
        errors.push('Description must be 2000 characters or less')
    }

    if (data.priority && !validateTaskPriority(data.priority)) {
        errors.push('Invalid task priority')
    }

    if (data.dueDate && !validateDueDate(data.dueDate)) {
        errors.push('Due date must be today or in the future')
    }

    return {
        isValid: errors.length === 0,
        errors
    }
}

/**
 * Validates task update data
 */
export function validateUpdateTask(data: UpdateTaskDTO): { isValid: boolean; errors: string[] } {
    const errors: string[] = []

    if (data.title !== undefined && !validateTaskTitle(data.title)) {
        errors.push('Title must be between 1 and 255 characters')
    }

    if (data.description !== undefined && !validateTaskDescription(data.description)) {
        errors.push('Description must be 2000 characters or less')
    }

    if (data.priority !== undefined && !validateTaskPriority(data.priority)) {
        errors.push('Invalid task priority')
    }

    if (data.dueDate !== undefined && !validateDueDate(data.dueDate)) {
        errors.push('Due date must be today or in the future')
    }

    return {
        isValid: errors.length === 0,
        errors
    }
}
// Project validation schemas
export interface CreateProjectDTO {
    name: string
    description: string
}

export interface UpdateProjectDTO {
    name?: string
    description?: string
}

export interface ProjectMemberDTO {
    userId: string
    projectId: string
}

/**
 * Validates project name
 */
export function validateProjectName(name: string): boolean {
    return name.trim().length >= 1 && name.trim().length <= 255
}

/**
 * Validates project description
 */
export function validateProjectDescription(description: string): boolean {
    return description.trim().length <= 2000
}

/**
 * Validates complete project creation data
 */
export function validateCreateProject(data: CreateProjectDTO): { isValid: boolean; errors: string[] } {
    const errors: string[] = []

    if (!validateProjectName(data.name)) {
        errors.push('Name must be between 1 and 255 characters')
    }

    if (!validateProjectDescription(data.description)) {
        errors.push('Description must be 2000 characters or less')
    }

    return {
        isValid: errors.length === 0,
        errors
    }
}

/**
 * Validates project update data
 */
export function validateUpdateProject(data: UpdateProjectDTO): { isValid: boolean; errors: string[] } {
    const errors: string[] = []

    if (data.name !== undefined && !validateProjectName(data.name)) {
        errors.push('Name must be between 1 and 255 characters')
    }

    if (data.description !== undefined && !validateProjectDescription(data.description)) {
        errors.push('Description must be 2000 characters or less')
    }

    return {
        isValid: errors.length === 0,
        errors
    }
}