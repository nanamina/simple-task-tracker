// Shared type definitions for both client and server

export interface User {
    id: string
    email: string
    name: string
    role: 'admin' | 'manager' | 'member'
    preferredLanguage: 'ja' | 'en'
    createdAt: Date
    updatedAt: Date
}

export interface Project {
    id: string
    name: string
    description: string
    createdBy: string
    createdAt: Date
    updatedAt: Date
    members: string[]
}

export interface Task {
    id: string
    title: string
    description: string
    status: 'todo' | 'in-progress' | 'completed'
    priority: 'low' | 'medium' | 'high' | 'critical'
    dueDate?: Date
    assigneeId?: string
    projectId?: string
    createdBy: string
    createdAt: Date
    updatedAt: Date
    completedAt?: Date
}

export type TaskStatus = Task['status']
export type TaskPriority = Task['priority']
export type UserRole = User['role']
export type Language = User['preferredLanguage']

// Re-export validation types
export * from './validation'