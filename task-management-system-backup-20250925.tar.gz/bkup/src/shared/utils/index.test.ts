import { formatDate, isValidEmail, generateId } from './index'

describe('Utility Functions', () => {
    describe('formatDate', () => {
        it('should format date in Japanese locale by default', () => {
            const date = new Date('2024-01-15')
            const formatted = formatDate(date)
            expect(formatted).toBe('2024/01/15')
        })

        it('should format date in specified locale', () => {
            const date = new Date('2024-01-15')
            const formatted = formatDate(date, 'en-US')
            expect(formatted).toBe('01/15/2024')
        })
    })

    describe('isValidEmail', () => {
        it('should validate correct email addresses', () => {
            expect(isValidEmail('test@example.com')).toBe(true)
            expect(isValidEmail('user.name@domain.co.jp')).toBe(true)
        })

        it('should reject invalid email addresses', () => {
            expect(isValidEmail('invalid-email')).toBe(false)
            expect(isValidEmail('test@')).toBe(false)
            expect(isValidEmail('@domain.com')).toBe(false)
        })
    })

    describe('generateId', () => {
        it('should generate a string ID', () => {
            const id = generateId()
            expect(typeof id).toBe('string')
            expect(id.length).toBeGreaterThan(0)
        })

        it('should generate unique IDs', () => {
            const id1 = generateId()
            const id2 = generateId()
            expect(id1).not.toBe(id2)
        })
    })
})