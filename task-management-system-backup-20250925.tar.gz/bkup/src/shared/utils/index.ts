// Shared utility functions

export const formatDate = (date: Date, locale: string = 'ja-JP'): string => {
    return new Intl.DateTimeFormat(locale, {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    }).format(date)
}

export const formatDateTime = (date: Date, locale: string = 'ja-JP'): string => {
    return new Intl.DateTimeFormat(locale, {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    }).format(date)
}

export const isValidEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
}

export const generateId = (): string => {
    return Math.random().toString(36).substr(2, 9)
}