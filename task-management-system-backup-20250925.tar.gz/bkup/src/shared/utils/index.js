"use strict";
// Shared utility functions
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateId = exports.isValidEmail = exports.formatDateTime = exports.formatDate = void 0;
const formatDate = (date, locale = 'ja-JP') => {
    return new Intl.DateTimeFormat(locale, {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    }).format(date);
};
exports.formatDate = formatDate;
const formatDateTime = (date, locale = 'ja-JP') => {
    return new Intl.DateTimeFormat(locale, {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    }).format(date);
};
exports.formatDateTime = formatDateTime;
const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
};
exports.isValidEmail = isValidEmail;
const generateId = () => {
    return Math.random().toString(36).substr(2, 9);
};
exports.generateId = generateId;
