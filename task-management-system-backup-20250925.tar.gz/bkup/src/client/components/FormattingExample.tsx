import React from 'react';
import { useFormatting } from '../hooks/useFormatting';
import { useTranslation } from '../hooks/useTranslation';

/**
 * Example component demonstrating locale-specific formatting
 * This component shows how different data types are formatted
 * according to the current language setting
 */
export const FormattingExample: React.FC = () => {
    const { t } = useTranslation();
    const formatting = useFormatting();

    // Sample data for demonstration
    const sampleData = {
        date: new Date('2024-03-15T14:30:00Z'),
        pastDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
        futureDate: new Date(Date.now() + 3 * 60 * 60 * 1000), // 3 hours from now
        number: 1234567.89,
        currency: 50000,
        percentage: 0.7542,
        fileSize: 1024 * 1024 * 2.5, // 2.5 MB
    };

    return (
        <div className="p-6 bg-white rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-6 text-gray-800">
                {t('common.formatting')} - {t('profile.languages.' + formatting.language)}
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Date and Time Formatting */}
                <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-700 border-b pb-2">
                        {t('common.dateTime')}
                    </h3>

                    <div className="space-y-2">
                        <div className="flex justify-between">
                            <span className="text-gray-600">{t('common.date')}:</span>
                            <span className="font-mono">{formatting.date(sampleData.date)}</span>
                        </div>

                        <div className="flex justify-between">
                            <span className="text-gray-600">{t('common.dateTime')}:</span>
                            <span className="font-mono">{formatting.dateTime(sampleData.date)}</span>
                        </div>

                        <div className="flex justify-between">
                            <span className="text-gray-600">{t('common.time')}:</span>
                            <span className="font-mono">{formatting.time(sampleData.date)}</span>
                        </div>

                        <div className="flex justify-between">
                            <span className="text-gray-600">{t('common.pastDate')}:</span>
                            <span className="font-mono">{formatting.relativeTime(sampleData.pastDate)}</span>
                        </div>

                        <div className="flex justify-between">
                            <span className="text-gray-600">{t('common.futureDate')}:</span>
                            <span className="font-mono">{formatting.relativeTime(sampleData.futureDate)}</span>
                        </div>
                    </div>
                </div>

                {/* Number and Currency Formatting */}
                <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-700 border-b pb-2">
                        {t('common.numbers')}
                    </h3>

                    <div className="space-y-2">
                        <div className="flex justify-between">
                            <span className="text-gray-600">{t('common.number')}:</span>
                            <span className="font-mono">{formatting.number(sampleData.number)}</span>
                        </div>

                        <div className="flex justify-between">
                            <span className="text-gray-600">{t('common.currency')}:</span>
                            <span className="font-mono">{formatting.currency(sampleData.currency)}</span>
                        </div>

                        <div className="flex justify-between">
                            <span className="text-gray-600">{t('common.percentage')}:</span>
                            <span className="font-mono">{formatting.percentage(sampleData.percentage)}</span>
                        </div>

                        <div className="flex justify-between">
                            <span className="text-gray-600">{t('common.fileSize')}:</span>
                            <span className="font-mono">{formatting.fileSize(sampleData.fileSize)}</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Locale Information */}
            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-700 mb-3">
                    {t('common.localeInfo')}
                </h3>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                        <span className="text-gray-600">{t('common.locale')}:</span>
                        <div className="font-mono">{formatting.locale}</div>
                    </div>

                    <div>
                        <span className="text-gray-600">{t('common.timeFormat')}:</span>
                        <div className="font-mono">{formatting.uses24Hour ? '24h' : '12h'}</div>
                    </div>

                    <div>
                        <span className="text-gray-600">{t('common.dateSeparator')}:</span>
                        <div className="font-mono">"{formatting.dateSeparator}"</div>
                    </div>

                    <div>
                        <span className="text-gray-600">{t('common.language')}:</span>
                        <div className="font-mono">{formatting.language}</div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default FormattingExample;