import React from 'react';

interface PieChartProps {
    data: Array<{
        label: string;
        value: number;
        color?: string;
    }>;
    title?: string;
    size?: number;
    showLegend?: boolean;
}

/**
 * Simple pie chart component for displaying distribution data
 */
export const PieChart: React.FC<PieChartProps> = ({
    data,
    title,
    size = 200,
    showLegend = true
}) => {
    const total = data.reduce((sum, item) => sum + item.value, 0);

    if (total === 0) {
        return (
            <div className="bg-white p-6 rounded-lg shadow-md">
                {title && (
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>
                )}
                <div className="flex items-center justify-center h-48 text-gray-500">
                    No data available
                </div>
            </div>
        );
    }

    const colors = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];
    const radius = size / 2 - 10;
    const center = size / 2;

    let currentAngle = 0;
    const slices = data.map((item, index) => {
        const percentage = (item.value / total) * 100;
        const angle = (item.value / total) * 360;
        const startAngle = currentAngle;
        const endAngle = currentAngle + angle;

        currentAngle += angle;

        const color = item.color || colors[index % colors.length];

        // Calculate path for slice
        const startAngleRad = (startAngle * Math.PI) / 180;
        const endAngleRad = (endAngle * Math.PI) / 180;

        const x1 = center + radius * Math.cos(startAngleRad);
        const y1 = center + radius * Math.sin(startAngleRad);
        const x2 = center + radius * Math.cos(endAngleRad);
        const y2 = center + radius * Math.sin(endAngleRad);

        const largeArcFlag = angle > 180 ? 1 : 0;

        const pathData = [
            `M ${center} ${center}`,
            `L ${x1} ${y1}`,
            `A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2}`,
            'Z'
        ].join(' ');

        return {
            ...item,
            color,
            percentage: Math.round(percentage * 10) / 10,
            pathData
        };
    });

    return (
        <div className="bg-white p-6 rounded-lg shadow-md">
            {title && (
                <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>
            )}

            <div className="flex items-center justify-center space-x-8">
                {/* Pie Chart */}
                <div className="relative">
                    <svg width={size} height={size} className="transform -rotate-90">
                        {slices.map((slice, index) => (
                            <path
                                key={index}
                                d={slice.pathData}
                                fill={slice.color}
                                className="hover:opacity-80 transition-opacity duration-200 cursor-pointer"
                            >
                                <title>{`${slice.label}: ${slice.value} (${slice.percentage}%)`}</title>
                            </path>
                        ))}
                    </svg>

                    {/* Center text */}
                    <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center">
                            <div className="text-2xl font-bold text-gray-900">{total}</div>
                            <div className="text-sm text-gray-500">Total</div>
                        </div>
                    </div>
                </div>

                {/* Legend */}
                {showLegend && (
                    <div className="space-y-2">
                        {slices.map((slice, index) => (
                            <div key={index} className="flex items-center space-x-2">
                                <div
                                    className="w-4 h-4 rounded-sm"
                                    style={{ backgroundColor: slice.color }}
                                />
                                <span className="text-sm text-gray-700">
                                    {slice.label.replace('-', ' ')} ({slice.percentage}%)
                                </span>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};