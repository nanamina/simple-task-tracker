import React from 'react';

interface LineChartProps {
    data: Array<{
        date: string;
        value: number;
    }>;
    title?: string;
    height?: number;
    color?: string;
}

/**
 * Simple line chart component for displaying trend data
 */
export const LineChart: React.FC<LineChartProps> = ({
    data,
    title,
    height = 300,
    color = '#3B82F6'
}) => {
    if (data.length === 0) {
        return (
            <div className="bg-white p-6 rounded-lg shadow-md">
                {title && (
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>
                )}
                <div className="flex items-center justify-center h-48 text-gray-500">
                    No data available
                </div>
            </div>
        );
    }

    const maxValue = Math.max(...data.map(item => item.value));
    const minValue = Math.min(...data.map(item => item.value));
    const range = maxValue - minValue || 1;

    const chartWidth = 100; // percentage
    const chartHeight = height - 100; // Account for padding and labels

    // Generate SVG path for the line
    const pathData = data.map((item, index) => {
        const x = (index / (data.length - 1)) * chartWidth;
        const y = chartHeight - ((item.value - minValue) / range) * chartHeight;
        return `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
    }).join(' ');

    // Generate points for hover
    const points = data.map((item, index) => ({
        x: (index / (data.length - 1)) * chartWidth,
        y: chartHeight - ((item.value - minValue) / range) * chartHeight,
        value: item.value,
        date: item.date
    }));

    return (
        <div className="bg-white p-6 rounded-lg shadow-md">
            {title && (
                <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>
            )}

            <div className="relative" style={{ height }}>
                <svg
                    width="100%"
                    height={chartHeight}
                    viewBox={`0 0 ${chartWidth} ${chartHeight}`}
                    className="overflow-visible"
                >
                    {/* Grid lines */}
                    <defs>
                        <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                            <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#f3f4f6" strokeWidth="0.5" />
                        </pattern>
                    </defs>
                    <rect width="100%" height="100%" fill="url(#grid)" />

                    {/* Line */}
                    <path
                        d={pathData}
                        fill="none"
                        stroke={color}
                        strokeWidth="2"
                        className="drop-shadow-sm"
                    />

                    {/* Points */}
                    {points.map((point, index) => (
                        <g key={index}>
                            <circle
                                cx={point.x}
                                cy={point.y}
                                r="4"
                                fill={color}
                                className="hover:r-6 transition-all duration-200 cursor-pointer"
                            />
                            <title>{`${point.date}: ${point.value}`}</title>
                        </g>
                    ))}
                </svg>

                {/* X-axis labels */}
                <div className="flex justify-between mt-2 text-xs text-gray-500">
                    <span>{new Date(data[0].date).toLocaleDateString()}</span>
                    <span>{new Date(data[data.length - 1].date).toLocaleDateString()}</span>
                </div>

                {/* Y-axis labels */}
                <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-gray-500 -ml-8">
                    <span>{maxValue}</span>
                    <span>{Math.round((maxValue + minValue) / 2)}</span>
                    <span>{minValue}</span>
                </div>
            </div>
        </div>
    );
};