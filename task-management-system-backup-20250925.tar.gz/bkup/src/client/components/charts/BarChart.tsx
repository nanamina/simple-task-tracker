import React from 'react';

interface BarChartProps {
    data: Array<{
        label: string;
        value: number;
        color?: string;
    }>;
    title?: string;
    height?: number;
    showValues?: boolean;
}

/**
 * Simple bar chart component for displaying analytics data
 */
export const BarChart: React.FC<BarChartProps> = ({
    data,
    title,
    height = 300,
    showValues = true
}) => {
    const maxValue = Math.max(...data.map(item => item.value));
    const colors = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

    return (
        <div className="bg-white p-6 rounded-lg shadow-md">
            {title && (
                <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>
            )}

            <div className="flex items-end justify-between space-x-2" style={{ height }}>
                {data.map((item, index) => {
                    const barHeight = maxValue > 0 ? (item.value / maxValue) * (height - 60) : 0;
                    const color = item.color || colors[index % colors.length];

                    return (
                        <div key={item.label} className="flex flex-col items-center flex-1">
                            <div className="relative flex flex-col items-center justify-end" style={{ height: height - 60 }}>
                                {showValues && item.value > 0 && (
                                    <span className="text-sm font-medium text-gray-700 mb-1">
                                        {item.value}
                                    </span>
                                )}
                                <div
                                    className="w-full rounded-t-md transition-all duration-300 hover:opacity-80"
                                    style={{
                                        height: barHeight,
                                        backgroundColor: color,
                                        minHeight: item.value > 0 ? '4px' : '0px'
                                    }}
                                />
                            </div>
                            <div className="mt-2 text-center">
                                <span className="text-sm text-gray-600 capitalize">
                                    {item.label.replace('-', ' ')}
                                </span>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};