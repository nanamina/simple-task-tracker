import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { RootState, AppDispatch } from '@/client/store'
import { fetchProjects, deleteProject, clearError } from '@/client/store/slices/projectSlice'
import { Project } from '@/shared/types'

/**
 * ProjectList component - displays a list of projects with overview information
 * Provides filtering, sorting, and basic project management actions
 */
const ProjectList: React.FC = () => {
    const dispatch = useDispatch<AppDispatch>()
    const navigate = useNavigate()
    const { t } = useTranslation()

    const { projects, loading, error } = useSelector((state: RootState) => state.projects)
    const { user } = useSelector((state: RootState) => state.auth)

    const [searchTerm, setSearchTerm] = useState('')
    const [sortBy, setSortBy] = useState<'name' | 'createdAt' | 'updatedAt'>('createdAt')
    const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc')
    const [projectToDelete, setProjectToDelete] = useState<Project | null>(null)

    useEffect(() => {
        dispatch(fetchProjects())
        dispatch(clearError())
    }, [dispatch])

    /**
     * Filters projects based on search term
     */
    const filteredProjects = projects.filter(project =>
        project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        project.description.toLowerCase().includes(searchTerm.toLowerCase())
    )

    /**
     * Sorts filtered projects based on current sort settings
     */
    const sortedProjects = [...filteredProjects].sort((a, b) => {
        let aValue: string | Date
        let bValue: string | Date

        switch (sortBy) {
            case 'name':
                aValue = a.name.toLowerCase()
                bValue = b.name.toLowerCase()
                break
            case 'createdAt':
                aValue = new Date(a.createdAt)
                bValue = new Date(b.createdAt)
                break
            case 'updatedAt':
                aValue = new Date(a.updatedAt)
                bValue = new Date(b.updatedAt)
                break
            default:
                return 0
        }

        if (aValue < bValue) return sortOrder === 'asc' ? -1 : 1
        if (aValue > bValue) return sortOrder === 'asc' ? 1 : -1
        return 0
    })

    /**
     * Handles project deletion
     */
    const handleDeleteProject = async (project: Project) => {
        if (window.confirm(t('projects.deleteConfirm', { name: project.name }))) {
            try {
                await dispatch(deleteProject(project.id)).unwrap()
            } catch (error) {
                console.error('Failed to delete project:', error)
            }
        }
    }

    /**
     * Handles sort change
     */
    const handleSortChange = (newSortBy: typeof sortBy) => {
        if (sortBy === newSortBy) {
            setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')
        } else {
            setSortBy(newSortBy)
            setSortOrder('asc')
        }
    }

    /**
     * Checks if user can manage projects (admin or manager)
     */
    const canManageProjects = user?.role === 'admin' || user?.role === 'manager'

    if (loading) {
        return (
            <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-indigo-600"></div>
            </div>
        )
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">
                        {t('projects.title')}
                    </h1>
                    <p className="mt-1 text-sm text-gray-600">
                        {t('projects.subtitle')}
                    </p>
                </div>
                {canManageProjects && (
                    <button
                        onClick={() => navigate('/projects/new')}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md text-sm font-medium"
                    >
                        {t('projects.create')}
                    </button>
                )}
            </div>

            {/* Error Display */}
            {error && (
                <div className="bg-red-50 border border-red-200 rounded-md p-4">
                    <div className="flex">
                        <div className="ml-3">
                            <h3 className="text-sm font-medium text-red-800">
                                {t('common.error')}
                            </h3>
                            <div className="mt-2 text-sm text-red-700">
                                {error}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Search and Filters */}
            <div className="bg-white shadow rounded-lg p-6">
                <div className="flex flex-col sm:flex-row gap-4">
                    {/* Search */}
                    <div className="flex-1">
                        <label htmlFor="search" className="sr-only">
                            {t('common.search')}
                        </label>
                        <input
                            type="text"
                            id="search"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                            placeholder={t('projects.searchPlaceholder')}
                        />
                    </div>

                    {/* Sort Options */}
                    <div className="flex gap-2">
                        <button
                            onClick={() => handleSortChange('name')}
                            className={`px-3 py-2 text-sm font-medium rounded-md ${sortBy === 'name'
                                    ? 'bg-indigo-100 text-indigo-700'
                                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                }`}
                        >
                            {t('projects.sortByName')}
                            {sortBy === 'name' && (
                                <span className="ml-1">
                                    {sortOrder === 'asc' ? '↑' : '↓'}
                                </span>
                            )}
                        </button>
                        <button
                            onClick={() => handleSortChange('createdAt')}
                            className={`px-3 py-2 text-sm font-medium rounded-md ${sortBy === 'createdAt'
                                    ? 'bg-indigo-100 text-indigo-700'
                                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                }`}
                        >
                            {t('projects.sortByCreated')}
                            {sortBy === 'createdAt' && (
                                <span className="ml-1">
                                    {sortOrder === 'asc' ? '↑' : '↓'}
                                </span>
                            )}
                        </button>
                        <button
                            onClick={() => handleSortChange('updatedAt')}
                            className={`px-3 py-2 text-sm font-medium rounded-md ${sortBy === 'updatedAt'
                                    ? 'bg-indigo-100 text-indigo-700'
                                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                }`}
                        >
                            {t('projects.sortByUpdated')}
                            {sortBy === 'updatedAt' && (
                                <span className="ml-1">
                                    {sortOrder === 'asc' ? '↑' : '↓'}
                                </span>
                            )}
                        </button>
                    </div>
                </div>
            </div>

            {/* Projects Grid */}
            {sortedProjects.length === 0 ? (
                <div className="text-center py-12">
                    <div className="mx-auto h-12 w-12 text-gray-400">
                        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                        </svg>
                    </div>
                    <h3 className="mt-2 text-sm font-medium text-gray-900">
                        {searchTerm ? t('projects.noSearchResults') : t('projects.noProjects')}
                    </h3>
                    <p className="mt-1 text-sm text-gray-500">
                        {searchTerm
                            ? t('projects.tryDifferentSearch')
                            : t('projects.getStarted')
                        }
                    </p>
                    {canManageProjects && !searchTerm && (
                        <div className="mt-6">
                            <button
                                onClick={() => navigate('/projects/new')}
                                className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
                            >
                                {t('projects.createFirst')}
                            </button>
                        </div>
                    )}
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {sortedProjects.map(project => (
                        <div key={project.id} className="bg-white shadow rounded-lg overflow-hidden">
                            <div className="p-6">
                                <div className="flex items-center justify-between">
                                    <h3 className="text-lg font-medium text-gray-900 truncate">
                                        <Link
                                            to={`/projects/${project.id}`}
                                            className="hover:text-indigo-600"
                                        >
                                            {project.name}
                                        </Link>
                                    </h3>
                                    {canManageProjects && (
                                        <div className="flex space-x-2">
                                            <button
                                                onClick={() => navigate(`/projects/${project.id}/edit`)}
                                                className="text-indigo-600 hover:text-indigo-900 text-sm"
                                            >
                                                {t('common.edit')}
                                            </button>
                                            <button
                                                onClick={() => handleDeleteProject(project)}
                                                className="text-red-600 hover:text-red-900 text-sm"
                                            >
                                                {t('common.delete')}
                                            </button>
                                        </div>
                                    )}
                                </div>
                                <p className="mt-2 text-sm text-gray-600 line-clamp-3">
                                    {project.description}
                                </p>
                                <div className="mt-4 flex items-center justify-between text-sm text-gray-500">
                                    <span>
                                        {t('projects.members')}: {project.members.length}
                                    </span>
                                    <span>
                                        {t('projects.updated')}: {new Date(project.updatedAt).toLocaleDateString('ja-JP')}
                                    </span>
                                </div>
                            </div>
                            <div className="bg-gray-50 px-6 py-3">
                                <Link
                                    to={`/projects/${project.id}`}
                                    className="text-indigo-600 hover:text-indigo-900 text-sm font-medium"
                                >
                                    {t('projects.viewDetails')} →
                                </Link>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    )
}

export default ProjectList