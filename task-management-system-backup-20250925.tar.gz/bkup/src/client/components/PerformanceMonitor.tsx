import React, { useState, useEffect } from 'react';
import { LineChart } from './charts/LineChart';

interface PerformanceMetrics {
    timestamp: string;
    responseTime: number;
    memoryUsage: number;
    activeUsers: number;
    errorRate: number;
}

interface PerformanceMonitorProps {
    className?: string;
    refreshInterval?: number; // in milliseconds
}

/**
 * Performance monitoring component for tracking system metrics
 */
export const PerformanceMonitor: React.FC<PerformanceMonitorProps> = ({
    className = '',
    refreshInterval = 30000 // 30 seconds
}) => {
    const [metrics, setMetrics] = useState<PerformanceMetrics[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isRealTime, setIsRealTime] = useState(false);

    useEffect(() => {
        loadInitialMetrics();

        let interval: NodeJS.Timeout;
        if (isRealTime) {
            interval = setInterval(loadPerformanceMetrics, refreshInterval);
        }

        return () => {
            if (interval) {
                clearInterval(interval);
            }
        };
    }, [isRealTime, refreshInterval]);

    const loadInitialMetrics = async () => {
        try {
            setLoading(true);
            setError(null);

            // Generate mock performance data for demonstration
            // In a real implementation, this would fetch from a monitoring API
            const mockMetrics = generateMockMetrics(24); // Last 24 hours
            setMetrics(mockMetrics);
        } catch (err) {
            console.error('Error loading performance metrics:', err);
            setError('Failed to load performance metrics');
        } finally {
            setLoading(false);
        }
    };

    const loadPerformanceMetrics = async () => {
        try {
            // In a real implementation, this would fetch current metrics from an API
            const currentMetric = generateCurrentMetric();

            setMetrics(prev => {
                const updated = [...prev, currentMetric];
                // Keep only last 100 data points
                return updated.slice(-100);
            });
        } catch (err) {
            console.error('Error loading current metrics:', err);
        }
    };

    const generateMockMetrics = (hours: number): PerformanceMetrics[] => {
        const metrics: PerformanceMetrics[] = [];
        const now = new Date();

        for (let i = hours; i >= 0; i--) {
            const timestamp = new Date(now.getTime() - i * 60 * 60 * 1000);
            metrics.push({
                timestamp: timestamp.toISOString(),
                responseTime: Math.random() * 200 + 50, // 50-250ms
                memoryUsage: Math.random() * 30 + 40, // 40-70%
                activeUsers: Math.floor(Math.random() * 50 + 10), // 10-60 users
                errorRate: Math.random() * 2 // 0-2%
            });
        }

        return metrics;
    };

    const generateCurrentMetric = (): PerformanceMetrics => {
        return {
            timestamp: new Date().toISOString(),
            responseTime: Math.random() * 200 + 50,
            memoryUsage: Math.random() * 30 + 40,
            activeUsers: Math.floor(Math.random() * 50 + 10),
            errorRate: Math.random() * 2
        };
    };

    const getLatestMetric = (): PerformanceMetrics | null => {
        return metrics.length > 0 ? metrics[metrics.length - 1] : null;
    };

    const getAverageMetrics = () => {
        if (metrics.length === 0) return null;

        const totals = metrics.reduce((acc, metric) => ({
            responseTime: acc.responseTime + metric.responseTime,
            memoryUsage: acc.memoryUsage + metric.memoryUsage,
            activeUsers: acc.activeUsers + metric.activeUsers,
            errorRate: acc.errorRate + metric.errorRate
        }), { responseTime: 0, memoryUsage: 0, activeUsers: 0, errorRate: 0 });

        const count = metrics.length;
        return {
            responseTime: Math.round(totals.responseTime / count),
            memoryUsage: Math.round(totals.memoryUsage / count),
            activeUsers: Math.round(totals.activeUsers / count),
            errorRate: Math.round((totals.errorRate / count) * 100) / 100
        };
    };

    if (loading) {
        return (
            <div className={`space-y-6 ${className}`}>
                <div className="animate-pulse">
                    <div className="h-8 bg-gray-200 rounded w-1/3 mb-6"></div>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                        {[...Array(4)].map((_, i) => (
                            <div key={i} className="h-24 bg-gray-200 rounded-lg"></div>
                        ))}
                    </div>
                    <div className="h-64 bg-gray-200 rounded-lg"></div>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className={`bg-red-50 border border-red-200 rounded-lg p-4 ${className}`}>
                <div className="text-red-800">{error}</div>
                <button
                    onClick={loadInitialMetrics}
                    className="mt-2 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
                >
                    Retry
                </button>
            </div>
        );
    }

    const latestMetric = getLatestMetric();
    const averageMetrics = getAverageMetrics();

    const responseTimeData = metrics.map(metric => ({
        date: metric.timestamp,
        value: metric.responseTime
    }));

    const memoryUsageData = metrics.map(metric => ({
        date: metric.timestamp,
        value: metric.memoryUsage
    }));

    const activeUsersData = metrics.map(metric => ({
        date: metric.timestamp,
        value: metric.activeUsers
    }));

    const errorRateData = metrics.map(metric => ({
        date: metric.timestamp,
        value: metric.errorRate
    }));

    return (
        <div className={`space-y-6 ${className}`}>
            {/* Header */}
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-900">Performance Monitor</h2>

                <div className="flex items-center space-x-4">
                    <label className="flex items-center">
                        <input
                            type="checkbox"
                            checked={isRealTime}
                            onChange={(e) => setIsRealTime(e.target.checked)}
                            className="mr-2"
                        />
                        <span className="text-sm text-gray-700">Real-time updates</span>
                    </label>

                    {isRealTime && (
                        <div className="flex items-center space-x-2">
                            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                            <span className="text-sm text-green-600">Live</span>
                        </div>
                    )}
                </div>
            </div>

            {/* Current Metrics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <div className="text-2xl font-bold text-blue-600">
                        {latestMetric ? Math.round(latestMetric.responseTime) : 0}ms
                    </div>
                    <div className="text-sm text-gray-500">Response Time</div>
                    {averageMetrics && (
                        <div className="text-xs text-gray-400 mt-1">
                            Avg: {averageMetrics.responseTime}ms
                        </div>
                    )}
                </div>

                <div className="bg-white p-6 rounded-lg shadow-md">
                    <div className="text-2xl font-bold text-orange-600">
                        {latestMetric ? Math.round(latestMetric.memoryUsage) : 0}%
                    </div>
                    <div className="text-sm text-gray-500">Memory Usage</div>
                    {averageMetrics && (
                        <div className="text-xs text-gray-400 mt-1">
                            Avg: {averageMetrics.memoryUsage}%
                        </div>
                    )}
                </div>

                <div className="bg-white p-6 rounded-lg shadow-md">
                    <div className="text-2xl font-bold text-green-600">
                        {latestMetric ? latestMetric.activeUsers : 0}
                    </div>
                    <div className="text-sm text-gray-500">Active Users</div>
                    {averageMetrics && (
                        <div className="text-xs text-gray-400 mt-1">
                            Avg: {averageMetrics.activeUsers}
                        </div>
                    )}
                </div>

                <div className="bg-white p-6 rounded-lg shadow-md">
                    <div className="text-2xl font-bold text-red-600">
                        {latestMetric ? Math.round(latestMetric.errorRate * 100) / 100 : 0}%
                    </div>
                    <div className="text-sm text-gray-500">Error Rate</div>
                    {averageMetrics && (
                        <div className="text-xs text-gray-400 mt-1">
                            Avg: {averageMetrics.errorRate}%
                        </div>
                    )}
                </div>
            </div>

            {/* Performance Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <LineChart
                    data={responseTimeData}
                    title="Response Time (ms)"
                    color="#3B82F6"
                    height={250}
                />

                <LineChart
                    data={memoryUsageData}
                    title="Memory Usage (%)"
                    color="#F59E0B"
                    height={250}
                />

                <LineChart
                    data={activeUsersData}
                    title="Active Users"
                    color="#10B981"
                    height={250}
                />

                <LineChart
                    data={errorRateData}
                    title="Error Rate (%)"
                    color="#EF4444"
                    height={250}
                />
            </div>

            {/* System Status */}
            <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">System Status</h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${latestMetric && latestMetric.responseTime < 200 ? 'bg-green-500' :
                                latestMetric && latestMetric.responseTime < 500 ? 'bg-yellow-500' : 'bg-red-500'
                            }`}></div>
                        <span className="text-sm text-gray-700">API Response</span>
                    </div>

                    <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${latestMetric && latestMetric.memoryUsage < 70 ? 'bg-green-500' :
                                latestMetric && latestMetric.memoryUsage < 85 ? 'bg-yellow-500' : 'bg-red-500'
                            }`}></div>
                        <span className="text-sm text-gray-700">Memory</span>
                    </div>

                    <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${latestMetric && latestMetric.errorRate < 1 ? 'bg-green-500' :
                                latestMetric && latestMetric.errorRate < 3 ? 'bg-yellow-500' : 'bg-red-500'
                            }`}></div>
                        <span className="text-sm text-gray-700">Error Rate</span>
                    </div>
                </div>
            </div>
        </div>
    );
};