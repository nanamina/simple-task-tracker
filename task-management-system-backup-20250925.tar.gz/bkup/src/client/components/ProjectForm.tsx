import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { RootState, AppDispatch } from '@/client/store'
import { createProject, updateProject, clearError } from '@/client/store/slices/projectSlice'
import { Project } from '@/shared/types'

interface ProjectFormProps {
    project?: Project
    onCancel?: () => void
    onSuccess?: (project: Project) => void
}

/**
 * ProjectForm component - handles project creation and editing
 * Provides form validation and submission for project data
 */
const ProjectForm: React.FC<ProjectFormProps> = ({ project, onCancel, onSuccess }) => {
    const dispatch = useDispatch<AppDispatch>()
    const navigate = useNavigate()
    const { t } = useTranslation()

    const { loading, error } = useSelector((state: RootState) => state.projects)

    const [formData, setFormData] = useState({
        name: project?.name || '',
        description: project?.description || '',
    })

    const [formErrors, setFormErrors] = useState<Record<string, string>>({})

    useEffect(() => {
        // Clear any existing errors when component mounts
        dispatch(clearError())
    }, [dispatch])

    useEffect(() => {
        // Update form data when project prop changes
        if (project) {
            setFormData({
                name: project.name,
                description: project.description,
            })
        }
    }, [project])

    /**
     * Validates form data and returns validation errors
     */
    const validateForm = (): Record<string, string> => {
        const errors: Record<string, string> = {}

        if (!formData.name.trim()) {
            errors.name = t('validation.required', { field: t('projects.name') })
        } else if (formData.name.trim().length < 2) {
            errors.name = t('validation.minLength', { field: t('projects.name'), min: 2 })
        } else if (formData.name.trim().length > 100) {
            errors.name = t('validation.maxLength', { field: t('projects.name'), max: 100 })
        }

        if (!formData.description.trim()) {
            errors.description = t('validation.required', { field: t('projects.description') })
        } else if (formData.description.trim().length < 10) {
            errors.description = t('validation.minLength', { field: t('projects.description'), min: 10 })
        } else if (formData.description.trim().length > 500) {
            errors.description = t('validation.maxLength', { field: t('projects.description'), max: 500 })
        }

        return errors
    }

    /**
     * Handles form input changes
     */
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target
        setFormData(prev => ({
            ...prev,
            [name]: value
        }))

        // Clear field error when user starts typing
        if (formErrors[name]) {
            setFormErrors(prev => ({
                ...prev,
                [name]: ''
            }))
        }
    }

    /**
     * Handles form submission
     */
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()

        const errors = validateForm()
        if (Object.keys(errors).length > 0) {
            setFormErrors(errors)
            return
        }

        try {
            const projectData = {
                name: formData.name.trim(),
                description: formData.description.trim(),
            }

            let result
            if (project) {
                // Update existing project
                result = await dispatch(updateProject({
                    id: project.id,
                    updates: projectData
                })).unwrap()
            } else {
                // Create new project
                result = await dispatch(createProject(projectData)).unwrap()
            }

            if (onSuccess) {
                onSuccess(result)
            } else {
                navigate(`/projects/${result.id}`)
            }
        } catch (error) {
            // Error is handled by Redux slice
            console.error('Failed to save project:', error)
        }
    }

    /**
     * Handles form cancellation
     */
    const handleCancel = () => {
        if (onCancel) {
            onCancel()
        } else {
            navigate('/projects')
        }
    }

    return (
        <div className="max-w-2xl mx-auto">
            <div className="bg-white shadow rounded-lg p-6">
                <div className="mb-6">
                    <h2 className="text-xl font-semibold text-gray-900">
                        {project ? t('projects.edit') : t('projects.create')}
                    </h2>
                    <p className="mt-1 text-sm text-gray-600">
                        {project
                            ? t('projects.editDescription')
                            : t('projects.createDescription')
                        }
                    </p>
                </div>

                {error && (
                    <div className="mb-6 bg-red-50 border border-red-200 rounded-md p-4">
                        <div className="flex">
                            <div className="ml-3">
                                <h3 className="text-sm font-medium text-red-800">
                                    {t('common.error')}
                                </h3>
                                <div className="mt-2 text-sm text-red-700">
                                    {error}
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Project Name */}
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                            {t('projects.name')} <span className="text-red-500">*</span>
                        </label>
                        <div className="mt-1">
                            <input
                                type="text"
                                id="name"
                                name="name"
                                value={formData.name}
                                onChange={handleInputChange}
                                className={`block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm ${formErrors.name
                                        ? 'border-red-300 text-red-900 placeholder-red-300'
                                        : 'border-gray-300'
                                    }`}
                                placeholder={t('projects.namePlaceholder')}
                                maxLength={100}
                            />
                            {formErrors.name && (
                                <p className="mt-2 text-sm text-red-600">
                                    {formErrors.name}
                                </p>
                            )}
                        </div>
                    </div>

                    {/* Project Description */}
                    <div>
                        <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                            {t('projects.description')} <span className="text-red-500">*</span>
                        </label>
                        <div className="mt-1">
                            <textarea
                                id="description"
                                name="description"
                                rows={4}
                                value={formData.description}
                                onChange={handleInputChange}
                                className={`block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm ${formErrors.description
                                        ? 'border-red-300 text-red-900 placeholder-red-300'
                                        : 'border-gray-300'
                                    }`}
                                placeholder={t('projects.descriptionPlaceholder')}
                                maxLength={500}
                            />
                            {formErrors.description && (
                                <p className="mt-2 text-sm text-red-600">
                                    {formErrors.description}
                                </p>
                            )}
                            <p className="mt-2 text-sm text-gray-500">
                                {formData.description.length}/500 {t('common.characters')}
                            </p>
                        </div>
                    </div>

                    {/* Form Actions */}
                    <div className="flex justify-end space-x-3">
                        <button
                            type="button"
                            onClick={handleCancel}
                            className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                        >
                            {t('common.cancel')}
                        </button>
                        <button
                            type="submit"
                            disabled={loading}
                            className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {loading ? (
                                <>
                                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                    </svg>
                                    {t('common.saving')}
                                </>
                            ) : (
                                project ? t('common.update') : t('common.create')
                            )}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    )
}

export default ProjectForm