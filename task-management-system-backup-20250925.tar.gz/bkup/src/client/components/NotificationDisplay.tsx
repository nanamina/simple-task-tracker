import React, { useState, useEffect } from 'react';
import { useTranslation } from '../hooks/useTranslation';

export interface Notification {
    id: string;
    type: 'success' | 'error' | 'warning' | 'info';
    title: string;
    message: string;
    timestamp: Date;
    read: boolean;
    actionUrl?: string;
    actionLabel?: string;
}

interface NotificationItemProps {
    notification: Notification;
    onMarkAsRead: (id: string) => void;
    onDismiss: (id: string) => void;
    onAction?: (notification: Notification) => void;
}

interface NotificationDisplayProps {
    notifications: Notification[];
    onMarkAsRead: (id: string) => void;
    onDismiss: (id: string) => void;
    onMarkAllAsRead: () => void;
    onClearAll: () => void;
    maxVisible?: number;
}

/**
 * Individual notification item component
 */
const NotificationItem: React.FC<NotificationItemProps> = ({
    notification,
    onMarkAsRead,
    onDismiss,
    onAction
}) => {
    const { t } = useTranslation();

    /**
     * Get icon based on notification type
     */
    const getIcon = () => {
        switch (notification.type) {
            case 'success':
                return (
                    <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                );
            case 'error':
                return (
                    <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                );
            case 'warning':
                return (
                    <svg className="w-5 h-5 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16c-.77.833.192 2.5 1.732 2.5z" />
                    </svg>
                );
            case 'info':
            default:
                return (
                    <svg className="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                );
        }
    };

    /**
     * Get background color based on notification type and read status
     */
    const getBackgroundColor = () => {
        const baseClasses = notification.read ? 'bg-gray-50' : 'bg-white';
        const borderClasses = notification.read ? 'border-gray-200' : 'border-l-4';

        let borderColor = '';
        switch (notification.type) {
            case 'success':
                borderColor = 'border-l-green-500';
                break;
            case 'error':
                borderColor = 'border-l-red-500';
                break;
            case 'warning':
                borderColor = 'border-l-yellow-500';
                break;
            case 'info':
            default:
                borderColor = 'border-l-blue-500';
                break;
        }

        return `${baseClasses} ${borderClasses} ${!notification.read ? borderColor : ''}`;
    };

    /**
     * Handle notification click to mark as read
     */
    const handleClick = () => {
        if (!notification.read) {
            onMarkAsRead(notification.id);
        }
    };

    /**
     * Handle action button click
     */
    const handleActionClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (onAction) {
            onAction(notification);
        }
    };

    /**
     * Handle dismiss button click
     */
    const handleDismissClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        onDismiss(notification.id);
    };

    return (
        <div
            className={`p-4 border rounded-lg cursor-pointer transition-colors hover:bg-gray-50 ${getBackgroundColor()}`}
            onClick={handleClick}
        >
            <div className="flex items-start space-x-3">
                {/* Icon */}
                <div className="flex-shrink-0 mt-0.5">
                    {getIcon()}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                        <div className="flex-1">
                            <h4 className={`text-sm font-medium ${notification.read ? 'text-gray-600' : 'text-gray-900'}`}>
                                {notification.title}
                            </h4>
                            <p className={`mt-1 text-sm ${notification.read ? 'text-gray-500' : 'text-gray-700'}`}>
                                {notification.message}
                            </p>
                            <p className="mt-2 text-xs text-gray-400">
                                {notification.timestamp.toLocaleString()}
                            </p>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center space-x-2 ml-4">
                            {notification.actionUrl && notification.actionLabel && (
                                <button
                                    onClick={handleActionClick}
                                    className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                                >
                                    {notification.actionLabel}
                                </button>
                            )}
                            <button
                                onClick={handleDismissClick}
                                className="text-gray-400 hover:text-gray-600 transition-colors"
                                aria-label="Dismiss notification"
                            >
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

/**
 * Main notification display component
 * Shows a list of notifications with actions to manage them
 */
export const NotificationDisplay: React.FC<NotificationDisplayProps> = ({
    notifications,
    onMarkAsRead,
    onDismiss,
    onMarkAllAsRead,
    onClearAll,
    maxVisible = 10
}) => {
    const { t } = useTranslation();
    const [showAll, setShowAll] = useState(false);

    // Sort notifications by timestamp (newest first) and read status (unread first)
    const sortedNotifications = [...notifications].sort((a, b) => {
        if (a.read !== b.read) {
            return a.read ? 1 : -1; // Unread first
        }
        return b.timestamp.getTime() - a.timestamp.getTime(); // Newest first
    });

    // Limit visible notifications if not showing all
    const visibleNotifications = showAll
        ? sortedNotifications
        : sortedNotifications.slice(0, maxVisible);

    const unreadCount = notifications.filter(n => !n.read).length;
    const hasMore = notifications.length > maxVisible;

    /**
     * Handle action click for notifications with URLs
     */
    const handleNotificationAction = (notification: Notification) => {
        if (notification.actionUrl) {
            // In a real app, you might use React Router for internal navigation
            // or window.open for external links
            window.location.href = notification.actionUrl;
        }
    };

    if (notifications.length === 0) {
        return (
            <div className="bg-white rounded-lg shadow-md p-6">
                <div className="text-center text-gray-500">
                    <svg className="w-12 h-12 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-5 5v-5zM9 7H4l5-5v5zm6 10V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2h6a2 2 0 002-2z" />
                    </svg>
                    <p>{t('notifications.noNotifications') || 'No notifications'}</p>
                </div>
            </div>
        );
    }

    return (
        <div className="bg-white rounded-lg shadow-md">
            {/* Header */}
            <div className="px-6 py-4 border-b border-gray-200">
                <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                        <h3 className="text-lg font-medium text-gray-900">
                            {t('notifications.title') || 'Notifications'}
                        </h3>
                        {unreadCount > 0 && (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                {unreadCount}
                            </span>
                        )}
                    </div>

                    {/* Header actions */}
                    <div className="flex items-center space-x-2">
                        {unreadCount > 0 && (
                            <button
                                onClick={onMarkAllAsRead}
                                className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                            >
                                {t('notifications.markAllRead') || 'Mark all as read'}
                            </button>
                        )}
                        {notifications.length > 0 && (
                            <button
                                onClick={onClearAll}
                                className="text-sm text-gray-600 hover:text-gray-800 font-medium"
                            >
                                {t('notifications.clearAll') || 'Clear all'}
                            </button>
                        )}
                    </div>
                </div>
            </div>

            {/* Notifications list */}
            <div className="max-h-96 overflow-y-auto">
                <div className="p-4 space-y-3">
                    {visibleNotifications.map((notification) => (
                        <NotificationItem
                            key={notification.id}
                            notification={notification}
                            onMarkAsRead={onMarkAsRead}
                            onDismiss={onDismiss}
                            onAction={handleNotificationAction}
                        />
                    ))}
                </div>
            </div>

            {/* Footer */}
            {hasMore && (
                <div className="px-6 py-3 border-t border-gray-200 text-center">
                    <button
                        onClick={() => setShowAll(!showAll)}
                        className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                    >
                        {showAll
                            ? (t('notifications.showLess') || 'Show less')
                            : (t('notifications.showAll') || `Show all ${notifications.length} notifications`)
                        }
                    </button>
                </div>
            )}
        </div>
    );
};

export default NotificationDisplay;