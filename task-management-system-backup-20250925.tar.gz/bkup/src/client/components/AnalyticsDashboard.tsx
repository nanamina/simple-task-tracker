import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { BarChart } from './charts/BarChart';
import { LineChart } from './charts/LineChart';
import { PieChart } from './charts/PieChart';
import { ErrorMessage } from './ErrorMessage';

interface ProjectMetrics {
    projectId: string;
    projectName: string;
    totalTasks: number;
    statusDistribution: {
        todo: number;
        'in-progress': number;
        completed: number;
    };
    completionRate: number;
    averageTaskDuration: number;
    overdueTasksCount: number;
    overdueTasks: Array<{
        id: string;
        title: string;
        dueDate: string;
        assigneeId?: string;
        priority: string;
    }>;
}

interface TeamWorkload {
    userId: string;
    userName: string;
    totalTasks: number;
    completedTasks: number;
    inProgressTasks: number;
    todoTasks: number;
    overdueTasks: number;
    completionRate: number;
}

interface CompletionTrend {
    date: string;
    completedTasks: number;
}

interface AnalyticsDashboardProps {
    projectId?: string;
    className?: string;
}

/**
 * Analytics dashboard component displaying project metrics and reports
 */
export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
    projectId,
    className = ''
}) => {
    const { t } = useTranslation();
    const [metrics, setMetrics] = useState<ProjectMetrics | null>(null);
    const [workload, setWorkload] = useState<TeamWorkload[]>([]);
    const [trends, setTrends] = useState<CompletionTrend[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [selectedPeriod, setSelectedPeriod] = useState<number>(30);

    useEffect(() => {
        loadAnalyticsData();
    }, [projectId, selectedPeriod]);

    const loadAnalyticsData = async () => {
        try {
            setLoading(true);
            setError(null);

            const token = localStorage.getItem('token');
            if (!token) {
                throw new Error('Authentication required');
            }

            const headers = {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            };

            // Load project metrics if projectId is provided
            let metricsData = null;
            if (projectId) {
                const metricsResponse = await fetch(`/api/analytics/projects/${projectId}/metrics`, {
                    headers
                });

                if (!metricsResponse.ok) {
                    throw new Error('Failed to load project metrics');
                }

                const metricsResult = await metricsResponse.json();
                metricsData = metricsResult.data;
            }

            // Load team workload
            const workloadUrl = projectId
                ? `/api/analytics/workload?projectId=${projectId}`
                : '/api/analytics/workload';

            const workloadResponse = await fetch(workloadUrl, { headers });
            if (!workloadResponse.ok) {
                throw new Error('Failed to load team workload');
            }

            const workloadResult = await workloadResponse.json();

            // Load completion trends
            const trendsUrl = projectId
                ? `/api/analytics/trends?projectId=${projectId}&days=${selectedPeriod}`
                : `/api/analytics/trends?days=${selectedPeriod}`;

            const trendsResponse = await fetch(trendsUrl, { headers });
            if (!trendsResponse.ok) {
                throw new Error('Failed to load completion trends');
            }

            const trendsResult = await trendsResponse.json();

            setMetrics(metricsData);
            setWorkload(workloadResult.data);
            setTrends(trendsResult.data);
        } catch (err) {
            console.error('Error loading analytics data:', err);
            setError(err instanceof Error ? err.message : 'Failed to load analytics data');
        } finally {
            setLoading(false);
        }
    };

    const handleExportReport = async (format: 'csv' | 'json') => {
        if (!projectId) return;

        try {
            const token = localStorage.getItem('token');
            const response = await fetch(`/api/analytics/projects/${projectId}/export?format=${format}`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (!response.ok) {
                throw new Error('Failed to export report');
            }

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `project-${projectId}-report.${format}`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (err) {
            console.error('Error exporting report:', err);
            setError('Failed to export report');
        }
    };

    if (loading) {
        return (
            <div className={`space-y-6 ${className}`}>
                <div className="animate-pulse">
                    <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {[...Array(6)].map((_, i) => (
                            <div key={i} className="h-64 bg-gray-200 rounded-lg"></div>
                        ))}
                    </div>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className={className}>
                <ErrorMessage
                    error={{
                        title: 'Analytics Error',
                        message: error,
                        isRetryable: true
                    }}
                    onRetry={loadAnalyticsData}
                />
            </div>
        );
    }

    const statusDistributionData = metrics ? [
        { label: 'todo', value: metrics.statusDistribution.todo, color: '#F59E0B' },
        { label: 'in-progress', value: metrics.statusDistribution['in-progress'], color: '#3B82F6' },
        { label: 'completed', value: metrics.statusDistribution.completed, color: '#10B981' }
    ] : [];

    const workloadData = workload.map(member => ({
        label: member.userName,
        value: member.totalTasks
    }));

    const trendsData = trends.map(trend => ({
        date: trend.date,
        value: trend.completedTasks
    }));

    return (
        <div className={`space-y-6 ${className}`}>
            {/* Header */}
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-900">
                    {projectId ? `${metrics?.projectName} Analytics` : 'Team Analytics'}
                </h2>

                <div className="flex space-x-2">
                    {/* Period selector */}
                    <select
                        value={selectedPeriod}
                        onChange={(e) => setSelectedPeriod(Number(e.target.value))}
                        className="px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                        <option value={7}>Last 7 days</option>
                        <option value={30}>Last 30 days</option>
                        <option value={90}>Last 90 days</option>
                    </select>

                    {/* Export buttons */}
                    {projectId && (
                        <>
                            <button
                                onClick={() => handleExportReport('csv')}
                                className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 text-sm"
                            >
                                Export CSV
                            </button>
                            <button
                                onClick={() => handleExportReport('json')}
                                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm"
                            >
                                Export JSON
                            </button>
                        </>
                    )}
                </div>
            </div>

            {/* Summary Cards */}
            {metrics && (
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <div className="text-2xl font-bold text-gray-900">{metrics.totalTasks}</div>
                        <div className="text-sm text-gray-500">Total Tasks</div>
                    </div>
                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <div className="text-2xl font-bold text-green-600">{metrics.completionRate}%</div>
                        <div className="text-sm text-gray-500">Completion Rate</div>
                    </div>
                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <div className="text-2xl font-bold text-blue-600">{metrics.averageTaskDuration}</div>
                        <div className="text-sm text-gray-500">Avg Duration (days)</div>
                    </div>
                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <div className="text-2xl font-bold text-red-600">{metrics.overdueTasksCount}</div>
                        <div className="text-sm text-gray-500">Overdue Tasks</div>
                    </div>
                </div>
            )}

            {/* Charts Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Status Distribution */}
                {metrics && (
                    <PieChart
                        data={statusDistributionData}
                        title="Task Status Distribution"
                        size={250}
                    />
                )}

                {/* Team Workload */}
                {workload.length > 0 && (
                    <BarChart
                        data={workloadData}
                        title="Team Workload"
                        height={300}
                    />
                )}

                {/* Completion Trends */}
                {trends.length > 0 && (
                    <div className="lg:col-span-2">
                        <LineChart
                            data={trendsData}
                            title={`Task Completion Trends (${selectedPeriod} days)`}
                            height={300}
                        />
                    </div>
                )}
            </div>

            {/* Overdue Tasks Table */}
            {metrics && metrics.overdueTasks.length > 0 && (
                <div className="bg-white rounded-lg shadow-md">
                    <div className="px-6 py-4 border-b border-gray-200">
                        <h3 className="text-lg font-semibold text-gray-900">Overdue Tasks</h3>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Task
                                    </th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Due Date
                                    </th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Priority
                                    </th>
                                </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                                {metrics.overdueTasks.map((task) => (
                                    <tr key={task.id}>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                            {task.title}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600">
                                            {new Date(task.dueDate).toLocaleDateString()}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${task.priority === 'critical' ? 'bg-red-100 text-red-800' :
                                                task.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                                                    task.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                                        'bg-green-100 text-green-800'
                                                }`}>
                                                {task.priority}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
};