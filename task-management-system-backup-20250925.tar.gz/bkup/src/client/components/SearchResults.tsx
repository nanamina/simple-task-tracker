import React from 'react'
import { Task, Project } from '@/shared/types'
import { useTranslation } from '@/client/hooks/useTranslation'
import { highlightAndTruncate, createSearchExcerpt } from '@/client/utils/searchHighlight'
import { TaskCard } from './TaskCard'

interface SearchResultsProps {
    tasks?: Task[]
    projects?: Project[]
    searchTerm?: string
    isLoading?: boolean
    onTaskStatusChange?: (taskId: string, status: Task['status']) => void
    onTaskEdit?: (task: Task) => void
    onTaskDelete?: (taskId: string) => void
    onProjectClick?: (projectId: string) => void
}

/**
 * Search results component with highlighted search terms
 * Displays both task and project search results with excerpts
 */
export const SearchResults: React.FC<SearchResultsProps> = ({
    tasks = [],
    projects = [],
    searchTerm = '',
    isLoading = false,
    onTaskStatusChange,
    onTaskEdit,
    onTaskDelete,
    onProjectClick
}) => {
    const { t } = useTranslation()

    if (isLoading) {
        return (
            <div className="text-center py-8">
                <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <p className="mt-2 text-gray-600">{t('common.searching')}</p>
            </div>
        )
    }

    const hasResults = tasks.length > 0 || projects.length > 0
    const showSearchTerm = searchTerm && searchTerm.trim()

    if (!hasResults && showSearchTerm) {
        return (
            <div className="text-center py-12">
                <div className="mx-auto h-12 w-12 text-gray-400 mb-4">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                    {t('search.noResults')}
                </h3>
                <p className="text-gray-600">
                    {t('search.noResultsFor', { term: searchTerm })}
                </p>
                <div className="mt-4 text-sm text-gray-500">
                    <p>{t('search.suggestions.title')}</p>
                    <ul className="mt-2 space-y-1">
                        <li>• {t('search.suggestions.checkSpelling')}</li>
                        <li>• {t('search.suggestions.tryDifferentKeywords')}</li>
                        <li>• {t('search.suggestions.useFewerKeywords')}</li>
                    </ul>
                </div>
            </div>
        )
    }

    return (
        <div className="space-y-6">
            {/* Search summary */}
            {showSearchTerm && hasResults && (
                <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
                    <p className="text-blue-800">
                        {t('search.resultsFor', {
                            term: searchTerm,
                            count: tasks.length + projects.length
                        })}
                    </p>
                </div>
            )}

            {/* Project results */}
            {projects.length > 0 && (
                <div>
                    <h2 className="text-lg font-semibold text-gray-900 mb-4">
                        {t('search.projects')} ({projects.length})
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {projects.map(project => (
                            <ProjectSearchResult
                                key={project.id}
                                project={project}
                                searchTerm={searchTerm}
                                onClick={() => onProjectClick?.(project.id)}
                            />
                        ))}
                    </div>
                </div>
            )}

            {/* Task results */}
            {tasks.length > 0 && (
                <div>
                    <h2 className="text-lg font-semibold text-gray-900 mb-4">
                        {t('search.tasks')} ({tasks.length})
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {tasks.map(task => (
                            <TaskSearchResult
                                key={task.id}
                                task={task}
                                searchTerm={searchTerm}
                                onStatusChange={onTaskStatusChange}
                                onEdit={onTaskEdit}
                                onDelete={onTaskDelete}
                            />
                        ))}
                    </div>
                </div>
            )}
        </div>
    )
}

/**
 * Project search result item with highlighting
 */
const ProjectSearchResult: React.FC<{
    project: Project
    searchTerm: string
    onClick?: () => void
}> = ({ project, searchTerm, onClick }) => {
    const { t } = useTranslation()

    return (
        <div
            className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
            onClick={onClick}
        >
            <div className="flex items-start justify-between mb-2">
                <h3
                    className="font-medium text-gray-900 truncate"
                    dangerouslySetInnerHTML={{
                        __html: highlightAndTruncate(project.name, searchTerm, 50)
                    }}
                />
                <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                    {t('common.project')}
                </span>
            </div>

            {project.description && (
                <p
                    className="text-sm text-gray-600 mb-3"
                    dangerouslySetInnerHTML={{
                        __html: createSearchExcerpt(project.description, searchTerm, 120)
                    }}
                />
            )}

            <div className="flex items-center justify-between text-xs text-gray-500">
                <span>{t('projects.members')}: {project.members.length}</span>
                <span>{new Date(project.updatedAt).toLocaleDateString('ja-JP')}</span>
            </div>
        </div>
    )
}

/**
 * Task search result item with highlighting
 */
const TaskSearchResult: React.FC<{
    task: Task
    searchTerm: string
    onStatusChange?: (taskId: string, status: Task['status']) => void
    onEdit?: (task: Task) => void
    onDelete?: (taskId: string) => void
}> = ({ task, searchTerm, onStatusChange, onEdit, onDelete }) => {
    return (
        <div className="relative">
            {/* Search excerpt overlay */}
            {searchTerm && (
                <div className="absolute top-0 left-0 right-0 bg-yellow-50 border-b border-yellow-200 px-3 py-2 text-xs">
                    <span
                        className="text-gray-700"
                        dangerouslySetInnerHTML={{
                            __html: createSearchExcerpt(
                                `${task.title} ${task.description}`,
                                searchTerm,
                                80
                            )
                        }}
                    />
                </div>
            )}

            {/* Task card with top margin if search excerpt is shown */}
            <div className={searchTerm ? 'mt-12' : ''}>
                <TaskCard
                    task={task}
                    onStatusChange={onStatusChange}
                    onEdit={onEdit}
                    onDelete={onDelete}
                    highlightTerm={searchTerm}
                />
            </div>
        </div>
    )
}