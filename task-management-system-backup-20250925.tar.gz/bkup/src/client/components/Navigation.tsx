import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { RootState } from '../store';
import { logout } from '../store/slices/authSlice';
import { useTranslation } from '../hooks/useTranslation';
import LanguageSwitcher from './LanguageSwitcher';
import { UserRole } from '@/shared/types';

interface NavigationItem {
    key: string;
    path: string;
    label: string;
    icon: React.ReactNode;
    roles?: UserRole[]; // If specified, only these roles can see this item
}

/**
 * Navigation component with role-based menu items
 * Provides main navigation for the application with user authentication state
 */
export const Navigation: React.FC = () => {
    const { t } = useTranslation();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const location = useLocation();
    const { user, isAuthenticated } = useSelector((state: RootState) => state.auth);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    /**
     * Navigation items configuration with role-based access
     */
    const navigationItems: NavigationItem[] = [
        {
            key: 'dashboard',
            path: '/dashboard',
            label: t('navigation.dashboard'),
            icon: (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5a2 2 0 012-2h4a2 2 0 012 2v6a2 2 0 01-2 2H10a2 2 0 01-2-2V5z" />
                </svg>
            )
        },
        {
            key: 'tasks',
            path: '/tasks',
            label: t('navigation.tasks'),
            icon: (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                </svg>
            )
        },
        {
            key: 'projects',
            path: '/projects',
            label: t('navigation.projects'),
            icon: (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                </svg>
            ),
            roles: ['admin', 'manager'] // Only admins and managers can see projects
        }
    ];

    /**
     * Filter navigation items based on user role
     */
    const getVisibleNavigationItems = (): NavigationItem[] => {
        if (!user) return [];

        return navigationItems.filter(item => {
            // If no roles specified, item is visible to all authenticated users
            if (!item.roles) return true;
            // Check if user's role is in the allowed roles
            return item.roles.includes(user.role);
        });
    };

    /**
     * Handle user logout
     */
    const handleLogout = () => {
        dispatch(logout());
        navigate('/login');
        setIsMobileMenuOpen(false);
    };

    /**
     * Handle profile navigation
     */
    const handleProfileClick = () => {
        navigate('/profile');
        setIsMobileMenuOpen(false);
    };

    /**
     * Check if a navigation item is currently active
     */
    const isActiveItem = (path: string): boolean => {
        return location.pathname === path;
    };

    /**
     * Toggle mobile menu
     */
    const toggleMobileMenu = () => {
        setIsMobileMenuOpen(!isMobileMenuOpen);
    };

    // Don't render navigation if user is not authenticated
    if (!isAuthenticated || !user) {
        return null;
    }

    const visibleItems = getVisibleNavigationItems();

    return (
        <nav className="bg-white shadow-lg border-b border-gray-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between h-16">
                    {/* Logo and main navigation */}
                    <div className="flex">
                        {/* Logo */}
                        <div className="flex-shrink-0 flex items-center">
                            <Link to="/dashboard" className="text-xl font-bold text-blue-600">
                                TaskManager
                            </Link>
                        </div>

                        {/* Desktop navigation */}
                        <div className="hidden md:ml-6 md:flex md:space-x-8">
                            {visibleItems.map((item) => (
                                <Link
                                    key={item.key}
                                    to={item.path}
                                    className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors duration-200 ${isActiveItem(item.path)
                                            ? 'border-blue-500 text-gray-900'
                                            : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                                        }`}
                                >
                                    <span className="mr-2">{item.icon}</span>
                                    {item.label}
                                </Link>
                            ))}
                        </div>
                    </div>

                    {/* Right side - User menu and language switcher */}
                    <div className="hidden md:ml-6 md:flex md:items-center md:space-x-4">
                        {/* Language Switcher */}
                        <LanguageSwitcher />

                        {/* User menu */}
                        <div className="relative">
                            <div className="flex items-center space-x-3">
                                {/* User info */}
                                <div className="text-sm">
                                    <div className="font-medium text-gray-700">{user.name}</div>
                                    <div className="text-gray-500">{t(`users.role.${user.role}`)}</div>
                                </div>

                                {/* Profile button */}
                                <button
                                    onClick={handleProfileClick}
                                    className="flex items-center p-2 text-gray-400 hover:text-gray-600 transition-colors"
                                    aria-label="User profile"
                                >
                                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                    </svg>
                                </button>

                                {/* Logout button */}
                                <button
                                    onClick={handleLogout}
                                    className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors"
                                    aria-label="Logout"
                                >
                                    <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                                    </svg>
                                    {t('navigation.logout')}
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Mobile menu button */}
                    <div className="md:hidden flex items-center">
                        <button
                            onClick={toggleMobileMenu}
                            className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500"
                            aria-expanded="false"
                        >
                            <span className="sr-only">Open main menu</span>
                            {isMobileMenuOpen ? (
                                <svg className="block h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            ) : (
                                <svg className="block h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                                </svg>
                            )}
                        </button>
                    </div>
                </div>
            </div>

            {/* Mobile menu */}
            {isMobileMenuOpen && (
                <div className="md:hidden">
                    <div className="pt-2 pb-3 space-y-1">
                        {visibleItems.map((item) => (
                            <Link
                                key={item.key}
                                to={item.path}
                                onClick={() => setIsMobileMenuOpen(false)}
                                className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium transition-colors duration-200 ${isActiveItem(item.path)
                                        ? 'bg-blue-50 border-blue-500 text-blue-700'
                                        : 'border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800'
                                    }`}
                            >
                                <div className="flex items-center">
                                    <span className="mr-3">{item.icon}</span>
                                    {item.label}
                                </div>
                            </Link>
                        ))}
                    </div>

                    {/* Mobile user section */}
                    <div className="pt-4 pb-3 border-t border-gray-200">
                        <div className="flex items-center px-4">
                            <div className="flex-shrink-0">
                                <div className="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center">
                                    <svg className="h-6 w-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                    </svg>
                                </div>
                            </div>
                            <div className="ml-3">
                                <div className="text-base font-medium text-gray-800">{user.name}</div>
                                <div className="text-sm font-medium text-gray-500">{user.email}</div>
                                <div className="text-sm text-gray-500">{t(`users.role.${user.role}`)}</div>
                            </div>
                        </div>
                        <div className="mt-3 space-y-1">
                            <div className="px-4 py-2">
                                <LanguageSwitcher />
                            </div>
                            <button
                                onClick={handleProfileClick}
                                className="block w-full text-left px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
                            >
                                {t('navigation.profile')}
                            </button>
                            <button
                                onClick={handleLogout}
                                className="block w-full text-left px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
                            >
                                {t('navigation.logout')}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </nav>
    );
};

export default Navigation;