import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useParams } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { RootState, AppDispatch } from '@/client/store'
import {
    fetchProject,
    fetchProjectTasks,
    fetchProjectMetrics,
    clearCurrentProject,
} from '@/client/store/slices/projectSlice'
import { Task } from '@/shared/types'

/**
 * ProjectDashboard component - displays project overview with metrics and task distribution
 * Shows project details, completion statistics, and task breakdown by status
 */
const ProjectDashboard: React.FC = () => {
    const { projectId } = useParams<{ projectId: string }>()
    const dispatch = useDispatch<AppDispatch>()
    const { t } = useTranslation()

    const {
        currentProject,
        projectTasks,
        projectMetrics,
        loading,
        error,
    } = useSelector((state: RootState) => state.projects)

    useEffect(() => {
        if (projectId) {
            dispatch(fetchProject(projectId))
            dispatch(fetchProjectTasks(projectId))
            dispatch(fetchProjectMetrics(projectId))
        }

        return () => {
            dispatch(clearCurrentProject())
        }
    }, [dispatch, projectId])

    if (loading) {
        return (
            <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-indigo-600"></div>
            </div>
        )
    }

    if (error) {
        return (
            <div className="bg-red-50 border border-red-200 rounded-md p-4">
                <div className="flex">
                    <div className="ml-3">
                        <h3 className="text-sm font-medium text-red-800">
                            {t('common.error')}
                        </h3>
                        <div className="mt-2 text-sm text-red-700">
                            {error}
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    if (!currentProject) {
        return (
            <div className="text-center py-12">
                <h3 className="text-lg font-medium text-gray-900">
                    {t('projects.notFound')}
                </h3>
            </div>
        )
    }

    // Ensure projectTasks is an array
    const tasks = Array.isArray(projectTasks) ? projectTasks : []

    // Calculate task distribution by status
    const tasksByStatus = tasks.reduce((acc, task) => {
        acc[task.status] = (acc[task.status] || 0) + 1
        return acc
    }, {} as Record<string, number>)

    // Calculate task distribution by priority
    const tasksByPriority = tasks.reduce((acc, task) => {
        acc[task.priority] = (acc[task.priority] || 0) + 1
        return acc
    }, {} as Record<string, number>)

    // Get overdue tasks
    const overdueTasks = tasks.filter(task =>
        task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'completed'
    )

    return (
        <div className="space-y-6">
            {/* Project Header */}
            <div className="bg-white shadow rounded-lg p-6">
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900">
                            {currentProject.name}
                        </h1>
                        <p className="mt-1 text-sm text-gray-600">
                            {currentProject.description}
                        </p>
                        <p className="mt-2 text-xs text-gray-500">
                            {t('projects.createdAt')}: {new Date(currentProject.createdAt).toLocaleDateString('ja-JP')}
                        </p>
                    </div>
                    <div className="flex space-x-3">
                        <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md text-sm font-medium">
                            {t('projects.edit')}
                        </button>
                        <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm font-medium">
                            {t('tasks.create')}
                        </button>
                    </div>
                </div>
            </div>

            {/* Metrics Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-white overflow-hidden shadow rounded-lg">
                    <div className="p-5">
                        <div className="flex items-center">
                            <div className="flex-shrink-0">
                                <div className="w-8 h-8 bg-blue-500 rounded-md flex items-center justify-center">
                                    <span className="text-white text-sm font-medium">
                                        {projectMetrics?.totalTasks || tasks.length}
                                    </span>
                                </div>
                            </div>
                            <div className="ml-5 w-0 flex-1">
                                <dl>
                                    <dt className="text-sm font-medium text-gray-500 truncate">
                                        {t('projects.totalTasks')}
                                    </dt>
                                    <dd className="text-lg font-medium text-gray-900">
                                        {projectMetrics?.totalTasks || tasks.length}
                                    </dd>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-white overflow-hidden shadow rounded-lg">
                    <div className="p-5">
                        <div className="flex items-center">
                            <div className="flex-shrink-0">
                                <div className="w-8 h-8 bg-green-500 rounded-md flex items-center justify-center">
                                    <span className="text-white text-sm font-medium">
                                        {projectMetrics?.completedTasks || tasksByStatus.completed || 0}
                                    </span>
                                </div>
                            </div>
                            <div className="ml-5 w-0 flex-1">
                                <dl>
                                    <dt className="text-sm font-medium text-gray-500 truncate">
                                        {t('projects.completedTasks')}
                                    </dt>
                                    <dd className="text-lg font-medium text-gray-900">
                                        {projectMetrics?.completedTasks || tasksByStatus.completed || 0}
                                    </dd>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-white overflow-hidden shadow rounded-lg">
                    <div className="p-5">
                        <div className="flex items-center">
                            <div className="flex-shrink-0">
                                <div className="w-8 h-8 bg-yellow-500 rounded-md flex items-center justify-center">
                                    <span className="text-white text-sm font-medium">
                                        {projectMetrics?.inProgressTasks || tasksByStatus['in-progress'] || 0}
                                    </span>
                                </div>
                            </div>
                            <div className="ml-5 w-0 flex-1">
                                <dl>
                                    <dt className="text-sm font-medium text-gray-500 truncate">
                                        {t('projects.inProgressTasks')}
                                    </dt>
                                    <dd className="text-lg font-medium text-gray-900">
                                        {projectMetrics?.inProgressTasks || tasksByStatus['in-progress'] || 0}
                                    </dd>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-white overflow-hidden shadow rounded-lg">
                    <div className="p-5">
                        <div className="flex items-center">
                            <div className="flex-shrink-0">
                                <div className="w-8 h-8 bg-red-500 rounded-md flex items-center justify-center">
                                    <span className="text-white text-sm font-medium">
                                        {overdueTasks.length}
                                    </span>
                                </div>
                            </div>
                            <div className="ml-5 w-0 flex-1">
                                <dl>
                                    <dt className="text-sm font-medium text-gray-500 truncate">
                                        {t('projects.overdueTasks')}
                                    </dt>
                                    <dd className="text-lg font-medium text-gray-900">
                                        {overdueTasks.length}
                                    </dd>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Progress Bar */}
            <div className="bg-white shadow rounded-lg p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                    {t('projects.progress')}
                </h3>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div
                        className="bg-green-600 h-2.5 rounded-full transition-all duration-300"
                        style={{
                            width: `${projectMetrics?.completionRate ||
                                (tasksByStatus.completed || 0) / Math.max(tasks.length, 1) * 100}%`
                        }}
                    ></div>
                </div>
                <p className="mt-2 text-sm text-gray-600">
                    {Math.round(projectMetrics?.completionRate ||
                        (tasksByStatus.completed || 0) / Math.max(tasks.length, 1) * 100)}% {t('projects.complete')}
                </p>
            </div>

            {/* Task Distribution Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Status Distribution */}
                <div className="bg-white shadow rounded-lg p-6">
                    <h3 className="text-lg font-medium text-gray-900 mb-4">
                        {t('projects.tasksByStatus')}
                    </h3>
                    <div className="space-y-3">
                        {['todo', 'in-progress', 'completed'].map(status => (
                            <div key={status} className="flex items-center justify-between">
                                <div className="flex items-center">
                                    <div className={`w-3 h-3 rounded-full mr-3 ${status === 'todo' ? 'bg-gray-400' :
                                        status === 'in-progress' ? 'bg-yellow-500' :
                                            'bg-green-500'
                                        }`}></div>
                                    <span className="text-sm text-gray-700">
                                        {t(`tasks.status.${status}`)}
                                    </span>
                                </div>
                                <span className="text-sm font-medium text-gray-900">
                                    {tasksByStatus[status] || 0}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Priority Distribution */}
                <div className="bg-white shadow rounded-lg p-6">
                    <h3 className="text-lg font-medium text-gray-900 mb-4">
                        {t('projects.tasksByPriority')}
                    </h3>
                    <div className="space-y-3">
                        {['critical', 'high', 'medium', 'low'].map(priority => (
                            <div key={priority} className="flex items-center justify-between">
                                <div className="flex items-center">
                                    <div className={`w-3 h-3 rounded-full mr-3 ${priority === 'critical' ? 'bg-red-600' :
                                        priority === 'high' ? 'bg-orange-500' :
                                            priority === 'medium' ? 'bg-yellow-500' :
                                                'bg-green-500'
                                        }`}></div>
                                    <span className="text-sm text-gray-700">
                                        {t(`tasks.priority.${priority}`)}
                                    </span>
                                </div>
                                <span className="text-sm font-medium text-gray-900">
                                    {tasksByPriority[priority] || 0}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Recent Tasks */}
            <div className="bg-white shadow rounded-lg p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                    {t('projects.recentTasks')}
                </h3>
                {tasks.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">
                        {t('projects.noTasks')}
                    </p>
                ) : (
                    <div className="space-y-3">
                        {tasks.slice(0, 5).map(task => (
                            <div key={task.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-md">
                                <div className="flex-1">
                                    <h4 className="text-sm font-medium text-gray-900">
                                        {task.title}
                                    </h4>
                                    <p className="text-xs text-gray-500 mt-1">
                                        {task.description}
                                    </p>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${task.status === 'completed' ? 'bg-green-100 text-green-800' :
                                        task.status === 'in-progress' ? 'bg-yellow-100 text-yellow-800' :
                                            'bg-gray-100 text-gray-800'
                                        }`}>
                                        {t(`tasks.status.${task.status}`)}
                                    </span>
                                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${task.priority === 'critical' ? 'bg-red-100 text-red-800' :
                                        task.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                                            task.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                                'bg-green-100 text-green-800'
                                        }`}>
                                        {t(`tasks.priority.${task.priority}`)}
                                    </span>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    )
}

export default ProjectDashboard