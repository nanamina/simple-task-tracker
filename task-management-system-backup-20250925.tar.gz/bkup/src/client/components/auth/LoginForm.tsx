import React, { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { AppDispatch, RootState } from '@/client/store'
import { loginUser, clearError } from '@/client/store/slices/authSlice'

interface LoginFormData {
    email: string
    password: string
}

/**
 * Login form component that handles user authentication
 * Provides email/password login with validation and error handling
 */
const LoginForm: React.FC = () => {
    const { t } = useTranslation()
    const dispatch = useDispatch<AppDispatch>()
    const navigate = useNavigate()
    const { isLoading, error, isAuthenticated } = useSelector((state: RootState) => state.auth)

    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm<LoginFormData>()

    // Redirect to dashboard if already authenticated
    useEffect(() => {
        if (isAuthenticated) {
            navigate('/dashboard')
        }
    }, [isAuthenticated, navigate])

    // Clear error when component unmounts
    useEffect(() => {
        return () => {
            dispatch(clearError())
        }
    }, [dispatch])

    const onSubmit = async (data: LoginFormData) => {
        try {
            await dispatch(loginUser(data)).unwrap()
            // Navigation will be handled by the useEffect above
        } catch (error) {
            // Error is handled by the Redux slice
            console.error('Login failed:', error)
        }
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-md w-full space-y-8">
                <div>
                    <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
                        {t('auth.login.title')}
                    </h2>
                    <p className="mt-2 text-center text-sm text-gray-600">
                        {t('auth.login.noAccount')}{' '}
                        <Link
                            to="/register"
                            className="font-medium text-indigo-600 hover:text-indigo-500"
                        >
                            {t('auth.login.signUp')}
                        </Link>
                    </p>
                </div>

                <form className="mt-8 space-y-6" onSubmit={handleSubmit(onSubmit)}>
                    {error && (
                        <div className="rounded-md bg-red-50 p-4">
                            <div className="text-sm text-red-700">{error}</div>
                        </div>
                    )}

                    <div className="space-y-4">
                        <div>
                            <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                                {t('auth.login.email')}
                            </label>
                            <input
                                {...register('email', {
                                    required: t('validation.required', { field: t('auth.login.email') }),
                                    pattern: {
                                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                                        message: t('validation.email'),
                                    },
                                })}
                                type="email"
                                id="email"
                                autoComplete="email"
                                className="mt-1 appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                                placeholder={t('auth.login.email')}
                            />
                            {errors.email && (
                                <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>
                            )}
                        </div>

                        <div>
                            <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                                {t('auth.login.password')}
                            </label>
                            <input
                                {...register('password', {
                                    required: t('validation.required', { field: t('auth.login.password') }),
                                    minLength: {
                                        value: 6,
                                        message: t('validation.minLength', { field: t('auth.login.password'), min: 6 }),
                                    },
                                })}
                                type="password"
                                id="password"
                                autoComplete="current-password"
                                className="mt-1 appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                                placeholder={t('auth.login.password')}
                            />
                            {errors.password && (
                                <p className="mt-1 text-sm text-red-600">{errors.password.message}</p>
                            )}
                        </div>
                    </div>

                    <div>
                        <button
                            type="submit"
                            disabled={isLoading}
                            className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {isLoading ? (
                                <div className="flex items-center">
                                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                    {t('common.loading')}
                                </div>
                            ) : (
                                t('auth.login.submit')
                            )}
                        </button>
                    </div>

                    <div className="text-center">
                        <Link
                            to="/forgot-password"
                            className="text-sm text-indigo-600 hover:text-indigo-500"
                        >
                            {t('auth.login.forgotPassword')}
                        </Link>
                    </div>
                </form>
            </div>
        </div>
    )
}

export default LoginForm