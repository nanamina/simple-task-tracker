import React, { useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { Navigate, useLocation } from 'react-router-dom'
import { RootState, AppDispatch } from '@/client/store'
import { verifyToken } from '@/client/store/slices/authSlice'
import { UserRole } from '@/shared/types'

interface ProtectedRouteProps {
    children: React.ReactNode
    requiredRole?: UserRole
    redirectTo?: string
}

/**
 * Protected route wrapper that ensures user authentication and authorization
 * Redirects to login if not authenticated or to unauthorized page if insufficient permissions
 * 
 * @param children - Components to render if access is granted
 * @param requiredRole - Minimum role required to access the route
 * @param redirectTo - Custom redirect path (defaults to /login)
 */
const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
    children,
    requiredRole,
    redirectTo = '/login'
}) => {
    const dispatch = useDispatch<AppDispatch>()
    const location = useLocation()
    const { isAuthenticated, user, isLoading, token } = useSelector((state: RootState) => state.auth)

    // Verify token on mount if we have a token but no user
    useEffect(() => {
        if (token && !user && !isLoading) {
            dispatch(verifyToken())
        }
    }, [dispatch, token, user, isLoading])

    // Show loading spinner while verifying token
    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
            </div>
        )
    }

    // Redirect to login if not authenticated
    if (!isAuthenticated || !user) {
        return <Navigate to={redirectTo} state={{ from: location }} replace />
    }

    // Check role-based access if required role is specified
    if (requiredRole && !hasRequiredRole(user.role, requiredRole)) {
        return <Navigate to="/unauthorized" replace />
    }

    return <>{children}</>
}

/**
 * Helper function to check if user has required role
 * Role hierarchy: admin > manager > member
 */
function hasRequiredRole(userRole: UserRole, requiredRole: UserRole): boolean {
    const roleHierarchy: Record<UserRole, number> = {
        member: 1,
        manager: 2,
        admin: 3,
    }

    return roleHierarchy[userRole] >= roleHierarchy[requiredRole]
}

export default ProtectedRoute