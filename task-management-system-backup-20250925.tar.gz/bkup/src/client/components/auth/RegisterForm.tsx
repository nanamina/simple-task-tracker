import React, { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { AppDispatch, RootState } from '@/client/store'
import { registerUser, clearError } from '@/client/store/slices/authSlice'

interface RegisterFormData {
    name: string
    email: string
    password: string
    confirmPassword: string
}

/**
 * Registration form component that handles new user registration
 * Provides name, email, password registration with validation and confirmation
 */
const RegisterForm: React.FC = () => {
    const { t } = useTranslation()
    const dispatch = useDispatch<AppDispatch>()
    const navigate = useNavigate()
    const { isLoading, error, isAuthenticated } = useSelector((state: RootState) => state.auth)

    const {
        register,
        handleSubmit,
        watch,
        formState: { errors },
    } = useForm<RegisterFormData>()

    const password = watch('password')

    // Redirect to dashboard if already authenticated
    useEffect(() => {
        if (isAuthenticated) {
            navigate('/dashboard')
        }
    }, [isAuthenticated, navigate])

    // Clear error when component unmounts
    useEffect(() => {
        return () => {
            dispatch(clearError())
        }
    }, [dispatch])

    const onSubmit = async (data: RegisterFormData) => {
        try {
            const { confirmPassword, ...registerData } = data
            await dispatch(registerUser(registerData)).unwrap()
            // Navigation will be handled by the useEffect above
        } catch (error) {
            // Error is handled by the Redux slice
            console.error('Registration failed:', error)
        }
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-md w-full space-y-8">
                <div>
                    <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
                        {t('auth.register.title')}
                    </h2>
                    <p className="mt-2 text-center text-sm text-gray-600">
                        {t('auth.register.hasAccount')}{' '}
                        <Link
                            to="/login"
                            className="font-medium text-indigo-600 hover:text-indigo-500"
                        >
                            {t('auth.register.signIn')}
                        </Link>
                    </p>
                </div>

                <form className="mt-8 space-y-6" onSubmit={handleSubmit(onSubmit)}>
                    {error && (
                        <div className="rounded-md bg-red-50 p-4">
                            <div className="text-sm text-red-700">{error}</div>
                        </div>
                    )}

                    <div className="space-y-4">
                        <div>
                            <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                                {t('auth.register.name')}
                            </label>
                            <input
                                {...register('name', {
                                    required: t('validation.required', { field: t('auth.register.name') }),
                                    minLength: {
                                        value: 2,
                                        message: t('validation.minLength', { field: t('auth.register.name'), min: 2 }),
                                    },
                                })}
                                type="text"
                                id="name"
                                autoComplete="name"
                                className="mt-1 appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                                placeholder={t('auth.register.name')}
                            />
                            {errors.name && (
                                <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
                            )}
                        </div>

                        <div>
                            <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                                {t('auth.register.email')}
                            </label>
                            <input
                                {...register('email', {
                                    required: t('validation.required', { field: t('auth.register.email') }),
                                    pattern: {
                                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                                        message: t('validation.email'),
                                    },
                                })}
                                type="email"
                                id="email"
                                autoComplete="email"
                                className="mt-1 appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                                placeholder={t('auth.register.email')}
                            />
                            {errors.email && (
                                <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>
                            )}
                        </div>

                        <div>
                            <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                                {t('auth.register.password')}
                            </label>
                            <input
                                {...register('password', {
                                    required: t('validation.required', { field: t('auth.register.password') }),
                                    minLength: {
                                        value: 6,
                                        message: t('validation.minLength', { field: t('auth.register.password'), min: 6 }),
                                    },
                                })}
                                type="password"
                                id="password"
                                autoComplete="new-password"
                                className="mt-1 appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                                placeholder={t('auth.register.password')}
                            />
                            {errors.password && (
                                <p className="mt-1 text-sm text-red-600">{errors.password.message}</p>
                            )}
                        </div>

                        <div>
                            <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
                                {t('auth.register.confirmPassword')}
                            </label>
                            <input
                                {...register('confirmPassword', {
                                    required: t('validation.required', { field: t('auth.register.confirmPassword') }),
                                    validate: (value) =>
                                        value === password || t('validation.passwordMatch'),
                                })}
                                type="password"
                                id="confirmPassword"
                                autoComplete="new-password"
                                className="mt-1 appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                                placeholder={t('auth.register.confirmPassword')}
                            />
                            {errors.confirmPassword && (
                                <p className="mt-1 text-sm text-red-600">{errors.confirmPassword.message}</p>
                            )}
                        </div>
                    </div>

                    <div>
                        <button
                            type="submit"
                            disabled={isLoading}
                            className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {isLoading ? (
                                <div className="flex items-center">
                                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                    {t('common.loading')}
                                </div>
                            ) : (
                                t('auth.register.submit')
                            )}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    )
}

export default RegisterForm