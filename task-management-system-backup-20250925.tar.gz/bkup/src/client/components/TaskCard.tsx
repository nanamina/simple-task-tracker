import React from 'react'
import { Task, TaskStatus } from '@/shared/types'
import { useTranslation } from '@/client/hooks/useTranslation'
import { useFormatting } from '@/client/hooks/useFormatting'
import { highlightSearchTerm } from '@/client/utils/searchHighlight'

interface TaskCardProps {
    task: Task
    onStatusChange: (taskId: string, status: TaskStatus) => void
    onEdit: (task: Task) => void
    onDelete: (taskId: string) => void
    onAssign?: (taskId: string) => void
    highlightTerm?: string
}

/**
 * TaskCard component displays individual task information
 * Supports status updates, editing, and deletion
 */
export const TaskCard: React.FC<TaskCardProps> = ({
    task,
    onStatusChange,
    onEdit,
    onDelete,
    onAssign,
    highlightTerm,
}) => {
    const { t } = useTranslation()
    const { formatDate } = useFormatting()

    // Get priority color classes
    const getPriorityColor = (priority: Task['priority']) => {
        switch (priority) {
            case 'critical':
                return 'bg-red-100 text-red-800 border-red-200'
            case 'high':
                return 'bg-orange-100 text-orange-800 border-orange-200'
            case 'medium':
                return 'bg-yellow-100 text-yellow-800 border-yellow-200'
            case 'low':
                return 'bg-green-100 text-green-800 border-green-200'
            default:
                return 'bg-gray-100 text-gray-800 border-gray-200'
        }
    }

    // Get status color classes
    const getStatusColor = (status: TaskStatus) => {
        switch (status) {
            case 'completed':
                return 'bg-green-100 text-green-800 border-green-200'
            case 'in-progress':
                return 'bg-blue-100 text-blue-800 border-blue-200'
            case 'todo':
                return 'bg-gray-100 text-gray-800 border-gray-200'
            default:
                return 'bg-gray-100 text-gray-800 border-gray-200'
        }
    }

    // Check if task is overdue
    const isOverdue = task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'completed'

    // Handle status change
    const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newStatus = e.target.value as TaskStatus
        onStatusChange(task.id, newStatus)
    }

    // Handle delete with confirmation
    const handleDelete = () => {
        if (window.confirm(t('tasks.messages.confirmDelete'))) {
            onDelete(task.id)
        }
    }

    return (
        <div className={`bg-white rounded-lg shadow-md border-l-4 p-4 hover:shadow-lg transition-shadow ${isOverdue ? 'border-l-red-500' : 'border-l-blue-500'
            }`}>
            {/* Header with title and actions */}
            <div className="flex justify-between items-start mb-3">
                <h3 className="text-lg font-semibold text-gray-900 flex-1 mr-2">
                    {highlightTerm ? (
                        <span dangerouslySetInnerHTML={{ __html: highlightSearchTerm(task.title, highlightTerm) }} />
                    ) : (
                        task.title
                    )}
                    {isOverdue && (
                        <span className="ml-2 text-xs bg-red-100 text-red-800 px-2 py-1 rounded-full">
                            {t('tasks.filters.overdue')}
                        </span>
                    )}
                </h3>
                <div className="flex space-x-2">
                    <button
                        onClick={() => onEdit(task)}
                        className="text-blue-600 hover:text-blue-800 text-sm"
                        title={t('common.edit')}
                    >
                        ✏️
                    </button>
                    <button
                        onClick={handleDelete}
                        className="text-red-600 hover:text-red-800 text-sm"
                        title={t('common.delete')}
                    >
                        🗑️
                    </button>
                </div>
            </div>

            {/* Description */}
            {task.description && (
                <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                    {highlightTerm ? (
                        <span dangerouslySetInnerHTML={{ __html: highlightSearchTerm(task.description, highlightTerm) }} />
                    ) : (
                        task.description
                    )}
                </p>
            )}

            {/* Status and Priority badges */}
            <div className="flex flex-wrap gap-2 mb-3">
                <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(task.status)}`}>
                    {t(`tasks.status.${task.status === 'in-progress' ? 'inProgress' : task.status}`)}
                </span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getPriorityColor(task.priority)}`}>
                    {t(`tasks.priority.${task.priority}`)}
                </span>
            </div>

            {/* Task details */}
            <div className="space-y-2 text-sm text-gray-600">
                {task.dueDate && (
                    <div className="flex justify-between">
                        <span>{t('tasks.fields.dueDate')}:</span>
                        <span className={isOverdue ? 'text-red-600 font-medium' : ''}>
                            {formatDate(new Date(task.dueDate))}
                        </span>
                    </div>
                )}

                {task.assigneeId && (
                    <div className="flex justify-between">
                        <span>{t('tasks.fields.assignee')}:</span>
                        <span>{task.assigneeId}</span>
                    </div>
                )}

                <div className="flex justify-between">
                    <span>{t('tasks.fields.createdAt')}:</span>
                    <span>{formatDate(new Date(task.createdAt))}</span>
                </div>
            </div>

            {/* Status update dropdown */}
            <div className="mt-4 pt-3 border-t border-gray-200">
                <div className="flex items-center justify-between">
                    <label htmlFor={`status-${task.id}`} className="text-sm font-medium text-gray-700">
                        {t('tasks.fields.status')}:
                    </label>
                    <select
                        id={`status-${task.id}`}
                        value={task.status}
                        onChange={handleStatusChange}
                        className="ml-2 text-sm border border-gray-300 rounded-md px-2 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                        <option value="todo">{t('tasks.status.todo')}</option>
                        <option value="in-progress">{t('tasks.status.inProgress')}</option>
                        <option value="completed">{t('tasks.status.completed')}</option>
                    </select>
                </div>

                {/* Assign button if task is unassigned */}
                {!task.assigneeId && onAssign && (
                    <button
                        onClick={() => onAssign(task.id)}
                        className="mt-2 w-full text-sm bg-blue-50 text-blue-700 border border-blue-200 rounded-md px-3 py-1 hover:bg-blue-100 transition-colors"
                    >
                        {t('tasks.assign')}
                    </button>
                )}
            </div>
        </div>
    )
}