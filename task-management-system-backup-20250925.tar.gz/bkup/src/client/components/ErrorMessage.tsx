import React from 'react'
import { useTranslation } from 'react-i18next'
import { ProcessedError } from '../utils/errorHandling'

interface ErrorMessageProps {
    error: ProcessedError
    onRetry?: () => void
    onDismiss?: () => void
    className?: string
    variant?: 'inline' | 'banner' | 'modal'
}

/**
 * Reusable error message component with different display variants
 * Supports internationalization and retry functionality
 */
export function ErrorMessage({
    error,
    onRetry,
    onDismiss,
    className = '',
    variant = 'inline'
}: ErrorMessageProps) {
    const { t } = useTranslation()

    const baseClasses = 'rounded-md p-4'
    const variantClasses = {
        inline: 'bg-red-50 border border-red-200',
        banner: 'bg-red-100 border-l-4 border-red-500',
        modal: 'bg-white border border-red-300 shadow-lg'
    }

    return (
        <div className={`${baseClasses} ${variantClasses[variant]} ${className}`}>
            <div className="flex">
                {/* Error icon */}
                <div className="flex-shrink-0">
                    <svg
                        className="h-5 w-5 text-red-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"
                        />
                    </svg>
                </div>

                {/* Error content */}
                <div className="ml-3 flex-1">
                    <h3 className="text-sm font-medium text-red-800">
                        {error.title}
                    </h3>
                    <div className="mt-2 text-sm text-red-700">
                        <p>{error.message}</p>
                    </div>

                    {/* Action buttons */}
                    {(onRetry || onDismiss) && (
                        <div className="mt-4 flex space-x-3">
                            {onRetry && error.isRetryable && (
                                <button
                                    type="button"
                                    onClick={onRetry}
                                    className="text-sm font-medium text-red-800 hover:text-red-900 underline"
                                >
                                    {t('errors.actions.retry')}
                                </button>
                            )}
                            {onDismiss && (
                                <button
                                    type="button"
                                    onClick={onDismiss}
                                    className="text-sm font-medium text-red-800 hover:text-red-900 underline"
                                >
                                    {t('errors.actions.dismiss')}
                                </button>
                            )}
                        </div>
                    )}
                </div>

                {/* Dismiss button */}
                {onDismiss && (
                    <div className="ml-auto pl-3">
                        <div className="-mx-1.5 -my-1.5">
                            <button
                                type="button"
                                onClick={onDismiss}
                                className="inline-flex rounded-md p-1.5 text-red-500 hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-red-600 focus:ring-offset-2 focus:ring-offset-red-50"
                            >
                                <span className="sr-only">{t('errors.actions.dismiss')}</span>
                                <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M6 18L18 6M6 6l12 12"
                                    />
                                </svg>
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    )
}

interface NetworkErrorProps {
    onRetry?: () => void
    className?: string
}

/**
 * Specialized component for network connectivity errors
 */
export function NetworkError({ onRetry, className = '' }: NetworkErrorProps) {
    const { t } = useTranslation()

    return (
        <div className={`bg-yellow-50 border border-yellow-200 rounded-md p-4 ${className}`}>
            <div className="flex">
                <div className="flex-shrink-0">
                    <svg
                        className="h-5 w-5 text-yellow-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                    </svg>
                </div>
                <div className="ml-3">
                    <h3 className="text-sm font-medium text-yellow-800">
                        {t('errors.network.title')}
                    </h3>
                    <div className="mt-2 text-sm text-yellow-700">
                        <p>{t('errors.network.offline')}</p>
                    </div>
                    {onRetry && (
                        <div className="mt-4">
                            <button
                                type="button"
                                onClick={onRetry}
                                className="text-sm font-medium text-yellow-800 hover:text-yellow-900 underline"
                            >
                                {t('errors.actions.retry')}
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}

interface LoadingErrorProps {
    message?: string
    onRetry?: () => void
    className?: string
}

/**
 * Component for displaying loading/fetch errors
 */
export function LoadingError({ message, onRetry, className = '' }: LoadingErrorProps) {
    const { t } = useTranslation()

    return (
        <div className={`text-center py-8 ${className}`}>
            <div className="mx-auto h-12 w-12 text-gray-400">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                </svg>
            </div>
            <h3 className="mt-4 text-sm font-medium text-gray-900">
                {t('errors.loading.title')}
            </h3>
            <p className="mt-2 text-sm text-gray-500">
                {message || t('errors.loading.message')}
            </p>
            {onRetry && (
                <div className="mt-4">
                    <button
                        type="button"
                        onClick={onRetry}
                        className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                        {t('errors.actions.retry')}
                    </button>
                </div>
            )}
        </div>
    )
}

interface FormErrorProps {
    errors: Record<string, string>
    className?: string
}

/**
 * Component for displaying form validation errors
 */
export function FormError({ errors, className = '' }: FormErrorProps) {
    const { t } = useTranslation()
    const errorEntries = Object.entries(errors)

    if (errorEntries.length === 0) {
        return null
    }

    return (
        <div className={`bg-red-50 border border-red-200 rounded-md p-4 ${className}`}>
            <div className="flex">
                <div className="flex-shrink-0">
                    <svg
                        className="h-5 w-5 text-red-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"
                        />
                    </svg>
                </div>
                <div className="ml-3">
                    <h3 className="text-sm font-medium text-red-800">
                        {errorEntries.length === 1
                            ? t('errors.validation.singleError')
                            : t('errors.validation.multipleErrors', { count: errorEntries.length })
                        }
                    </h3>
                    <div className="mt-2 text-sm text-red-700">
                        {errorEntries.length === 1 ? (
                            <p>{errorEntries[0][1]}</p>
                        ) : (
                            <ul className="list-disc list-inside space-y-1">
                                {errorEntries.map(([field, message]) => (
                                    <li key={field}>{message}</li>
                                ))}
                            </ul>
                        )}
                    </div>
                </div>
            </div>
        </div>
    )
}