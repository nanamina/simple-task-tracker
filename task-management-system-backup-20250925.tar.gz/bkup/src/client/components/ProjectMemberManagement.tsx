import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useTranslation } from 'react-i18next'
import { RootState, AppDispatch } from '@/client/store'
import {
    addProjectMember,
    removeProjectMember,
    setAvailableUsers,
    clearError,
} from '@/client/store/slices/projectSlice'
import { User, Project } from '@/shared/types'

interface ProjectMemberManagementProps {
    project: Project
}

/**
 * ProjectMemberManagement component - handles adding and removing project members
 * Provides interface for managing project team membership
 */
const ProjectMemberManagement: React.FC<ProjectMemberManagementProps> = ({ project }) => {
    const dispatch = useDispatch<AppDispatch>()
    const { t } = useTranslation()

    const { availableUsers, loading, error } = useSelector((state: RootState) => state.projects)
    const { user: currentUser } = useSelector((state: RootState) => state.auth)

    const [selectedUserId, setSelectedUserId] = useState('')
    const [showAddMember, setShowAddMember] = useState(false)

    useEffect(() => {
        // Fetch available users when component mounts
        fetchAvailableUsers()
        dispatch(clearError())
    }, [dispatch])

    /**
     * Fetches list of users that can be added to projects
     */
    const fetchAvailableUsers = async () => {
        try {
            const response = await fetch('/api/users')
            if (response.ok) {
                const users = await response.json()
                dispatch(setAvailableUsers(users))
            }
        } catch (error) {
            console.error('Failed to fetch users:', error)
        }
    }

    /**
     * Gets user details by ID from available users list
     */
    const getUserById = (userId: string): User | undefined => {
        const users = Array.isArray(availableUsers) ? availableUsers : []
        return users.find(user => user.id === userId)
    }

    /**
     * Gets users that are not currently project members
     */
    const getNonMemberUsers = (): User[] => {
        const users = Array.isArray(availableUsers) ? availableUsers : []
        return users.filter(user => !project.members.includes(user.id))
    }

    /**
     * Handles adding a new member to the project
     */
    const handleAddMember = async () => {
        if (!selectedUserId) return

        try {
            await dispatch(addProjectMember({
                projectId: project.id,
                userId: selectedUserId
            })).unwrap()

            setSelectedUserId('')
            setShowAddMember(false)
        } catch (error) {
            console.error('Failed to add member:', error)
        }
    }

    /**
     * Handles removing a member from the project
     */
    const handleRemoveMember = async (userId: string) => {
        const user = getUserById(userId)
        if (!user) return

        if (window.confirm(t('projects.removeMemberConfirm', { name: user.name }))) {
            try {
                await dispatch(removeProjectMember({
                    projectId: project.id,
                    userId
                })).unwrap()
            } catch (error) {
                console.error('Failed to remove member:', error)
            }
        }
    }

    /**
     * Checks if current user can manage project members
     */
    const canManageMembers = currentUser?.role === 'admin' || currentUser?.role === 'manager'

    const nonMemberUsers = getNonMemberUsers()

    return (
        <div className="bg-white shadow rounded-lg p-6">
            <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-medium text-gray-900">
                    {t('projects.members')} ({project.members.length})
                </h3>
                {canManageMembers && nonMemberUsers.length > 0 && (
                    <button
                        onClick={() => setShowAddMember(!showAddMember)}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md text-sm font-medium"
                    >
                        {t('projects.addMember')}
                    </button>
                )}
            </div>

            {/* Error Display */}
            {error && (
                <div className="mb-4 bg-red-50 border border-red-200 rounded-md p-4">
                    <div className="flex">
                        <div className="ml-3">
                            <h3 className="text-sm font-medium text-red-800">
                                {t('common.error')}
                            </h3>
                            <div className="mt-2 text-sm text-red-700">
                                {error}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Add Member Form */}
            {showAddMember && canManageMembers && (
                <div className="mb-6 p-4 bg-gray-50 rounded-md">
                    <h4 className="text-sm font-medium text-gray-900 mb-3">
                        {t('projects.addNewMember')}
                    </h4>
                    <div className="flex gap-3">
                        <select
                            value={selectedUserId}
                            onChange={(e) => setSelectedUserId(e.target.value)}
                            className="flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                        >
                            <option value="">
                                {t('projects.selectUser')}
                            </option>
                            {nonMemberUsers.map(user => (
                                <option key={user.id} value={user.id}>
                                    {user.name} ({user.email}) - {t(`users.role.${user.role}`)}
                                </option>
                            ))}
                        </select>
                        <button
                            onClick={handleAddMember}
                            disabled={!selectedUserId || loading}
                            className="bg-green-600 hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-2 rounded-md text-sm font-medium"
                        >
                            {loading ? t('common.adding') : t('common.add')}
                        </button>
                        <button
                            onClick={() => {
                                setShowAddMember(false)
                                setSelectedUserId('')
                            }}
                            className="bg-gray-300 hover:bg-gray-400 text-gray-700 px-4 py-2 rounded-md text-sm font-medium"
                        >
                            {t('common.cancel')}
                        </button>
                    </div>
                </div>
            )}

            {/* Members List */}
            {project.members.length === 0 ? (
                <div className="text-center py-8">
                    <div className="mx-auto h-12 w-12 text-gray-400">
                        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
                        </svg>
                    </div>
                    <h3 className="mt-2 text-sm font-medium text-gray-900">
                        {t('projects.noMembers')}
                    </h3>
                    <p className="mt-1 text-sm text-gray-500">
                        {t('projects.addMembersToStart')}
                    </p>
                </div>
            ) : (
                <div className="space-y-3">
                    {project.members.map(memberId => {
                        const member = getUserById(memberId)
                        if (!member) return null

                        return (
                            <div key={member.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-md">
                                <div className="flex items-center space-x-3">
                                    <div className="flex-shrink-0">
                                        <div className="h-8 w-8 bg-indigo-500 rounded-full flex items-center justify-center">
                                            <span className="text-sm font-medium text-white">
                                                {member.name.charAt(0).toUpperCase()}
                                            </span>
                                        </div>
                                    </div>
                                    <div>
                                        <p className="text-sm font-medium text-gray-900">
                                            {member.name}
                                        </p>
                                        <p className="text-sm text-gray-500">
                                            {member.email}
                                        </p>
                                    </div>
                                </div>
                                <div className="flex items-center space-x-3">
                                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${member.role === 'admin' ? 'bg-red-100 text-red-800' :
                                        member.role === 'manager' ? 'bg-yellow-100 text-yellow-800' :
                                            'bg-green-100 text-green-800'
                                        }`}>
                                        {t(`users.role.${member.role}`)}
                                    </span>
                                    {canManageMembers && member.id !== currentUser?.id && (
                                        <button
                                            onClick={() => handleRemoveMember(member.id)}
                                            className="text-red-600 hover:text-red-900 text-sm font-medium"
                                        >
                                            {t('common.remove')}
                                        </button>
                                    )}
                                </div>
                            </div>
                        )
                    })}
                </div>
            )}

            {/* No Available Users Message */}
            {canManageMembers && nonMemberUsers.length === 0 && project.members.length > 0 && (
                <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
                    <p className="text-sm text-blue-700">
                        {t('projects.allUsersAreMembers')}
                    </p>
                </div>
            )}
        </div>
    )
}

export default ProjectMemberManagement