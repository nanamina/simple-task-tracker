import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { useTranslation } from '../hooks/useTranslation';
import { User } from '@/shared/types';
import LanguageSwitcher from './LanguageSwitcher';

interface UserProfileProps {
    onClose?: () => void;
}

/**
 * UserProfile component for managing user settings and profile information
 * Allows users to view and edit their profile details including language preferences
 */
export const UserProfile: React.FC<UserProfileProps> = ({ onClose }) => {
    const { t } = useTranslation();
    const dispatch = useDispatch();
    const { user, token } = useSelector((state: RootState) => state.auth);

    const [isEditing, setIsEditing] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [formData, setFormData] = useState({
        name: user?.name || '',
        email: user?.email || '',
        preferredLanguage: user?.preferredLanguage || 'ja' as 'ja' | 'en'
    });

    // Update form data when user changes
    useEffect(() => {
        if (user) {
            setFormData({
                name: user.name,
                email: user.email,
                preferredLanguage: user.preferredLanguage
            });
        }
    }, [user]);

    /**
     * Handle form input changes
     */
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    /**
     * Handle profile update submission
     */
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user || !token) return;

        setIsLoading(true);
        setError(null);

        try {
            const response = await fetch('/api/users/profile', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(formData)
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error?.message || 'Failed to update profile');
            }

            const updatedUser = await response.json();

            // Update Redux store with new user data
            // Note: In a real implementation, you'd dispatch an action to update the user
            // For now, we'll just show success and exit edit mode
            setIsEditing(false);

            // Show success message (you might want to use a toast notification system)
            alert(t('profile.messages.profileUpdated'));

        } catch (err) {
            setError(err instanceof Error ? err.message : 'An error occurred');
        } finally {
            setIsLoading(false);
        }
    };

    /**
     * Cancel editing and reset form
     */
    const handleCancel = () => {
        if (user) {
            setFormData({
                name: user.name,
                email: user.email,
                preferredLanguage: user.preferredLanguage
            });
        }
        setIsEditing(false);
        setError(null);
    };

    if (!user) {
        return (
            <div className="bg-white rounded-lg shadow-md p-6">
                <div className="text-center text-gray-500">
                    {t('common.loading')}
                </div>
            </div>
        );
    }

    return (
        <div className="bg-white rounded-lg shadow-md p-6 max-w-2xl mx-auto">
            {/* Header */}
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900">
                    {t('profile.title')}
                </h2>
                {onClose && (
                    <button
                        onClick={onClose}
                        className="text-gray-400 hover:text-gray-600 transition-colors"
                        aria-label="Close profile"
                    >
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                )}
            </div>

            {/* Error Message */}
            {error && (
                <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
                    {error}
                </div>
            )}

            {/* Profile Form */}
            <form onSubmit={handleSubmit}>
                <div className="space-y-6">
                    {/* Name Field */}
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                            {t('profile.fields.name')}
                        </label>
                        {isEditing ? (
                            <input
                                type="text"
                                id="name"
                                name="name"
                                value={formData.name}
                                onChange={handleInputChange}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                required
                            />
                        ) : (
                            <div className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-md">
                                {user.name}
                            </div>
                        )}
                    </div>

                    {/* Email Field */}
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                            {t('profile.fields.email')}
                        </label>
                        {isEditing ? (
                            <input
                                type="email"
                                id="email"
                                name="email"
                                value={formData.email}
                                onChange={handleInputChange}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                required
                            />
                        ) : (
                            <div className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-md">
                                {user.email}
                            </div>
                        )}
                    </div>

                    {/* Role Field (Read-only) */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            {t('profile.fields.role')}
                        </label>
                        <div className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-md">
                            {t(`profile.roles.${user.role}`)}
                        </div>
                    </div>

                    {/* Language Preference */}
                    <div>
                        <label htmlFor="preferredLanguage" className="block text-sm font-medium text-gray-700 mb-2">
                            {t('profile.fields.preferredLanguage')}
                        </label>
                        {isEditing ? (
                            <select
                                id="preferredLanguage"
                                name="preferredLanguage"
                                value={formData.preferredLanguage}
                                onChange={handleInputChange}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                            >
                                <option value="ja">{t('profile.languages.ja')}</option>
                                <option value="en">{t('profile.languages.en')}</option>
                            </select>
                        ) : (
                            <div className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-md flex items-center justify-between">
                                <span>{t(`profile.languages.${user.preferredLanguage}`)}</span>
                                <LanguageSwitcher />
                            </div>
                        )}
                    </div>

                    {/* Join Date */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            {t('profile.fields.joinedAt')}
                        </label>
                        <div className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-md">
                            {new Date(user.createdAt).toLocaleDateString()}
                        </div>
                    </div>
                </div>

                {/* Action Buttons */}
                <div className="mt-8 flex justify-end space-x-3">
                    {isEditing ? (
                        <>
                            <button
                                type="button"
                                onClick={handleCancel}
                                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                                disabled={isLoading}
                            >
                                {t('common.cancel')}
                            </button>
                            <button
                                type="submit"
                                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
                                disabled={isLoading}
                            >
                                {isLoading ? t('common.saving') : t('common.save')}
                            </button>
                        </>
                    ) : (
                        <button
                            type="button"
                            onClick={() => setIsEditing(true)}
                            className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                        >
                            {t('profile.edit')}
                        </button>
                    )}
                </div>
            </form>
        </div>
    );
};

export default UserProfile;