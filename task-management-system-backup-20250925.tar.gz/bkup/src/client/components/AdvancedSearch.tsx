import React, { useState, useEffect } from 'react'
import { useTranslation } from '@/client/hooks/useTranslation'
import { TaskStatus, TaskPriority } from '@/shared/types'

interface AdvancedSearchProps {
    onSearch: (filters: SearchFilters) => void
    onClear: () => void
    initialFilters?: SearchFilters
    isLoading?: boolean
}

export interface SearchFilters {
    search?: string
    status?: TaskStatus
    priority?: TaskPriority
    assigneeId?: string
    projectId?: string
    isOverdue?: boolean
    isUnassigned?: boolean
    sortBy?: 'createdAt' | 'updatedAt' | 'dueDate' | 'priority' | 'title' | 'relevance'
    sortOrder?: 'asc' | 'desc'
}

/**
 * Advanced search component with multiple filter criteria
 * Provides comprehensive search and filtering capabilities for tasks
 */
export const AdvancedSearch: React.FC<AdvancedSearchProps> = ({
    onSearch,
    onClear,
    initialFilters = {},
    isLoading = false
}) => {
    const { t } = useTranslation()
    const [isExpanded, setIsExpanded] = useState(false)
    const [filters, setFilters] = useState<SearchFilters>(initialFilters)

    // Update filters when initialFilters change
    useEffect(() => {
        setFilters(initialFilters)
    }, [initialFilters])

    // Handle filter changes
    const handleFilterChange = (key: keyof SearchFilters, value: any) => {
        const newFilters = { ...filters, [key]: value }

        // Remove empty values
        if (value === '' || value === undefined || value === null) {
            delete newFilters[key]
        }

        setFilters(newFilters)
    }

    // Handle search submission
    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault()
        onSearch(filters)
    }

    // Handle clear filters
    const handleClear = () => {
        setFilters({})
        onClear()
    }

    // Check if any advanced filters are active
    const hasAdvancedFilters = Object.keys(filters).some(key =>
        key !== 'search' && key !== 'sortBy' && key !== 'sortOrder' && filters[key as keyof SearchFilters]
    )

    return (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
            <form onSubmit={handleSearch}>
                {/* Basic search row */}
                <div className="flex flex-col sm:flex-row gap-4 mb-4">
                    {/* Search input */}
                    <div className="flex-1">
                        <label htmlFor="search" className="sr-only">
                            {t('common.search')}
                        </label>
                        <div className="relative">
                            <input
                                type="text"
                                id="search"
                                value={filters.search || ''}
                                onChange={(e) => handleFilterChange('search', e.target.value)}
                                placeholder={t('search.placeholder')}
                                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                            />
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <svg className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                </svg>
                            </div>
                        </div>
                    </div>

                    {/* Sort options */}
                    <div className="flex gap-2">
                        <select
                            value={filters.sortBy || 'createdAt'}
                            onChange={(e) => handleFilterChange('sortBy', e.target.value)}
                            className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                            <option value="createdAt">{t('tasks.fields.createdAt')}</option>
                            <option value="updatedAt">{t('tasks.fields.updatedAt')}</option>
                            <option value="dueDate">{t('tasks.fields.dueDate')}</option>
                            <option value="priority">{t('tasks.fields.priority')}</option>
                            <option value="title">{t('tasks.fields.title')}</option>
                            {filters.search && <option value="relevance">{t('search.relevance')}</option>}
                        </select>

                        <button
                            type="button"
                            onClick={() => handleFilterChange('sortOrder', filters.sortOrder === 'asc' ? 'desc' : 'asc')}
                            className="px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            title={t('search.sortOrder')}
                        >
                            {filters.sortOrder === 'asc' ? '↑' : '↓'}
                        </button>
                    </div>

                    {/* Action buttons */}
                    <div className="flex gap-2">
                        <button
                            type="submit"
                            disabled={isLoading}
                            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                        >
                            {isLoading ? t('common.searching') : t('common.search')}
                        </button>

                        <button
                            type="button"
                            onClick={() => setIsExpanded(!isExpanded)}
                            className={`px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${hasAdvancedFilters || isExpanded
                                    ? 'border-blue-300 bg-blue-50 text-blue-700'
                                    : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                                }`}
                        >
                            {t('search.advanced')}
                            <svg
                                className={`ml-1 h-4 w-4 inline transition-transform ${isExpanded ? 'rotate-180' : ''}`}
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                            >
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>
                    </div>
                </div>

                {/* Advanced filters */}
                {isExpanded && (
                    <div className="border-t border-gray-200 pt-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                            {/* Status filter */}
                            <div>
                                <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-1">
                                    {t('tasks.fields.status')}
                                </label>
                                <select
                                    id="status"
                                    value={filters.status || ''}
                                    onChange={(e) => handleFilterChange('status', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                >
                                    <option value="">{t('tasks.filters.all')}</option>
                                    <option value="todo">{t('tasks.status.todo')}</option>
                                    <option value="in-progress">{t('tasks.status.inProgress')}</option>
                                    <option value="completed">{t('tasks.status.completed')}</option>
                                </select>
                            </div>

                            {/* Priority filter */}
                            <div>
                                <label htmlFor="priority" className="block text-sm font-medium text-gray-700 mb-1">
                                    {t('tasks.fields.priority')}
                                </label>
                                <select
                                    id="priority"
                                    value={filters.priority || ''}
                                    onChange={(e) => handleFilterChange('priority', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                >
                                    <option value="">{t('tasks.filters.all')}</option>
                                    <option value="low">{t('tasks.priority.low')}</option>
                                    <option value="medium">{t('tasks.priority.medium')}</option>
                                    <option value="high">{t('tasks.priority.high')}</option>
                                    <option value="critical">{t('tasks.priority.critical')}</option>
                                </select>
                            </div>

                            {/* Assignee filter */}
                            <div>
                                <label htmlFor="assignee" className="block text-sm font-medium text-gray-700 mb-1">
                                    {t('tasks.fields.assignee')}
                                </label>
                                <select
                                    id="assignee"
                                    value={filters.assigneeId || ''}
                                    onChange={(e) => handleFilterChange('assigneeId', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                >
                                    <option value="">{t('tasks.filters.all')}</option>
                                    <option value="assigned">{t('tasks.filters.assigned')}</option>
                                    <option value="unassigned">{t('tasks.filters.unassigned')}</option>
                                </select>
                            </div>

                            {/* Project filter */}
                            <div>
                                <label htmlFor="project" className="block text-sm font-medium text-gray-700 mb-1">
                                    {t('tasks.fields.project')}
                                </label>
                                <select
                                    id="project"
                                    value={filters.projectId || ''}
                                    onChange={(e) => handleFilterChange('projectId', e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                >
                                    <option value="">{t('tasks.filters.all')}</option>
                                    {/* TODO: Load actual projects */}
                                </select>
                            </div>
                        </div>

                        {/* Special filters */}
                        <div className="flex flex-wrap gap-4 mb-4">
                            <label className="flex items-center">
                                <input
                                    type="checkbox"
                                    checked={filters.isOverdue || false}
                                    onChange={(e) => handleFilterChange('isOverdue', e.target.checked)}
                                    className="mr-2 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                />
                                <span className="text-sm text-gray-700">{t('tasks.filters.overdue')}</span>
                            </label>

                            <label className="flex items-center">
                                <input
                                    type="checkbox"
                                    checked={filters.isUnassigned || false}
                                    onChange={(e) => handleFilterChange('isUnassigned', e.target.checked)}
                                    className="mr-2 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                />
                                <span className="text-sm text-gray-700">{t('tasks.filters.unassigned')}</span>
                            </label>
                        </div>

                        {/* Clear filters */}
                        {(Object.keys(filters).length > 0) && (
                            <div className="flex justify-end">
                                <button
                                    type="button"
                                    onClick={handleClear}
                                    className="px-3 py-1 text-sm text-gray-600 hover:text-gray-800 underline"
                                >
                                    {t('search.clearFilters')}
                                </button>
                            </div>
                        )}
                    </div>
                )}
            </form>
        </div>
    )
}