import React, { useState, useEffect } from 'react'
import { Task, TaskStatus, TaskPriority } from '@/shared/types'
import { useTranslation } from '@/client/hooks/useTranslation'

interface TaskFormProps {
    task?: Task | null
    onSubmit: (taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'createdBy'>) => void
    onCancel: () => void
    loading?: boolean
}

/**
 * TaskForm component for creating and editing tasks
 * Supports all task fields with validation
 */
export const TaskForm: React.FC<TaskFormProps> = ({
    task,
    onSubmit,
    onCancel,
    loading = false,
}) => {
    const { t } = useTranslation()

    // Form state
    const [formData, setFormData] = useState({
        title: '',
        description: '',
        status: 'todo' as TaskStatus,
        priority: 'medium' as TaskPriority,
        dueDate: '',
        assigneeId: '',
        projectId: '',
    })

    const [errors, setErrors] = useState<Record<string, string>>({})

    // Initialize form data when task prop changes
    useEffect(() => {
        if (task) {
            setFormData({
                title: task.title,
                description: task.description,
                status: task.status,
                priority: task.priority,
                dueDate: task.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : '',
                assigneeId: task.assigneeId || '',
                projectId: task.projectId || '',
            })
        } else {
            // Reset form for new task
            setFormData({
                title: '',
                description: '',
                status: 'todo',
                priority: 'medium',
                dueDate: '',
                assigneeId: '',
                projectId: '',
            })
        }
        setErrors({})
    }, [task])

    // Handle input changes
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target
        setFormData(prev => ({
            ...prev,
            [name]: value,
        }))

        // Clear error when user starts typing
        if (errors[name]) {
            setErrors(prev => ({
                ...prev,
                [name]: '',
            }))
        }
    }

    // Validate form
    const validateForm = () => {
        const newErrors: Record<string, string> = {}

        if (!formData.title.trim()) {
            newErrors.title = t('validation.required', { field: t('tasks.fields.title') })
        }

        if (!formData.description.trim()) {
            newErrors.description = t('validation.required', { field: t('tasks.fields.description') })
        }

        if (formData.dueDate) {
            const dueDate = new Date(formData.dueDate)
            const today = new Date()
            today.setHours(0, 0, 0, 0)

            if (dueDate < today) {
                newErrors.dueDate = t('validation.pastDate')
            }
        }

        setErrors(newErrors)
        return Object.keys(newErrors).length === 0
    }

    // Handle form submission
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault()

        if (!validateForm()) {
            return
        }

        const taskData = {
            title: formData.title.trim(),
            description: formData.description.trim(),
            status: formData.status,
            priority: formData.priority,
            dueDate: formData.dueDate ? new Date(formData.dueDate) : undefined,
            assigneeId: formData.assigneeId || undefined,
            projectId: formData.projectId || undefined,
        }

        onSubmit(taskData)
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
                <div className="p-6">
                    <h2 className="text-xl font-semibold text-gray-900 mb-4">
                        {task ? t('tasks.edit') : t('tasks.create')}
                    </h2>

                    <form onSubmit={handleSubmit} className="space-y-4">
                        {/* Title */}
                        <div>
                            <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                                {t('tasks.fields.title')} *
                            </label>
                            <input
                                type="text"
                                id="title"
                                name="title"
                                value={formData.title}
                                onChange={handleChange}
                                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.title ? 'border-red-500' : 'border-gray-300'
                                    }`}
                                placeholder={t('tasks.fields.title')}
                            />
                            {errors.title && (
                                <p className="mt-1 text-sm text-red-600">{errors.title}</p>
                            )}
                        </div>

                        {/* Description */}
                        <div>
                            <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                                {t('tasks.fields.description')} *
                            </label>
                            <textarea
                                id="description"
                                name="description"
                                value={formData.description}
                                onChange={handleChange}
                                rows={3}
                                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.description ? 'border-red-500' : 'border-gray-300'
                                    }`}
                                placeholder={t('tasks.fields.description')}
                            />
                            {errors.description && (
                                <p className="mt-1 text-sm text-red-600">{errors.description}</p>
                            )}
                        </div>

                        {/* Status and Priority row */}
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-1">
                                    {t('tasks.fields.status')}
                                </label>
                                <select
                                    id="status"
                                    name="status"
                                    value={formData.status}
                                    onChange={handleChange}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                >
                                    <option value="todo">{t('tasks.status.todo')}</option>
                                    <option value="in-progress">{t('tasks.status.inProgress')}</option>
                                    <option value="completed">{t('tasks.status.completed')}</option>
                                </select>
                            </div>

                            <div>
                                <label htmlFor="priority" className="block text-sm font-medium text-gray-700 mb-1">
                                    {t('tasks.fields.priority')}
                                </label>
                                <select
                                    id="priority"
                                    name="priority"
                                    value={formData.priority}
                                    onChange={handleChange}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                >
                                    <option value="low">{t('tasks.priority.low')}</option>
                                    <option value="medium">{t('tasks.priority.medium')}</option>
                                    <option value="high">{t('tasks.priority.high')}</option>
                                    <option value="critical">{t('tasks.priority.critical')}</option>
                                </select>
                            </div>
                        </div>

                        {/* Due Date */}
                        <div>
                            <label htmlFor="dueDate" className="block text-sm font-medium text-gray-700 mb-1">
                                {t('tasks.fields.dueDate')}
                            </label>
                            <input
                                type="date"
                                id="dueDate"
                                name="dueDate"
                                value={formData.dueDate}
                                onChange={handleChange}
                                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.dueDate ? 'border-red-500' : 'border-gray-300'
                                    }`}
                            />
                            {errors.dueDate && (
                                <p className="mt-1 text-sm text-red-600">{errors.dueDate}</p>
                            )}
                        </div>

                        {/* Assignee ID (simplified for now) */}
                        <div>
                            <label htmlFor="assigneeId" className="block text-sm font-medium text-gray-700 mb-1">
                                {t('tasks.fields.assignee')}
                            </label>
                            <input
                                type="text"
                                id="assigneeId"
                                name="assigneeId"
                                value={formData.assigneeId}
                                onChange={handleChange}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder={t('tasks.fields.assignee')}
                            />
                        </div>

                        {/* Project ID (simplified for now) */}
                        <div>
                            <label htmlFor="projectId" className="block text-sm font-medium text-gray-700 mb-1">
                                {t('tasks.fields.project')}
                            </label>
                            <input
                                type="text"
                                id="projectId"
                                name="projectId"
                                value={formData.projectId}
                                onChange={handleChange}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder={t('tasks.fields.project')}
                            />
                        </div>

                        {/* Form actions */}
                        <div className="flex justify-end space-x-3 pt-4">
                            <button
                                type="button"
                                onClick={onCancel}
                                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500"
                                disabled={loading}
                            >
                                {t('common.cancel')}
                            </button>
                            <button
                                type="submit"
                                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                                disabled={loading}
                            >
                                {loading ? t('common.loading') : (task ? t('common.update') : t('common.create'))}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}