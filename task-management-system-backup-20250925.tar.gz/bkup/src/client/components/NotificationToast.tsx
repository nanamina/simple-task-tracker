import React, { useEffect, useState } from 'react';
import { useTranslation } from '../hooks/useTranslation';

export interface ToastNotification {
    id: string;
    type: 'success' | 'error' | 'warning' | 'info';
    title: string;
    message: string;
    duration?: number; // Auto-dismiss duration in milliseconds (0 = no auto-dismiss)
    action?: {
        label: string;
        onClick: () => void;
    };
}

interface NotificationToastProps {
    notification: ToastNotification;
    onDismiss: (id: string) => void;
}

interface ToastContainerProps {
    notifications: ToastNotification[];
    onDismiss: (id: string) => void;
    position?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left' | 'top-center' | 'bottom-center';
    maxVisible?: number;
}

/**
 * Individual toast notification component
 */
const NotificationToast: React.FC<NotificationToastProps> = ({ notification, onDismiss }) => {
    const { t } = useTranslation();
    const [isVisible, setIsVisible] = useState(false);
    const [isExiting, setIsExiting] = useState(false);

    // Auto-dismiss timer
    useEffect(() => {
        if (notification.duration && notification.duration > 0) {
            const timer = setTimeout(() => {
                handleDismiss();
            }, notification.duration);

            return () => clearTimeout(timer);
        }
    }, [notification.duration]);

    // Animation effect
    useEffect(() => {
        // Trigger entrance animation
        const timer = setTimeout(() => setIsVisible(true), 100);
        return () => clearTimeout(timer);
    }, []);

    /**
     * Get styles based on notification type
     */
    const getTypeStyles = () => {
        switch (notification.type) {
            case 'success':
                return {
                    bg: 'bg-green-50',
                    border: 'border-green-200',
                    icon: 'text-green-500',
                    title: 'text-green-800',
                    message: 'text-green-700'
                };
            case 'error':
                return {
                    bg: 'bg-red-50',
                    border: 'border-red-200',
                    icon: 'text-red-500',
                    title: 'text-red-800',
                    message: 'text-red-700'
                };
            case 'warning':
                return {
                    bg: 'bg-yellow-50',
                    border: 'border-yellow-200',
                    icon: 'text-yellow-500',
                    title: 'text-yellow-800',
                    message: 'text-yellow-700'
                };
            case 'info':
            default:
                return {
                    bg: 'bg-blue-50',
                    border: 'border-blue-200',
                    icon: 'text-blue-500',
                    title: 'text-blue-800',
                    message: 'text-blue-700'
                };
        }
    };

    /**
     * Get icon based on notification type
     */
    const getIcon = () => {
        const styles = getTypeStyles();

        switch (notification.type) {
            case 'success':
                return (
                    <svg className={`w-5 h-5 ${styles.icon}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                );
            case 'error':
                return (
                    <svg className={`w-5 h-5 ${styles.icon}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                );
            case 'warning':
                return (
                    <svg className={`w-5 h-5 ${styles.icon}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16c-.77.833.192 2.5 1.732 2.5z" />
                    </svg>
                );
            case 'info':
            default:
                return (
                    <svg className={`w-5 h-5 ${styles.icon}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                );
        }
    };

    /**
     * Handle dismiss with exit animation
     */
    const handleDismiss = () => {
        setIsExiting(true);
        setTimeout(() => {
            onDismiss(notification.id);
        }, 300); // Match animation duration
    };

    /**
     * Handle action button click
     */
    const handleActionClick = () => {
        if (notification.action) {
            notification.action.onClick();
            handleDismiss();
        }
    };

    const styles = getTypeStyles();

    return (
        <div
            className={`
                max-w-sm w-full shadow-lg rounded-lg pointer-events-auto ring-1 ring-black ring-opacity-5 overflow-hidden
                transform transition-all duration-300 ease-in-out
                ${styles.bg} ${styles.border}
                ${isVisible && !isExiting ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'}
                ${isExiting ? 'translate-x-full opacity-0' : ''}
            `}
        >
            <div className="p-4">
                <div className="flex items-start">
                    {/* Icon */}
                    <div className="flex-shrink-0">
                        {getIcon()}
                    </div>

                    {/* Content */}
                    <div className="ml-3 w-0 flex-1 pt-0.5">
                        <p className={`text-sm font-medium ${styles.title}`}>
                            {notification.title}
                        </p>
                        <p className={`mt-1 text-sm ${styles.message}`}>
                            {notification.message}
                        </p>

                        {/* Action button */}
                        {notification.action && (
                            <div className="mt-3">
                                <button
                                    onClick={handleActionClick}
                                    className={`text-sm font-medium ${styles.title} hover:opacity-75 transition-opacity`}
                                >
                                    {notification.action.label}
                                </button>
                            </div>
                        )}
                    </div>

                    {/* Dismiss button */}
                    <div className="ml-4 flex-shrink-0 flex">
                        <button
                            onClick={handleDismiss}
                            className={`rounded-md inline-flex ${styles.message} hover:opacity-75 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white focus:ring-gray-500`}
                        >
                            <span className="sr-only">Close</span>
                            <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

/**
 * Toast container component that manages multiple toast notifications
 */
export const ToastContainer: React.FC<ToastContainerProps> = ({
    notifications,
    onDismiss,
    position = 'top-right',
    maxVisible = 5
}) => {
    // Limit the number of visible notifications
    const visibleNotifications = notifications.slice(0, maxVisible);

    /**
     * Get position classes based on position prop
     */
    const getPositionClasses = () => {
        switch (position) {
            case 'top-left':
                return 'top-0 left-0 items-start';
            case 'top-center':
                return 'top-0 left-1/2 transform -translate-x-1/2 items-center';
            case 'top-right':
                return 'top-0 right-0 items-end';
            case 'bottom-left':
                return 'bottom-0 left-0 items-start';
            case 'bottom-center':
                return 'bottom-0 left-1/2 transform -translate-x-1/2 items-center';
            case 'bottom-right':
                return 'bottom-0 right-0 items-end';
            default:
                return 'top-0 right-0 items-end';
        }
    };

    if (visibleNotifications.length === 0) {
        return null;
    }

    return (
        <div
            className={`fixed z-50 p-6 space-y-4 pointer-events-none flex flex-col ${getPositionClasses()}`}
            aria-live="assertive"
        >
            {visibleNotifications.map((notification) => (
                <NotificationToast
                    key={notification.id}
                    notification={notification}
                    onDismiss={onDismiss}
                />
            ))}
        </div>
    );
};

export default ToastContainer;