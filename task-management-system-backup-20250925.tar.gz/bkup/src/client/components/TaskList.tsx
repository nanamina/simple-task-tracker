import React, { useState, useEffect } from 'react'
import { Task, TaskStatus, TaskPriority } from '@/shared/types'
import { useTranslation } from '@/client/hooks/useTranslation'
import { useTasks } from '@/client/hooks/useTasks'
import { TaskCard } from './TaskCard'
import { TaskForm } from './TaskForm'
import { AdvancedSearch, SearchFilters } from './AdvancedSearch'
import { SearchResults } from './SearchResults'

/**
 * TaskList component with filtering, sorting, and CRUD operations
 * Main component for task management interface
 */
export const TaskList: React.FC = () => {
    const { t } = useTranslation()
    const {
        filteredTasks,
        loading,
        error,
        filters,
        sortBy,
        sortOrder,
        loadTasks,
        addTask,
        editTask,
        changeTaskStatus,
        removeTask,
        updateFilters,
        updateSorting,
        clearTaskError,
    } = useTasks()

    // Local state for UI
    const [showForm, setShowForm] = useState(false)
    const [editingTask, setEditingTask] = useState<Task | null>(null)
    const [searchFilters, setSearchFilters] = useState<SearchFilters>({})
    const [isSearchMode, setIsSearchMode] = useState(false)

    // Load tasks on component mount
    useEffect(() => {
        loadTasks()
    }, [loadTasks])

    // Handle advanced search
    const handleSearch = (newFilters: SearchFilters) => {
        setSearchFilters(newFilters)
        setIsSearchMode(true)

        // Convert SearchFilters to the format expected by useTasks
        const taskFilters = {
            ...filters,
            search: newFilters.search,
            status: newFilters.status,
            priority: newFilters.priority,
            assigneeId: newFilters.assigneeId,
            projectId: newFilters.projectId,
            isOverdue: newFilters.isOverdue,
            isUnassigned: newFilters.isUnassigned
        }

        updateFilters(taskFilters)

        if (newFilters.sortBy && newFilters.sortOrder) {
            updateSorting(newFilters.sortBy, newFilters.sortOrder)
        }
    }

    // Handle clear search
    const handleClearSearch = () => {
        setSearchFilters({})
        setIsSearchMode(false)
        updateFilters({})
        updateSorting('createdAt', 'desc')
    }

    // Handle filter changes
    const handleFilterChange = (filterType: keyof typeof filters, value: string) => {
        const newFilters = { ...filters }
        if (value === '') {
            delete newFilters[filterType]
        } else {
            newFilters[filterType] = value
        }
        updateFilters(newFilters)
    }

    // Handle sorting changes
    const handleSortChange = (newSortBy: typeof sortBy) => {
        const newSortOrder = sortBy === newSortBy && sortOrder === 'asc' ? 'desc' : 'asc'
        updateSorting(newSortBy, newSortOrder)
    }

    // Handle task creation
    const handleCreateTask = async (taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'createdBy'>) => {
        try {
            await addTask(taskData)
            setShowForm(false)
        } catch (error) {
            console.error('Failed to create task:', error)
        }
    }

    // Handle task editing
    const handleEditTask = async (taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'createdBy'>) => {
        if (!editingTask) return

        try {
            await editTask(editingTask.id, taskData)
            setEditingTask(null)
            setShowForm(false)
        } catch (error) {
            console.error('Failed to update task:', error)
        }
    }

    // Handle task status change
    const handleStatusChange = async (taskId: string, status: TaskStatus) => {
        try {
            await changeTaskStatus(taskId, status)
        } catch (error) {
            console.error('Failed to update task status:', error)
        }
    }

    // Handle task deletion
    const handleDeleteTask = async (taskId: string) => {
        try {
            await removeTask(taskId)
        } catch (error) {
            console.error('Failed to delete task:', error)
        }
    }

    // Open edit form
    const openEditForm = (task: Task) => {
        setEditingTask(task)
        setShowForm(true)
    }

    // Close form
    const closeForm = () => {
        setShowForm(false)
        setEditingTask(null)
    }

    // Clear error
    const handleClearError = () => {
        clearTaskError()
    }

    return (
        <div className="max-w-6xl mx-auto p-6">
            {/* Header */}
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold text-gray-900">{t('tasks.title')}</h1>
                <button
                    onClick={() => setShowForm(true)}
                    className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                    {t('tasks.create')}
                </button>
            </div>

            {/* Error display */}
            {error && (
                <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
                    <div className="flex justify-between items-center">
                        <p className="text-red-800">{error}</p>
                        <button
                            onClick={handleClearError}
                            className="text-red-600 hover:text-red-800"
                        >
                            ✕
                        </button>
                    </div>
                </div>
            )}

            {/* Advanced Search */}
            <AdvancedSearch
                onSearch={handleSearch}
                onClear={handleClearSearch}
                initialFilters={searchFilters}
                isLoading={loading}
            />

            {/* Loading state */}
            {loading && (
                <div className="text-center py-8">
                    <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                    <p className="mt-2 text-gray-600">{t('common.loading')}</p>
                </div>
            )}

            {/* Task results */}
            {!loading && (
                <>
                    {isSearchMode ? (
                        <SearchResults
                            tasks={filteredTasks}
                            searchTerm={searchFilters.search}
                            isLoading={loading}
                            onTaskStatusChange={handleStatusChange}
                            onTaskEdit={openEditForm}
                            onTaskDelete={handleDeleteTask}
                        />
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {filteredTasks.length > 0 ? (
                                filteredTasks.map((task) => (
                                    <TaskCard
                                        key={task.id}
                                        task={task}
                                        onStatusChange={handleStatusChange}
                                        onEdit={openEditForm}
                                        onDelete={handleDeleteTask}
                                        highlightTerm={searchFilters.search}
                                    />
                                ))
                            ) : (
                                <div className="col-span-full text-center py-8">
                                    <p className="text-gray-500">{t('tasks.messages.noTasks')}</p>
                                </div>
                            )}
                        </div>
                    )}
                </>
            )}

            {/* Task form modal */}
            {showForm && (
                <TaskForm
                    task={editingTask}
                    onSubmit={editingTask ? handleEditTask : handleCreateTask}
                    onCancel={closeForm}
                    loading={loading}
                />
            )}
        </div>
    )
}