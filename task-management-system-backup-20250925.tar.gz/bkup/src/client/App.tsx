import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Provider } from 'react-redux'
import { store } from './store'
import LoginForm from './components/auth/LoginForm'
import RegisterForm from './components/auth/RegisterForm'
import ProtectedRoute from './components/auth/ProtectedRoute'
import Dashboard from './components/Dashboard'
import { TaskList } from './components/TaskList'
import { TaskForm } from './components/TaskForm'
import ProjectList from './components/ProjectList'
import ProjectForm from './components/ProjectForm'
import ProjectDashboard from './components/ProjectDashboard'
import UserProfile from './components/UserProfile'
import { Navigation } from './components/Navigation'
import ErrorBoundary from './components/ErrorBoundary'

/**
 * Main application component that sets up routing and Redux store
 * Handles authentication flow and protected routes
 */
function App() {
    return (
        <ErrorBoundary>
            <Provider store={store}>
                <Router>
                    <div className="min-h-screen bg-gray-100">
                        <Routes>
                            {/* Public routes */}
                            <Route path="/login" element={<LoginForm />} />
                            <Route path="/register" element={<RegisterForm />} />

                            {/* Protected routes with navigation */}
                            <Route
                                path="/dashboard"
                                element={
                                    <ProtectedRoute>
                                        <div className="min-h-screen bg-gray-100">
                                            <Navigation />
                                            <Dashboard />
                                        </div>
                                    </ProtectedRoute>
                                }
                            />
                            <Route
                                path="/tasks"
                                element={
                                    <ProtectedRoute>
                                        <div className="min-h-screen bg-gray-100">
                                            <Navigation />
                                            <TaskList />
                                        </div>
                                    </ProtectedRoute>
                                }
                            />
                            <Route
                                path="/tasks/new"
                                element={
                                    <ProtectedRoute>
                                        <div className="min-h-screen bg-gray-100">
                                            <Navigation />
                                            <TaskForm />
                                        </div>
                                    </ProtectedRoute>
                                }
                            />
                            <Route
                                path="/tasks/edit/:id"
                                element={
                                    <ProtectedRoute>
                                        <div className="min-h-screen bg-gray-100">
                                            <Navigation />
                                            <TaskForm />
                                        </div>
                                    </ProtectedRoute>
                                }
                            />
                            <Route
                                path="/projects"
                                element={
                                    <ProtectedRoute>
                                        <div className="min-h-screen bg-gray-100">
                                            <Navigation />
                                            <ProjectList />
                                        </div>
                                    </ProtectedRoute>
                                }
                            />
                            <Route
                                path="/projects/new"
                                element={
                                    <ProtectedRoute>
                                        <div className="min-h-screen bg-gray-100">
                                            <Navigation />
                                            <ProjectForm />
                                        </div>
                                    </ProtectedRoute>
                                }
                            />
                            <Route
                                path="/projects/:id"
                                element={
                                    <ProtectedRoute>
                                        <div className="min-h-screen bg-gray-100">
                                            <Navigation />
                                            <ProjectDashboard />
                                        </div>
                                    </ProtectedRoute>
                                }
                            />
                            <Route
                                path="/profile"
                                element={
                                    <ProtectedRoute>
                                        <div className="min-h-screen bg-gray-100">
                                            <Navigation />
                                            <UserProfile />
                                        </div>
                                    </ProtectedRoute>
                                }
                            />

                            {/* Redirect root to dashboard */}
                            <Route path="/" element={<Navigate to="/dashboard" replace />} />

                            {/* Unauthorized page */}
                            <Route
                                path="/unauthorized"
                                element={
                                    <div className="min-h-screen flex items-center justify-center">
                                        <div className="text-center">
                                            <h1 className="text-2xl font-bold text-gray-900 mb-4">
                                                アクセス権限がありません
                                            </h1>
                                            <p className="text-gray-600">
                                                このページにアクセスする権限がありません。
                                            </p>
                                        </div>
                                    </div>
                                }
                            />

                            {/* 404 page */}
                            <Route
                                path="*"
                                element={
                                    <div className="min-h-screen flex items-center justify-center">
                                        <div className="text-center">
                                            <h1 className="text-2xl font-bold text-gray-900 mb-4">
                                                ページが見つかりません
                                            </h1>
                                            <p className="text-gray-600">
                                                お探しのページは存在しません。
                                            </p>
                                        </div>
                                    </div>
                                }
                            />
                        </Routes>
                    </div>
                </Router>
            </Provider>
        </ErrorBoundary>
    )
}

export default App