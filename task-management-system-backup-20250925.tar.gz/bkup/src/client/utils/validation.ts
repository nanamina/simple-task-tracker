import i18n from '../i18n'

/**
 * Validation rule types
 */
export interface ValidationRule {
    required?: boolean
    minLength?: number
    maxLength?: number
    pattern?: RegExp
    email?: boolean
    custom?: (value: any) => string | null
}

/**
 * Validation result
 */
export interface ValidationResult {
    isValid: boolean
    errors: Record<string, string>
}

/**
 * Field validation configuration
 */
export interface FieldValidation {
    [fieldName: string]: ValidationRule
}

/**
 * Validate a single field value against its rules
 */
export function validateField(
    fieldName: string,
    value: any,
    rules: ValidationRule,
    customFieldName?: string
): string | null {
    const displayName = customFieldName || getFieldDisplayName(fieldName)

    // Required validation
    if (rules.required && (!value || (typeof value === 'string' && value.trim() === ''))) {
        return i18n.t('validation.required', { field: displayName })
    }

    // Skip other validations if field is empty and not required
    if (!value || (typeof value === 'string' && value.trim() === '')) {
        return null
    }

    const stringValue = String(value).trim()

    // Email validation
    if (rules.email && !isValidEmail(stringValue)) {
        return i18n.t('validation.email')
    }

    // Minimum length validation
    if (rules.minLength && stringValue.length < rules.minLength) {
        return i18n.t('validation.minLength', {
            field: displayName,
            min: rules.minLength
        })
    }

    // Maximum length validation
    if (rules.maxLength && stringValue.length > rules.maxLength) {
        return i18n.t('validation.maxLength', {
            field: displayName,
            max: rules.maxLength
        })
    }

    // Pattern validation
    if (rules.pattern && !rules.pattern.test(stringValue)) {
        return getPatternErrorMessage(fieldName, rules.pattern)
    }

    // Custom validation
    if (rules.custom) {
        const customError = rules.custom(value)
        if (customError) {
            return customError
        }
    }

    return null
}

/**
 * Validate multiple fields
 */
export function validateFields(
    data: Record<string, any>,
    validationRules: FieldValidation,
    customFieldNames?: Record<string, string>
): ValidationResult {
    const errors: Record<string, string> = {}

    Object.entries(validationRules).forEach(([fieldName, rules]) => {
        const value = data[fieldName]
        const customName = customFieldNames?.[fieldName]
        const error = validateField(fieldName, value, rules, customName)

        if (error) {
            errors[fieldName] = error
        }
    })

    return {
        isValid: Object.keys(errors).length === 0,
        errors
    }
}

/**
 * Check if email format is valid
 */
function isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
}

/**
 * Get display name for field (with i18n support)
 */
function getFieldDisplayName(fieldName: string): string {
    // Try to get translated field name
    const translationKey = `fields.${fieldName}`
    const translated = i18n.t(translationKey, { defaultValue: null })

    if (translated) {
        return translated
    }

    // Fallback to formatted field name
    return fieldName
        .replace(/([A-Z])/g, ' $1')
        .replace(/^./, str => str.toUpperCase())
        .trim()
}

/**
 * Get error message for pattern validation
 */
function getPatternErrorMessage(fieldName: string, pattern: RegExp): string {
    // Common patterns with specific error messages
    if (pattern.source.includes('\\d')) {
        return i18n.t('validation.mustContainNumbers')
    }

    if (pattern.source.includes('[A-Z]')) {
        return i18n.t('validation.mustContainUppercase')
    }

    if (pattern.source.includes('[a-z]')) {
        return i18n.t('validation.mustContainLowercase')
    }

    if (pattern.source.includes('[!@#$%^&*]')) {
        return i18n.t('validation.mustContainSpecialChars')
    }

    // Generic pattern error
    return i18n.t('validation.invalidFormat', {
        field: getFieldDisplayName(fieldName)
    })
}

/**
 * Common validation rules for the task management system
 */
export const commonValidationRules = {
    // User fields
    name: {
        required: true,
        minLength: 2,
        maxLength: 100
    } as ValidationRule,

    email: {
        required: true,
        email: true,
        maxLength: 255
    } as ValidationRule,

    password: {
        required: true,
        minLength: 8,
        maxLength: 128,
        pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).*$/
    } as ValidationRule,

    confirmPassword: (password: string) => ({
        required: true,
        custom: (value: string) => {
            if (value !== password) {
                return i18n.t('validation.passwordMatch')
            }
            return null
        }
    } as ValidationRule),

    // Task fields
    taskTitle: {
        required: true,
        minLength: 1,
        maxLength: 255
    } as ValidationRule,

    taskDescription: {
        maxLength: 2000
    } as ValidationRule,

    dueDate: {
        custom: (value: string) => {
            if (!value) return null

            const date = new Date(value)
            if (isNaN(date.getTime())) {
                return i18n.t('validation.invalidDate')
            }

            // Check if date is in the past (optional - depends on requirements)
            const today = new Date()
            today.setHours(0, 0, 0, 0)
            if (date < today) {
                return i18n.t('validation.pastDate')
            }

            return null
        }
    } as ValidationRule,

    // Project fields
    projectName: {
        required: true,
        minLength: 1,
        maxLength: 255
    } as ValidationRule,

    projectDescription: {
        maxLength: 2000
    } as ValidationRule,
}

/**
 * Validate task data
 */
export function validateTask(taskData: any): ValidationResult {
    return validateFields(taskData, {
        title: commonValidationRules.taskTitle,
        description: commonValidationRules.taskDescription,
        dueDate: commonValidationRules.dueDate,
    })
}

/**
 * Validate project data
 */
export function validateProject(projectData: any): ValidationResult {
    return validateFields(projectData, {
        name: commonValidationRules.projectName,
        description: commonValidationRules.projectDescription,
    })
}

/**
 * Validate user registration data
 */
export function validateUserRegistration(userData: any): ValidationResult {
    return validateFields(userData, {
        name: commonValidationRules.name,
        email: commonValidationRules.email,
        password: commonValidationRules.password,
        confirmPassword: commonValidationRules.confirmPassword(userData.password),
    })
}

/**
 * Validate user login data
 */
export function validateUserLogin(loginData: any): ValidationResult {
    return validateFields(loginData, {
        email: { required: true, email: true },
        password: { required: true },
    })
}

/**
 * Validate user profile update data
 */
export function validateUserProfile(profileData: any): ValidationResult {
    return validateFields(profileData, {
        name: commonValidationRules.name,
        email: commonValidationRules.email,
    })
}

/**
 * Real-time validation hook for forms
 */
export function useFieldValidation(
    fieldName: string,
    value: any,
    rules: ValidationRule,
    customFieldName?: string
) {
    const error = validateField(fieldName, value, rules, customFieldName)
    return {
        error,
        isValid: !error,
        hasError: !!error
    }
}