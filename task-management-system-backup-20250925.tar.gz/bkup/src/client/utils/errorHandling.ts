import { SerializedError } from '@reduxjs/toolkit'
import { FetchBaseQueryError } from '@reduxjs/toolkit/query'
import i18n from '../i18n'

/**
 * Standard error response format from the backend
 */
export interface ApiErrorResponse {
    error: {
        code: string
        message: string
        details?: any
        timestamp: string
    }
}

/**
 * Error codes used throughout the application
 */
export enum ErrorCodes {
    VALIDATION_ERROR = 'VALIDATION_ERROR',
    UNAUTHORIZED = 'UNAUTHORIZED',
    FORBIDDEN = 'FORBIDDEN',
    NOT_FOUND = 'NOT_FOUND',
    CONFLICT = 'CONFLICT',
    INTERNAL_ERROR = 'INTERNAL_ERROR',
    NETWORK_ERROR = 'NETWORK_ERROR',
    TIMEOUT_ERROR = 'TIMEOUT_ERROR',
}

/**
 * Processed error information for UI display
 */
export interface ProcessedError {
    title: string
    message: string
    code?: string
    details?: any
    isRetryable: boolean
}

/**
 * Check if an error is a FetchBaseQueryError
 */
export function isFetchBaseQueryError(error: unknown): error is FetchBaseQueryError {
    return typeof error === 'object' && error != null && 'status' in error
}

/**
 * Check if an error is a SerializedError
 */
export function isSerializedError(error: unknown): error is SerializedError {
    return typeof error === 'object' && error != null && 'message' in error && !('status' in error)
}

/**
 * Extract error information from RTK Query error
 */
export function extractErrorInfo(error: FetchBaseQueryError | SerializedError | undefined): ProcessedError {
    if (!error) {
        return {
            title: i18n.t('errors.unknown.title'),
            message: i18n.t('errors.unknown.message'),
            isRetryable: false,
        }
    }

    // Handle FetchBaseQueryError (API errors)
    if (isFetchBaseQueryError(error)) {
        return processFetchError(error)
    }

    // Handle SerializedError (network/runtime errors)
    if (isSerializedError(error)) {
        return processSerializedError(error)
    }

    // Fallback for unknown error types
    return {
        title: i18n.t('errors.unknown.title'),
        message: i18n.t('errors.unknown.message'),
        isRetryable: false,
    }
}

/**
 * Process FetchBaseQueryError from API calls
 */
function processFetchError(error: FetchBaseQueryError): ProcessedError {
    const status = error.status

    // Handle different HTTP status codes
    if (typeof status === 'number') {
        switch (status) {
            case 400:
                return processBadRequestError(error)
            case 401:
                return {
                    title: i18n.t('errors.unauthorized.title'),
                    message: i18n.t('errors.unauthorized.message'),
                    code: ErrorCodes.UNAUTHORIZED,
                    isRetryable: false,
                }
            case 403:
                return {
                    title: i18n.t('errors.forbidden.title'),
                    message: i18n.t('errors.forbidden.message'),
                    code: ErrorCodes.FORBIDDEN,
                    isRetryable: false,
                }
            case 404:
                return {
                    title: i18n.t('errors.notFound.title'),
                    message: i18n.t('errors.notFound.message'),
                    code: ErrorCodes.NOT_FOUND,
                    isRetryable: false,
                }
            case 409:
                return {
                    title: i18n.t('errors.conflict.title'),
                    message: i18n.t('errors.conflict.message'),
                    code: ErrorCodes.CONFLICT,
                    isRetryable: false,
                }
            case 422:
                return processValidationError(error)
            case 500:
            case 502:
            case 503:
            case 504:
                return {
                    title: i18n.t('errors.server.title'),
                    message: i18n.t('errors.server.message'),
                    code: ErrorCodes.INTERNAL_ERROR,
                    isRetryable: true,
                }
            default:
                return {
                    title: i18n.t('errors.api.title'),
                    message: i18n.t('errors.api.message', { status }),
                    isRetryable: status >= 500,
                }
        }
    }

    // Handle string status (network errors)
    if (typeof status === 'string') {
        switch (status) {
            case 'FETCH_ERROR':
                return {
                    title: i18n.t('errors.network.title'),
                    message: i18n.t('errors.network.message'),
                    code: ErrorCodes.NETWORK_ERROR,
                    isRetryable: true,
                }
            case 'TIMEOUT_ERROR':
                return {
                    title: i18n.t('errors.timeout.title'),
                    message: i18n.t('errors.timeout.message'),
                    code: ErrorCodes.TIMEOUT_ERROR,
                    isRetryable: true,
                }
            case 'PARSING_ERROR':
                return {
                    title: i18n.t('errors.parsing.title'),
                    message: i18n.t('errors.parsing.message'),
                    isRetryable: false,
                }
            default:
                return {
                    title: i18n.t('errors.unknown.title'),
                    message: i18n.t('errors.unknown.message'),
                    isRetryable: false,
                }
        }
    }

    return {
        title: i18n.t('errors.unknown.title'),
        message: i18n.t('errors.unknown.message'),
        isRetryable: false,
    }
}

/**
 * Process SerializedError from runtime/network issues
 */
function processSerializedError(error: SerializedError): ProcessedError {
    return {
        title: i18n.t('errors.runtime.title'),
        message: error.message || i18n.t('errors.runtime.message'),
        isRetryable: false,
    }
}

/**
 * Process 400 Bad Request errors
 */
function processBadRequestError(error: FetchBaseQueryError): ProcessedError {
    const errorData = error.data as ApiErrorResponse | undefined

    if (errorData?.error) {
        return {
            title: i18n.t('errors.badRequest.title'),
            message: errorData.error.message,
            code: errorData.error.code,
            details: errorData.error.details,
            isRetryable: false,
        }
    }

    return {
        title: i18n.t('errors.badRequest.title'),
        message: i18n.t('errors.badRequest.message'),
        isRetryable: false,
    }
}

/**
 * Process 422 Validation errors
 */
function processValidationError(error: FetchBaseQueryError): ProcessedError {
    const errorData = error.data as ApiErrorResponse | undefined

    if (errorData?.error) {
        return {
            title: i18n.t('errors.validation.title'),
            message: errorData.error.message,
            code: ErrorCodes.VALIDATION_ERROR,
            details: errorData.error.details,
            isRetryable: false,
        }
    }

    return {
        title: i18n.t('errors.validation.title'),
        message: i18n.t('errors.validation.message'),
        code: ErrorCodes.VALIDATION_ERROR,
        isRetryable: false,
    }
}

/**
 * Format validation errors for form display
 */
export function formatValidationErrors(details: any): Record<string, string> {
    if (!details || typeof details !== 'object') {
        return {}
    }

    const formattedErrors: Record<string, string> = {}

    // Handle express-validator format
    if (Array.isArray(details)) {
        details.forEach((error: any) => {
            if (error.path && error.msg) {
                formattedErrors[error.path] = error.msg
            }
        })
    }

    // Handle object format
    if (typeof details === 'object' && !Array.isArray(details)) {
        Object.entries(details).forEach(([field, message]) => {
            if (typeof message === 'string') {
                formattedErrors[field] = message
            }
        })
    }

    return formattedErrors
}

/**
 * Check if the user should be redirected to login
 */
export function shouldRedirectToLogin(error: ProcessedError): boolean {
    return error.code === ErrorCodes.UNAUTHORIZED
}

/**
 * Get user-friendly error message for common scenarios
 */
export function getErrorMessage(error: ProcessedError, context?: string): string {
    // Context-specific error messages
    if (context) {
        const contextKey = `errors.context.${context}.${error.code}`
        const contextMessage = i18n.t(contextKey, { defaultValue: null })
        if (contextMessage) {
            return contextMessage
        }
    }

    return error.message
}

/**
 * Log error for debugging and monitoring
 */
export function logError(error: ProcessedError, context?: string) {
    const logData = {
        title: error.title,
        message: error.message,
        code: error.code,
        context,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        url: window.location.href,
    }

    console.error('Application Error:', logData)

    // In production, send to error monitoring service
    if (process.env.NODE_ENV === 'production') {
        // Example: sendToErrorService(logData)
    }
}