/**
 * Search highlighting utilities
 */

/**
 * Highlights search terms in text
 * @param text - Text to highlight
 * @param searchTerm - Search term to highlight
 * @returns Text with highlighted search terms
 */
export function highlightSearchTerm(text: string, searchTerm: string): string {
    if (!searchTerm || !text) {
        return text
    }

    const regex = new RegExp(`(${escapeRegExp(searchTerm)})`, 'gi')
    return text.replace(regex, '<mark class="bg-yellow-200 px-1 rounded">$1</mark>')
}

/**
 * Escapes special regex characters
 * @param string - String to escape
 * @returns Escaped string
 */
function escapeRegExp(string: string): string {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

/**
 * Truncates text and highlights search terms
 * @param text - Text to truncate and highlight
 * @param searchTerm - Search term to highlight
 * @param maxLength - Maximum length of text
 * @returns Truncated and highlighted text
 */
export function highlightAndTruncate(text: string, searchTerm: string, maxLength: number = 150): string {
    if (!text) return ''

    let truncated = text

    // If we have a search term, try to include it in the truncated text
    if (searchTerm && text.length > maxLength) {
        const searchIndex = text.toLowerCase().indexOf(searchTerm.toLowerCase())
        if (searchIndex !== -1) {
            // Calculate start position to center the search term
            const start = Math.max(0, searchIndex - Math.floor(maxLength / 2))
            const end = Math.min(text.length, start + maxLength)

            truncated = text.substring(start, end)

            // Add ellipsis if we truncated
            if (start > 0) truncated = '...' + truncated
            if (end < text.length) truncated = truncated + '...'
        } else {
            // No search term found, just truncate from beginning
            truncated = text.substring(0, maxLength) + (text.length > maxLength ? '...' : '')
        }
    } else if (text.length > maxLength) {
        truncated = text.substring(0, maxLength) + '...'
    }

    return highlightSearchTerm(truncated, searchTerm)
}

/**
 * Creates a search excerpt with highlighted terms
 * @param text - Full text
 * @param searchTerm - Search term
 * @param excerptLength - Length of excerpt
 * @returns Search excerpt with highlights
 */
export function createSearchExcerpt(text: string, searchTerm: string, excerptLength: number = 200): string {
    if (!searchTerm || !text) {
        return text.substring(0, excerptLength) + (text.length > excerptLength ? '...' : '')
    }

    const searchIndex = text.toLowerCase().indexOf(searchTerm.toLowerCase())

    if (searchIndex === -1) {
        // Search term not found, return beginning of text
        return text.substring(0, excerptLength) + (text.length > excerptLength ? '...' : '')
    }

    // Calculate excerpt boundaries to center the search term
    const halfExcerpt = Math.floor(excerptLength / 2)
    const start = Math.max(0, searchIndex - halfExcerpt)
    const end = Math.min(text.length, start + excerptLength)

    let excerpt = text.substring(start, end)

    // Add ellipsis if needed
    if (start > 0) excerpt = '...' + excerpt
    if (end < text.length) excerpt = excerpt + '...'

    return highlightSearchTerm(excerpt, searchTerm)
}