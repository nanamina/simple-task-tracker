import i18n from '../i18n';

/**
 * Translation utility functions
 * Provides helper functions for common translation tasks
 */

/**
 * Get translation for a key outside of React components
 * @param key - Translation key
 * @param options - Translation options
 * @returns Translated string
 */
export const translate = (key: string, options?: any): string => {
    return i18n.t(key, options);
};

/**
 * Get current language code
 * @returns Current language ('ja' or 'en')
 */
export const getCurrentLanguage = (): 'ja' | 'en' => {
    return (i18n.language as 'ja' | 'en') || 'ja';
};

/**
 * Change language programmatically
 * @param language - Target language code
 */
export const changeLanguage = async (language: 'ja' | 'en'): Promise<void> => {
    await i18n.changeLanguage(language);
};

/**
 * Check if current language is Japanese
 * @returns True if Japanese is active
 */
export const isJapanese = (): boolean => {
    return getCurrentLanguage() === 'ja';
};

/**
 * Check if current language is English
 * @returns True if English is active
 */
export const isEnglish = (): boolean => {
    return getCurrentLanguage() === 'en';
};

/**
 * Get localized task status
 * @param status - Task status value
 * @returns Localized status string
 */
export const getLocalizedTaskStatus = (status: 'todo' | 'in-progress' | 'completed'): string => {
    const statusKey = status === 'in-progress' ? 'inProgress' : status;
    return translate(`tasks.status.${statusKey}`);
};

/**
 * Get localized priority level
 * @param priority - Priority level
 * @returns Localized priority string
 */
export const getLocalizedPriority = (priority: 'low' | 'medium' | 'high' | 'critical'): string => {
    return translate(`tasks.priority.${priority}`);
};

/**
 * Get localized user role
 * @param role - User role
 * @returns Localized role string
 */
export const getLocalizedRole = (role: 'admin' | 'manager' | 'member'): string => {
    return translate(`profile.roles.${role}`);
};

/**
 * Format validation error message with interpolation
 * @param errorType - Type of validation error
 * @param params - Parameters for interpolation
 * @returns Localized error message
 */
export const getValidationError = (errorType: string, params?: Record<string, any>): string => {
    return translate(`validation.${errorType}`, params);
};

export default {
    translate,
    getCurrentLanguage,
    changeLanguage,
    isJapanese,
    isEnglish,
    getLocalizedTaskStatus,
    getLocalizedPriority,
    getLocalizedRole,
    getValidationError,
};