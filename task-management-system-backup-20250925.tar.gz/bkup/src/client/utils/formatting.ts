/**
 * Locale-specific formatting utilities using the Intl API
 * Supports Japanese (YYYY/MM/DD) and English (MM/DD/YYYY) date formats
 */

import { getCurrentLanguage } from './i18n';

/**
 * Format a date according to the current locale
 * Japanese: YYYY/MM/DD format
 * English: MM/DD/YYYY format
 * @param date - Date to format
 * @param options - Additional formatting options
 * @returns Formatted date string
 */
export const formatDate = (date: Date | string, options?: Intl.DateTimeFormatOptions): string => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;

    if (isNaN(dateObj.getTime())) {
        return '';
    }

    const currentLanguage = getCurrentLanguage();

    // Default options for each locale
    const defaultOptions: Intl.DateTimeFormatOptions = {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        ...options,
    };

    // Use Japanese locale for Japanese language, English for others
    const locale = currentLanguage === 'ja' ? 'ja-JP' : 'en-US';

    return new Intl.DateTimeFormat(locale, defaultOptions).format(dateObj);
};

/**
 * Format a date and time according to the current locale
 * @param date - Date to format
 * @param options - Additional formatting options
 * @returns Formatted date and time string
 */
export const formatDateTime = (date: Date | string, options?: Intl.DateTimeFormatOptions): string => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;

    if (isNaN(dateObj.getTime())) {
        return '';
    }

    const currentLanguage = getCurrentLanguage();

    const defaultOptions: Intl.DateTimeFormatOptions = {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        hour12: currentLanguage === 'en', // 12-hour format for English, 24-hour for Japanese
        ...options,
    };

    const locale = currentLanguage === 'ja' ? 'ja-JP' : 'en-US';

    return new Intl.DateTimeFormat(locale, defaultOptions).format(dateObj);
};

/**
 * Format a time according to the current locale
 * @param date - Date to format (time portion)
 * @param options - Additional formatting options
 * @returns Formatted time string
 */
export const formatTime = (date: Date | string, options?: Intl.DateTimeFormatOptions): string => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;

    if (isNaN(dateObj.getTime())) {
        return '';
    }

    const currentLanguage = getCurrentLanguage();

    const defaultOptions: Intl.DateTimeFormatOptions = {
        hour: '2-digit',
        minute: '2-digit',
        hour12: currentLanguage === 'en',
        ...options,
    };

    const locale = currentLanguage === 'ja' ? 'ja-JP' : 'en-US';

    return new Intl.DateTimeFormat(locale, defaultOptions).format(dateObj);
};

/**
 * Format a relative time (e.g., "2 days ago", "in 3 hours")
 * @param date - Date to compare against current time
 * @param options - Additional formatting options
 * @returns Formatted relative time string
 */
export const formatRelativeTime = (date: Date | string, options?: Intl.RelativeTimeFormatOptions): string => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;

    if (isNaN(dateObj.getTime())) {
        return '';
    }

    const currentLanguage = getCurrentLanguage();
    const locale = currentLanguage === 'ja' ? 'ja-JP' : 'en-US';

    const now = new Date();
    const diffInSeconds = Math.floor((dateObj.getTime() - now.getTime()) / 1000);

    const defaultOptions: Intl.RelativeTimeFormatOptions = {
        numeric: 'auto',
        ...options,
    };

    const rtf = new Intl.RelativeTimeFormat(locale, defaultOptions);

    // Determine the appropriate unit and value
    const absDiff = Math.abs(diffInSeconds);

    if (absDiff < 60) {
        return rtf.format(diffInSeconds, 'second');
    } else if (absDiff < 3600) {
        return rtf.format(Math.floor(diffInSeconds / 60), 'minute');
    } else if (absDiff < 86400) {
        return rtf.format(Math.floor(diffInSeconds / 3600), 'hour');
    } else if (absDiff < 2592000) {
        return rtf.format(Math.floor(diffInSeconds / 86400), 'day');
    } else if (absDiff < 31536000) {
        return rtf.format(Math.floor(diffInSeconds / 2592000), 'month');
    } else {
        return rtf.format(Math.floor(diffInSeconds / 31536000), 'year');
    }
};

/**
 * Format a number according to the current locale
 * @param number - Number to format
 * @param options - Additional formatting options
 * @returns Formatted number string
 */
export const formatNumber = (number: number, options?: Intl.NumberFormatOptions): string => {
    const currentLanguage = getCurrentLanguage();
    const locale = currentLanguage === 'ja' ? 'ja-JP' : 'en-US';

    return new Intl.NumberFormat(locale, options).format(number);
};

/**
 * Format a currency amount according to the current locale
 * @param amount - Amount to format
 * @param currency - Currency code (default: JPY for Japanese, USD for English)
 * @param options - Additional formatting options
 * @returns Formatted currency string
 */
export const formatCurrency = (
    amount: number,
    currency?: string,
    options?: Intl.NumberFormatOptions
): string => {
    const currentLanguage = getCurrentLanguage();
    const locale = currentLanguage === 'ja' ? 'ja-JP' : 'en-US';
    const defaultCurrency = currentLanguage === 'ja' ? 'JPY' : 'USD';

    const defaultOptions: Intl.NumberFormatOptions = {
        style: 'currency',
        currency: currency || defaultCurrency,
        ...options,
    };

    return new Intl.NumberFormat(locale, defaultOptions).format(amount);
};

/**
 * Format a percentage according to the current locale
 * @param value - Value to format as percentage (0.5 = 50%)
 * @param options - Additional formatting options
 * @returns Formatted percentage string
 */
export const formatPercentage = (value: number, options?: Intl.NumberFormatOptions): string => {
    const currentLanguage = getCurrentLanguage();
    const locale = currentLanguage === 'ja' ? 'ja-JP' : 'en-US';

    const defaultOptions: Intl.NumberFormatOptions = {
        style: 'percent',
        minimumFractionDigits: 0,
        maximumFractionDigits: 1,
        ...options,
    };

    return new Intl.NumberFormat(locale, defaultOptions).format(value);
};

/**
 * Get the current locale string based on the selected language
 * @returns Locale string (ja-JP or en-US)
 */
export const getCurrentLocale = (): string => {
    const currentLanguage = getCurrentLanguage();
    return currentLanguage === 'ja' ? 'ja-JP' : 'en-US';
};

/**
 * Check if the current locale uses 24-hour time format
 * @returns True if 24-hour format is used
 */
export const uses24HourFormat = (): boolean => {
    return getCurrentLanguage() === 'ja';
};

/**
 * Get the date separator for the current locale
 * @returns Date separator character
 */
export const getDateSeparator = (): string => {
    return '/'; // Both Japanese and English use '/' as separator
};

/**
 * Format a file size in bytes to human-readable format
 * @param bytes - Size in bytes
 * @param decimals - Number of decimal places (default: 2)
 * @returns Formatted file size string
 */
export const formatFileSize = (bytes: number, decimals: number = 2): string => {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const currentLanguage = getCurrentLanguage();

    // Size units in both languages
    const sizes = currentLanguage === 'ja'
        ? ['バイト', 'KB', 'MB', 'GB', 'TB', 'PB']
        : ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB'];

    const i = Math.floor(Math.log(bytes) / Math.log(k));
    const value = parseFloat((bytes / Math.pow(k, i)).toFixed(dm));

    return `${formatNumber(value)} ${sizes[i]}`;
};

export default {
    formatDate,
    formatDateTime,
    formatTime,
    formatRelativeTime,
    formatNumber,
    formatCurrency,
    formatPercentage,
    getCurrentLocale,
    uses24HourFormat,
    getDateSeparator,
    formatFileSize,
};