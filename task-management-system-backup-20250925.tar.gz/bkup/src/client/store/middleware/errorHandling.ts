import { isRejectedWithValue, Middleware } from '@reduxjs/toolkit'
import { addNotification } from '../slices/uiSlice'
import { logout } from '../slices/authSlice'

/**
 * Global error handling middleware for Redux actions
 * 
 * Automatically handles:
 * - Authentication errors (401) - logs user out
 * - Network errors - shows appropriate notifications
 * - Server errors - shows user-friendly messages
 * - Validation errors - displays specific error details
 */
export const errorHandlingMiddleware: Middleware = (store) => (next) => (action) => {
    // Handle rejected async thunk actions
    if (isRejectedWithValue(action)) {
        const error = action.payload
        const errorMessage = typeof error === 'string' ? error : 'An error occurred'

        // Handle authentication errors
        if (action.payload?.status === 401 || errorMessage.includes('Authentication required')) {
            store.dispatch(logout())
            store.dispatch(addNotification({
                type: 'warning',
                message: 'Your session has expired. Please log in again.',
                autoHide: true,
                duration: 5000,
            }))
            return next(action)
        }

        // Handle network errors
        if (errorMessage.includes('Network error') || errorMessage.includes('fetch')) {
            store.dispatch(addNotification({
                type: 'error',
                message: 'Network connection problem. Please check your internet connection.',
                autoHide: false,
                duration: 10000,
            }))
            return next(action)
        }

        // Handle server errors (5xx)
        if (errorMessage.includes('Server error') || errorMessage.includes('status 5')) {
            store.dispatch(addNotification({
                type: 'error',
                message: 'Server is temporarily unavailable. Please try again later.',
                autoHide: true,
                duration: 8000,
            }))
            return next(action)
        }

        // Handle permission errors
        if (errorMessage.includes('permission') || errorMessage.includes('forbidden')) {
            store.dispatch(addNotification({
                type: 'warning',
                message: 'You do not have permission to perform this action.',
                autoHide: true,
                duration: 6000,
            }))
            return next(action)
        }

        // Handle validation errors - these are usually handled by individual components
        // but we can provide a fallback
        if (errorMessage.includes('Validation failed') || errorMessage.includes('Invalid')) {
            // Don't show global notification for validation errors
            // Let components handle these specifically
            return next(action)
        }

        // For other errors, show a generic notification if not already handled
        if (!action.meta?.skipGlobalErrorHandling) {
            store.dispatch(addNotification({
                type: 'error',
                message: errorMessage,
                autoHide: true,
                duration: 6000,
            }))
        }
    }

    return next(action)
}

/**
 * Loading state middleware to automatically manage global loading indicators
 */
export const loadingStateMiddleware: Middleware = (store) => (next) => (action) => {
    const result = next(action)

    // Track loading states for different action types
    if (action.type.endsWith('/pending')) {
        const actionType = action.type.replace('/pending', '')

        // Set loading state based on action type
        if (actionType.includes('auth/')) {
            // Auth loading is handled by auth slice
        } else if (actionType.includes('task')) {
            // Task loading is handled by task slice
        } else if (actionType.includes('project')) {
            // Project loading is handled by project slice
        }
    }

    return result
}

/**
 * Performance monitoring middleware for tracking slow operations
 */
export const performanceMiddleware: Middleware = (store) => (next) => (action) => {
    const start = performance.now()
    const result = next(action)
    const duration = performance.now() - start

    // Log slow operations in development
    if (process.env.NODE_ENV === 'development' && duration > 100) {
        console.warn(`Slow Redux action detected: ${action.type} took ${duration.toFixed(2)}ms`)
    }

    // Track async thunk performance
    if (action.type.endsWith('/fulfilled') || action.type.endsWith('/rejected')) {
        const actionType = action.type.replace(/\/(fulfilled|rejected)$/, '')

        // In a real app, you might send this to analytics
        if (duration > 1000) {
            console.warn(`Slow async operation: ${actionType} took ${duration.toFixed(2)}ms`)
        }
    }

    return result
}

/**
 * Cache invalidation middleware for managing data freshness
 */
export const cacheInvalidationMiddleware: Middleware = (store) => (next) => (action) => {
    const result = next(action)

    // Invalidate related caches when data changes
    if (action.type.includes('create') || action.type.includes('update') || action.type.includes('delete')) {
        // RTK Query handles most cache invalidation automatically through tags
        // This middleware can handle additional custom cache invalidation logic

        // Example: Clear user cache when profile is updated
        if (action.type.includes('user/update')) {
            // Custom cache clearing logic could go here
        }
    }

    return result
}