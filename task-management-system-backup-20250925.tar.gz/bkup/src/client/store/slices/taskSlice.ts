import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit'
import { Task, TaskStatus, TaskPriority } from '@/shared/types'

// API functions for tasks
const API_BASE = '/api'

// Async thunks for task operations
export const fetchTasks = createAsyncThunk(
    'tasks/fetchTasks',
    async (filters?: {
        status?: TaskStatus
        priority?: TaskPriority
        assigneeId?: string
        projectId?: string
        search?: string
    }) => {
        const params = new URLSearchParams()
        if (filters) {
            Object.entries(filters).forEach(([key, value]) => {
                if (value) params.append(key, value)
            })
        }

        const response = await fetch(`${API_BASE}/tasks?${params}`)
        if (!response.ok) {
            throw new Error('Failed to fetch tasks')
        }
        return response.json()
    }
)

export const createTask = createAsyncThunk(
    'tasks/createTask',
    async (taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'createdBy'>) => {
        const response = await fetch(`${API_BASE}/tasks`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(taskData),
        })
        if (!response.ok) {
            throw new Error('Failed to create task')
        }
        return response.json()
    }
)

export const updateTask = createAsyncThunk(
    'tasks/updateTask',
    async ({ id, updates }: { id: string; updates: Partial<Task> }) => {
        const response = await fetch(`${API_BASE}/tasks/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updates),
        })
        if (!response.ok) {
            throw new Error('Failed to update task')
        }
        return response.json()
    }
)

export const updateTaskStatus = createAsyncThunk(
    'tasks/updateTaskStatus',
    async ({ id, status }: { id: string; status: TaskStatus }) => {
        const response = await fetch(`${API_BASE}/tasks/${id}/status`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ status }),
        })
        if (!response.ok) {
            throw new Error('Failed to update task status')
        }
        return response.json()
    }
)

export const deleteTask = createAsyncThunk(
    'tasks/deleteTask',
    async (id: string) => {
        const response = await fetch(`${API_BASE}/tasks/${id}`, {
            method: 'DELETE',
        })
        if (!response.ok) {
            throw new Error('Failed to delete task')
        }
        return id
    }
)

// Task slice state interface
interface TaskState {
    tasks: Task[]
    loading: boolean
    error: string | null
    filters: {
        status?: TaskStatus
        priority?: TaskPriority
        assigneeId?: string
        projectId?: string
        search?: string
    }
    sortBy: 'dueDate' | 'priority' | 'createdAt' | 'status'
    sortOrder: 'asc' | 'desc'
}

const initialState: TaskState = {
    tasks: [],
    loading: false,
    error: null,
    filters: {},
    sortBy: 'createdAt',
    sortOrder: 'desc',
}

const taskSlice = createSlice({
    name: 'tasks',
    initialState,
    reducers: {
        setFilters: (state, action: PayloadAction<TaskState['filters']>) => {
            state.filters = action.payload
        },
        setSorting: (state, action: PayloadAction<{ sortBy: TaskState['sortBy']; sortOrder: TaskState['sortOrder'] }>) => {
            state.sortBy = action.payload.sortBy
            state.sortOrder = action.payload.sortOrder
        },
        clearError: (state) => {
            state.error = null
        },
    },
    extraReducers: (builder) => {
        // Fetch tasks
        builder
            .addCase(fetchTasks.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchTasks.fulfilled, (state, action) => {
                state.loading = false
                state.tasks = action.payload
            })
            .addCase(fetchTasks.rejected, (state, action) => {
                state.loading = false
                state.error = action.error.message || 'Failed to fetch tasks'
            })

        // Create task
        builder
            .addCase(createTask.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(createTask.fulfilled, (state, action) => {
                state.loading = false
                state.tasks.unshift(action.payload)
            })
            .addCase(createTask.rejected, (state, action) => {
                state.loading = false
                state.error = action.error.message || 'Failed to create task'
            })

        // Update task
        builder
            .addCase(updateTask.fulfilled, (state, action) => {
                const index = state.tasks.findIndex(task => task.id === action.payload.id)
                if (index !== -1) {
                    state.tasks[index] = action.payload
                }
            })
            .addCase(updateTask.rejected, (state, action) => {
                state.error = action.error.message || 'Failed to update task'
            })

        // Update task status
        builder
            .addCase(updateTaskStatus.fulfilled, (state, action) => {
                const index = state.tasks.findIndex(task => task.id === action.payload.id)
                if (index !== -1) {
                    state.tasks[index] = action.payload
                }
            })
            .addCase(updateTaskStatus.rejected, (state, action) => {
                state.error = action.error.message || 'Failed to update task status'
            })

        // Delete task
        builder
            .addCase(deleteTask.fulfilled, (state, action) => {
                state.tasks = state.tasks.filter(task => task.id !== action.payload)
            })
            .addCase(deleteTask.rejected, (state, action) => {
                state.error = action.error.message || 'Failed to delete task'
            })
    },
})

export const { setFilters, setSorting, clearError } = taskSlice.actions
export default taskSlice.reducer