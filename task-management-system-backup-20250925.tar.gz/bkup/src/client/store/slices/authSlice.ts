import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit'
import { User } from '@/shared/types'

// API types for authentication
interface LoginCredentials {
    email: string
    password: string
}

interface RegisterData {
    name: string
    email: string
    password: string
}

interface AuthResponse {
    user: User
    token: string
}

interface AuthState {
    user: User | null
    token: string | null
    isLoading: boolean
    error: string | null
    isAuthenticated: boolean
}

const initialState: AuthState = {
    user: null,
    token: typeof window !== 'undefined' ? localStorage.getItem('token') : null,
    isLoading: false,
    error: null,
    isAuthenticated: false,
}

// Async thunks for authentication
export const loginUser = createAsyncThunk<AuthResponse, LoginCredentials>(
    'auth/login',
    async (credentials, { rejectWithValue }) => {
        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(credentials),
            })

            if (!response.ok) {
                const error = await response.json()
                return rejectWithValue(error.error?.message || 'Login failed')
            }

            const data = await response.json()

            // Store token in localStorage
            if (typeof window !== 'undefined') {
                localStorage.setItem('token', data.token)
            }

            return data
        } catch (error) {
            return rejectWithValue('Network error occurred')
        }
    }
)

export const registerUser = createAsyncThunk<AuthResponse, RegisterData>(
    'auth/register',
    async (userData, { rejectWithValue }) => {
        try {
            const response = await fetch('/api/auth/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(userData),
            })

            if (!response.ok) {
                const error = await response.json()
                return rejectWithValue(error.error?.message || 'Registration failed')
            }

            const data = await response.json()

            // Store token in localStorage
            if (typeof window !== 'undefined') {
                localStorage.setItem('token', data.token)
            }

            return data
        } catch (error) {
            return rejectWithValue('Network error occurred')
        }
    }
)

export const verifyToken = createAsyncThunk<User, void>(
    'auth/verifyToken',
    async (_, { rejectWithValue, getState }) => {
        try {
            const state = getState() as { auth: AuthState }
            const token = state.auth.token

            if (!token) {
                return rejectWithValue('No token found')
            }

            const response = await fetch('/api/users/profile', {
                headers: {
                    'Authorization': `Bearer ${token}`,
                },
            })

            if (!response.ok) {
                if (typeof window !== 'undefined') {
                    localStorage.removeItem('token')
                }
                return rejectWithValue('Token verification failed')
            }

            const user = await response.json()
            return user
        } catch (error) {
            if (typeof window !== 'undefined') {
                localStorage.removeItem('token')
            }
            return rejectWithValue('Network error occurred')
        }
    }
)

const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers: {
        logout: (state) => {
            state.user = null
            state.token = null
            state.isAuthenticated = false
            state.error = null
            if (typeof window !== 'undefined') {
                localStorage.removeItem('token')
            }
        },
        clearError: (state) => {
            state.error = null
        },
    },
    extraReducers: (builder) => {
        builder
            // Login cases
            .addCase(loginUser.pending, (state) => {
                state.isLoading = true
                state.error = null
            })
            .addCase(loginUser.fulfilled, (state, action: PayloadAction<AuthResponse>) => {
                state.isLoading = false
                state.user = action.payload.user
                state.token = action.payload.token
                state.isAuthenticated = true
                state.error = null
            })
            .addCase(loginUser.rejected, (state, action) => {
                state.isLoading = false
                state.error = action.payload as string
                state.isAuthenticated = false
            })
            // Register cases
            .addCase(registerUser.pending, (state) => {
                state.isLoading = true
                state.error = null
            })
            .addCase(registerUser.fulfilled, (state, action: PayloadAction<AuthResponse>) => {
                state.isLoading = false
                state.user = action.payload.user
                state.token = action.payload.token
                state.isAuthenticated = true
                state.error = null
            })
            .addCase(registerUser.rejected, (state, action) => {
                state.isLoading = false
                state.error = action.payload as string
                state.isAuthenticated = false
            })
            // Token verification cases
            .addCase(verifyToken.pending, (state) => {
                state.isLoading = true
            })
            .addCase(verifyToken.fulfilled, (state, action: PayloadAction<User>) => {
                state.isLoading = false
                state.user = action.payload
                state.isAuthenticated = true
                state.error = null
            })
            .addCase(verifyToken.rejected, (state) => {
                state.isLoading = false
                state.user = null
                state.token = null
                state.isAuthenticated = false
                if (typeof window !== 'undefined') {
                    localStorage.removeItem('token')
                }
            })
    },
})

export const { logout, clearError } = authSlice.actions
export default authSlice.reducer