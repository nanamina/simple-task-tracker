import { createSlice, PayloadAction } from '@reduxjs/toolkit'
import { Language } from '@/shared/types'

// UI notification interface
export interface Notification {
    id: string
    type: 'success' | 'error' | 'warning' | 'info'
    message: string
    timestamp: string // ISO string for serialization
    autoHide?: boolean
    duration?: number
}

// UI slice state interface
interface UIState {
    language: Language
    notifications: Notification[]
    sidebarOpen: boolean
    theme: 'light' | 'dark'
    loading: {
        global: boolean
        tasks: boolean
        projects: boolean
        auth: boolean
    }
}

const initialState: UIState = {
    language: 'ja', // Japanese as default per requirements
    notifications: [],
    sidebarOpen: true,
    theme: 'light',
    loading: {
        global: false,
        tasks: false,
        projects: false,
        auth: false,
    },
}

/**
 * UI slice for managing application-wide UI state including language preferences,
 * notifications, sidebar state, and loading indicators.
 * 
 * Handles:
 * - Language switching between Japanese and English
 * - Notification management with auto-hide functionality
 * - Sidebar toggle state
 * - Theme preferences
 * - Loading states for different sections
 */
const uiSlice = createSlice({
    name: 'ui',
    initialState,
    reducers: {
        // Language management
        setLanguage: (state, action: PayloadAction<Language>) => {
            state.language = action.payload
            // Store language preference in localStorage for persistence
            if (typeof window !== 'undefined') {
                localStorage.setItem('preferredLanguage', action.payload)
            }
        },

        // Notification management
        addNotification: (state, action: PayloadAction<Omit<Notification, 'id' | 'timestamp'>>) => {
            const notification: Notification = {
                ...action.payload,
                id: `notification-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                timestamp: new Date().toISOString(),
                autoHide: action.payload.autoHide ?? true,
                duration: action.payload.duration ?? 5000,
            }
            state.notifications.push(notification)
        },

        removeNotification: (state, action: PayloadAction<string>) => {
            state.notifications = state.notifications.filter(
                notification => notification.id !== action.payload
            )
        },

        clearAllNotifications: (state) => {
            state.notifications = []
        },

        // Sidebar management
        toggleSidebar: (state) => {
            state.sidebarOpen = !state.sidebarOpen
        },

        setSidebarOpen: (state, action: PayloadAction<boolean>) => {
            state.sidebarOpen = action.payload
        },

        // Theme management
        setTheme: (state, action: PayloadAction<'light' | 'dark'>) => {
            state.theme = action.payload
            if (typeof window !== 'undefined') {
                localStorage.setItem('theme', action.payload)
            }
        },

        // Loading state management
        setGlobalLoading: (state, action: PayloadAction<boolean>) => {
            state.loading.global = action.payload
        },

        setTasksLoading: (state, action: PayloadAction<boolean>) => {
            state.loading.tasks = action.payload
        },

        setProjectsLoading: (state, action: PayloadAction<boolean>) => {
            state.loading.projects = action.payload
        },

        setAuthLoading: (state, action: PayloadAction<boolean>) => {
            state.loading.auth = action.payload
        },

        // Initialize UI state from localStorage
        initializeUIState: (state) => {
            if (typeof window !== 'undefined') {
                const savedLanguage = localStorage.getItem('preferredLanguage') as Language
                const savedTheme = localStorage.getItem('theme') as 'light' | 'dark'

                if (savedLanguage && (savedLanguage === 'ja' || savedLanguage === 'en')) {
                    state.language = savedLanguage
                }

                if (savedTheme && (savedTheme === 'light' || savedTheme === 'dark')) {
                    state.theme = savedTheme
                }
            }
        },
    },
})

export const {
    setLanguage,
    addNotification,
    removeNotification,
    clearAllNotifications,
    toggleSidebar,
    setSidebarOpen,
    setTheme,
    setGlobalLoading,
    setTasksLoading,
    setProjectsLoading,
    setAuthLoading,
    initializeUIState,
} = uiSlice.actions

export default uiSlice.reducer