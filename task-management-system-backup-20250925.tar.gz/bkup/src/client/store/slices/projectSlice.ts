import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit'
import { Project, Task, User } from '@/shared/types'

// API functions for projects
const API_BASE = '/api'

// Project metrics interface
export interface ProjectMetrics {
    totalTasks: number
    completedTasks: number
    inProgressTasks: number
    todoTasks: number
    completionRate: number
    overdueTasksCount: number
    averageTaskDuration?: number
}

// Async thunks for project operations
export const fetchProjects = createAsyncThunk(
    'projects/fetchProjects',
    async () => {
        const response = await fetch(`${API_BASE}/projects`)
        if (!response.ok) {
            throw new Error('Failed to fetch projects')
        }
        return response.json()
    }
)

export const fetchProject = createAsyncThunk(
    'projects/fetchProject',
    async (id: string) => {
        const response = await fetch(`${API_BASE}/projects/${id}`)
        if (!response.ok) {
            throw new Error('Failed to fetch project')
        }
        return response.json()
    }
)

export const createProject = createAsyncThunk(
    'projects/createProject',
    async (projectData: Omit<Project, 'id' | 'createdAt' | 'updatedAt' | 'createdBy' | 'members'>) => {
        const response = await fetch(`${API_BASE}/projects`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(projectData),
        })
        if (!response.ok) {
            throw new Error('Failed to create project')
        }
        return response.json()
    }
)

export const updateProject = createAsyncThunk(
    'projects/updateProject',
    async ({ id, updates }: { id: string; updates: Partial<Project> }) => {
        const response = await fetch(`${API_BASE}/projects/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updates),
        })
        if (!response.ok) {
            throw new Error('Failed to update project')
        }
        return response.json()
    }
)

export const deleteProject = createAsyncThunk(
    'projects/deleteProject',
    async (id: string) => {
        const response = await fetch(`${API_BASE}/projects/${id}`, {
            method: 'DELETE',
        })
        if (!response.ok) {
            throw new Error('Failed to delete project')
        }
        return id
    }
)

export const fetchProjectTasks = createAsyncThunk(
    'projects/fetchProjectTasks',
    async (projectId: string) => {
        const response = await fetch(`${API_BASE}/projects/${projectId}/tasks`)
        if (!response.ok) {
            throw new Error('Failed to fetch project tasks')
        }
        return response.json()
    }
)

export const fetchProjectMetrics = createAsyncThunk(
    'projects/fetchProjectMetrics',
    async (projectId: string) => {
        const response = await fetch(`${API_BASE}/projects/${projectId}/metrics`)
        if (!response.ok) {
            throw new Error('Failed to fetch project metrics')
        }
        return response.json()
    }
)

export const addProjectMember = createAsyncThunk(
    'projects/addProjectMember',
    async ({ projectId, userId }: { projectId: string; userId: string }) => {
        const response = await fetch(`${API_BASE}/projects/${projectId}/members`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ userId }),
        })
        if (!response.ok) {
            throw new Error('Failed to add project member')
        }
        return response.json()
    }
)

export const removeProjectMember = createAsyncThunk(
    'projects/removeProjectMember',
    async ({ projectId, userId }: { projectId: string; userId: string }) => {
        const response = await fetch(`${API_BASE}/projects/${projectId}/members/${userId}`, {
            method: 'DELETE',
        })
        if (!response.ok) {
            throw new Error('Failed to remove project member')
        }
        return { projectId, userId }
    }
)

// Project slice state interface
interface ProjectState {
    projects: Project[]
    currentProject: Project | null
    projectTasks: Task[]
    projectMetrics: ProjectMetrics | null
    availableUsers: User[]
    loading: boolean
    error: string | null
}

const initialState: ProjectState = {
    projects: [],
    currentProject: null,
    projectTasks: [],
    projectMetrics: null,
    availableUsers: [],
    loading: false,
    error: null,
}

const projectSlice = createSlice({
    name: 'projects',
    initialState,
    reducers: {
        clearError: (state) => {
            state.error = null
        },
        clearCurrentProject: (state) => {
            state.currentProject = null
            state.projectTasks = []
            state.projectMetrics = null
        },
        setAvailableUsers: (state, action: PayloadAction<User[]>) => {
            state.availableUsers = action.payload
        },
    },
    extraReducers: (builder) => {
        // Fetch projects
        builder
            .addCase(fetchProjects.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchProjects.fulfilled, (state, action) => {
                state.loading = false
                state.projects = action.payload
            })
            .addCase(fetchProjects.rejected, (state, action) => {
                state.loading = false
                state.error = action.error.message || 'Failed to fetch projects'
            })

        // Fetch single project
        builder
            .addCase(fetchProject.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchProject.fulfilled, (state, action) => {
                state.loading = false
                state.currentProject = action.payload
            })
            .addCase(fetchProject.rejected, (state, action) => {
                state.loading = false
                state.error = action.error.message || 'Failed to fetch project'
            })

        // Create project
        builder
            .addCase(createProject.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(createProject.fulfilled, (state, action) => {
                state.loading = false
                state.projects.unshift(action.payload)
            })
            .addCase(createProject.rejected, (state, action) => {
                state.loading = false
                state.error = action.error.message || 'Failed to create project'
            })

        // Update project
        builder
            .addCase(updateProject.fulfilled, (state, action) => {
                const index = state.projects.findIndex(project => project.id === action.payload.id)
                if (index !== -1) {
                    state.projects[index] = action.payload
                }
                if (state.currentProject?.id === action.payload.id) {
                    state.currentProject = action.payload
                }
            })
            .addCase(updateProject.rejected, (state, action) => {
                state.error = action.error.message || 'Failed to update project'
            })

        // Delete project
        builder
            .addCase(deleteProject.fulfilled, (state, action) => {
                state.projects = state.projects.filter(project => project.id !== action.payload)
                if (state.currentProject?.id === action.payload) {
                    state.currentProject = null
                    state.projectTasks = []
                    state.projectMetrics = null
                }
            })
            .addCase(deleteProject.rejected, (state, action) => {
                state.error = action.error.message || 'Failed to delete project'
            })

        // Fetch project tasks
        builder
            .addCase(fetchProjectTasks.fulfilled, (state, action) => {
                state.projectTasks = action.payload
            })
            .addCase(fetchProjectTasks.rejected, (state, action) => {
                state.error = action.error.message || 'Failed to fetch project tasks'
            })

        // Fetch project metrics
        builder
            .addCase(fetchProjectMetrics.fulfilled, (state, action) => {
                state.projectMetrics = action.payload
            })
            .addCase(fetchProjectMetrics.rejected, (state, action) => {
                state.error = action.error.message || 'Failed to fetch project metrics'
            })

        // Add project member
        builder
            .addCase(addProjectMember.fulfilled, (state, action) => {
                if (state.currentProject) {
                    state.currentProject = action.payload
                }
                const projectIndex = state.projects.findIndex(p => p.id === action.payload.id)
                if (projectIndex !== -1) {
                    state.projects[projectIndex] = action.payload
                }
            })
            .addCase(addProjectMember.rejected, (state, action) => {
                state.error = action.error.message || 'Failed to add project member'
            })

        // Remove project member
        builder
            .addCase(removeProjectMember.fulfilled, (state, action) => {
                const { projectId, userId } = action.payload
                if (state.currentProject?.id === projectId) {
                    state.currentProject.members = state.currentProject.members.filter(id => id !== userId)
                }
                const projectIndex = state.projects.findIndex(p => p.id === projectId)
                if (projectIndex !== -1) {
                    state.projects[projectIndex].members = state.projects[projectIndex].members.filter(id => id !== userId)
                }
            })
            .addCase(removeProjectMember.rejected, (state, action) => {
                state.error = action.error.message || 'Failed to remove project member'
            })
    },
})

export const { clearError, clearCurrentProject, setAvailableUsers } = projectSlice.actions
export default projectSlice.reducer