import { useCallback } from 'react'
import { useAppDispatch, useAppSelector } from './index'
import { addNotification, removeNotification, setLanguage } from './slices/uiSlice'
import { clearError as clearAuthError } from './slices/authSlice'
import { clearError as clearTaskError } from './slices/taskSlice'
import { clearError as clearProjectError } from './slices/projectSlice'
import type { Language } from '@/shared/types'
import type { Notification } from './slices/uiSlice'

/**
 * Custom hook for managing UI notifications
 * Provides methods to show success, error, warning, and info notifications
 */
export const useNotifications = () => {
    const dispatch = useAppDispatch()
    const notifications = useAppSelector(state => state.ui.notifications)

    const showNotification = useCallback((notification: Omit<Notification, 'id' | 'timestamp'>) => {
        dispatch(addNotification(notification))
    }, [dispatch])

    const showSuccess = useCallback((message: string, autoHide = true, duration = 5000) => {
        showNotification({ type: 'success', message, autoHide, duration })
    }, [showNotification])

    const showError = useCallback((message: string, autoHide = false, duration = 8000) => {
        showNotification({ type: 'error', message, autoHide, duration })
    }, [showNotification])

    const showWarning = useCallback((message: string, autoHide = true, duration = 6000) => {
        showNotification({ type: 'warning', message, autoHide, duration })
    }, [showNotification])

    const showInfo = useCallback((message: string, autoHide = true, duration = 5000) => {
        showNotification({ type: 'info', message, autoHide, duration })
    }, [showNotification])

    const hideNotification = useCallback((id: string) => {
        dispatch(removeNotification(id))
    }, [dispatch])

    return {
        notifications,
        showNotification,
        showSuccess,
        showError,
        showWarning,
        showInfo,
        hideNotification,
    }
}

/**
 * Custom hook for managing language preferences
 * Handles language switching and provides current language state
 */
export const useLanguage = () => {
    const dispatch = useAppDispatch()
    const currentLanguage = useAppSelector(state => state.ui.language)

    const changeLanguage = useCallback((language: Language) => {
        dispatch(setLanguage(language))
    }, [dispatch])

    const toggleLanguage = useCallback(() => {
        const newLanguage = currentLanguage === 'ja' ? 'en' : 'ja'
        changeLanguage(newLanguage)
    }, [currentLanguage, changeLanguage])

    return {
        currentLanguage,
        changeLanguage,
        toggleLanguage,
        isJapanese: currentLanguage === 'ja',
        isEnglish: currentLanguage === 'en',
    }
}

/**
 * Custom hook for managing loading states across the application
 */
export const useLoadingStates = () => {
    const loading = useAppSelector(state => state.ui.loading)
    const authLoading = useAppSelector(state => state.auth.isLoading)
    const tasksLoading = useAppSelector(state => state.tasks.loading)
    const projectsLoading = useAppSelector(state => state.projects.loading)

    return {
        global: loading.global,
        auth: authLoading,
        tasks: tasksLoading,
        projects: projectsLoading,
        isAnyLoading: loading.global || authLoading || tasksLoading || projectsLoading,
    }
}

/**
 * Custom hook for managing error states across all slices
 * Provides methods to clear errors from different parts of the application
 */
export const useErrorHandling = () => {
    const dispatch = useAppDispatch()

    const authError = useAppSelector(state => state.auth.error)
    const tasksError = useAppSelector(state => state.tasks.error)
    const projectsError = useAppSelector(state => state.projects.error)

    const clearAuthErrors = useCallback(() => {
        dispatch(clearAuthError())
    }, [dispatch])

    const clearTaskErrors = useCallback(() => {
        dispatch(clearTaskError())
    }, [dispatch])

    const clearProjectErrors = useCallback(() => {
        dispatch(clearProjectError())
    }, [dispatch])

    const clearAllErrors = useCallback(() => {
        clearAuthErrors()
        clearTaskErrors()
        clearProjectErrors()
    }, [clearAuthErrors, clearTaskErrors, clearProjectErrors])

    return {
        errors: {
            auth: authError,
            tasks: tasksError,
            projects: projectsError,
        },
        hasErrors: !!(authError || tasksError || projectsError),
        clearAuthErrors,
        clearTaskErrors,
        clearProjectErrors,
        clearAllErrors,
    }
}

/**
 * Custom hook for accessing current user information and authentication state
 */
export const useAuth = () => {
    const auth = useAppSelector(state => state.auth)

    return {
        user: auth.user,
        token: auth.token,
        isAuthenticated: auth.isAuthenticated,
        isLoading: auth.isLoading,
        error: auth.error,
        isAdmin: auth.user?.role === 'admin',
        isManager: auth.user?.role === 'manager' || auth.user?.role === 'admin',
        isMember: !!auth.user,
    }
}

/**
 * Custom hook for accessing task-related state and computed values
 */
export const useTaskState = () => {
    const tasks = useAppSelector(state => state.tasks)

    // Computed values for task statistics
    const taskStats = {
        total: tasks.tasks.length,
        todo: tasks.tasks.filter(task => task.status === 'todo').length,
        inProgress: tasks.tasks.filter(task => task.status === 'in-progress').length,
        completed: tasks.tasks.filter(task => task.status === 'completed').length,
        overdue: tasks.tasks.filter(task =>
            task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'completed'
        ).length,
    }

    return {
        ...tasks,
        taskStats,
    }
}

/**
 * Custom hook for accessing project-related state and computed values
 */
export const useProjectState = () => {
    const projects = useAppSelector(state => state.projects)

    return {
        ...projects,
        hasCurrentProject: !!projects.currentProject,
        projectCount: projects.projects.length,
    }
}