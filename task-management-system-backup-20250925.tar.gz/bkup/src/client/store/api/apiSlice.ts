import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import type { RootState } from '../index'
import type { User, Task, Project, TaskStatus, TaskPriority } from '@/shared/types'
import { logError, extractErrorInfo, shouldRedirectToLogin } from '../../utils/errorHandling'

// API response types
export interface AuthResponse {
    user: User
    token: string
}

export interface LoginCredentials {
    email: string
    password: string
}

export interface RegisterData {
    name: string
    email: string
    password: string
}

export interface TaskFilters {
    status?: TaskStatus
    priority?: TaskPriority
    assigneeId?: string
    projectId?: string
    search?: string
}

export interface ProjectMetrics {
    totalTasks: number
    completedTasks: number
    inProgressTasks: number
    todoTasks: number
    completionRate: number
    overdueTasksCount: number
    averageTaskDuration?: number
}

/**
 * RTK Query API slice for centralized API communication
 * 
 * Provides:
 * - Automatic caching and invalidation
 * - Loading state management
 * - Error handling
 * - Optimistic updates
 * - Background refetching
 */
export const apiSlice = createApi({
    reducerPath: 'api',
    baseQuery: fetchBaseQuery({
        baseUrl: '/api',
        prepareHeaders: (headers, { getState }) => {
            // Add auth token to requests
            const token = (getState() as RootState).auth.token
            if (token) {
                headers.set('authorization', `Bearer ${token}`)
            }
            headers.set('content-type', 'application/json')
            return headers
        },
        // Global error handling
        responseHandler: async (response) => {
            // Handle successful responses
            if (response.ok) {
                const contentType = response.headers.get('content-type')
                if (contentType && contentType.includes('application/json')) {
                    return response.json()
                }
                return response.text()
            }

            // Handle error responses
            let errorData
            try {
                errorData = await response.json()
            } catch {
                errorData = { error: { message: response.statusText } }
            }

            // Log error for monitoring
            const processedError = extractErrorInfo({
                status: response.status,
                data: errorData
            })
            logError(processedError, 'API_REQUEST')

            // Handle authentication errors
            if (shouldRedirectToLogin(processedError)) {
                // Dispatch logout action or redirect to login
                window.location.href = '/login'
            }

            throw errorData
        },
    }),
    tagTypes: ['User', 'Task', 'Project', 'ProjectMetrics'],
    endpoints: (builder) => ({
        // Authentication endpoints
        login: builder.mutation<AuthResponse, LoginCredentials>({
            query: (credentials) => ({
                url: '/auth/login',
                method: 'POST',
                body: credentials,
            }),
            invalidatesTags: ['User'],
        }),

        register: builder.mutation<AuthResponse, RegisterData>({
            query: (userData) => ({
                url: '/auth/register',
                method: 'POST',
                body: userData,
            }),
            invalidatesTags: ['User'],
        }),

        // User endpoints
        getCurrentUser: builder.query<User, void>({
            query: () => '/users/profile',
            providesTags: ['User'],
        }),

        updateUserProfile: builder.mutation<User, Partial<User>>({
            query: (updates) => ({
                url: '/users/profile',
                method: 'PUT',
                body: updates,
            }),
            invalidatesTags: ['User'],
        }),

        getTeamMembers: builder.query<User[], void>({
            query: () => '/users',
            providesTags: ['User'],
        }),

        // Task endpoints
        getTasks: builder.query<Task[], TaskFilters | void>({
            query: (filters = {}) => {
                const params = new URLSearchParams()
                Object.entries(filters).forEach(([key, value]) => {
                    if (value) params.append(key, value)
                })
                return `/tasks?${params}`
            },
            providesTags: (result) =>
                result
                    ? [
                        ...result.map(({ id }) => ({ type: 'Task' as const, id })),
                        { type: 'Task', id: 'LIST' },
                    ]
                    : [{ type: 'Task', id: 'LIST' }],
        }),

        getTask: builder.query<Task, string>({
            query: (id) => `/tasks/${id}`,
            providesTags: (result, error, id) => [{ type: 'Task', id }],
        }),

        createTask: builder.mutation<Task, Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'createdBy'>>({
            query: (taskData) => ({
                url: '/tasks',
                method: 'POST',
                body: taskData,
            }),
            invalidatesTags: [{ type: 'Task', id: 'LIST' }, 'ProjectMetrics'],
        }),

        updateTask: builder.mutation<Task, { id: string; updates: Partial<Task> }>({
            query: ({ id, updates }) => ({
                url: `/tasks/${id}`,
                method: 'PUT',
                body: updates,
            }),
            invalidatesTags: (result, error, { id }) => [
                { type: 'Task', id },
                { type: 'Task', id: 'LIST' },
                'ProjectMetrics',
            ],
        }),

        updateTaskStatus: builder.mutation<Task, { id: string; status: TaskStatus }>({
            query: ({ id, status }) => ({
                url: `/tasks/${id}/status`,
                method: 'PATCH',
                body: { status },
            }),
            invalidatesTags: (result, error, { id }) => [
                { type: 'Task', id },
                { type: 'Task', id: 'LIST' },
                'ProjectMetrics',
            ],
        }),

        deleteTask: builder.mutation<void, string>({
            query: (id) => ({
                url: `/tasks/${id}`,
                method: 'DELETE',
            }),
            invalidatesTags: (result, error, id) => [
                { type: 'Task', id },
                { type: 'Task', id: 'LIST' },
                'ProjectMetrics',
            ],
        }),

        // Project endpoints
        getProjects: builder.query<Project[], void>({
            query: () => '/projects',
            providesTags: (result) =>
                result
                    ? [
                        ...result.map(({ id }) => ({ type: 'Project' as const, id })),
                        { type: 'Project', id: 'LIST' },
                    ]
                    : [{ type: 'Project', id: 'LIST' }],
        }),

        getProject: builder.query<Project, string>({
            query: (id) => `/projects/${id}`,
            providesTags: (result, error, id) => [{ type: 'Project', id }],
        }),

        createProject: builder.mutation<Project, Omit<Project, 'id' | 'createdAt' | 'updatedAt' | 'createdBy' | 'members'>>({
            query: (projectData) => ({
                url: '/projects',
                method: 'POST',
                body: projectData,
            }),
            invalidatesTags: [{ type: 'Project', id: 'LIST' }],
        }),

        updateProject: builder.mutation<Project, { id: string; updates: Partial<Project> }>({
            query: ({ id, updates }) => ({
                url: `/projects/${id}`,
                method: 'PUT',
                body: updates,
            }),
            invalidatesTags: (result, error, { id }) => [
                { type: 'Project', id },
                { type: 'Project', id: 'LIST' },
            ],
        }),

        deleteProject: builder.mutation<void, string>({
            query: (id) => ({
                url: `/projects/${id}`,
                method: 'DELETE',
            }),
            invalidatesTags: (result, error, id) => [
                { type: 'Project', id },
                { type: 'Project', id: 'LIST' },
                { type: 'Task', id: 'LIST' },
            ],
        }),

        getProjectTasks: builder.query<Task[], string>({
            query: (projectId) => `/projects/${projectId}/tasks`,
            providesTags: (result, error, projectId) => [
                { type: 'Task', id: 'LIST' },
                { type: 'Project', id: projectId },
            ],
        }),

        getProjectMetrics: builder.query<ProjectMetrics, string>({
            query: (projectId) => `/projects/${projectId}/metrics`,
            providesTags: (result, error, projectId) => [
                { type: 'ProjectMetrics', id: projectId },
            ],
        }),

        addProjectMember: builder.mutation<Project, { projectId: string; userId: string }>({
            query: ({ projectId, userId }) => ({
                url: `/projects/${projectId}/members`,
                method: 'POST',
                body: { userId },
            }),
            invalidatesTags: (result, error, { projectId }) => [
                { type: 'Project', id: projectId },
                { type: 'Project', id: 'LIST' },
            ],
        }),

        removeProjectMember: builder.mutation<void, { projectId: string; userId: string }>({
            query: ({ projectId, userId }) => ({
                url: `/projects/${projectId}/members/${userId}`,
                method: 'DELETE',
            }),
            invalidatesTags: (result, error, { projectId }) => [
                { type: 'Project', id: projectId },
                { type: 'Project', id: 'LIST' },
            ],
        }),
    }),
})

// Export hooks for usage in functional components
export const {
    // Auth hooks
    useLoginMutation,
    useRegisterMutation,

    // User hooks
    useGetCurrentUserQuery,
    useUpdateUserProfileMutation,
    useGetTeamMembersQuery,

    // Task hooks
    useGetTasksQuery,
    useGetTaskQuery,
    useCreateTaskMutation,
    useUpdateTaskMutation,
    useUpdateTaskStatusMutation,
    useDeleteTaskMutation,

    // Project hooks
    useGetProjectsQuery,
    useGetProjectQuery,
    useCreateProjectMutation,
    useUpdateProjectMutation,
    useDeleteProjectMutation,
    useGetProjectTasksQuery,
    useGetProjectMetricsQuery,
    useAddProjectMemberMutation,
    useRemoveProjectMemberMutation,
} = apiSlice