import { createAsyncThunk } from '@reduxjs/toolkit'
import { addNotification } from '../slices/uiSlice'
import type { RootState, AppDispatch } from '../index'

// Enhanced error handling for async thunks
export interface AsyncThunkConfig {
    state: RootState
    dispatch: AppDispatch
    rejectValue: string
}

/**
 * Enhanced createAsyncThunk wrapper with automatic error handling and notifications
 * 
 * @param typePrefix - The action type prefix
 * @param payloadCreator - The async function to execute
 * @param options - Additional options including error handling
 */
export const createAsyncThunkWithErrorHandling = <Returned, ThunkArg = void>(
    typePrefix: string,
    payloadCreator: (
        arg: ThunkArg,
        thunkAPI: {
            dispatch: AppDispatch
            getState: () => RootState
            rejectWithValue: (value: string) => any
        }
    ) => Promise<Returned>,
    options?: {
        showSuccessNotification?: boolean
        successMessage?: string
        showErrorNotification?: boolean
        customErrorHandler?: (error: any, dispatch: AppDispatch) => void
    }
) => {
    return createAsyncThunk<Returned, ThunkArg, AsyncThunkConfig>(
        typePrefix,
        async (arg, { dispatch, getState, rejectWithValue }) => {
            try {
                const result = await payloadCreator(arg, { dispatch, getState, rejectWithValue })

                // Show success notification if enabled
                if (options?.showSuccessNotification && options?.successMessage) {
                    dispatch(addNotification({
                        type: 'success',
                        message: options.successMessage,
                        autoHide: true,
                        duration: 3000,
                    }))
                }

                return result
            } catch (error: any) {
                const errorMessage = extractErrorMessage(error)

                // Custom error handler
                if (options?.customErrorHandler) {
                    options.customErrorHandler(error, dispatch)
                } else if (options?.showErrorNotification !== false) {
                    // Show error notification by default
                    dispatch(addNotification({
                        type: 'error',
                        message: errorMessage,
                        autoHide: false,
                        duration: 8000,
                    }))
                }

                return rejectWithValue(errorMessage)
            }
        }
    )
}

/**
 * Extract user-friendly error message from various error types
 */
export const extractErrorMessage = (error: any): string => {
    // Handle fetch/network errors
    if (error instanceof TypeError && error.message.includes('fetch')) {
        return 'Network error. Please check your connection and try again.'
    }

    // Handle HTTP response errors
    if (error.response) {
        const status = error.response.status
        const data = error.response.data

        switch (status) {
            case 400:
                return data?.error?.message || 'Invalid request. Please check your input.'
            case 401:
                return 'Authentication required. Please log in again.'
            case 403:
                return 'You do not have permission to perform this action.'
            case 404:
                return 'The requested resource was not found.'
            case 409:
                return data?.error?.message || 'A conflict occurred. The resource may already exist.'
            case 422:
                return data?.error?.message || 'Validation failed. Please check your input.'
            case 429:
                return 'Too many requests. Please wait a moment and try again.'
            case 500:
                return 'Server error. Please try again later.'
            case 503:
                return 'Service temporarily unavailable. Please try again later.'
            default:
                return data?.error?.message || `Request failed with status ${status}`
        }
    }

    // Handle API error responses
    if (error.error && typeof error.error === 'object') {
        return error.error.message || 'An error occurred'
    }

    // Handle string errors
    if (typeof error === 'string') {
        return error
    }

    // Handle Error objects
    if (error instanceof Error) {
        return error.message
    }

    // Fallback for unknown error types
    return 'An unexpected error occurred. Please try again.'
}

/**
 * Retry mechanism for failed async operations
 */
export const withRetry = async <T>(
    operation: () => Promise<T>,
    maxRetries: number = 3,
    delay: number = 1000
): Promise<T> => {
    let lastError: any

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            return await operation()
        } catch (error) {
            lastError = error

            // Don't retry on client errors (4xx) except 408, 429
            if (error.response?.status >= 400 && error.response?.status < 500) {
                if (error.response.status !== 408 && error.response.status !== 429) {
                    throw error
                }
            }

            // Don't retry on the last attempt
            if (attempt === maxRetries) {
                break
            }

            // Wait before retrying with exponential backoff
            await new Promise(resolve => setTimeout(resolve, delay * Math.pow(2, attempt - 1)))
        }
    }

    throw lastError
}

/**
 * Debounced async thunk creator for operations that should be delayed
 */
export const createDebouncedAsyncThunk = <Returned, ThunkArg = void>(
    typePrefix: string,
    payloadCreator: (arg: ThunkArg, thunkAPI: any) => Promise<Returned>,
    debounceMs: number = 300
) => {
    let timeoutId: NodeJS.Timeout | null = null

    return createAsyncThunk<Returned, ThunkArg, AsyncThunkConfig>(
        typePrefix,
        async (arg, thunkAPI) => {
            return new Promise<Returned>((resolve, reject) => {
                if (timeoutId) {
                    clearTimeout(timeoutId)
                }

                timeoutId = setTimeout(async () => {
                    try {
                        const result = await payloadCreator(arg, thunkAPI)
                        resolve(result)
                    } catch (error) {
                        reject(error)
                    }
                }, debounceMs)
            })
        }
    )
}

/**
 * Optimistic update helper for immediate UI feedback
 */
export const createOptimisticAsyncThunk = <Returned, ThunkArg = void>(
    typePrefix: string,
    payloadCreator: (arg: ThunkArg, thunkAPI: any) => Promise<Returned>,
    optimisticUpdate: (arg: ThunkArg, dispatch: AppDispatch, getState: () => RootState) => void,
    revertUpdate: (arg: ThunkArg, dispatch: AppDispatch, getState: () => RootState) => void
) => {
    return createAsyncThunk<Returned, ThunkArg, AsyncThunkConfig>(
        typePrefix,
        async (arg, { dispatch, getState, rejectWithValue }) => {
            // Apply optimistic update
            optimisticUpdate(arg, dispatch, getState)

            try {
                const result = await payloadCreator(arg, { dispatch, getState, rejectWithValue })
                return result
            } catch (error) {
                // Revert optimistic update on failure
                revertUpdate(arg, dispatch, getState)
                throw error
            }
        }
    )
}