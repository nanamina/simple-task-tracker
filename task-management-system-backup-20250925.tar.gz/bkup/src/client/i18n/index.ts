import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Import translation files
import jaTranslations from './locales/ja.json';
import enTranslations from './locales/en.json';

/**
 * i18next configuration for the Task Management System
 * Supports Japanese (default) and English languages
 */
i18n
    .use(LanguageDetector) // Detect user language
    .use(initReactI18next) // Pass i18n instance to react-i18next
    .init({
        // Default language is Japanese as per requirements
        lng: 'ja',
        fallbackLng: 'ja',

        // Available languages
        supportedLngs: ['ja', 'en'],

        // Language detection options
        detection: {
            // Check localStorage first, then browser language
            order: ['localStorage', 'navigator'],
            caches: ['localStorage'],
            lookupLocalStorage: 'i18nextLng',
        },

        // Translation resources
        resources: {
            ja: {
                translation: jaTranslations,
            },
            en: {
                translation: enTranslations,
            },
        },

        // Interpolation options
        interpolation: {
            escapeValue: false, // React already escapes values
        },

        // Development options
        debug: process.env.NODE_ENV === 'development',

        // React-specific options
        react: {
            useSuspense: false, // Disable suspense for better error handling
        },
    });

export default i18n;