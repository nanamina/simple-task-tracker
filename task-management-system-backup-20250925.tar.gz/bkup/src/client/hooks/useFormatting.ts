import { useMemo } from 'react';
import { useTranslation } from './useTranslation';
import {
    formatDate,
    formatDateTime,
    formatTime,
    formatRelativeTime,
    formatNumber,
    formatCurrency,
    formatPercentage,
    getCurrentLocale,
    uses24HourFormat,
    getDateSeparator,
    formatFileSize,
} from '../utils/formatting';

/**
 * Custom hook for locale-aware formatting
 * Provides formatting functions that automatically update when language changes
 */
export const useFormatting = () => {
    const { getCurrentLanguage } = useTranslation();

    // Memoize the current language to avoid unnecessary recalculations
    const currentLanguage = useMemo(() => getCurrentLanguage(), [getCurrentLanguage]);

    // Memoize formatting functions to maintain referential equality
    const formatters = useMemo(() => ({
        /**
         * Format a date according to the current locale
         */
        date: (date: Date | string, options?: Intl.DateTimeFormatOptions) =>
            formatDate(date, options),

        /**
         * Format a date and time according to the current locale
         */
        dateTime: (date: Date | string, options?: Intl.DateTimeFormatOptions) =>
            formatDateTime(date, options),

        /**
         * Format a time according to the current locale
         */
        time: (date: Date | string, options?: Intl.DateTimeFormatOptions) =>
            formatTime(date, options),

        /**
         * Format a relative time (e.g., "2 days ago")
         */
        relativeTime: (date: Date | string, options?: Intl.RelativeTimeFormatOptions) =>
            formatRelativeTime(date, options),

        /**
         * Format a number according to the current locale
         */
        number: (number: number, options?: Intl.NumberFormatOptions) =>
            formatNumber(number, options),

        /**
         * Format a currency amount according to the current locale
         */
        currency: (amount: number, currency?: string, options?: Intl.NumberFormatOptions) =>
            formatCurrency(amount, currency, options),

        /**
         * Format a percentage according to the current locale
         */
        percentage: (value: number, options?: Intl.NumberFormatOptions) =>
            formatPercentage(value, options),

        /**
         * Format a file size in human-readable format
         */
        fileSize: (bytes: number, decimals?: number) =>
            formatFileSize(bytes, decimals),
    }), [currentLanguage]);

    // Memoize locale information
    const localeInfo = useMemo(() => ({
        /**
         * Get the current locale string
         */
        locale: getCurrentLocale(),

        /**
         * Check if 24-hour format is used
         */
        uses24Hour: uses24HourFormat(),

        /**
         * Get the date separator character
         */
        dateSeparator: getDateSeparator(),

        /**
         * Get the current language code
         */
        language: currentLanguage,
    }), [currentLanguage]);

    return {
        ...formatters,
        ...localeInfo,
    };
};

export default useFormatting;