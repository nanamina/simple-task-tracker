import { useTranslation as useI18nTranslation } from 'react-i18next';

/**
 * Custom hook for translations with type safety
 * Wraps react-i18next's useTranslation hook with additional utilities
 */
export const useTranslation = () => {
    const { t, i18n } = useI18nTranslation();

    /**
     * Change the current language
     * @param language - Language code ('ja' or 'en')
     */
    const changeLanguage = async (language: 'ja' | 'en') => {
        try {
            await i18n.changeLanguage(language);
            // Store preference in localStorage
            localStorage.setItem('i18nextLng', language);
        } catch (error) {
            console.error('Failed to change language:', error);
        }
    };

    /**
     * Get the current language
     * @returns Current language code
     */
    const getCurrentLanguage = (): 'ja' | 'en' => {
        return (i18n.language as 'ja' | 'en') || 'ja';
    };

    /**
     * Check if the current language is Japanese
     * @returns True if current language is Japanese
     */
    const isJapanese = (): boolean => {
        return getCurrentLanguage() === 'ja';
    };

    /**
     * Check if the current language is English
     * @returns True if current language is English
     */
    const isEnglish = (): boolean => {
        return getCurrentLanguage() === 'en';
    };

    /**
     * Get available languages
     * @returns Array of available language codes
     */
    const getAvailableLanguages = (): Array<{ code: 'ja' | 'en'; name: string }> => {
        return [
            { code: 'ja', name: t('profile.languages.ja') },
            { code: 'en', name: t('profile.languages.en') },
        ];
    };

    return {
        t,
        i18n,
        changeLanguage,
        getCurrentLanguage,
        isJapanese,
        isEnglish,
        getAvailableLanguages,
    };
};

export default useTranslation;