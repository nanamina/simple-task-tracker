import { useSelector, useDispatch } from 'react-redux'
import { useCallback } from 'react'
import { RootState, AppDispatch } from '@/client/store'
import {
    fetchTasks,
    createTask,
    updateTask,
    updateTaskStatus,
    deleteTask,
    setFilters,
    setSorting,
    clearError,
} from '@/client/store/slices/taskSlice'
import { Task, TaskStatus, TaskPriority } from '@/shared/types'

/**
 * Custom hook for task management operations
 * Provides access to task state and actions for components
 */
export const useTasks = () => {
    const dispatch = useDispatch<AppDispatch>()
    const taskState = useSelector((state: RootState) => state.tasks)

    // Fetch tasks with optional filters
    const loadTasks = useCallback((filters?: {
        status?: TaskStatus
        priority?: TaskPriority
        assigneeId?: string
        projectId?: string
        search?: string
    }) => {
        dispatch(fetchTasks(filters))
    }, [dispatch])

    // Create a new task
    const addTask = useCallback((taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'createdBy'>) => {
        return dispatch(createTask(taskData))
    }, [dispatch])

    // Update an existing task
    const editTask = useCallback((id: string, updates: Partial<Task>) => {
        return dispatch(updateTask({ id, updates }))
    }, [dispatch])

    // Update task status specifically
    const changeTaskStatus = useCallback((id: string, status: TaskStatus) => {
        return dispatch(updateTaskStatus({ id, status }))
    }, [dispatch])

    // Delete a task
    const removeTask = useCallback((id: string) => {
        return dispatch(deleteTask(id))
    }, [dispatch])

    // Update filters
    const updateFilters = useCallback((filters: {
        status?: TaskStatus
        priority?: TaskPriority
        assigneeId?: string
        projectId?: string
        search?: string
    }) => {
        dispatch(setFilters(filters))
    }, [dispatch])

    // Update sorting
    const updateSorting = useCallback((sortBy: 'dueDate' | 'priority' | 'createdAt' | 'status', sortOrder: 'asc' | 'desc') => {
        dispatch(setSorting({ sortBy, sortOrder }))
    }, [dispatch])

    // Clear error state
    const clearTaskError = useCallback(() => {
        dispatch(clearError())
    }, [dispatch])

    // Get filtered and sorted tasks
    const getFilteredTasks = useCallback(() => {
        let filteredTasks = [...taskState.tasks]

        // Apply filters
        const { status, priority, assigneeId, projectId, search } = taskState.filters

        if (status) {
            filteredTasks = filteredTasks.filter(task => task.status === status)
        }
        if (priority) {
            filteredTasks = filteredTasks.filter(task => task.priority === priority)
        }
        if (assigneeId) {
            filteredTasks = filteredTasks.filter(task => task.assigneeId === assigneeId)
        }
        if (projectId) {
            filteredTasks = filteredTasks.filter(task => task.projectId === projectId)
        }
        if (search) {
            const searchLower = search.toLowerCase()
            filteredTasks = filteredTasks.filter(task =>
                task.title.toLowerCase().includes(searchLower) ||
                task.description.toLowerCase().includes(searchLower)
            )
        }

        // Apply sorting
        filteredTasks.sort((a, b) => {
            let aValue: any
            let bValue: any

            switch (taskState.sortBy) {
                case 'dueDate':
                    aValue = a.dueDate ? new Date(a.dueDate).getTime() : Infinity
                    bValue = b.dueDate ? new Date(b.dueDate).getTime() : Infinity
                    break
                case 'priority':
                    const priorityOrder = { low: 1, medium: 2, high: 3, critical: 4 }
                    aValue = priorityOrder[a.priority]
                    bValue = priorityOrder[b.priority]
                    break
                case 'createdAt':
                    aValue = new Date(a.createdAt).getTime()
                    bValue = new Date(b.createdAt).getTime()
                    break
                case 'status':
                    const statusOrder = { todo: 1, 'in-progress': 2, completed: 3 }
                    aValue = statusOrder[a.status]
                    bValue = statusOrder[b.status]
                    break
                default:
                    return 0
            }

            if (taskState.sortOrder === 'asc') {
                return aValue - bValue
            } else {
                return bValue - aValue
            }
        })

        return filteredTasks
    }, [taskState])

    return {
        // State
        tasks: taskState.tasks,
        filteredTasks: getFilteredTasks(),
        loading: taskState.loading,
        error: taskState.error,
        filters: taskState.filters,
        sortBy: taskState.sortBy,
        sortOrder: taskState.sortOrder,

        // Actions
        loadTasks,
        addTask,
        editTask,
        changeTaskStatus,
        removeTask,
        updateFilters,
        updateSorting,
        clearTaskError,
    }
}