import React, { useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { SerializedError } from '@reduxjs/toolkit'
import { FetchBaseQueryError } from '@reduxjs/toolkit/query'
import {
    extractErrorInfo,
    shouldRedirectToLogin,
    logError,
    ProcessedError
} from '../utils/errorHandling'
import { logout } from '../store/slices/authSlice'

/**
 * Hook for handling errors consistently across components
 * Provides error processing, logging, and navigation logic
 */
export function useErrorHandler() {
    const navigate = useNavigate()
    const dispatch = useDispatch()

    /**
     * Process and handle an error from RTK Query or other sources
     */
    const handleError = useCallback((
        error: FetchBaseQueryError | SerializedError | undefined,
        context?: string
    ): ProcessedError => {
        const processedError = extractErrorInfo(error)

        // Log the error
        logError(processedError, context)

        // Handle authentication errors
        if (shouldRedirectToLogin(processedError)) {
            dispatch(logout())
            navigate('/login', { replace: true })
        }

        return processedError
    }, [navigate, dispatch])

    /**
     * Handle form submission errors
     */
    const handleFormError = useCallback((
        error: FetchBaseQueryError | SerializedError | undefined,
        setFieldErrors?: (errors: Record<string, string>) => void
    ): ProcessedError => {
        const processedError = handleError(error, 'FORM_SUBMISSION')

        // Set field-specific errors if available
        if (setFieldErrors && processedError.details) {
            const fieldErrors = extractFieldErrors(processedError.details)
            if (Object.keys(fieldErrors).length > 0) {
                setFieldErrors(fieldErrors)
            }
        }

        return processedError
    }, [handleError])

    /**
     * Handle API query errors (for data fetching)
     */
    const handleQueryError = useCallback((
        error: FetchBaseQueryError | SerializedError | undefined,
        resourceName?: string
    ): ProcessedError => {
        const context = resourceName ? `QUERY_${resourceName.toUpperCase()}` : 'QUERY'
        return handleError(error, context)
    }, [handleError])

    /**
     * Handle mutation errors (for data modification)
     */
    const handleMutationError = useCallback((
        error: FetchBaseQueryError | SerializedError | undefined,
        operation?: string
    ): ProcessedError => {
        const context = operation ? `MUTATION_${operation.toUpperCase()}` : 'MUTATION'
        return handleError(error, context)
    }, [handleError])

    return {
        handleError,
        handleFormError,
        handleQueryError,
        handleMutationError,
    }
}

/**
 * Extract field-specific errors from error details
 */
function extractFieldErrors(details: any): Record<string, string> {
    if (!details || typeof details !== 'object') {
        return {}
    }

    const fieldErrors: Record<string, string> = {}

    // Handle express-validator format
    if (Array.isArray(details)) {
        details.forEach((error: any) => {
            if (error.path && error.msg) {
                fieldErrors[error.path] = error.msg
            }
        })
    }

    // Handle object format
    if (typeof details === 'object' && !Array.isArray(details)) {
        Object.entries(details).forEach(([field, message]) => {
            if (typeof message === 'string') {
                fieldErrors[field] = message
            }
        })
    }

    return fieldErrors
}

/**
 * Hook for handling network connectivity
 */
export function useNetworkStatus() {
    const [isOnline, setIsOnline] = React.useState(navigator.onLine)

    React.useEffect(() => {
        const handleOnline = () => setIsOnline(true)
        const handleOffline = () => setIsOnline(false)

        window.addEventListener('online', handleOnline)
        window.addEventListener('offline', handleOffline)

        return () => {
            window.removeEventListener('online', handleOnline)
            window.removeEventListener('offline', handleOffline)
        }
    }, [])

    return { isOnline, isOffline: !isOnline }
}

/**
 * Hook for retry functionality
 */
export function useRetry() {
    const [retryCount, setRetryCount] = React.useState(0)
    const [isRetrying, setIsRetrying] = React.useState(false)

    const retry = useCallback(async (
        operation: () => Promise<any>,
        maxRetries: number = 3,
        delay: number = 1000
    ) => {
        if (retryCount >= maxRetries) {
            throw new Error('Maximum retry attempts reached')
        }

        setIsRetrying(true)

        try {
            // Add exponential backoff delay
            if (retryCount > 0) {
                await new Promise(resolve =>
                    setTimeout(resolve, delay * Math.pow(2, retryCount - 1))
                )
            }

            const result = await operation()
            setRetryCount(0) // Reset on success
            return result
        } catch (error) {
            setRetryCount(prev => prev + 1)
            throw error
        } finally {
            setIsRetrying(false)
        }
    }, [retryCount])

    const resetRetry = useCallback(() => {
        setRetryCount(0)
        setIsRetrying(false)
    }, [])

    return {
        retry,
        resetRetry,
        retryCount,
        isRetrying,
        canRetry: retryCount < 3
    }
}

