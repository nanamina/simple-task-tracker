import { useSelector, useDispatch } from 'react-redux'
import { useCallback } from 'react'
import { RootState, AppDispatch } from '@/client/store'
import { logout, clearError } from '@/client/store/slices/authSlice'
import { UserRole } from '@/shared/types'

/**
 * Custom hook for authentication state and actions
 * Provides convenient access to auth state and common auth operations
 */
export const useAuth = () => {
    const dispatch = useDispatch<AppDispatch>()
    const authState = useSelector((state: RootState) => state.auth)

    const handleLogout = useCallback(() => {
        dispatch(logout())
    }, [dispatch])

    const clearAuthError = useCallback(() => {
        dispatch(clearError())
    }, [dispatch])

    const hasRole = useCallback((requiredRole: UserRole): boolean => {
        if (!authState.user) return false

        const roleHierarchy: Record<UserRole, number> = {
            member: 1,
            manager: 2,
            admin: 3,
        }

        return roleHierarchy[authState.user.role] >= roleHierarchy[requiredRole]
    }, [authState.user])

    const isAdmin = useCallback(() => hasRole('admin'), [hasRole])
    const isManager = useCallback(() => hasRole('manager'), [hasRole])

    return {
        // State
        user: authState.user,
        token: authState.token,
        isAuthenticated: authState.isAuthenticated,
        isLoading: authState.isLoading,
        error: authState.error,

        // Actions
        logout: handleLogout,
        clearError: clearAuthError,

        // Role checks
        hasRole,
        isAdmin,
        isManager,
    }
}