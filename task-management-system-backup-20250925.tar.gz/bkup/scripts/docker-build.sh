#!/bin/bash

# Docker build script for Task Management System

set -e

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
IMAGE_NAME="task-management-system"
TAG=${1:-latest}
DOCKERFILE=${2:-Dockerfile}

echo -e "${BLUE}🐳 Building Docker image: ${IMAGE_NAME}:${TAG}${NC}"

# Check if Docker is available
if ! command -v docker >/dev/null 2>&1; then
    echo -e "${RED}❌ Error: Docker is not installed${NC}"
    exit 1
fi

# Check if Dockerfile exists
if [[ ! -f "$DOCKERFILE" ]]; then
    echo -e "${YELLOW}⚠️  Dockerfile not found. Creating basic Dockerfile...${NC}"
    cat > Dockerfile << 'EOF'
# Multi-stage build for Task Management System
FROM node:18-alpine AS builder

# Set working directory
WORKDIR /app

# Copy package files
COPY package*.json ./

# Install all dependencies (including dev dependencies for build)
RUN npm ci

# Copy source code
COPY . .

# Build the application
RUN npm run build

# Production stage
FROM node:18-alpine AS production

# Install dumb-init for proper signal handling
RUN apk add --no-cache dumb-init

# Create app user
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nodejs -u 1001

# Set working directory
WORKDIR /app

# Copy package files
COPY package*.json ./

# Install only production dependencies
RUN npm ci --only=production && npm cache clean --force

# Copy built application from builder stage
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/migrations ./migrations

# Copy environment template
COPY .env.example .env.example

# Change ownership to nodejs user
RUN chown -R nodejs:nodejs /app
USER nodejs

# Expose port
EXPOSE 3001

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD node -e "require('http').get('http://localhost:3001/api/health', (res) => { process.exit(res.statusCode === 200 ? 0 : 1) }).on('error', () => process.exit(1))"

# Start the application
CMD ["dumb-init", "node", "dist/server/index.js"]
EOF
fi

# Build the Docker image
echo -e "${YELLOW}🔨 Building Docker image...${NC}"
docker build -t "${IMAGE_NAME}:${TAG}" -f "$DOCKERFILE" .

# Tag as latest if not already
if [[ "$TAG" != "latest" ]]; then
    docker tag "${IMAGE_NAME}:${TAG}" "${IMAGE_NAME}:latest"
fi

echo -e "${GREEN}✅ Docker image built successfully: ${IMAGE_NAME}:${TAG}${NC}"

# Show image info
echo -e "${BLUE}📊 Image Information:${NC}"
docker images "${IMAGE_NAME}:${TAG}" --format "table {{.Repository}}\t{{.Tag}}\t{{.Size}}\t{{.CreatedAt}}"

echo -e "${YELLOW}📝 Usage:${NC}"
echo "  Run container: docker run -p 3001:3001 --env-file .env ${IMAGE_NAME}:${TAG}"
echo "  Run with compose: docker-compose up"