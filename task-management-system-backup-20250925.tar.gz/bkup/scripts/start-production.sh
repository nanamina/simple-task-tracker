#!/bin/bash

# Production startup script for Task Management System

set -e

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}🚀 Starting Task Management System in Production Mode${NC}"

# Check if build exists
if [[ ! -d "dist" ]]; then
    echo -e "${YELLOW}⚠️  Build directory not found. Running deployment...${NC}"
    ./scripts/deploy.sh production
fi

# Check if .env exists
if [[ ! -f "dist/.env" ]] && [[ ! -f ".env" ]]; then
    echo -e "${YELLOW}⚠️  Environment file not found. Please create .env file${NC}"
    exit 1
fi

# Navigate to build directory
cd dist

# Install production dependencies if needed
if [[ ! -d "node_modules" ]]; then
    echo -e "${YELLOW}📦 Installing production dependencies...${NC}"
    npm ci --only=production
fi

# Run database migrations
echo -e "${YELLOW}🗄️  Running database migrations...${NC}"
npm run migrate

# Start the server
echo -e "${GREEN}✅ Starting server...${NC}"
NODE_ENV=production node server/index.js