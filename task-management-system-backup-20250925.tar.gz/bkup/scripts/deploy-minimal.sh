#!/bin/bash

# Minimal deployment script without linting/testing

set -e

echo "🚀 Starting minimal deployment..."

# Install dependencies
echo "📦 Installing dependencies..."
npm ci --only=production

# Build application
echo "🔨 Building application..."
npm run build

# Check if build was successful
if [[ ! -d "dist" ]]; then
    echo "❌ Build failed - dist directory not found"
    exit 1
fi

echo "✅ Minimal deployment completed!"
echo "Start the server with: npm run start:prod"