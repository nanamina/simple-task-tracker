#!/usr/bin/env ts-node

/**
 * Migration CLI script
 * Usage: npm run migrate [command]
 * Commands: up, down, status, seed, clear
 */

import { migrationRunner } from '../src/server/config/migrate'
import { databaseSeeder } from '../src/server/config/seeds'
import { testConnection, closePool } from '../src/server/config/database'

async function main() {
    const command = process.argv[2] || 'up'

    try {
        // Test database connection first
        await testConnection()

        switch (command) {
            case 'up':
                console.log('Running migrations...')
                await migrationRunner.runMigrations()
                break

            case 'down':
                console.log('Rolling back last migration...')
                await migrationRunner.rollbackLastMigration()
                break

            case 'status':
                await migrationRunner.getMigrationStatus()
                break

            case 'seed':
                console.log('Seeding database...')
                await databaseSeeder.seedAll()
                break

            case 'seed:minimal':
                console.log('Seeding minimal data...')
                await databaseSeeder.seedMinimal()
                break

            case 'clear':
                console.log('Clearing all data...')
                await databaseSeeder.clearAllData()
                break

            case 'reset':
                console.log('Resetting database (clear + migrate + seed)...')
                await databaseSeeder.clearAllData()
                await migrationRunner.runMigrations()
                await databaseSeeder.seedAll()
                break

            default:
                console.log('Available commands:')
                console.log('  up          - Run pending migrations')
                console.log('  down        - Rollback last migration')
                console.log('  status      - Show migration status')
                console.log('  seed        - Seed database with sample data')
                console.log('  seed:minimal - Seed minimal test data')
                console.log('  clear       - Clear all data')
                console.log('  reset       - Clear, migrate, and seed')
                process.exit(1)
        }

        console.log('Operation completed successfully!')
    } catch (error) {
        console.error('Operation failed:', error)
        process.exit(1)
    } finally {
        await closePool()
    }
}

// Run the script
main()