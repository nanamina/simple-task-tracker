#!/bin/bash

# Deployment Verification Script
# Verifies that the deployed application is working correctly

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
BASE_URL=${1:-http://localhost:3001}
TIMEOUT=30

echo -e "${BLUE}🔍 Verifying deployment at: ${BASE_URL}${NC}"

# Function to make HTTP requests with timeout
make_request() {
    local url=$1
    local expected_status=${2:-200}
    local method=${3:-GET}
    
    echo -e "${YELLOW}Testing: ${method} ${url}${NC}"
    
    if command -v curl >/dev/null 2>&1; then
        local response=$(curl -s -w "%{http_code}" -m $TIMEOUT -X "$method" "$url" -o /tmp/response.txt)
        local status_code=$response
        local body=$(cat /tmp/response.txt)
        
        if [[ "$status_code" == "$expected_status" ]]; then
            echo -e "${GREEN}✅ ${method} ${url} - Status: ${status_code}${NC}"
            return 0
        else
            echo -e "${RED}❌ ${method} ${url} - Expected: ${expected_status}, Got: ${status_code}${NC}"
            echo "Response body: $body"
            return 1
        fi
    else
        echo -e "${RED}❌ curl not available for testing${NC}"
        return 1
    fi
}

# Function to test JSON response
test_json_response() {
    local url=$1
    local expected_field=$2
    
    echo -e "${YELLOW}Testing JSON response: ${url}${NC}"
    
    if command -v curl >/dev/null 2>&1 && command -v jq >/dev/null 2>&1; then
        local response=$(curl -s -m $TIMEOUT "$url")
        local field_value=$(echo "$response" | jq -r ".$expected_field")
        
        if [[ "$field_value" != "null" && "$field_value" != "" ]]; then
            echo -e "${GREEN}✅ JSON field '${expected_field}' found: ${field_value}${NC}"
            return 0
        else
            echo -e "${RED}❌ JSON field '${expected_field}' not found or empty${NC}"
            echo "Response: $response"
            return 1
        fi
    else
        echo -e "${YELLOW}⚠️  jq not available, skipping JSON validation${NC}"
        return 0
    fi
}

# Test counter
tests_passed=0
tests_failed=0

# Function to run test and track results
run_test() {
    if "$@"; then
        ((tests_passed++))
    else
        ((tests_failed++))
    fi
}

echo -e "${BLUE}🏥 Running Health Checks${NC}"

# Test basic health endpoint
run_test make_request "${BASE_URL}/api/health" 200

# Test database health endpoint
run_test make_request "${BASE_URL}/api/health/db" 200

# Test health endpoint JSON structure
run_test test_json_response "${BASE_URL}/api/health" "status"
run_test test_json_response "${BASE_URL}/api/health" "message"
run_test test_json_response "${BASE_URL}/api/health" "timestamp"

echo -e "${BLUE}🔐 Testing Authentication Endpoints${NC}"

# Test registration endpoint (should require data)
run_test make_request "${BASE_URL}/api/auth/register" 400 POST

# Test login endpoint (should require data)
run_test make_request "${BASE_URL}/api/auth/login" 400 POST

echo -e "${BLUE}🛡️  Testing Protected Endpoints${NC}"

# Test protected endpoints without authentication (should return 401)
run_test make_request "${BASE_URL}/api/tasks" 401
run_test make_request "${BASE_URL}/api/projects" 401
run_test make_request "${BASE_URL}/api/users/profile" 401

echo -e "${BLUE}🌐 Testing Static Assets (if production)${NC}"

# Test if this is a production deployment with static assets
if [[ "$BASE_URL" == *"localhost"* ]]; then
    echo -e "${YELLOW}⚠️  Localhost detected, skipping static asset tests${NC}"
else
    # Test static assets
    run_test make_request "${BASE_URL}/" 200
    run_test make_request "${BASE_URL}/assets/index.css" 200
fi

echo -e "${BLUE}🔍 Testing Error Handling${NC}"

# Test 404 handling
run_test make_request "${BASE_URL}/api/nonexistent" 404

# Test invalid JSON handling
if command -v curl >/dev/null 2>&1; then
    echo -e "${YELLOW}Testing invalid JSON handling${NC}"
    response=$(curl -s -w "%{http_code}" -m $TIMEOUT \
        -X POST "${BASE_URL}/api/auth/login" \
        -H "Content-Type: application/json" \
        -d "invalid json" \
        -o /tmp/response.txt)
    
    if [[ "$response" == "400" ]]; then
        echo -e "${GREEN}✅ Invalid JSON handling - Status: 400${NC}"
        ((tests_passed++))
    else
        echo -e "${RED}❌ Invalid JSON handling - Expected: 400, Got: ${response}${NC}"
        ((tests_failed++))
    fi
fi

echo -e "${BLUE}📊 Performance Tests${NC}"

# Test response time
if command -v curl >/dev/null 2>&1; then
    echo -e "${YELLOW}Testing response time${NC}"
    response_time=$(curl -s -w "%{time_total}" -o /dev/null "${BASE_URL}/api/health")
    
    # Convert to milliseconds for easier reading
    response_time_ms=$(echo "$response_time * 1000" | bc 2>/dev/null || echo "N/A")
    
    if [[ "$response_time_ms" != "N/A" ]]; then
        echo -e "${GREEN}✅ Response time: ${response_time_ms}ms${NC}"
        
        # Check if response time is reasonable (< 2 seconds)
        if (( $(echo "$response_time < 2.0" | bc -l 2>/dev/null || echo 0) )); then
            ((tests_passed++))
        else
            echo -e "${YELLOW}⚠️  Response time is high (>${response_time}s)${NC}"
            ((tests_failed++))
        fi
    else
        echo -e "${YELLOW}⚠️  Could not measure response time${NC}"
    fi
fi

# Summary
echo -e "${BLUE}📋 Verification Summary${NC}"
echo -e "Tests passed: ${GREEN}${tests_passed}${NC}"
echo -e "Tests failed: ${RED}${tests_failed}${NC}"
echo -e "Total tests: $((tests_passed + tests_failed))"

if [[ $tests_failed -eq 0 ]]; then
    echo -e "${GREEN}🎉 All verification tests passed!${NC}"
    echo -e "${GREEN}✅ Deployment appears to be working correctly${NC}"
    exit 0
else
    echo -e "${RED}❌ Some verification tests failed${NC}"
    echo -e "${RED}⚠️  Please check the deployment and fix any issues${NC}"
    exit 1
fi