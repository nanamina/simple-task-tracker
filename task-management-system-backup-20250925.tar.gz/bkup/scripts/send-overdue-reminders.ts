#!/usr/bin/env ts-node

/**
 * CLI script to send overdue task reminders
 * This script can be run manually or scheduled as a cron job
 * 
 * Usage:
 *   npm run send-overdue-reminders
 *   ts-node scripts/send-overdue-reminders.ts
 *   ts-node scripts/send-overdue-reminders.ts --days-overdue 1
 */

import * as dotenv from 'dotenv'
import { sendOverdueTaskReminders, areNotificationsEnabled } from '../src/server/services/notification-helper'

// Load environment variables
dotenv.config()

async function main() {
    try {
        console.log('Starting overdue task reminder process...')

        // Check if notifications are enabled
        if (!areNotificationsEnabled()) {
            console.log('Email notifications are not configured. Please set SMTP environment variables.')
            console.log('Required variables: SMTP_HOST, SMTP_USER, SMTP_PASSWORD')
            process.exit(1)
        }

        // Parse command line arguments
        const args = process.argv.slice(2)
        let daysOverdue = 0

        for (let i = 0; i < args.length; i++) {
            if (args[i] === '--days-overdue' && i + 1 < args.length) {
                daysOverdue = parseInt(args[i + 1])
                if (isNaN(daysOverdue) || daysOverdue < 0) {
                    console.error('Invalid days-overdue value. Must be a non-negative number.')
                    process.exit(1)
                }
                break
            }
        }

        console.log(`Checking for tasks overdue by ${daysOverdue} or more days...`)

        // Send overdue reminders
        await sendOverdueTaskReminders(daysOverdue)

        console.log('Overdue reminder process completed successfully.')
        process.exit(0)
    } catch (error) {
        console.error('Failed to send overdue reminders:', error)
        process.exit(1)
    }
}

// Handle process termination gracefully
process.on('SIGINT', () => {
    console.log('\nReceived SIGINT. Exiting gracefully...')
    process.exit(0)
})

process.on('SIGTERM', () => {
    console.log('\nReceived SIGTERM. Exiting gracefully...')
    process.exit(0)
})

// Run the main function
main().catch(error => {
    console.error('Unhandled error:', error)
    process.exit(1)
})