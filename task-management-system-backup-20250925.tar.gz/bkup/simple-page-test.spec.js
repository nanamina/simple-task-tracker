const { test, expect } = require('@playwright/test');

test('simple page load test', async ({ page }) => {
    // Navigate to the webpage
    await page.goto('https://example.com');

    // Check if the page loads correctly by verifying the title
    await expect(page).toHaveTitle(/Example Domain/);

    // Check if the main heading is visible
    const heading = page.locator('h1');
    await expect(heading).toBeVisible();
    await expect(heading).toContainText('Example Domain');

    // Verify the page URL is correct
    expect(page.url()).toBe('https://example.com/');

    // Take a screenshot for verification
    await page.screenshot({ path: 'test-screenshot.png' });

    console.log('✅ Page loaded successfully!');
});